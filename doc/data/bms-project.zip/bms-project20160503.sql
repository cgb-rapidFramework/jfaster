/*
Navicat MySQL Data Transfer

Source Server         : xampp_mysql
Source Server Version : 50621
Source Host           : localhost:3306
Source Database       : bms-project

Target Server Type    : MYSQL
Target Server Version : 50621
File Encoding         : 65001

Date: 2016-05-03 21:22:07
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for qrtz_blob_triggers
-- ----------------------------
DROP TABLE IF EXISTS `qrtz_blob_triggers`;
CREATE TABLE `qrtz_blob_triggers` (
  `SCHED_NAME` varchar(120) NOT NULL,
  `TRIGGER_NAME` varchar(200) NOT NULL,
  `TRIGGER_GROUP` varchar(200) NOT NULL,
  `BLOB_DATA` blob,
  PRIMARY KEY (`SCHED_NAME`,`TRIGGER_NAME`,`TRIGGER_GROUP`),
  CONSTRAINT `qrtz_blob_triggers_ibfk_1` FOREIGN KEY (`SCHED_NAME`, `TRIGGER_NAME`, `TRIGGER_GROUP`) REFERENCES `qrtz_triggers` (`SCHED_NAME`, `TRIGGER_NAME`, `TRIGGER_GROUP`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of qrtz_blob_triggers
-- ----------------------------

-- ----------------------------
-- Table structure for qrtz_calendars
-- ----------------------------
DROP TABLE IF EXISTS `qrtz_calendars`;
CREATE TABLE `qrtz_calendars` (
  `SCHED_NAME` varchar(120) NOT NULL,
  `CALENDAR_NAME` varchar(200) NOT NULL,
  `CALENDAR` blob NOT NULL,
  PRIMARY KEY (`SCHED_NAME`,`CALENDAR_NAME`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of qrtz_calendars
-- ----------------------------

-- ----------------------------
-- Table structure for qrtz_cron_triggers
-- ----------------------------
DROP TABLE IF EXISTS `qrtz_cron_triggers`;
CREATE TABLE `qrtz_cron_triggers` (
  `SCHED_NAME` varchar(120) NOT NULL,
  `TRIGGER_NAME` varchar(200) NOT NULL,
  `TRIGGER_GROUP` varchar(200) NOT NULL,
  `CRON_EXPRESSION` varchar(200) NOT NULL,
  `TIME_ZONE_ID` varchar(80) DEFAULT NULL,
  PRIMARY KEY (`SCHED_NAME`,`TRIGGER_NAME`,`TRIGGER_GROUP`),
  CONSTRAINT `qrtz_cron_triggers_ibfk_1` FOREIGN KEY (`SCHED_NAME`, `TRIGGER_NAME`, `TRIGGER_GROUP`) REFERENCES `qrtz_triggers` (`SCHED_NAME`, `TRIGGER_NAME`, `TRIGGER_GROUP`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of qrtz_cron_triggers
-- ----------------------------
INSERT INTO `qrtz_cron_triggers` VALUES ('schedulerFactoryBean', 'testjob1', 'default', '0/5 * * * * ?', 'Asia/Shanghai');
INSERT INTO `qrtz_cron_triggers` VALUES ('schedulerFactoryBean', 'testjob2', 'default', '0/5 * * * * ?', 'Asia/Shanghai');

-- ----------------------------
-- Table structure for qrtz_fired_triggers
-- ----------------------------
DROP TABLE IF EXISTS `qrtz_fired_triggers`;
CREATE TABLE `qrtz_fired_triggers` (
  `SCHED_NAME` varchar(120) NOT NULL,
  `ENTRY_ID` varchar(95) NOT NULL,
  `TRIGGER_NAME` varchar(200) NOT NULL,
  `TRIGGER_GROUP` varchar(200) NOT NULL,
  `INSTANCE_NAME` varchar(200) NOT NULL,
  `FIRED_TIME` bigint(13) NOT NULL,
  `SCHED_TIME` bigint(13) NOT NULL,
  `PRIORITY` int(11) NOT NULL,
  `STATE` varchar(16) NOT NULL,
  `JOB_NAME` varchar(200) DEFAULT NULL,
  `JOB_GROUP` varchar(200) DEFAULT NULL,
  `IS_NONCONCURRENT` varchar(1) DEFAULT NULL,
  `REQUESTS_RECOVERY` varchar(1) DEFAULT NULL,
  PRIMARY KEY (`SCHED_NAME`,`ENTRY_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of qrtz_fired_triggers
-- ----------------------------
INSERT INTO `qrtz_fired_triggers` VALUES ('schedulerFactoryBean', 'NON_CLUSTERED1462281297958', 'testjob1', 'default', 'NON_CLUSTERED', '1462281552554', '1462281555000', '5', 'ACQUIRED', null, null, '0', '0');

-- ----------------------------
-- Table structure for qrtz_job_details
-- ----------------------------
DROP TABLE IF EXISTS `qrtz_job_details`;
CREATE TABLE `qrtz_job_details` (
  `SCHED_NAME` varchar(120) NOT NULL,
  `JOB_NAME` varchar(200) NOT NULL,
  `JOB_GROUP` varchar(200) NOT NULL,
  `DESCRIPTION` varchar(250) DEFAULT NULL,
  `JOB_CLASS_NAME` varchar(250) NOT NULL,
  `IS_DURABLE` varchar(1) NOT NULL,
  `IS_NONCONCURRENT` varchar(1) NOT NULL,
  `IS_UPDATE_DATA` varchar(1) NOT NULL,
  `REQUESTS_RECOVERY` varchar(1) NOT NULL,
  `JOB_DATA` blob,
  PRIMARY KEY (`SCHED_NAME`,`JOB_NAME`,`JOB_GROUP`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of qrtz_job_details
-- ----------------------------
INSERT INTO `qrtz_job_details` VALUES ('schedulerFactoryBean', 'testjob1', 'default', null, 'org.jeecgframework.web.system.job.quartz.SyncJob', '0', '0', '0', '0', 0xACED0005737200156F72672E71756172747A2E4A6F62446174614D61709FB083E8BFA9B0CB020000787200266F72672E71756172747A2E7574696C732E537472696E674B65794469727479466C61674D61708208E8C3FBC55D280200015A0013616C6C6F77735472616E7369656E74446174617872001D6F72672E71756172747A2E7574696C732E4469727479466C61674D617013E62EAD28760ACE0200025A000564697274794C00036D617074000F4C6A6176612F7574696C2F4D61703B787001737200116A6176612E7574696C2E486173684D61700507DAC1C31660D103000246000A6C6F6164466163746F724900097468726573686F6C6478703F4000000000000C770800000010000000017400086A6F62506172616D737200336F72672E6A656563676672616D65776F726B2E7765622E73797374656D2E656E746974792E636F72652E4A6F62456E7469747992F2A7BE49F582A40200094C000A637265617465446174657400104C6A6176612F7574696C2F446174653B4C000B6465736372697074696F6E7400124C6A6176612F6C616E672F537472696E673B4C000A65787072657373696F6E71007E000A4C000567726F757071007E000A4C0002696471007E000A4C0006697353796E637400134C6A6176612F6C616E672F426F6F6C65616E3B4C00046E616D6571007E000A4C000673746174757371007E000A4C000A7570646174654461746571007E000978707074000AE6B58BE8AF956A6F623174000D302F35202A202A202A202A203F74000764656661756C74740000737200116A6176612E6C616E672E426F6F6C65616ECD207280D59CFAEE0200015A000576616C7565787001740008746573746A6F62317400064E4F524D414C707800);
INSERT INTO `qrtz_job_details` VALUES ('schedulerFactoryBean', 'testjob2', 'default', null, 'org.jeecgframework.web.system.job.quartz.AsyncJob', '0', '1', '0', '0', 0xACED0005737200156F72672E71756172747A2E4A6F62446174614D61709FB083E8BFA9B0CB020000787200266F72672E71756172747A2E7574696C732E537472696E674B65794469727479466C61674D61708208E8C3FBC55D280200015A0013616C6C6F77735472616E7369656E74446174617872001D6F72672E71756172747A2E7574696C732E4469727479466C61674D617013E62EAD28760ACE0200025A000564697274794C00036D617074000F4C6A6176612F7574696C2F4D61703B787001737200116A6176612E7574696C2E486173684D61700507DAC1C31660D103000246000A6C6F6164466163746F724900097468726573686F6C6478703F4000000000000C770800000010000000017400086A6F62506172616D737200336F72672E6A656563676672616D65776F726B2E7765622E73797374656D2E656E746974792E636F72652E4A6F62456E7469747992F2A7BE49F582A40200094C000A637265617465446174657400104C6A6176612F7574696C2F446174653B4C000B6465736372697074696F6E7400124C6A6176612F6C616E672F537472696E673B4C000A65787072657373696F6E71007E000A4C000567726F757071007E000A4C0002696471007E000A4C0006697353796E637400134C6A6176612F6C616E672F426F6F6C65616E3B4C00046E616D6571007E000A4C000673746174757371007E000A4C000A7570646174654461746571007E000978707074000AE6B58BE8AF956A6F623274000D302F35202A202A202A202A203F74000764656661756C74740000737200116A6176612E6C616E672E426F6F6C65616ECD207280D59CFAEE0200015A000576616C7565787000740008746573746A6F62327400064E4F524D414C707800);

-- ----------------------------
-- Table structure for qrtz_locks
-- ----------------------------
DROP TABLE IF EXISTS `qrtz_locks`;
CREATE TABLE `qrtz_locks` (
  `SCHED_NAME` varchar(120) NOT NULL,
  `LOCK_NAME` varchar(40) NOT NULL,
  PRIMARY KEY (`SCHED_NAME`,`LOCK_NAME`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of qrtz_locks
-- ----------------------------
INSERT INTO `qrtz_locks` VALUES ('schedulerFactoryBean', 'TRIGGER_ACCESS');

-- ----------------------------
-- Table structure for qrtz_paused_trigger_grps
-- ----------------------------
DROP TABLE IF EXISTS `qrtz_paused_trigger_grps`;
CREATE TABLE `qrtz_paused_trigger_grps` (
  `SCHED_NAME` varchar(120) NOT NULL,
  `TRIGGER_GROUP` varchar(200) NOT NULL,
  PRIMARY KEY (`SCHED_NAME`,`TRIGGER_GROUP`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of qrtz_paused_trigger_grps
-- ----------------------------

-- ----------------------------
-- Table structure for qrtz_scheduler_state
-- ----------------------------
DROP TABLE IF EXISTS `qrtz_scheduler_state`;
CREATE TABLE `qrtz_scheduler_state` (
  `SCHED_NAME` varchar(120) NOT NULL,
  `INSTANCE_NAME` varchar(200) NOT NULL,
  `LAST_CHECKIN_TIME` bigint(13) NOT NULL,
  `CHECKIN_INTERVAL` bigint(13) NOT NULL,
  PRIMARY KEY (`SCHED_NAME`,`INSTANCE_NAME`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of qrtz_scheduler_state
-- ----------------------------

-- ----------------------------
-- Table structure for qrtz_simple_triggers
-- ----------------------------
DROP TABLE IF EXISTS `qrtz_simple_triggers`;
CREATE TABLE `qrtz_simple_triggers` (
  `SCHED_NAME` varchar(120) NOT NULL,
  `TRIGGER_NAME` varchar(200) NOT NULL,
  `TRIGGER_GROUP` varchar(200) NOT NULL,
  `REPEAT_COUNT` bigint(7) NOT NULL,
  `REPEAT_INTERVAL` bigint(12) NOT NULL,
  `TIMES_TRIGGERED` bigint(10) NOT NULL,
  PRIMARY KEY (`SCHED_NAME`,`TRIGGER_NAME`,`TRIGGER_GROUP`),
  CONSTRAINT `qrtz_simple_triggers_ibfk_1` FOREIGN KEY (`SCHED_NAME`, `TRIGGER_NAME`, `TRIGGER_GROUP`) REFERENCES `qrtz_triggers` (`SCHED_NAME`, `TRIGGER_NAME`, `TRIGGER_GROUP`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of qrtz_simple_triggers
-- ----------------------------

-- ----------------------------
-- Table structure for qrtz_simprop_triggers
-- ----------------------------
DROP TABLE IF EXISTS `qrtz_simprop_triggers`;
CREATE TABLE `qrtz_simprop_triggers` (
  `SCHED_NAME` varchar(120) NOT NULL,
  `TRIGGER_NAME` varchar(200) NOT NULL,
  `TRIGGER_GROUP` varchar(200) NOT NULL,
  `STR_PROP_1` varchar(512) DEFAULT NULL,
  `STR_PROP_2` varchar(512) DEFAULT NULL,
  `STR_PROP_3` varchar(512) DEFAULT NULL,
  `INT_PROP_1` int(11) DEFAULT NULL,
  `INT_PROP_2` int(11) DEFAULT NULL,
  `LONG_PROP_1` bigint(20) DEFAULT NULL,
  `LONG_PROP_2` bigint(20) DEFAULT NULL,
  `DEC_PROP_1` decimal(13,4) DEFAULT NULL,
  `DEC_PROP_2` decimal(13,4) DEFAULT NULL,
  `BOOL_PROP_1` varchar(1) DEFAULT NULL,
  `BOOL_PROP_2` varchar(1) DEFAULT NULL,
  PRIMARY KEY (`SCHED_NAME`,`TRIGGER_NAME`,`TRIGGER_GROUP`),
  CONSTRAINT `qrtz_simprop_triggers_ibfk_1` FOREIGN KEY (`SCHED_NAME`, `TRIGGER_NAME`, `TRIGGER_GROUP`) REFERENCES `qrtz_triggers` (`SCHED_NAME`, `TRIGGER_NAME`, `TRIGGER_GROUP`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of qrtz_simprop_triggers
-- ----------------------------

-- ----------------------------
-- Table structure for qrtz_triggers
-- ----------------------------
DROP TABLE IF EXISTS `qrtz_triggers`;
CREATE TABLE `qrtz_triggers` (
  `SCHED_NAME` varchar(120) NOT NULL,
  `TRIGGER_NAME` varchar(200) NOT NULL,
  `TRIGGER_GROUP` varchar(200) NOT NULL,
  `JOB_NAME` varchar(200) NOT NULL,
  `JOB_GROUP` varchar(200) NOT NULL,
  `DESCRIPTION` varchar(250) DEFAULT NULL,
  `NEXT_FIRE_TIME` bigint(13) DEFAULT NULL,
  `PREV_FIRE_TIME` bigint(13) DEFAULT NULL,
  `PRIORITY` int(11) DEFAULT NULL,
  `TRIGGER_STATE` varchar(16) NOT NULL,
  `TRIGGER_TYPE` varchar(8) NOT NULL,
  `START_TIME` bigint(13) NOT NULL,
  `END_TIME` bigint(13) DEFAULT NULL,
  `CALENDAR_NAME` varchar(200) DEFAULT NULL,
  `MISFIRE_INSTR` smallint(2) DEFAULT NULL,
  `JOB_DATA` blob,
  PRIMARY KEY (`SCHED_NAME`,`TRIGGER_NAME`,`TRIGGER_GROUP`),
  KEY `SCHED_NAME` (`SCHED_NAME`,`JOB_NAME`,`JOB_GROUP`),
  CONSTRAINT `qrtz_triggers_ibfk_1` FOREIGN KEY (`SCHED_NAME`, `JOB_NAME`, `JOB_GROUP`) REFERENCES `qrtz_job_details` (`SCHED_NAME`, `JOB_NAME`, `JOB_GROUP`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of qrtz_triggers
-- ----------------------------
INSERT INTO `qrtz_triggers` VALUES ('schedulerFactoryBean', 'testjob1', 'default', 'testjob1', 'default', null, '1462281555000', '1462281550000', '5', 'ACQUIRED', 'CRON', '1462281478000', '0', null, '0', '');
INSERT INTO `qrtz_triggers` VALUES ('schedulerFactoryBean', 'testjob2', 'default', 'testjob2', 'default', null, '1462281555000', '1462281550000', '5', 'WAITING', 'CRON', '1462281528000', '0', null, '0', '');

-- ----------------------------
-- Table structure for t_s_base_user
-- ----------------------------
DROP TABLE IF EXISTS `t_s_base_user`;
CREATE TABLE `t_s_base_user` (
  `ID` varchar(32) NOT NULL,
  `activitiSync` smallint(6) DEFAULT NULL,
  `browser` varchar(20) DEFAULT NULL,
  `password` varchar(100) DEFAULT NULL,
  `realname` varchar(50) DEFAULT NULL,
  `signature` blob,
  `status` smallint(6) DEFAULT NULL,
  `userkey` varchar(200) DEFAULT NULL,
  `username` varchar(10) NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of t_s_base_user
-- ----------------------------
INSERT INTO `t_s_base_user` VALUES ('40280081544c16d601544c173c5a000e', '0', null, '97c07a884bf272b5', 'scott', null, '1', null, 'scott');
INSERT INTO `t_s_base_user` VALUES ('40280081544c16d601544c173c50000c', '1', null, 'c44b01947c9e6e3f', '管理员', null, '1', null, 'admin');

-- ----------------------------
-- Table structure for t_s_category
-- ----------------------------
DROP TABLE IF EXISTS `t_s_category`;
CREATE TABLE `t_s_category` (
  `ID` varchar(36) NOT NULL,
  `CODE` varchar(32) DEFAULT NULL,
  `CREATE_BY` varchar(50) DEFAULT NULL,
  `CREATE_DATE` datetime DEFAULT NULL,
  `CREATE_NAME` varchar(50) DEFAULT NULL,
  `NAME` varchar(32) DEFAULT NULL,
  `SYS_COMPANY_CODE` varchar(15) DEFAULT NULL,
  `SYS_ORG_CODE` varchar(15) DEFAULT NULL,
  `UPDATE_BY` varchar(50) DEFAULT NULL,
  `UPDATE_DATE` datetime DEFAULT NULL,
  `UPDATE_NAME` varchar(50) DEFAULT NULL,
  `ICON_ID` varchar(32) DEFAULT NULL,
  `PARENT_CODE` varchar(32) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  UNIQUE KEY `UK_oq59hcr5ovx37sknrss7ufqjn` (`CODE`) USING BTREE,
  KEY `FK_bpuenm5ncwcf5jtwpjd5pf2i7` (`ICON_ID`) USING BTREE,
  KEY `FK_j44c28b51a7y0uimjv13d8eak` (`PARENT_CODE`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of t_s_category
-- ----------------------------

-- ----------------------------
-- Table structure for t_s_config
-- ----------------------------
DROP TABLE IF EXISTS `t_s_config`;
CREATE TABLE `t_s_config` (
  `ID` varchar(32) NOT NULL,
  `code` varchar(100) DEFAULT NULL,
  `content` longtext,
  `name` varchar(100) NOT NULL,
  `note` longtext,
  `userid` varchar(32) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `FK_m3q8r50ror4fl7fjkvd82tqgn` (`userid`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of t_s_config
-- ----------------------------

-- ----------------------------
-- Table structure for t_s_data_rule
-- ----------------------------
DROP TABLE IF EXISTS `t_s_data_rule`;
CREATE TABLE `t_s_data_rule` (
  `ID` varchar(32) NOT NULL,
  `create_by` varchar(32) NOT NULL,
  `create_date` datetime NOT NULL,
  `create_name` varchar(32) NOT NULL,
  `rule_column` varchar(100) NOT NULL,
  `rule_conditions` varchar(100) NOT NULL,
  `rule_name` varchar(32) NOT NULL,
  `rule_value` varchar(100) NOT NULL,
  `update_by` varchar(32) NOT NULL,
  `update_date` datetime NOT NULL,
  `update_name` varchar(32) NOT NULL,
  `functionId` varchar(32) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `FK_28e11cxuu1le41015ymurtyjp` (`functionId`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of t_s_data_rule
-- ----------------------------

-- ----------------------------
-- Table structure for t_s_data_source
-- ----------------------------
DROP TABLE IF EXISTS `t_s_data_source`;
CREATE TABLE `t_s_data_source` (
  `ID` varchar(36) NOT NULL,
  `DB_KEY` varchar(50) NOT NULL,
  `DB_PASSWORD` varchar(50) DEFAULT NULL,
  `DB_TYPE` varchar(50) DEFAULT NULL,
  `DB_USER` varchar(50) NOT NULL,
  `DESCRIPTION` varchar(50) NOT NULL,
  `DRIVER_CLASS` varchar(50) NOT NULL,
  `URL` varchar(100) NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of t_s_data_source
-- ----------------------------

-- ----------------------------
-- Table structure for t_s_demo
-- ----------------------------
DROP TABLE IF EXISTS `t_s_demo`;
CREATE TABLE `t_s_demo` (
  `ID` varchar(32) NOT NULL,
  `democode` longtext,
  `demoorder` smallint(6) DEFAULT NULL,
  `demotitle` varchar(200) DEFAULT NULL,
  `demourl` varchar(200) DEFAULT NULL,
  `demopid` varchar(32) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `FK_fni8e3v88wcf2sahhlv57u4nm` (`demopid`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of t_s_demo
-- ----------------------------

-- ----------------------------
-- Table structure for t_s_depart
-- ----------------------------
DROP TABLE IF EXISTS `t_s_depart`;
CREATE TABLE `t_s_depart` (
  `ID` varchar(32) NOT NULL,
  `departname` varchar(100) NOT NULL,
  `description` longtext,
  `org_code` varchar(64) DEFAULT NULL,
  `org_type` varchar(1) DEFAULT NULL,
  `parentdepartid` varchar(32) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `FK_knnm3wb0bembwvm0il7tf6686` (`parentdepartid`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of t_s_depart
-- ----------------------------
INSERT INTO `t_s_depart` VALUES ('40280081544c16d601544c173c440009', '系统管理', '12', null, null, null);

-- ----------------------------
-- Table structure for t_s_fileno
-- ----------------------------
DROP TABLE IF EXISTS `t_s_fileno`;
CREATE TABLE `t_s_fileno` (
  `ID` varchar(32) NOT NULL,
  `filenobefore` varchar(32) DEFAULT NULL,
  `filenonum` int(11) DEFAULT NULL,
  `filenotype` varchar(32) DEFAULT NULL,
  `filenoYear` date DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of t_s_fileno
-- ----------------------------

-- ----------------------------
-- Table structure for t_s_function
-- ----------------------------
DROP TABLE IF EXISTS `t_s_function`;
CREATE TABLE `t_s_function` (
  `ID` varchar(32) NOT NULL,
  `functioniframe` smallint(6) DEFAULT NULL,
  `functionlevel` smallint(6) DEFAULT NULL,
  `functionname` varchar(50) NOT NULL,
  `functionorder` varchar(255) DEFAULT NULL,
  `functiontype` smallint(6) DEFAULT NULL,
  `functionurl` varchar(100) DEFAULT NULL,
  `parentfunctionid` varchar(32) DEFAULT NULL,
  `iconid` varchar(32) DEFAULT NULL,
  `desk_iconid` varchar(32) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `FK_brd7b3keorj8pmxcv8bpahnxp` (`parentfunctionid`) USING BTREE,
  KEY `FK_q5tqo3v4ltsp1pehdxd59rccx` (`iconid`) USING BTREE,
  KEY `FK_gbdacaoju6d5u53rp4jo4rbs9` (`desk_iconid`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of t_s_function
-- ----------------------------
INSERT INTO `t_s_function` VALUES ('40280081544c16d601544c173cb60036', null, '0', '系统管理', '5', null, '', null, '40280081544c16d601544c173c400006', '40280081544c16d601544c173cb40035');
INSERT INTO `t_s_function` VALUES ('40280081544c16d601544c173cba0038', null, '0', '统计查询', '3', null, '', null, '40280081544c16d601544c173c430008', '40280081544c16d601544c173cb90037');
INSERT INTO `t_s_function` VALUES ('40280081544c16d601544c173cbe003a', null, '0', '系统监控', '11', null, '', null, '40280081544c16d601544c173c190000', '40280081544c16d601544c173cbc0039');
INSERT INTO `t_s_function` VALUES ('40280081544c16d601544c173cc1003c', null, '1', '用户管理', '5', null, 'userController.do?user', '40280081544c16d601544c173cb60036', '40280081544c16d601544c173c190000', '40280081544c16d601544c173cc0003b');
INSERT INTO `t_s_function` VALUES ('40280081544c16d601544c173cc7003e', null, '1', '角色管理', '6', null, 'roleController.do?role', '40280081544c16d601544c173cb60036', '40280081544c16d601544c173c190000', '40280081544c16d601544c173cc6003d');
INSERT INTO `t_s_function` VALUES ('40280081544c16d601544c173ccc0040', null, '1', '菜单管理', '7', null, 'functionController.do?function', '40280081544c16d601544c173cb60036', '40280081544c16d601544c173c190000', '40280081544c16d601544c173cca003f');
INSERT INTO `t_s_function` VALUES ('40280081544c16d601544c173cd10042', null, '1', '数据字典', '6', null, 'systemController.do?typeGroupList', '40280081544c16d601544c173cb60036', '40280081544c16d601544c173c190000', '40280081544c16d601544c173ccf0041');
INSERT INTO `t_s_function` VALUES ('40280081544c16d601544c173cd30044', null, '1', '图标管理', '18', null, 'iconController.do?icon', '40280081544c16d601544c173cb60036', '40280081544c16d601544c173c190000', '40280081544c16d601544c173cd20043');
INSERT INTO `t_s_function` VALUES ('40280081544c16d601544c173cd80046', null, '1', '部门管理', '22', null, 'departController.do?depart', '40280081544c16d601544c173cb60036', '40280081544c16d601544c173c190000', '40280081544c16d601544c173cd70045');
INSERT INTO `t_s_function` VALUES ('40280081544c16d601544c173cdb0048', null, '1', '地域管理', '22', null, 'territoryController.do?territory', '40280081544c16d601544c173cb60036', '40280081544c16d601544c173c3c0002', '40280081544c16d601544c173cd90047');
INSERT INTO `t_s_function` VALUES ('40280081544c16d601544c173cdd004a', null, '1', '语言管理', '30', null, 'mutiLangController.do?mutiLang', '40280081544c16d601544c173cb60036', '40280081544c16d601544c173c3c0002', '40280081544c16d601544c173cdc0049');
INSERT INTO `t_s_function` VALUES ('40280081544c16d601544c173ce0004c', null, '1', '模版管理', '28', null, 'templateController.do?template', '40280081544c16d601544c173cb60036', '40280081544c16d601544c173c3c0002', '40280081544c16d601544c173cdf004b');
INSERT INTO `t_s_function` VALUES ('40280081544c16d601544c173ce2004e', null, '1', '用户分析', '17', null, 'logController.do?statisticTabs&isIframe', '40280081544c16d601544c173cba0038', '40280081544c16d601544c173c3c0002', '40280081544c16d601544c173ce1004d');
INSERT INTO `t_s_function` VALUES ('40280081544c16d601544c173ce50050', null, '1', '数据监控', '11', null, 'dataSourceController.do?goDruid&isIframe', '40280081544c16d601544c173cbe003a', '40280081544c16d601544c173c190000', '40280081544c16d601544c173ce4004f');
INSERT INTO `t_s_function` VALUES ('40280081544c16d601544c173cf20052', null, '1', '系统日志', '21', null, 'logController.do?log', '40280081544c16d601544c173cbe003a', '40280081544c16d601544c173c190000', '40280081544c16d601544c173cf00051');
INSERT INTO `t_s_function` VALUES ('40280081544c16d601544c173cf40054', null, '1', '定时任务', '21', null, 'timeTaskController.do?timeTask', '40280081544c16d601544c173cbe003a', '40280081544c16d601544c173c190000', '40280081544c16d601544c173cf30053');
INSERT INTO `t_s_function` VALUES ('40280081544c16d601544c173cf70056', null, '1', '报表示例', '21', null, 'reportDemoController.do?studentStatisticTabs&isIframe', '40280081544c16d601544c173cba0038', '40280081544c16d601544c173c3c0002', '40280081544c16d601544c173cf60055');
INSERT INTO `t_s_function` VALUES ('4028008154668b44015466fd39ec0002', null, '1', '任务管理', '20', '0', 'jobController.do?job', '40280081544c16d601544c173cb60036', '40280081544c16d601544c173c3d0003', '40280081544c16d601544c173cb40035');

-- ----------------------------
-- Table structure for t_s_icon
-- ----------------------------
DROP TABLE IF EXISTS `t_s_icon`;
CREATE TABLE `t_s_icon` (
  `ID` varchar(32) NOT NULL,
  `extend` varchar(255) DEFAULT NULL,
  `iconclas` varchar(200) DEFAULT NULL,
  `content` blob,
  `name` varchar(100) NOT NULL,
  `path` longtext,
  `type` smallint(6) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of t_s_icon
-- ----------------------------
INSERT INTO `t_s_icon` VALUES ('40280081544c16d601544c173c190000', 'png', 'default', null, '默认图', 'plug-in/accordion/images/default.png', '1');
INSERT INTO `t_s_icon` VALUES ('40280081544c16d601544c173c3a0001', 'png', 'back', null, '返回', 'plug-in/accordion/images/back.png', '1');
INSERT INTO `t_s_icon` VALUES ('40280081544c16d601544c173c3c0002', 'png', 'pie', null, '饼图', 'plug-in/accordion/images/pie.png', '1');
INSERT INTO `t_s_icon` VALUES ('40280081544c16d601544c173c3d0003', 'png', 'pictures', null, '图片', 'plug-in/accordion/images/pictures.png', '1');
INSERT INTO `t_s_icon` VALUES ('40280081544c16d601544c173c3e0004', 'png', 'pencil', null, '笔', 'plug-in/accordion/images/pencil.png', '1');
INSERT INTO `t_s_icon` VALUES ('40280081544c16d601544c173c3e0005', 'png', 'map', null, '地图', 'plug-in/accordion/images/map.png', '1');
INSERT INTO `t_s_icon` VALUES ('40280081544c16d601544c173c400006', 'png', 'group_add', null, '组', 'plug-in/accordion/images/group_add.png', '1');
INSERT INTO `t_s_icon` VALUES ('40280081544c16d601544c173c410007', 'png', 'calculator', null, '计算器', 'plug-in/accordion/images/calculator.png', '1');
INSERT INTO `t_s_icon` VALUES ('40280081544c16d601544c173c430008', 'png', 'folder', null, '文件夹', 'plug-in/accordion/images/folder.png', '1');
INSERT INTO `t_s_icon` VALUES ('40280081544c16d601544c173cb40035', 'png', 'deskIcon', null, '默认图标', 'plug-in/sliding/icon/default.png', '3');
INSERT INTO `t_s_icon` VALUES ('40280081544c16d601544c173cb90037', 'png', 'deskIcon', null, '默认图标', 'plug-in/sliding/icon/default.png', '3');
INSERT INTO `t_s_icon` VALUES ('40280081544c16d601544c173cbc0039', 'png', 'deskIcon', null, '默认图标', 'plug-in/sliding/icon/default.png', '3');
INSERT INTO `t_s_icon` VALUES ('40280081544c16d601544c173cc0003b', 'png', 'deskIcon', null, '用户管理', 'plug-in/sliding/icon/Finder.png', '3');
INSERT INTO `t_s_icon` VALUES ('40280081544c16d601544c173cc6003d', 'png', 'deskIcon', null, '角色管理', 'plug-in/sliding/icon/friendgroup.png', '3');
INSERT INTO `t_s_icon` VALUES ('40280081544c16d601544c173cca003f', 'png', 'deskIcon', null, '菜单管理', 'plug-in/sliding/icon/kaikai.png', '3');
INSERT INTO `t_s_icon` VALUES ('40280081544c16d601544c173ccf0041', 'png', 'deskIcon', null, '数据字典', 'plug-in/sliding/icon/friendnear.png', '3');
INSERT INTO `t_s_icon` VALUES ('40280081544c16d601544c173cd20043', 'png', 'deskIcon', null, '图标管理', 'plug-in/sliding/icon/kxjy.png', '3');
INSERT INTO `t_s_icon` VALUES ('40280081544c16d601544c173cd70045', 'png', 'deskIcon', null, '默认图标', 'plug-in/sliding/icon/default.png', '3');
INSERT INTO `t_s_icon` VALUES ('40280081544c16d601544c173cd90047', 'png', 'deskIcon', null, '默认图标', 'plug-in/sliding/icon/default.png', '3');
INSERT INTO `t_s_icon` VALUES ('40280081544c16d601544c173cdc0049', 'png', 'deskIcon', null, '默认图标', 'plug-in/sliding/icon/default.png', '3');
INSERT INTO `t_s_icon` VALUES ('40280081544c16d601544c173cdf004b', 'png', 'deskIcon', null, '默认图标', 'plug-in/sliding/icon/default.png', '3');
INSERT INTO `t_s_icon` VALUES ('40280081544c16d601544c173ce1004d', 'png', 'deskIcon', null, '用户分析', 'plug-in/sliding/icon/User.png', '3');
INSERT INTO `t_s_icon` VALUES ('40280081544c16d601544c173ce4004f', 'png', 'deskIcon', null, '数据监控', 'plug-in/sliding/icon/Super Disk.png', '3');
INSERT INTO `t_s_icon` VALUES ('40280081544c16d601544c173cf00051', 'png', 'deskIcon', null, '系统日志', 'plug-in/sliding/icon/fastsearch.png', '3');
INSERT INTO `t_s_icon` VALUES ('40280081544c16d601544c173cf30053', 'png', 'deskIcon', null, '定时任务', 'plug-in/sliding/icon/Utilities.png', '3');
INSERT INTO `t_s_icon` VALUES ('40280081544c16d601544c173cf60055', 'png', 'deskIcon', null, '默认图标', 'plug-in/sliding/icon/default.png', '3');

-- ----------------------------
-- Table structure for t_s_job
-- ----------------------------
DROP TABLE IF EXISTS `t_s_job`;
CREATE TABLE `t_s_job` (
  `id` varchar(32) NOT NULL COMMENT '任务id',
  `name` varchar(100) NOT NULL COMMENT '任务名称',
  `group` varchar(100) DEFAULT NULL COMMENT '任务分组',
  `status` varchar(50) DEFAULT NULL COMMENT '任务状态',
  `expression` varchar(200) NOT NULL COMMENT '任务运行时间表达式',
  `is_sync` char(1) NOT NULL COMMENT '是否异步',
  `description` varchar(500) DEFAULT NULL COMMENT '任务描述',
  `create_date` datetime DEFAULT NULL COMMENT '创建时间',
  `update_date` datetime DEFAULT NULL COMMENT '修改时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of t_s_job
-- ----------------------------
INSERT INTO `t_s_job` VALUES ('402800815476c1da015476c4a0060004', 'testjob1', 'default', 'NORMAL', '0/5 * * * * ?', 'Y', '测试job1', '2016-05-03 21:17:58', null);
INSERT INTO `t_s_job` VALUES ('402800815476c1da015476c566350007', 'testjob2', 'default', 'NORMAL', '0/5 * * * * ?', 'N', '测试job2', '2016-05-03 21:18:49', '2016-05-03 21:18:57');

-- ----------------------------
-- Table structure for t_s_log
-- ----------------------------
DROP TABLE IF EXISTS `t_s_log`;
CREATE TABLE `t_s_log` (
  `ID` varchar(32) NOT NULL,
  `broswer` varchar(100) DEFAULT NULL,
  `logcontent` longtext NOT NULL,
  `loglevel` smallint(6) DEFAULT NULL,
  `note` longtext,
  `operatetime` datetime NOT NULL,
  `operatetype` smallint(6) DEFAULT NULL,
  `userid` longtext,
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of t_s_log
-- ----------------------------
INSERT INTO `t_s_log` VALUES ('40280081544c16d601544c173caa0034', 'Chrome', '用户: admin登录成功', '1', '169.254.200.136', '2015-04-25 16:22:00', '1', null);
INSERT INTO `t_s_log` VALUES ('40280081544c16d601544c1793360082', 'Chrome', '用户: admin[系统管理]common.login.success', '1', '192.168.128.1', '2016-04-25 14:24:54', '1', '40280081544c16d601544c173c50000c');
INSERT INTO `t_s_log` VALUES ('402800815466815101546681d0df0000', 'Chrome', '用户: admin[系统管理]common.login.success', '1', '192.168.128.1', '2016-04-30 17:31:04', '1', '40280081544c16d601544c173c50000c');
INSERT INTO `t_s_log` VALUES ('4028008154668b440154668bef990000', 'Chrome', '用户: admin[系统管理]common.login.success', '1', '192.168.128.1', '2016-04-30 17:42:07', '1', '40280081544c16d601544c173c50000c');
INSERT INTO `t_s_log` VALUES ('4028008154668b44015466fb31b70001', 'Chrome', '用户: admin[系统管理]common.login.success', '1', '192.168.128.1', '2016-04-30 19:43:38', '1', '40280081544c16d601544c173c50000c');
INSERT INTO `t_s_log` VALUES ('4028008154668b44015466fd39fa0003', 'Chrome', '菜单 录入成功', '3', '192.168.128.1', '2016-04-30 19:45:52', '1', '40280081544c16d601544c173c50000c');
INSERT INTO `t_s_log` VALUES ('4028008154668b4401546704a0090005', 'Chrome', '用户admin已退出', '2', '192.168.128.1', '2016-04-30 19:53:57', '1', '40280081544c16d601544c173c50000c');
INSERT INTO `t_s_log` VALUES ('4028008154668b4401546704b4af0006', 'Chrome', '用户: admin[系统管理]common.login.success', '1', '192.168.128.1', '2016-04-30 19:54:02', '1', '40280081544c16d601544c173c50000c');
INSERT INTO `t_s_log` VALUES ('402800815467124d01546712bcf20000', 'Chrome', '用户: admin[系统管理]common.login.success', '1', '192.168.128.1', '2016-04-30 20:09:21', '1', '40280081544c16d601544c173c50000c');
INSERT INTO `t_s_log` VALUES ('4028008154671488015467153bab0000', 'Chrome', '用户: admin[系统管理]common.login.success', '1', '192.168.128.1', '2016-04-30 20:12:05', '1', '40280081544c16d601544c173c50000c');
INSERT INTO `t_s_log` VALUES ('40280081546714880154673b12670002', 'Chrome', '类型分组: 任务状态被添加成功', '3', '192.168.128.1', '2016-04-30 20:53:25', '1', '40280081544c16d601544c173c50000c');
INSERT INTO `t_s_log` VALUES ('40280081546714880154673c0dd40004', 'Chrome', '类型: NORMAL被添加成功', '3', '192.168.128.1', '2016-04-30 20:54:29', '1', '40280081544c16d601544c173c50000c');
INSERT INTO `t_s_log` VALUES ('40280081546714880154673db1aa0006', 'Chrome', '类型: None被添加成功', '3', '192.168.128.1', '2016-04-30 20:56:17', '1', '40280081544c16d601544c173c50000c');
INSERT INTO `t_s_log` VALUES ('40280081546714880154673df04d0008', 'Chrome', '类型: PAUSED被添加成功', '3', '192.168.128.1', '2016-04-30 20:56:33', '1', '40280081544c16d601544c173c50000c');
INSERT INTO `t_s_log` VALUES ('40280081546714880154673e96fc000a', 'Chrome', '类型: COMPLETE被添加成功', '3', '192.168.128.1', '2016-04-30 20:57:15', '1', '40280081544c16d601544c173c50000c');
INSERT INTO `t_s_log` VALUES ('40280081546714880154673edbe3000c', 'Chrome', '类型: BLOCKED被添加成功', '3', '192.168.128.1', '2016-04-30 20:57:33', '1', '40280081544c16d601544c173c50000c');
INSERT INTO `t_s_log` VALUES ('40280081546714880154673f1bbd000e', 'Chrome', '类型: ERROR被添加成功', '3', '192.168.128.1', '2016-04-30 20:57:49', '1', '40280081544c16d601544c173c50000c');
INSERT INTO `t_s_log` VALUES ('402800815467148801546747a889000f', 'Chrome', '类型: NORMAL被删除 成功', '4', '192.168.128.1', '2016-04-30 21:07:10', '1', '40280081544c16d601544c173c50000c');
INSERT INTO `t_s_log` VALUES ('402800815467148801546747afb30010', 'Chrome', '类型: None被删除 成功', '4', '192.168.128.1', '2016-04-30 21:07:11', '1', '40280081544c16d601544c173c50000c');
INSERT INTO `t_s_log` VALUES ('402800815467148801546747d8600011', 'Chrome', '类型: ERROR被删除 成功', '4', '192.168.128.1', '2016-04-30 21:07:22', '1', '40280081544c16d601544c173c50000c');
INSERT INTO `t_s_log` VALUES ('402800815467148801546747df4f0012', 'Chrome', '类型: BLOCKED被删除 成功', '4', '192.168.128.1', '2016-04-30 21:07:24', '1', '40280081544c16d601544c173c50000c');
INSERT INTO `t_s_log` VALUES ('402800815467148801546747e6c20013', 'Chrome', '类型: COMPLETE被删除 成功', '4', '192.168.128.1', '2016-04-30 21:07:26', '1', '40280081544c16d601544c173c50000c');
INSERT INTO `t_s_log` VALUES ('402800815467148801546747eebf0014', 'Chrome', '类型: PAUSED被删除 成功', '4', '192.168.128.1', '2016-04-30 21:07:28', '1', '40280081544c16d601544c173c50000c');
INSERT INTO `t_s_log` VALUES ('4028008154671488015467488d170016', 'Chrome', '类型: 正常状态被添加成功', '3', '192.168.128.1', '2016-04-30 21:08:08', '1', '40280081544c16d601544c173c50000c');
INSERT INTO `t_s_log` VALUES ('40280081546714880154674927040018', 'Chrome', '类型: 触发器完成且不会执行被添加成功', '3', '192.168.128.1', '2016-04-30 21:08:48', '1', '40280081544c16d601544c173c50000c');
INSERT INTO `t_s_log` VALUES ('4028008154671488015467498518001a', 'Chrome', '类型: 暂停状态被添加成功', '3', '192.168.128.1', '2016-04-30 21:09:12', '1', '40280081544c16d601544c173c50000c');
INSERT INTO `t_s_log` VALUES ('40280081546714880154674a6b1c001c', 'Chrome', '类型: 触发器完成且还在执行被添加成功', '3', '192.168.128.1', '2016-04-30 21:10:10', '1', '40280081544c16d601544c173c50000c');
INSERT INTO `t_s_log` VALUES ('40280081546714880154674ab0ae001e', 'Chrome', '类型: 线程阻塞状态被添加成功', '3', '192.168.128.1', '2016-04-30 21:10:28', '1', '40280081544c16d601544c173c50000c');
INSERT INTO `t_s_log` VALUES ('40280081546714880154674af2e50020', 'Chrome', '类型: 出现错误被添加成功', '3', '192.168.128.1', '2016-04-30 21:10:45', '1', '40280081544c16d601544c173c50000c');
INSERT INTO `t_s_log` VALUES ('40280081546714880154674ebc150022', 'Chrome', '类型分组: 任务是否异步被添加成功', '3', '192.168.128.1', '2016-04-30 21:14:53', '1', '40280081544c16d601544c173c50000c');
INSERT INTO `t_s_log` VALUES ('40280081546714880154674efb570024', 'Chrome', '类型: 否被添加成功', '3', '192.168.128.1', '2016-04-30 21:15:10', '1', '40280081544c16d601544c173c50000c');
INSERT INTO `t_s_log` VALUES ('40280081546714880154674f13bb0026', 'Chrome', '类型: 是被添加成功', '3', '192.168.128.1', '2016-04-30 21:15:16', '1', '40280081544c16d601544c173c50000c');
INSERT INTO `t_s_log` VALUES ('4028008154675d4d0154675dce530000', 'Chrome', '用户: admin[系统管理]common.login.success', '1', '192.168.128.1', '2016-04-30 21:31:21', '1', '40280081544c16d601544c173c50000c');
INSERT INTO `t_s_log` VALUES ('402800815467653701546765a8690000', 'Chrome', '用户: admin[系统管理]common.login.success', '1', '192.168.128.1', '2016-04-30 21:39:56', '1', '40280081544c16d601544c173c50000c');
INSERT INTO `t_s_log` VALUES ('402800815467694301546769fcdd0000', 'Chrome', '用户: admin[系统管理]common.login.success', '1', '192.168.128.1', '2016-04-30 21:44:39', '1', '40280081544c16d601544c173c50000c');
INSERT INTO `t_s_log` VALUES ('4028008154676fe0015467708ac30000', 'Chrome', '用户: admin[系统管理]common.login.success', '1', '192.168.128.1', '2016-04-30 21:51:49', '1', '40280081544c16d601544c173c50000c');
INSERT INTO `t_s_log` VALUES ('402800815467747601546775456b0000', 'Chrome', '用户: admin[系统管理]common.login.success', '1', '192.168.128.1', '2016-04-30 21:56:59', '1', '40280081544c16d601544c173c50000c');
INSERT INTO `t_s_log` VALUES ('40280081546781c301546782466b0000', 'Chrome', '用户: admin[系统管理]common.login.success', '1', '192.168.128.1', '2016-04-30 22:11:11', '1', '40280081544c16d601544c173c50000c');
INSERT INTO `t_s_log` VALUES ('402800815467887101546788c7580000', 'Chrome', '用户: admin[系统管理]common.login.success', '1', '192.168.128.1', '2016-04-30 22:18:17', '1', '40280081544c16d601544c173c50000c');
INSERT INTO `t_s_log` VALUES ('40280081546788710154678c29c70002', 'Chrome', '类型: 否被更新成功', '5', '192.168.128.1', '2016-04-30 22:21:59', '1', '40280081544c16d601544c173c50000c');
INSERT INTO `t_s_log` VALUES ('40280081546788710154678c3f200003', 'Chrome', '类型: 是被更新成功', '5', '192.168.128.1', '2016-04-30 22:22:05', '1', '40280081544c16d601544c173c50000c');
INSERT INTO `t_s_log` VALUES ('4028008154678ce40154678f79db0000', 'Chrome', '用户: admin[系统管理]common.login.success', '1', '192.168.128.1', '2016-04-30 22:25:36', '1', '40280081544c16d601544c173c50000c');
INSERT INTO `t_s_log` VALUES ('4028008154678ce401546791883d0001', 'Chrome', '类型: 否被更新成功', '5', '192.168.128.1', '2016-04-30 22:27:51', '1', '40280081544c16d601544c173c50000c');
INSERT INTO `t_s_log` VALUES ('4028008154678ce4015467919d870002', 'Chrome', '类型: 是被更新成功', '5', '192.168.128.1', '2016-04-30 22:27:56', '1', '40280081544c16d601544c173c50000c');
INSERT INTO `t_s_log` VALUES ('4028008154678ce401546791d3380003', 'Chrome', 'job更新成功', '5', '192.168.128.1', '2016-04-30 22:28:10', '1', '40280081544c16d601544c173c50000c');
INSERT INTO `t_s_log` VALUES ('4028008154678ce40154679307650005', 'Chrome', 'job更新成功', '5', '192.168.128.1', '2016-04-30 22:29:29', '1', '40280081544c16d601544c173c50000c');
INSERT INTO `t_s_log` VALUES ('4028008154678ce4015467b5c4360009', 'Chrome', 'job更新成功', '5', '192.168.128.1', '2016-04-30 23:07:26', '1', '40280081544c16d601544c173c50000c');
INSERT INTO `t_s_log` VALUES ('4028008154678ce4015467b742a6000a', 'Chrome', 'job更新成功', '5', '192.168.128.1', '2016-04-30 23:09:04', '1', '40280081544c16d601544c173c50000c');
INSERT INTO `t_s_log` VALUES ('402800815467bd0c015467bd89740000', 'Chrome', '用户: admin[系统管理]common.login.success', '1', '192.168.128.1', '2016-04-30 23:15:55', '1', '40280081544c16d601544c173c50000c');
INSERT INTO `t_s_log` VALUES ('402800815467bd0c015467c034f30003', 'Chrome', 'job添加成功', '3', '192.168.128.1', '2016-04-30 23:18:50', '1', '40280081544c16d601544c173c50000c');
INSERT INTO `t_s_log` VALUES ('402800815467ca62015467caad2a0000', 'Chrome', '用户: admin[系统管理]common.login.success', '1', '192.168.128.1', '2016-04-30 23:30:16', '1', '40280081544c16d601544c173c50000c');
INSERT INTO `t_s_log` VALUES ('402800815467cc2c015467cc7fdc0000', 'Chrome', '用户: admin[系统管理]common.login.success', '1', '192.168.128.1', '2016-04-30 23:32:15', '1', '40280081544c16d601544c173c50000c');
INSERT INTO `t_s_log` VALUES ('402800815467cc2c015467cca2000001', 'Chrome', 'job删除成功', '4', '192.168.128.1', '2016-04-30 23:32:24', '1', '40280081544c16d601544c173c50000c');
INSERT INTO `t_s_log` VALUES ('402800815467cc2c015467cd5be40003', 'Chrome', 'job添加成功', '3', '192.168.128.1', '2016-04-30 23:33:12', '1', '40280081544c16d601544c173c50000c');
INSERT INTO `t_s_log` VALUES ('402800815467cc2c015467cdf3460004', 'Chrome', 'job更新成功', '5', '192.168.128.1', '2016-04-30 23:33:51', '1', '40280081544c16d601544c173c50000c');
INSERT INTO `t_s_log` VALUES ('402800815469ce55015469ce99620000', 'Chrome', '用户: admin[系统管理]common.login.success', '1', '192.168.128.1', '2016-05-01 08:53:47', '1', '40280081544c16d601544c173c50000c');
INSERT INTO `t_s_log` VALUES ('402800815469ce55015469cedae30001', 'Chrome', 'job删除成功', '4', '192.168.128.1', '2016-05-01 08:54:04', '1', '40280081544c16d601544c173c50000c');
INSERT INTO `t_s_log` VALUES ('402800815469d1a9015469d2011a0000', 'Chrome', '用户: admin[系统管理]common.login.success', '1', '192.168.128.1', '2016-05-01 08:57:31', '1', '40280081544c16d601544c173c50000c');
INSERT INTO `t_s_log` VALUES ('402800815469d39c015469d414af0000', 'Chrome', '用户: admin[系统管理]common.login.success', '1', '192.168.128.1', '2016-05-01 08:59:47', '1', '40280081544c16d601544c173c50000c');
INSERT INTO `t_s_log` VALUES ('402800815469d39c015469d490610002', 'Chrome', 'job添加成功', '3', '192.168.128.1', '2016-05-01 09:00:18', '1', '40280081544c16d601544c173c50000c');
INSERT INTO `t_s_log` VALUES ('402800815469e4c7015469e53a560000', 'Chrome', '用户: admin[系统管理]common.login.success', '1', '192.168.128.1', '2016-05-01 09:18:30', '1', '40280081544c16d601544c173c50000c');
INSERT INTO `t_s_log` VALUES ('402800815469e4c7015469e59a340001', 'Chrome', 'job暂停成功', '4', '192.168.128.1', '2016-05-01 09:18:55', '1', '40280081544c16d601544c173c50000c');
INSERT INTO `t_s_log` VALUES ('40280081546c3e3801546c3ec66a0000', 'Chrome', '用户: admin[系统管理]common.login.success', '1', '192.168.128.1', '2016-05-01 20:15:33', '1', '40280081544c16d601544c173c50000c');
INSERT INTO `t_s_log` VALUES ('40280081546c4e0901546c4e76160000', 'Chrome', '用户: admin[系统管理]common.login.success', '1', '192.168.128.1', '2016-05-01 20:32:42', '1', '40280081544c16d601544c173c50000c');
INSERT INTO `t_s_log` VALUES ('40280081546c4e0901546c4f75a10001', 'Chrome', 'job恢复成功', '4', '192.168.128.1', '2016-05-01 20:33:47', '1', '40280081544c16d601544c173c50000c');
INSERT INTO `t_s_log` VALUES ('40280081546c4e0901546c5033ee0002', 'Chrome', 'job暂停成功', '4', '192.168.128.1', '2016-05-01 20:34:36', '1', '40280081544c16d601544c173c50000c');
INSERT INTO `t_s_log` VALUES ('40280081546c4e0901546c503f0b0003', 'Chrome', 'job暂停成功', '4', '192.168.128.1', '2016-05-01 20:34:38', '1', '40280081544c16d601544c173c50000c');
INSERT INTO `t_s_log` VALUES ('40280081546c4e0901546c5047cb0004', 'Chrome', 'job暂停成功', '4', '192.168.128.1', '2016-05-01 20:34:41', '1', '40280081544c16d601544c173c50000c');
INSERT INTO `t_s_log` VALUES ('40280081546c57c201546c5855d50000', 'Chrome', '用户: admin[系统管理]common.login.success', '1', '192.168.128.1', '2016-05-01 20:43:29', '1', '40280081544c16d601544c173c50000c');
INSERT INTO `t_s_log` VALUES ('40280081546c5a1101546c5a90e00000', 'Chrome', '用户: admin[系统管理]common.login.success', '1', '192.168.128.1', '2016-05-01 20:45:55', '1', '40280081544c16d601544c173c50000c');
INSERT INTO `t_s_log` VALUES ('40280081546c629201546c62f3060000', 'Chrome', '用户: admin[系统管理]common.login.success', '1', '192.168.128.1', '2016-05-01 20:55:04', '1', '40280081544c16d601544c173c50000c');
INSERT INTO `t_s_log` VALUES ('40280081546c685b01546c6902e10000', 'Chrome', '用户: admin[系统管理]common.login.success', '1', '192.168.128.1', '2016-05-01 21:01:41', '1', '40280081544c16d601544c173c50000c');
INSERT INTO `t_s_log` VALUES ('40280081546c6c9f01546c6d2bba0000', 'Chrome', '用户: admin[系统管理]common.login.success', '1', '192.168.128.1', '2016-05-01 21:06:14', '1', '40280081544c16d601544c173c50000c');
INSERT INTO `t_s_log` VALUES ('40280081546c6c9f01546c6d53280001', 'Chrome', 'job恢复成功', '4', '192.168.128.1', '2016-05-01 21:06:24', '1', '40280081544c16d601544c173c50000c');
INSERT INTO `t_s_log` VALUES ('40280081546c712901546c71e6af0000', 'Chrome', '用户: admin[系统管理]common.login.success', '1', '192.168.128.1', '2016-05-01 21:11:24', '1', '40280081544c16d601544c173c50000c');
INSERT INTO `t_s_log` VALUES ('40280081546c712901546c72079c0001', 'Chrome', 'job更新成功', '5', '192.168.128.1', '2016-05-01 21:11:33', '1', '40280081544c16d601544c173c50000c');
INSERT INTO `t_s_log` VALUES ('40280081546c712901546c7244a70002', 'Chrome', 'job更新成功', '5', '192.168.128.1', '2016-05-01 21:11:48', '1', '40280081544c16d601544c173c50000c');
INSERT INTO `t_s_log` VALUES ('40280081546c712901546c74a71e0003', 'Chrome', 'job更新成功', '5', '192.168.128.1', '2016-05-01 21:14:24', '1', '40280081544c16d601544c173c50000c');
INSERT INTO `t_s_log` VALUES ('40280081546c712901546c74ec2e0004', 'Chrome', 'job立即运行一次成功', '4', '192.168.128.1', '2016-05-01 21:14:42', '1', '40280081544c16d601544c173c50000c');
INSERT INTO `t_s_log` VALUES ('40280081546c915e01546c91f0170000', 'Chrome', '用户: admin[系统管理]common.login.success', '1', '192.168.128.1', '2016-05-01 21:46:24', '1', '40280081544c16d601544c173c50000c');
INSERT INTO `t_s_log` VALUES ('40280081546cb12601546cb247410000', 'Chrome', '用户: admin[系统管理]common.login.success', '1', '192.168.128.1', '2016-05-01 22:21:43', '1', '40280081544c16d601544c173c50000c');
INSERT INTO `t_s_log` VALUES ('40280081546fcf7301546fcff29a0000', 'Chrome', '用户: admin[系统管理]common.login.success', '1', '192.168.128.1', '2016-05-02 12:52:59', '1', '40280081544c16d601544c173c50000c');
INSERT INTO `t_s_log` VALUES ('4028008154705544015470559d610000', 'Chrome', '用户: admin[系统管理]common.login.success', '1', '192.168.128.1', '2016-05-02 15:18:59', '1', '40280081544c16d601544c173c50000c');
INSERT INTO `t_s_log` VALUES ('4028008154719cf2015471d223a30000', 'Chrome', '用户: admin[系统管理]common.login.success', '1', '192.168.128.1', '2016-05-02 22:14:37', '1', '40280081544c16d601544c173c50000c');
INSERT INTO `t_s_log` VALUES ('4028008154720992015472103bd90000', 'Chrome', '用户: admin[系统管理]common.login.success', '1', '192.168.128.1', '2016-05-02 23:22:27', '1', '40280081544c16d601544c173c50000c');
INSERT INTO `t_s_log` VALUES ('402800815475fe1a015475ff0a250000', 'Chrome', '用户: admin[系统管理]common.login.success', '1', '192.168.128.1', '2016-05-03 17:42:09', '1', '40280081544c16d601544c173c50000c');
INSERT INTO `t_s_log` VALUES ('402800815475fe1a01547641a9ff0001', 'Chrome', '用户: admin[系统管理]common.login.success', '1', '192.168.128.1', '2016-05-03 18:54:55', '1', '40280081544c16d601544c173c50000c');
INSERT INTO `t_s_log` VALUES ('4028008154764c2d0154764c945b0000', 'Chrome', '用户: admin[系统管理]common.login.success', '1', '192.168.128.1', '2016-05-03 19:06:50', '1', '40280081544c16d601544c173c50000c');
INSERT INTO `t_s_log` VALUES ('4028008154764f160154764f6fbb0000', 'Chrome', '用户: admin[系统管理]common.login.success', '1', '192.168.128.1', '2016-05-03 19:09:58', '1', '40280081544c16d601544c173c50000c');
INSERT INTO `t_s_log` VALUES ('402800815476555601547655f7530000', 'Chrome', '用户: admin[系统管理]common.login.success', '1', '192.168.128.1', '2016-05-03 19:17:06', '1', '40280081544c16d601544c173c50000c');
INSERT INTO `t_s_log` VALUES ('402800815476555601547669c1370001', 'Firefox', '用户: admin[系统管理]common.login.success', '1', '192.168.128.1', '2016-05-03 19:38:42', '1', '40280081544c16d601544c173c50000c');
INSERT INTO `t_s_log` VALUES ('40280081547655560154766a97d70002', 'MSIE 9.0', '用户: admin[系统管理]common.login.success', '1', '192.168.128.1', '2016-05-03 19:39:37', '1', '40280081544c16d601544c173c50000c');
INSERT INTO `t_s_log` VALUES ('40280081547693ab01547694d81a0000', 'Chrome', '用户: admin[系统管理]common.login.success', '1', '192.168.128.1', '2016-05-03 20:25:46', '1', '40280081544c16d601544c173c50000c');
INSERT INTO `t_s_log` VALUES ('40280081547693ab015476955d4e0001', 'Chrome', '用户admin已退出', '2', '192.168.128.1', '2016-05-03 20:26:20', '1', '40280081544c16d601544c173c50000c');
INSERT INTO `t_s_log` VALUES ('402800815476bc5b015476bcf1360000', 'Chrome', '用户: admin[系统管理]common.login.success', '1', '192.168.128.1', '2016-05-03 21:09:34', '1', '40280081544c16d601544c173c50000c');
INSERT INTO `t_s_log` VALUES ('402800815476bc5b015476bd548e0001', 'Chrome', 'job更新成功', '5', '192.168.128.1', '2016-05-03 21:10:00', '1', '40280081544c16d601544c173c50000c');
INSERT INTO `t_s_log` VALUES ('402800815476bc5b015476c123940002', 'Chrome', 'job恢复成功', '4', '192.168.128.1', '2016-05-03 21:14:09', '1', '40280081544c16d601544c173c50000c');
INSERT INTO `t_s_log` VALUES ('402800815476c1da015476c26b0a0000', 'Chrome', '用户: admin[系统管理]common.login.success', '1', '192.168.128.1', '2016-05-03 21:15:33', '1', '40280081544c16d601544c173c50000c');
INSERT INTO `t_s_log` VALUES ('402800815476c1da015476c378e10001', 'Chrome', 'job删除成功', '4', '192.168.128.1', '2016-05-03 21:16:42', '1', '40280081544c16d601544c173c50000c');
INSERT INTO `t_s_log` VALUES ('402800815476c1da015476c381780002', 'Chrome', 'job删除成功', '4', '192.168.128.1', '2016-05-03 21:16:44', '1', '40280081544c16d601544c173c50000c');
INSERT INTO `t_s_log` VALUES ('402800815476c1da015476c38a2e0003', 'Chrome', 'job删除成功', '4', '192.168.128.1', '2016-05-03 21:16:47', '1', '40280081544c16d601544c173c50000c');
INSERT INTO `t_s_log` VALUES ('402800815476c1da015476c4a00c0005', 'Chrome', 'job添加成功', '3', '192.168.128.1', '2016-05-03 21:17:58', '1', '40280081544c16d601544c173c50000c');
INSERT INTO `t_s_log` VALUES ('402800815476c1da015476c4e2470006', 'Chrome', 'job立即运行一次成功', '4', '192.168.128.1', '2016-05-03 21:18:15', '1', '40280081544c16d601544c173c50000c');
INSERT INTO `t_s_log` VALUES ('402800815476c1da015476c5663e0008', 'Chrome', 'job添加成功', '3', '192.168.128.1', '2016-05-03 21:18:48', '1', '40280081544c16d601544c173c50000c');

-- ----------------------------
-- Table structure for t_s_muti_lang
-- ----------------------------
DROP TABLE IF EXISTS `t_s_muti_lang`;
CREATE TABLE `t_s_muti_lang` (
  `id` varchar(32) NOT NULL COMMENT '主键',
  `lang_key` varchar(50) NOT NULL COMMENT '语言主键',
  `lang_context` varchar(500) NOT NULL COMMENT '内容',
  `lang_code` varchar(50) NOT NULL COMMENT '语言',
  `create_date` datetime DEFAULT NULL COMMENT '创建时间',
  `create_by` varchar(50) DEFAULT NULL COMMENT '创建人编号',
  `create_name` varchar(50) DEFAULT NULL COMMENT '创建人姓名',
  `update_date` datetime DEFAULT NULL COMMENT '更新日期',
  `update_by` varchar(50) DEFAULT NULL COMMENT '更新人编号',
  `update_name` varchar(50) DEFAULT NULL COMMENT '更新人姓名',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of t_s_muti_lang
-- ----------------------------
INSERT INTO `t_s_muti_lang` VALUES ('01ca201223b14e3e86c13904a9ae5ca2', 'common.password', '密码', 'zh-cn', '2014-07-03 18:39:43', '4028818d46f764fb0146f7661cb60052', 'admin', '2014-07-02 23:27:53', '4028818d46f764fb0146f7661cb60052', 'admin');
INSERT INTO `t_s_muti_lang` VALUES ('02916620f68b4845ba09773de6799706', 'please.select.department', 'Please select a department', 'en', '2014-07-04 18:39:43', '4028818d46f764fb0146f7661cb60052', 'admin', '2014-07-04 23:27:53', '4028818d46f764fb0146f7661cb60052', 'admin');
INSERT INTO `t_s_muti_lang` VALUES ('0ab1a1fddf14420fa0dbcbfb5d2e9e85', 'common.strong', 'Strong', 'en', '2014-07-04 18:39:43', '4028818d46f764fb0146f7661cb60052', 'admin', '2014-07-04 23:27:53', '4028818d46f764fb0146f7661cb60052', 'admin');
INSERT INTO `t_s_muti_lang` VALUES ('0bacd0fab1c84f03854435c1adab88c2', 'common.lock.user', '锁定用户', 'zh-cn', '2014-07-03 18:39:42', '4028818d46f764fb0146f7661cb60052', 'admin', '2014-07-02 23:27:53', '4028818d46f764fb0146f7661cb60052', 'admin');
INSERT INTO `t_s_muti_lang` VALUES ('11d18a9927e34873a813eade025b5c18', 'fill.realname', 'Fill in the real name', 'en', '2014-07-04 18:39:43', '4028818d46f764fb0146f7661cb60052', 'admin', '2014-07-04 23:27:53', '4028818d46f764fb0146f7661cb60052', 'admin');
INSERT INTO `t_s_muti_lang` VALUES ('121a68d32c6a419b800eb92431b20dd4', 'common.department', 'Org', 'en', '2014-07-03 18:39:42', '4028818d46f764fb0146f7661cb60052', 'admin', '2014-07-02 23:27:53', '4028818d46f764fb0146f7661cb60052', 'admin');
INSERT INTO `t_s_muti_lang` VALUES ('1e5963a78dcd4b1fa5f9d6d845f151be', 'common.department', '组织机构', 'zh-cn', '2014-07-03 18:39:42', '4028818d46f764fb0146f7661cb60052', 'admin', '2014-07-02 23:27:53', '4028818d46f764fb0146f7661cb60052', 'admin');
INSERT INTO `t_s_muti_lang` VALUES ('2075b6c641bc44b392638fed9a62cce9', 'password.rang6to18', '密码至少6个字符,最多18个字符', 'zh-cn', '2014-07-04 18:39:43', '4028818d46f764fb0146f7661cb60052', 'admin', '2014-07-04 23:27:53', '4028818d46f764fb0146f7661cb60052', 'admin');
INSERT INTO `t_s_muti_lang` VALUES ('27a06a8ed99f45438be00b7f1ca097f7', 'common.username', '用户名', 'zh-cn', '2014-07-03 18:39:42', '4028818d46f764fb0146f7661cb60052', 'admin', '2014-07-02 23:27:53', '4028818d46f764fb0146f7661cb60052', 'admin');
INSERT INTO `t_s_muti_lang` VALUES ('297e201046ff41480146ffbb62a30012', 'menu.manage', 'Menu Manage', 'en', '2014-07-04 12:56:50', '297e201046d3660a0146d36d7b7a01e7', 'admin', '2014-07-04 14:06:15', '297e201046d3660a0146d36d7b7a01e7', 'admin');
INSERT INTO `t_s_muti_lang` VALUES ('297e201046ff41480146ffbc59ac0014', 'menu.manage', '菜单管理', 'zh-cn', '2014-07-04 12:57:54', '297e201046d3660a0146d36d7b7a01e7', 'admin', '2014-07-04 14:06:26', '297e201046d3660a0146d36d7b7a01e7', 'admin');
INSERT INTO `t_s_muti_lang` VALUES ('297e201046ffc2ca0146ffc8cd320001', 'common.id', 'ID', 'en', '2014-07-04 13:11:28', '297e201046d3660a0146d36d7b7a01e7', 'admin', '2014-07-21 14:04:37', '8a8ab0b246dc81120146dc8181950052', 'admin');
INSERT INTO `t_s_muti_lang` VALUES ('297e201046ffc2ca0146ffc933dc0003', 'common.id', '编号', 'zh-cn', '2014-07-04 13:11:54', '297e201046d3660a0146d36d7b7a01e7', 'admin', '2014-07-04 13:11:54', '297e201046d3660a0146d36d7b7a01e7', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('297e201046ffc2ca0146ffc9b4bb0005', 'menu.name', 'Menu Name', 'en', '2014-07-04 13:12:27', '297e201046d3660a0146d36d7b7a01e7', 'admin', '2014-07-04 13:14:52', '297e201046d3660a0146d36d7b7a01e7', 'admin');
INSERT INTO `t_s_muti_lang` VALUES ('297e201046ffc2ca0146ffcd8f60000b', 'menu.name', '菜单名称', 'zh-cn', '2014-07-04 13:16:40', '297e201046d3660a0146d36d7b7a01e7', 'admin', '2014-07-04 13:16:40', '297e201046d3660a0146d36d7b7a01e7', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('297e201046ffc2ca0146ffcdc44b000d', 'common.icon', 'Icon', 'en', '2014-07-04 13:16:53', '297e201046d3660a0146d36d7b7a01e7', 'admin', '2014-07-04 13:16:53', '297e201046d3660a0146d36d7b7a01e7', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('297e201046ffc2ca0146ffcdf4a6000f', 'common.icon', '图标', 'zh-cn', '2014-07-04 13:17:06', '297e201046d3660a0146d36d7b7a01e7', 'admin', '2014-07-04 13:17:06', '297e201046d3660a0146d36d7b7a01e7', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('297e201046ffc2ca0146ffce76c70011', 'menu.url', 'Menu Url', 'en', '2014-07-04 13:17:39', '297e201046d3660a0146d36d7b7a01e7', 'admin', '2014-07-04 13:17:39', '297e201046d3660a0146d36d7b7a01e7', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('297e201046ffc2ca0146ffcea7d80013', 'menu.url', '菜单地址', 'zh-cn', '2014-07-04 13:17:51', '297e201046d3660a0146d36d7b7a01e7', 'admin', '2014-07-04 13:17:51', '297e201046d3660a0146d36d7b7a01e7', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('297e201046ffc2ca0146ffcf13090015', 'menu.order', 'Menu Order', 'en', '2014-07-04 13:18:19', '297e201046d3660a0146d36d7b7a01e7', 'admin', '2014-07-04 13:18:19', '297e201046d3660a0146d36d7b7a01e7', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('297e201046ffc2ca0146ffcf4b0a0017', 'menu.order', '菜单顺序', 'zh-cn', '2014-07-04 13:18:33', '297e201046d3660a0146d36d7b7a01e7', 'admin', '2014-07-04 13:18:33', '297e201046d3660a0146d36d7b7a01e7', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('297e201046ffc2ca0146ffd059670019', 'menu.add', 'Function Add', 'en', '2014-07-04 13:19:42', '297e201046d3660a0146d36d7b7a01e7', 'admin', '2014-07-04 13:22:11', '297e201046d3660a0146d36d7b7a01e7', 'admin');
INSERT INTO `t_s_muti_lang` VALUES ('297e201046ffc2ca0146ffd1cfeb001d', 'menu.edit', 'Menu Edit', 'en', '2014-07-04 13:21:18', '297e201046d3660a0146d36d7b7a01e7', 'admin', '2014-07-04 13:21:18', '297e201046d3660a0146d36d7b7a01e7', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('297e201046ffc2ca0146ffd20205001f', 'menu.edit', '菜单编辑', 'zh-cn', '2014-07-04 13:21:31', '297e201046d3660a0146d36d7b7a01e7', 'admin', '2014-07-04 13:21:31', '297e201046d3660a0146d36d7b7a01e7', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('297e201046ffc2ca0146ffe1a54f0023', 'menu.level', 'Menu Level', 'en', '2014-07-04 13:38:36', '297e201046d3660a0146d36d7b7a01e7', 'admin', '2014-07-04 13:38:36', '297e201046d3660a0146d36d7b7a01e7', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('297e201046ffc2ca0146ffe1e8530025', 'menu.level', '菜单等级', 'zh-cn', '2014-07-04 13:38:53', '297e201046d3660a0146d36d7b7a01e7', 'admin', '2014-07-04 13:38:53', '297e201046d3660a0146d36d7b7a01e7', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('297e201046ffc2ca0146ffe5e2860027', 'parent.function', 'Parent Function', 'en', '2014-07-04 13:43:14', '297e201046d3660a0146d36d7b7a01e7', 'admin', '2014-07-04 13:54:25', '297e201046d3660a0146d36d7b7a01e7', 'admin');
INSERT INTO `t_s_muti_lang` VALUES ('297e201046ffc2ca0146ffe6108b0029', 'parent.function', '父菜单', 'zh-cn', '2014-07-04 13:43:26', '297e201046d3660a0146d36d7b7a01e7', 'admin', '2014-07-04 13:54:37', '297e201046d3660a0146d36d7b7a01e7', 'admin');
INSERT INTO `t_s_muti_lang` VALUES ('297e201046ffc2ca0146ffe9ec39002b', 'main.function', 'Main Function', 'en', '2014-07-04 13:47:38', '297e201046d3660a0146d36d7b7a01e7', 'admin', '2014-07-04 13:54:52', '297e201046d3660a0146d36d7b7a01e7', 'admin');
INSERT INTO `t_s_muti_lang` VALUES ('297e201046ffc2ca0146ffea3970002d', 'main.function', '一级菜单', 'zh-cn', '2014-07-04 13:47:58', '297e201046d3660a0146d36d7b7a01e7', 'admin', '2014-07-04 13:55:06', '297e201046d3660a0146d36d7b7a01e7', 'admin');
INSERT INTO `t_s_muti_lang` VALUES ('297e201046ffc2ca0146ffea9f27002f', 'sub.function', 'Sub Function', 'en', '2014-07-04 13:48:24', '297e201046d3660a0146d36d7b7a01e7', 'admin', '2014-07-04 13:55:23', '297e201046d3660a0146d36d7b7a01e7', 'admin');
INSERT INTO `t_s_muti_lang` VALUES ('297e201046ffc2ca0146ffead7b80031', 'sub.function', '下级菜单', 'zh-cn', '2014-07-04 13:48:39', '297e201046d3660a0146d36d7b7a01e7', 'admin', '2014-07-04 13:55:34', '297e201046d3660a0146d36d7b7a01e7', 'admin');
INSERT INTO `t_s_muti_lang` VALUES ('297e201046ffc2ca0146ffebb2660033', 'desktop.icon', 'Desk Icon', 'en', '2014-07-04 13:49:35', '297e201046d3660a0146d36d7b7a01e7', 'admin', '2014-07-04 13:49:35', '297e201046d3660a0146d36d7b7a01e7', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('297e201046ffc2ca0146ffebdf940035', 'desktop.icon', '桌面图标', 'zh-cn', '2014-07-04 13:49:46', '297e201046d3660a0146d36d7b7a01e7', 'admin', '2014-07-04 13:49:46', '297e201046d3660a0146d36d7b7a01e7', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('297e201046fff2380146fffca39a0003', 'icon.list', 'Icon List', 'en', '2014-07-04 14:08:05', '297e201046d3660a0146d36d7b7a01e7', 'admin', '2014-07-04 15:20:31', '297e201046d3660a0146d36d7b7a01e7', 'admin');
INSERT INTO `t_s_muti_lang` VALUES ('297e201046fff2380146fffd42c40005', 'icon.list', '图标列表', 'zh-cn', '2014-07-04 14:08:46', '297e201046d3660a0146d36d7b7a01e7', 'admin', '2014-07-04 15:20:45', '297e201046d3660a0146d36d7b7a01e7', 'admin');
INSERT INTO `t_s_muti_lang` VALUES ('297e201046fff23801470001e905000b', 'common.icon.name', 'Icon Name', 'en', '2014-07-04 14:13:50', '297e201046d3660a0146d36d7b7a01e7', 'admin', '2014-07-04 14:13:50', '297e201046d3660a0146d36d7b7a01e7', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('297e201046fff23801470002280b000d', 'common.icon.name', '图标名称', 'zh-cn', '2014-07-04 14:14:07', '297e201046d3660a0146d36d7b7a01e7', 'admin', '2014-07-04 14:14:07', '297e201046d3660a0146d36d7b7a01e7', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('297e201046fff238014700030848000f', 'common.icon.style', 'Icon Style', 'en', '2014-07-04 14:15:04', '297e201046d3660a0146d36d7b7a01e7', 'admin', '2014-07-04 14:21:40', '297e201046d3660a0146d36d7b7a01e7', 'admin');
INSERT INTO `t_s_muti_lang` VALUES ('297e201046fff2380147000332810011', 'common.icon.style', '图标样式', 'zh-cn', '2014-07-04 14:15:15', '297e201046d3660a0146d36d7b7a01e7', 'admin', '2014-07-04 14:15:15', '297e201046d3660a0146d36d7b7a01e7', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('297e201046fff2380147000387440013', 'common.icon.type', 'Icon Type', 'en', '2014-07-04 14:15:37', '297e201046d3660a0146d36d7b7a01e7', 'admin', '2014-07-04 14:15:37', '297e201046d3660a0146d36d7b7a01e7', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('297e201046fff23801470003af940015', 'common.icon.type', '图标类型', 'zh-cn', '2014-07-04 14:15:47', '297e201046d3660a0146d36d7b7a01e7', 'admin', '2014-07-04 14:15:47', '297e201046d3660a0146d36d7b7a01e7', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('297e201046fff238014700054be10020', 'icon.add', 'Icon Add', 'en', '2014-07-04 14:17:32', '297e201046d3660a0146d36d7b7a01e7', 'admin', '2014-07-04 14:17:32', '297e201046d3660a0146d36d7b7a01e7', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('297e201046fff23801470005af9a0024', 'icon.edit', 'Icon Edit', 'en', '2014-07-04 14:17:58', '297e201046d3660a0146d36d7b7a01e7', 'admin', '2014-07-04 14:17:58', '297e201046d3660a0146d36d7b7a01e7', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('297e201046fff23801470005d3550026', 'icon.edit', '图标修改', 'zh-cn', '2014-07-04 14:18:07', '297e201046d3660a0146d36d7b7a01e7', 'admin', '2014-07-04 14:18:07', '297e201046d3660a0146d36d7b7a01e7', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('297e201046fff238014700063c220028', 'batch.generate.style', 'Batch Generate Style', 'en', '2014-07-04 14:18:34', '297e201046d3660a0146d36d7b7a01e7', 'admin', '2014-07-21 11:32:32', '8a8ab0b246dc81120146dc8181950052', 'admin');
INSERT INTO `t_s_muti_lang` VALUES ('297e201046fff238014700068560002a', 'batch.generate.style', '批量生成样式', 'zh-cn', '2014-07-04 14:18:53', '297e201046d3660a0146d36d7b7a01e7', 'admin', '2014-07-04 14:18:53', '297e201046d3660a0146d36d7b7a01e7', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('297e201046fff23801470015a389002e', 'common.department.list', 'Org List', 'en', '2014-07-04 14:35:23', '297e201046d3660a0146d36d7b7a01e7', 'admin', '2014-07-04 15:17:33', '297e201046d3660a0146d36d7b7a01e7', 'admin');
INSERT INTO `t_s_muti_lang` VALUES ('297e201046fff23801470015ff8f0030', 'common.department.list', '组织机构列表', 'zh-cn', '2014-07-04 14:35:47', '297e201046d3660a0146d36d7b7a01e7', 'admin', '2014-07-04 15:17:09', '297e201046d3660a0146d36d7b7a01e7', 'admin');
INSERT INTO `t_s_muti_lang` VALUES ('297e201046fff23801470016d58e0036', 'common.department.name', 'Org Name', 'en', '2014-07-04 14:36:42', '297e201046d3660a0146d36d7b7a01e7', 'admin', '2014-07-04 14:36:42', '297e201046d3660a0146d36d7b7a01e7', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('297e201046fff238014700172e590038', 'common.department.name', '组织机构名称', 'zh-cn', '2014-07-04 14:37:04', '297e201046d3660a0146d36d7b7a01e7', 'admin', '2014-07-04 14:37:04', '297e201046d3660a0146d36d7b7a01e7', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('297e201046fff23801470017a515003a', 'position.desc', 'Org Desc', 'en', '2014-07-04 14:37:35', '297e201046d3660a0146d36d7b7a01e7', 'admin', '2014-08-18 23:41:49', '8a8ab0b246dc81120146dc8181950052', 'admin');
INSERT INTO `t_s_muti_lang` VALUES ('297e201046fff23801470017d2fb003c', 'position.desc', '组织机构描述', 'zh-cn', '2014-07-04 14:37:47', '297e201046d3660a0146d36d7b7a01e7', 'admin', '2014-08-18 23:41:59', '8a8ab0b246dc81120146dc8181950052', 'admin');
INSERT INTO `t_s_muti_lang` VALUES ('297e201046fff238014700193e67003e', 'view.member', 'View Member', 'en', '2014-07-04 14:39:20', '297e201046d3660a0146d36d7b7a01e7', 'admin', '2014-07-04 14:39:20', '297e201046d3660a0146d36d7b7a01e7', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('297e201046fff2380147001963ef0040', 'view.member', '查看成员', 'zh-cn', '2014-07-04 14:39:29', '297e201046d3660a0146d36d7b7a01e7', 'admin', '2014-07-04 14:39:29', '297e201046d3660a0146d36d7b7a01e7', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('297e201046fff2380147001ab010004a', 'parent.depart', 'Parent Org', 'en', '2014-07-04 14:40:54', '297e201046d3660a0146d36d7b7a01e7', 'admin', '2014-07-04 14:40:54', '297e201046d3660a0146d36d7b7a01e7', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('297e201046fff2380147001ad6a7004c', 'parent.depart', '上级组织机构', 'zh-cn', '2014-07-04 14:41:04', '297e201046d3660a0146d36d7b7a01e7', 'admin', '2014-07-04 14:41:04', '297e201046d3660a0146d36d7b7a01e7', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('297e201046fff238014700256132004e', 'area.manage', 'Area Manage', 'en', '2014-07-04 14:52:35', '297e201046d3660a0146d36d7b7a01e7', 'admin', '2014-07-04 14:52:35', '297e201046d3660a0146d36d7b7a01e7', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('297e201046fff23801470025a7e70050', 'area.manage', '地域管理', 'zh-cn', '2014-07-04 14:52:53', '297e201046d3660a0146d36d7b7a01e7', 'admin', '2014-07-04 14:52:53', '297e201046d3660a0146d36d7b7a01e7', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('297e201046fff2380147002800990056', 'area.name', 'Area Name', 'en', '2014-07-04 14:55:27', '297e201046d3660a0146d36d7b7a01e7', 'admin', '2014-07-04 14:55:27', '297e201046d3660a0146d36d7b7a01e7', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('297e201046fff23801470028c0330058', 'area.name', '地域名称', 'zh-cn', '2014-07-04 14:56:16', '297e201046d3660a0146d36d7b7a01e7', 'admin', '2014-07-04 14:56:16', '297e201046d3660a0146d36d7b7a01e7', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('297e201046fff238014700295bd8005a', 'area.code', 'Area Code', 'en', '2014-07-04 14:56:56', '297e201046d3660a0146d36d7b7a01e7', 'admin', '2014-07-04 14:56:56', '297e201046d3660a0146d36d7b7a01e7', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('297e201046fff2380147002981ee005c', 'area.code', '地域编码', 'zh-cn', '2014-07-04 14:57:06', '297e201046d3660a0146d36d7b7a01e7', 'admin', '2014-07-04 14:57:06', '297e201046d3660a0146d36d7b7a01e7', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('297e201046fff23801470029c84d005e', 'display.order', 'Area Sort', 'en', '2014-07-04 14:57:24', '297e201046d3660a0146d36d7b7a01e7', 'admin', '2014-07-04 14:57:37', '297e201046d3660a0146d36d7b7a01e7', 'admin');
INSERT INTO `t_s_muti_lang` VALUES ('297e201046fff2380147002a3fa50061', 'display.order', '显示顺序', 'zh-cn', '2014-07-04 14:57:54', '297e201046d3660a0146d36d7b7a01e7', 'admin', '2014-07-04 14:58:02', '297e201046d3660a0146d36d7b7a01e7', 'admin');
INSERT INTO `t_s_muti_lang` VALUES ('297e201046fff2380147002a93ba0064', 'area.add.param', 'Area Add', 'en', '2014-07-04 14:58:16', '297e201046d3660a0146d36d7b7a01e7', 'admin', '2014-07-04 15:12:56', '297e201046d3660a0146d36d7b7a01e7', 'admin');
INSERT INTO `t_s_muti_lang` VALUES ('297e201046fff2380147002c144c006c', 'area.level', 'Area Level', 'en', '2014-07-04 14:59:54', '297e201046d3660a0146d36d7b7a01e7', 'admin', '2014-07-04 14:59:54', '297e201046d3660a0146d36d7b7a01e7', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('297e201046fff2380147002c3711006e', 'area.level', '地域等级', 'zh-cn', '2014-07-04 15:00:03', '297e201046d3660a0146d36d7b7a01e7', 'admin', '2014-07-04 15:00:03', '297e201046d3660a0146d36d7b7a01e7', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('297e201046fff2380147002ce8a70070', 'parent.area', 'Parent Area', 'en', '2014-07-04 15:00:48', '297e201046d3660a0146d36d7b7a01e7', 'admin', '2014-07-04 15:00:48', '297e201046d3660a0146d36d7b7a01e7', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('297e201046fff2380147002d42990072', 'parent.area', '父地域', 'zh-cn', '2014-07-04 15:01:11', '297e201046d3660a0146d36d7b7a01e7', 'admin', '2014-07-04 15:01:11', '297e201046d3660a0146d36d7b7a01e7', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('297e20104701c151014701d4ac920001', 'system.icon', 'System Icon', 'en', '2014-07-04 22:43:40', '297e201046d3660a0146d36d7b7a01e7', 'admin', '2014-07-04 22:43:40', '297e201046d3660a0146d36d7b7a01e7', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('297e20104701c151014701d4e2990003', 'system.icon', '系统图标', 'zh-cn', '2014-07-04 22:43:54', '297e201046d3660a0146d36d7b7a01e7', 'admin', '2014-07-04 22:43:54', '297e201046d3660a0146d36d7b7a01e7', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('297e20104701c151014701d53b200005', 'menu.icon', 'Menu Icon', 'en', '2014-07-04 22:44:17', '297e201046d3660a0146d36d7b7a01e7', 'admin', '2014-07-04 22:44:17', '297e201046d3660a0146d36d7b7a01e7', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('297e20104701c151014701d5c6cc0007', 'menu.icon', '菜单图标', 'zh-cn', '2014-07-04 22:44:53', '297e201046d3660a0146d36d7b7a01e7', 'admin', '2014-07-04 22:44:53', '297e201046d3660a0146d36d7b7a01e7', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('297e20104701c151014701dda832000d', 'main.area', 'Main Level', 'en', '2014-07-04 22:53:29', '297e201046d3660a0146d36d7b7a01e7', 'admin', '2014-07-04 22:53:29', '297e201046d3660a0146d36d7b7a01e7', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('297e20104701c151014701ddf718000f', 'main.area', '一级地域', 'zh-cn', '2014-07-04 22:53:49', '297e201046d3660a0146d36d7b7a01e7', 'admin', '2014-07-04 22:58:41', '297e201046d3660a0146d36d7b7a01e7', 'admin');
INSERT INTO `t_s_muti_lang` VALUES ('297e20104701c151014701de50dd0011', 'sub.area', 'Sub Level', 'en', '2014-07-04 22:54:12', '297e201046d3660a0146d36d7b7a01e7', 'admin', '2014-07-04 22:55:00', '297e201046d3660a0146d36d7b7a01e7', 'admin');
INSERT INTO `t_s_muti_lang` VALUES ('297e20104701c151014701dece660013', 'sub.area', '下级地域', 'zh-cn', '2014-07-04 22:54:44', '297e201046d3660a0146d36d7b7a01e7', 'admin', '2014-07-04 22:54:44', '297e201046d3660a0146d36d7b7a01e7', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('297e20104701ecd4014701f3a69c0001', 'member.list', 'Member List', 'en', '2014-07-04 23:17:30', '297e201046d3660a0146d36d7b7a01e7', 'admin', '2014-07-04 23:17:30', '297e201046d3660a0146d36d7b7a01e7', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('297e20104701ecd4014701f3dcfb0003', 'member.list', '成员列表', 'zh-cn', '2014-07-04 23:17:44', '297e201046d3660a0146d36d7b7a01e7', 'admin', '2014-07-04 23:17:44', '297e201046d3660a0146d36d7b7a01e7', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('297e2010477674e7014776e5ffae0005', 'iconname.rang2to10', '名称范围2~10位字符,且不为空', 'zh-cn', '2014-07-27 16:18:12', '8a8ab0b246dc81120146dc8181950052', 'admin', null, null, null);
INSERT INTO `t_s_muti_lang` VALUES ('297e2010477674e7014776e6eecd0007', 'iconname.rang2to10', 'Icon name should be 2-10 characters and should not empty', 'en', '2014-07-27 16:19:11', '8a8ab0b246dc81120146dc8181950052', 'admin', null, null, null);
INSERT INTO `t_s_muti_lang` VALUES ('297e20104777447a01477784810a000f', 'operate.name', '操作名称', 'zh-cn', '2014-07-27 19:11:18', '8a8ab0b246dc81120146dc8181950052', 'admin', '2014-07-27 19:17:45', '8a8ab0b246dc81120146dc8181950052', 'admin');
INSERT INTO `t_s_muti_lang` VALUES ('297e20104777447a0147778a170d0011', 'operate.name', 'Operate Name', 'en', '2014-07-27 19:17:24', '8a8ab0b246dc81120146dc8181950052', 'admin', null, null, null);
INSERT INTO `t_s_muti_lang` VALUES ('297e20104777447a01477791affe0014', 'operate.manage', 'Operate Manage', 'en', '2014-07-27 19:25:42', '8a8ab0b246dc81120146dc8181950052', 'admin', null, null, null);
INSERT INTO `t_s_muti_lang` VALUES ('297e20104777447a01477791eea00016', 'operate.manage', '操作管理', 'zh-cn', '2014-07-27 19:25:58', '8a8ab0b246dc81120146dc8181950052', 'admin', null, null, null);
INSERT INTO `t_s_muti_lang` VALUES ('297e20104777447a01477796ccde0018', 'operatename.rang2to20', '操作名称范围2~20位字符', 'zh-cn', '2014-07-27 19:31:17', '8a8ab0b246dc81120146dc8181950052', 'admin', null, null, null);
INSERT INTO `t_s_muti_lang` VALUES ('297e20104777447a014777979ab6001a', 'operatename.rang2to20', 'Operate name should be 2-20 characters', 'en', '2014-07-27 19:32:10', '8a8ab0b246dc81120146dc8181950052', 'admin', null, null, null);
INSERT INTO `t_s_muti_lang` VALUES ('297e20104777447a014777991ef9001c', 'operatestatus.number', '必须为数字', 'zh-cn', '2014-07-27 19:33:49', '8a8ab0b246dc81120146dc8181950052', 'admin', null, null, null);
INSERT INTO `t_s_muti_lang` VALUES ('297e20104777447a0147779a0f71001e', 'operatestatus.number', 'Must be numeric', 'en', '2014-07-27 19:34:50', '8a8ab0b246dc81120146dc8181950052', 'admin', null, null, null);
INSERT INTO `t_s_muti_lang` VALUES ('297e201047779c5b014777a9190b0007', 'common.default.icon', 'default', 'en', '2014-07-27 19:51:16', '8a8ab0b246dc81120146dc8181950052', 'admin', null, null, null);
INSERT INTO `t_s_muti_lang` VALUES ('297e201047779c5b014777a974ca0009', 'common.default.icon', '默认', 'zh-cn', '2014-07-27 19:51:39', '8a8ab0b246dc81120146dc8181950052', 'admin', null, null, null);
INSERT INTO `t_s_muti_lang` VALUES ('297e201047779c5b014777a9cbc3000b', 'common.back', 'back', 'en', '2014-07-27 19:52:02', '8a8ab0b246dc81120146dc8181950052', 'admin', null, null, null);
INSERT INTO `t_s_muti_lang` VALUES ('297e201047779c5b014777a9f433000d', 'common.back', '返回', 'zh-cn', '2014-07-27 19:52:12', '8a8ab0b246dc81120146dc8181950052', 'admin', null, null, null);
INSERT INTO `t_s_muti_lang` VALUES ('297e201047779c5b014777ae465e000f', 'common.smallpie.icon', 'smallpie', 'en', '2014-07-27 19:56:55', '8a8ab0b246dc81120146dc8181950052', 'admin', null, null, null);
INSERT INTO `t_s_muti_lang` VALUES ('297e201047779c5b014777aeb70c0011', 'common.smallpie.icon', '小饼状图', 'zh-cn', '2014-07-27 19:57:24', '8a8ab0b246dc81120146dc8181950052', 'admin', null, null, null);
INSERT INTO `t_s_muti_lang` VALUES ('297e201047779c5b014777af2a970013', 'common.picture', '图片', 'zh-cn', '2014-07-27 19:57:54', '8a8ab0b246dc81120146dc8181950052', 'admin', '2014-07-27 19:58:19', '8a8ab0b246dc81120146dc8181950052', 'admin');
INSERT INTO `t_s_muti_lang` VALUES ('297e201047779c5b014777af611a0015', 'common.picture', 'pictures', 'en', '2014-07-27 19:58:08', '8a8ab0b246dc81120146dc8181950052', 'admin', null, null, null);
INSERT INTO `t_s_muti_lang` VALUES ('297e201047779c5b014777afea2c0018', 'common.pencil.icon', '笔', 'zh-cn', '2014-07-27 19:58:43', '8a8ab0b246dc81120146dc8181950052', 'admin', null, null, null);
INSERT INTO `t_s_muti_lang` VALUES ('297e201047779c5b014777b01f4a001a', 'common.pencil.icon', 'pencil', 'en', '2014-07-27 19:58:56', '8a8ab0b246dc81120146dc8181950052', 'admin', null, null, null);
INSERT INTO `t_s_muti_lang` VALUES ('297e201047779c5b014777b210ae001c', 'common.smallmap', '小地图', 'zh-cn', '2014-07-27 20:01:04', '8a8ab0b246dc81120146dc8181950052', 'admin', null, null, null);
INSERT INTO `t_s_muti_lang` VALUES ('297e201047779c5b014777b2638d001e', 'common.smallmap', 'smallmap', 'en', '2014-07-27 20:01:25', '8a8ab0b246dc81120146dc8181950052', 'admin', null, null, null);
INSERT INTO `t_s_muti_lang` VALUES ('297e201047779c5b014777b2d38b0020', 'common.group', '组', 'zh-cn', '2014-07-27 20:01:54', '8a8ab0b246dc81120146dc8181950052', 'admin', null, null, null);
INSERT INTO `t_s_muti_lang` VALUES ('297e201047779c5b014777b3010a0022', 'common.group', 'group', 'en', '2014-07-27 20:02:05', '8a8ab0b246dc81120146dc8181950052', 'admin', null, null, null);
INSERT INTO `t_s_muti_lang` VALUES ('297e201047779c5b014777b361fa0024', 'common.calculator', '计算器', 'zh-cn', '2014-07-27 20:02:30', '8a8ab0b246dc81120146dc8181950052', 'admin', null, null, null);
INSERT INTO `t_s_muti_lang` VALUES ('297e201047779c5b014777b39c390026', 'common.calculator', 'calculator', 'en', '2014-07-27 20:02:45', '8a8ab0b246dc81120146dc8181950052', 'admin', null, null, null);
INSERT INTO `t_s_muti_lang` VALUES ('297e201047779c5b014777b3ed9e0028', 'common.folder', '文件夹', 'zh-cn', '2014-07-27 20:03:06', '8a8ab0b246dc81120146dc8181950052', 'admin', null, null, null);
INSERT INTO `t_s_muti_lang` VALUES ('297e201047779c5b014777b440fd002a', 'common.folder', 'folder', 'en', '2014-07-27 20:03:27', '8a8ab0b246dc81120146dc8181950052', 'admin', null, null, null);
INSERT INTO `t_s_muti_lang` VALUES ('297e20104777c827014777f13d7f0002', 'common.delete.fail.param', '{0}删除失败{1}', 'zh-cn', '2014-07-27 21:10:04', '8a8ab0b246dc81120146dc8181950052', 'admin', null, null, null);
INSERT INTO `t_s_muti_lang` VALUES ('297e20104777c827014777f282f60004', 'common.delete.fail.param', '{0} delete fail{1}', 'en', '2014-07-27 21:11:27', '8a8ab0b246dc81120146dc8181950052', 'admin', null, null, null);
INSERT INTO `t_s_muti_lang` VALUES ('297e20104777c827014777f52cd10006', 'common.icon.isusing', '！图标正在使用，不允许删除。', 'zh-cn', '2014-07-27 21:14:22', '8a8ab0b246dc81120146dc8181950052', 'admin', null, null, null);
INSERT INTO `t_s_muti_lang` VALUES ('297e20104777c827014777f8c27e0008', 'common.icon.isusing', ', Icon is using, can not be deleted.', 'en', '2014-07-27 21:18:17', '8a8ab0b246dc81120146dc8181950052', 'admin', '2014-07-27 21:27:54', '8a8ab0b246dc81120146dc8181950052', 'admin');
INSERT INTO `t_s_muti_lang` VALUES ('297e201047781c8e014778273b160007', 'departmentname.rang3to10', '机构名称在3~10位字符', 'zh-cn', '2014-07-27 22:09:02', '8a8ab0b246dc81120146dc8181950052', 'admin', null, null, null);
INSERT INTO `t_s_muti_lang` VALUES ('297e201047781c8e0147782885e90009', 'departmentname.rang3to10', 'Department name should be 3-10 characters', 'en', '2014-07-27 22:10:27', '8a8ab0b246dc81120146dc8181950052', 'admin', null, null, null);
INSERT INTO `t_s_muti_lang` VALUES ('297e201047781c8e0147782a1443000b', 'areaname.rang2to15', '地域名称范围2~15位字符,且不为空', 'zh-cn', '2014-07-27 22:12:09', '8a8ab0b246dc81120146dc8181950052', 'admin', null, null, null);
INSERT INTO `t_s_muti_lang` VALUES ('297e201047781c8e0147782a6615000d', 'areaname.rang2to15', 'Area name should be 2-15 characters and should not empty', 'en', '2014-07-27 22:12:30', '8a8ab0b246dc81120146dc8181950052', 'admin', null, null, null);
INSERT INTO `t_s_muti_lang` VALUES ('297e201047e73d0f0147e7ffd4540028', 'common.org.code', '机构编码', 'zh-cn', '2014-08-18 15:23:28', '8a8ab0b246dc81120146dc8181950052', 'admin', null, null, null);
INSERT INTO `t_s_muti_lang` VALUES ('297e201047e73d0f0147e8004113002a', 'common.org.code', 'Org Code', 'en', '2014-08-18 15:23:56', '8a8ab0b246dc81120146dc8181950052', 'admin', null, null, null);
INSERT INTO `t_s_muti_lang` VALUES ('297e201047e73d0f0147e800add5002c', 'common.org.type', '机构类型', 'zh-cn', '2014-08-18 15:24:24', '8a8ab0b246dc81120146dc8181950052', 'admin', null, null, null);
INSERT INTO `t_s_muti_lang` VALUES ('297e201047e73d0f0147e800edf8002e', 'common.org.type', 'Org Type', 'en', '2014-08-18 15:24:40', '8a8ab0b246dc81120146dc8181950052', 'admin', null, null, null);
INSERT INTO `t_s_muti_lang` VALUES ('297e201047e73d0f0147e80a71980030', 'common.company', '公司', 'zh-cn', '2014-08-18 15:35:04', '8a8ab0b246dc81120146dc8181950052', 'admin', null, null, null);
INSERT INTO `t_s_muti_lang` VALUES ('297e201047e73d0f0147e80abac10032', 'common.company', 'Company', 'en', '2014-08-18 15:35:23', '8a8ab0b246dc81120146dc8181950052', 'admin', null, null, null);
INSERT INTO `t_s_muti_lang` VALUES ('297e201047e73d0f0147e815144e0034', 'common.position', '岗位', 'zh-cn', '2014-08-18 15:46:41', '8a8ab0b246dc81120146dc8181950052', 'admin', null, null, null);
INSERT INTO `t_s_muti_lang` VALUES ('297e201047e73d0f0147e81561a80036', 'common.position', 'Position', 'en', '2014-08-18 15:47:01', '8a8ab0b246dc81120146dc8181950052', 'admin', null, null, null);
INSERT INTO `t_s_muti_lang` VALUES ('297e201047f766400147f7b9d4d20009', 'role.set', '角色设置', 'zh-cn', '2014-08-21 16:40:56', '8a8ab0b246dc81120146dc8181950052', 'admin', null, null, null);
INSERT INTO `t_s_muti_lang` VALUES ('297e201047f766400147f7be2c6a000c', 'current.org', '当前机构', 'zh-cn', '2014-08-21 16:45:41', '8a8ab0b246dc81120146dc8181950052', 'admin', '2014-08-21 16:49:44', '8a8ab0b246dc81120146dc8181950052', 'admin');
INSERT INTO `t_s_muti_lang` VALUES ('297e201047f766400147f7be6144000e', 'current.org', 'Current Org', 'en', '2014-08-21 16:45:54', '8a8ab0b246dc81120146dc8181950052', 'admin', '2014-08-21 16:50:03', '8a8ab0b246dc81120146dc8181950052', 'admin');
INSERT INTO `t_s_muti_lang` VALUES ('297e201047f8c5050147f923e5e8000c', 'role.set', 'Role Set', 'en', '2014-08-21 23:16:25', '8a8ab0b246dc81120146dc8181950052', 'admin', null, null, null);
INSERT INTO `t_s_muti_lang` VALUES ('297e201048154920014815c3e9a7000c', 'common.add.exist.user', '添加已有客户', 'zh-cn', '2014-08-27 12:40:33', '8a8ab0b246dc81120146dc8181950052', 'admin', null, null, null);
INSERT INTO `t_s_muti_lang` VALUES ('297e201048154920014815c47ac1000e', 'common.add.exist.user', 'Add Exist User', 'en', '2014-08-27 12:41:11', '8a8ab0b246dc81120146dc8181950052', 'admin', null, null, null);
INSERT INTO `t_s_muti_lang` VALUES ('297e201048b7e5c60148b7ffe64e0001', 'common.type.list', '类型列表', 'zh-cn', '2014-09-28 00:44:34', 'admin', '管理员', null, null, null);
INSERT INTO `t_s_muti_lang` VALUES ('297e201048b7e5c60148b8002b620003', 'common.type.list', 'Type List', 'en', '2014-09-28 00:44:51', 'admin', '管理员', '2014-09-28 00:46:01', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('297e201048b7e5c60148b801c7520006', 'common.type.code', '类型编码', 'zh-cn', '2014-09-28 00:46:37', 'admin', '管理员', null, null, null);
INSERT INTO `t_s_muti_lang` VALUES ('297e201048b7e5c60148b801f8dc0008', 'common.type.code', 'Type Code', 'en', '2014-09-28 00:46:50', 'admin', '管理员', null, null, null);
INSERT INTO `t_s_muti_lang` VALUES ('297e201048b7e5c60148b8024884000a', 'common.type.name', '类型名称', 'zh-cn', '2014-09-28 00:47:10', 'admin', '管理员', null, null, null);
INSERT INTO `t_s_muti_lang` VALUES ('297e201048b7e5c60148b802773e000c', 'common.type.name', 'Type Name', 'en', '2014-09-28 00:47:22', 'admin', '管理员', null, null, null);
INSERT INTO `t_s_muti_lang` VALUES ('297e201048b803ec0148b80d34360001', 'common.type.view', '查看类型', 'zh-cn', '2014-09-28 00:59:06', 'admin', '管理员', null, null, null);
INSERT INTO `t_s_muti_lang` VALUES ('297e201048b803ec0148b80d6da10003', 'common.type.view', 'Type View', 'en', '2014-09-28 00:59:20', 'admin', '管理员', null, null, null);
INSERT INTO `t_s_muti_lang` VALUES ('2a609258aef344bbbcf0c766d922e449', 'common.phone', 'Phone', 'en', '2014-07-03 18:39:43', '4028818d46f764fb0146f7661cb60052', 'admin', '2014-07-02 23:27:53', '4028818d46f764fb0146f7661cb60052', 'admin');
INSERT INTO `t_s_muti_lang` VALUES ('2bad4a20100e456aac2f6be3d1cc85ac', 'common.real.name', 'Real Name', 'en', '2014-07-03 18:39:42', '4028818d46f764fb0146f7661cb60052', 'admin', '2014-07-02 23:27:53', '4028818d46f764fb0146f7661cb60052', 'admin');
INSERT INTO `t_s_muti_lang` VALUES ('2c90841d50b676b20150b6967e5d0003', 'common.range', '不能为空', 'zh-cn', '2015-10-30 10:32:07', 'admin', '管理员', null, null, null);
INSERT INTO `t_s_muti_lang` VALUES ('2c90841d50b697200150b71336180005', 'rolescope.rang2to8.notnull', '2~8位字符', 'zh-cn', '2015-10-30 12:48:21', 'admin', '管理员', null, null, null);
INSERT INTO `t_s_muti_lang` VALUES ('2c90841d50b697200150b7139e760007', 'rolecode.rang2to15.notnull', '2至15位字符', 'zh-cn', '2015-10-30 12:48:47', 'admin', '管理员', null, null, null);
INSERT INTO `t_s_muti_lang` VALUES ('2c90843852783fca01527845deea0001', 'common.verifycode.error', '验证码错误', 'zh-cn', '2016-01-25 18:13:11', 'admin', '管理员', null, null, null);
INSERT INTO `t_s_muti_lang` VALUES ('2c9084b5507dd6ea01507dec5d290002', 'common.clear.localstorage', '清理缓存', 'zh-cn', '2015-10-19 10:27:33', 'admin', '管理员', null, null, null);
INSERT INTO `t_s_muti_lang` VALUES ('2c9084b5507df8ce01507e013a010002', 'effective.immediately', '更新任务时间', 'zh-cn', '2015-10-19 10:50:21', 'admin', '管理员', null, null, null);
INSERT INTO `t_s_muti_lang` VALUES ('2c9084b5507df8ce01507e0403200004', ' common.start', '开始任务', 'zh-cn', '2015-10-19 10:53:23', 'admin', '管理员', null, null, null);
INSERT INTO `t_s_muti_lang` VALUES ('2c9084dd50b2a7530150b2d153210023', 'system.name', 'bms演示系统', 'zh-cn', '2015-10-29 16:57:54', 'admin', '管理员', '2015-12-14 14:19:45', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('2c9084dd50b2a7530150b2d1b3a30025', 'system.version', 'v1.0.0', 'zh-cn', '2015-10-29 16:58:18', 'admin', '管理员', '2015-10-30 14:48:21', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('2c9084fe519f168401519f1a18820001', 'system.support', '呼啦搜', 'zh-cn', '2015-12-14 14:07:46', 'admin', '管理员', null, null, null);
INSERT INTO `t_s_muti_lang` VALUES ('2c9084fe519f1a9301519f1fa0d30001', 'system.right', 'bms开源系统', 'zh-cn', '2015-12-14 14:13:48', 'admin', '管理员', '2015-12-14 14:19:37', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('2d70c1a8158b415b9aff12e1957c1819', 'common.repeat.password', 'Repeat Password', 'en', '2014-07-03 18:39:43', '4028818d46f764fb0146f7661cb60052', 'admin', '2014-07-02 23:27:53', '4028818d46f764fb0146f7661cb60052', 'admin');
INSERT INTO `t_s_muti_lang` VALUES ('2fe5274af5d94fb49240d82b7b8d2a95', 'common.tel', 'Telephone', 'en', '2014-07-03 18:39:43', '4028818d46f764fb0146f7661cb60052', 'admin', '2014-07-02 23:27:53', '4028818d46f764fb0146f7661cb60052', 'admin');
INSERT INTO `t_s_muti_lang` VALUES ('3db54b3731434dc38bc5ea3b20de7db8', 'common.middle', 'Middle', 'en', '2014-07-04 18:39:43', '4028818d46f764fb0146f7661cb60052', 'admin', '2014-07-04 23:27:53', '4028818d46f764fb0146f7661cb60052', 'admin');
INSERT INTO `t_s_muti_lang` VALUES ('4028808847f3e70d0147f3eb326b0005', 'funcType', '菜单类型', 'zh-cn', '2014-08-20 22:56:23', '8a8ab0b246dc81120146dc8181950052', 'admin', null, null, null);
INSERT INTO `t_s_muti_lang` VALUES ('4028808847f3e70d0147f3eb9f400007', 'funcType', 'funcType', 'en', '2014-08-20 22:56:51', '8a8ab0b246dc81120146dc8181950052', 'admin', null, null, null);
INSERT INTO `t_s_muti_lang` VALUES ('4028808847f3e70d0147f3ef30570009', 'funcType.page', '菜单类型', 'zh-cn', '2014-08-20 23:00:44', '8a8ab0b246dc81120146dc8181950052', 'admin', '2014-08-23 01:48:20', '8a8ab0b246dc81120146dc8181950052', 'admin');
INSERT INTO `t_s_muti_lang` VALUES ('4028808847f3e70d0147f3ef5482000b', 'funcType.page', 'menu type', 'en', '2014-08-20 23:00:54', '8a8ab0b246dc81120146dc8181950052', 'admin', '2014-08-23 01:48:29', '8a8ab0b246dc81120146dc8181950052', 'admin');
INSERT INTO `t_s_muti_lang` VALUES ('4028808847f3e70d0147f3ef8590000d', 'funcType.from', 'access type', 'en', '2014-08-20 23:01:06', '8a8ab0b246dc81120146dc8181950052', 'admin', '2014-08-23 01:49:57', '8a8ab0b246dc81120146dc8181950052', 'admin');
INSERT INTO `t_s_muti_lang` VALUES ('4028808847f3e70d0147f3efcd02000f', 'funcType.from', '访问类型', 'zh-cn', '2014-08-20 23:01:24', '8a8ab0b246dc81120146dc8181950052', 'admin', '2014-08-23 01:50:07', '8a8ab0b246dc81120146dc8181950052', 'admin');
INSERT INTO `t_s_muti_lang` VALUES ('4028808847f972bb0147f9749a7b0003', 'operationType.disabled', 'disabled', 'en', '2014-08-22 00:44:34', '8a8ab0b246dc81120146dc8181950052', 'admin', null, null, null);
INSERT INTO `t_s_muti_lang` VALUES ('4028808847f972bb0147f974dc860005', 'operationType.disabled', '禁用', 'zh-cn', '2014-08-22 00:44:51', '8a8ab0b246dc81120146dc8181950052', 'admin', null, null, null);
INSERT INTO `t_s_muti_lang` VALUES ('4028808847f972bb0147f9754c030007', 'common.enable', '有效', 'zh-cn', '2014-08-22 00:45:19', '8a8ab0b246dc81120146dc8181950052', 'admin', null, null, null);
INSERT INTO `t_s_muti_lang` VALUES ('4028808847f972bb0147f97581920009', 'common.enable', 'enable', 'en', '2014-08-22 00:45:33', '8a8ab0b246dc81120146dc8181950052', 'admin', null, null, null);
INSERT INTO `t_s_muti_lang` VALUES ('4028808847f972bb0147f975c3c8000b', 'common.disable', '无效', 'zh-cn', '2014-08-22 00:45:50', '8a8ab0b246dc81120146dc8181950052', 'admin', null, null, null);
INSERT INTO `t_s_muti_lang` VALUES ('4028808847f972bb0147f97612a1000d', 'common.disable', 'disable', 'en', '2014-08-22 00:46:10', '8a8ab0b246dc81120146dc8181950052', 'admin', null, null, null);
INSERT INTO `t_s_muti_lang` VALUES ('402880e447e9ba550147e9be3a3a0003', 'common.rang', '{0}Operate name  should be {1}-{2} characters', 'en', '2014-08-18 23:31:03', '8a8ab0b246dc81120146dc8181950052', 'admin', '2014-08-18 23:32:00', '8a8ab0b246dc81120146dc8181950052', 'admin');
INSERT INTO `t_s_muti_lang` VALUES ('402880e447e9ba550147e9bf9eaa0006', 'common.rang', '{0}范围{1}~{2}位字符', 'zh-cn', '2014-08-18 23:32:35', '8a8ab0b246dc81120146dc8181950052', 'admin', null, null, null);
INSERT INTO `t_s_muti_lang` VALUES ('402880e447e9ba550147e9c1ab590008', 'departmentname.rang1to20', 'Depart name should be 1-20 characters', 'en', '2014-08-18 23:34:49', '8a8ab0b246dc81120146dc8181950052', 'admin', null, null, null);
INSERT INTO `t_s_muti_lang` VALUES ('402880e447e9ba550147e9c25bbe000a', 'departmentname.rang1to20', '组织机构范围1~20位字符', 'zh-cn', '2014-08-18 23:35:34', '8a8ab0b246dc81120146dc8181950052', 'admin', null, null, null);
INSERT INTO `t_s_muti_lang` VALUES ('402880e4489db6e601489dbc2cdc0001', 'common.add.to', 'AddTo', 'en', '2014-09-22 22:20:28', 'admin', '管理员', null, null, null);
INSERT INTO `t_s_muti_lang` VALUES ('402880e4489db6e601489dbc61380003', 'common.add.to', '添加', 'zh-cn', '2014-09-22 22:20:41', 'admin', '管理员', null, null, null);
INSERT INTO `t_s_muti_lang` VALUES ('402880e64705eca9014705eee9120001', 'user.analysis.line', 'User analysis Line', 'en', '2014-07-05 17:50:49', '402880e64705a8ce014705af94280052', 'admin', '2014-07-04 23:17:44', '297e201046d3660a0146d36d7b7a01e7', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('402880e64705eca9014705f1741c0003', 'user.analysis.line', '用户分析 Line', 'zh-cn', '2014-07-05 17:53:35', '402880e64705a8ce014705af94280052', 'admin', '2014-07-04 23:17:44', '297e201046d3660a0146d36d7b7a01e7', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('402880e64705eca9014705f535a50005', 'user.analysis.pie', 'User analysis Pie', 'en', '2014-07-05 17:57:41', '402880e64705a8ce014705af94280052', 'admin', '2014-07-04 23:17:44', '297e201046d3660a0146d36d7b7a01e7', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('402880e64705eca9014705f597d10007', 'user.analysis.pie', '用户分析 Pie', 'zh-cn', '2014-07-05 17:58:07', '402880e64705a8ce014705af94280052', 'admin', '2014-07-04 23:17:44', '297e201046d3660a0146d36d7b7a01e7', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('402880e64705eca9014705f82a580009', 'user.analysis.histogram', 'User Analysis Histogram', 'en', '2014-07-05 18:00:55', '402880e64705a8ce014705af94280052', 'admin', '2014-07-21 10:08:08', '8a8ab0b246dc81120146dc8181950052', 'admin');
INSERT INTO `t_s_muti_lang` VALUES ('402880e64705eca9014705fc8656000b', 'user.browser.analysis', ' Analysis of the user\'s browser proportion', 'en', '2014-07-05 18:00:00', '402880e64705a8ce014705af94280052', 'admin', '2014-07-04 23:00:00', '297e201046d3660a0146d36d7b7a01e7', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('402880e64705eca9014705fce72d000d', 'user.browser.analysis', '用户浏览器比例分析', 'zh-cn', '2014-07-05 18:06:06', '402880e64705a8ce014705af94280052', 'admin', '2014-07-04 23:17:44', '297e201046d3660a0146d36d7b7a01e7', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('402880e64705eca901470608088c000f', 'class.student.count.analysis', 'Class student ratio analysis', 'en', '2014-07-05 18:18:15', '402880e64705a8ce014705af94280052', 'admin', '2014-07-04 23:17:44', '297e201046d3660a0146d36d7b7a01e7', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('402880e64705eca9014706088d7c0011', 'class.student.count.analysis', '班级学生人数比例分析', 'zh-cn', '2014-07-05 18:18:49', '402880e64705a8ce014705af94280052', 'admin', '2014-07-04 23:17:44', '297e201046d3660a0146d36d7b7a01e7', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('402880e64705eca90147060a873a0013', 'common.line.chart', 'Line chart', 'en', '2014-07-05 18:20:59', '402880e64705a8ce014705af94280052', 'admin', '2014-07-04 23:17:44', '297e201046d3660a0146d36d7b7a01e7', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('402880e64705eca90147060aef730015', 'common.line.chart', '折线图', 'zh-cn', '2014-07-05 18:21:25', '402880e64705a8ce014705af94280052', 'admin', '2014-07-04 23:17:44', '297e201046d3660a0146d36d7b7a01e7', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('402880e64705eca90147060bfcae0017', 'common.pie.chart', 'pie', 'en', '2014-07-05 18:22:34', '402880e64705a8ce014705af94280052', 'admin', '2014-07-04 23:17:44', '297e201046d3660a0146d36d7b7a01e7', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('402880e64705eca90147060c5e310019', 'common.pie.chart', '饼状图', 'zh-cn', '2014-07-05 18:22:59', '402880e64705a8ce014705af94280052', 'admin', '2014-07-04 23:17:44', '297e201046d3660a0146d36d7b7a01e7', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('402880e64705eca90147060dc6b6001b', 'common.histogram', 'Histogram', 'en', '2014-07-05 18:24:31', '402880e64705a8ce014705af94280052', 'admin', '2014-07-04 23:17:44', '297e201046d3660a0146d36d7b7a01e7', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('402880e64705eca90147060e11f3001d', 'common.histogram', '柱状图', 'zh-cn', '2014-07-05 18:24:51', '402880e64705a8ce014705af94280052', 'admin', '2014-07-04 23:17:44', '297e201046d3660a0146d36d7b7a01e7', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('402880e64705eca90147060fa1ba001f', 'class.count.statistics', 'Class size statistics', 'en', '2014-07-05 18:26:33', '402880e64705a8ce014705af94280052', 'admin', '2014-07-04 23:17:44', '297e201046d3660a0146d36d7b7a01e7', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('402880e64705eca90147060fdf3a0021', 'class.count.statistics', '班级人数统计', 'zh-cn', '2014-07-05 18:26:49', '402880e64705a8ce014705af94280052', 'admin', '2014-07-04 23:17:44', '297e201046d3660a0146d36d7b7a01e7', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('402880e64705eca90147061123451230', 'common.query.statistics', '统计查询', 'zh-cn', '2014-07-05 18:33:40', '402880e64705a8ce014705af94280052', 'admin', '2014-07-05 18:33:40', '402880e64705a8ce014705af94280052', 'admin');
INSERT INTO `t_s_muti_lang` VALUES ('402880e64705eca90147061123451231', 'common.query.statistics', 'Statistics Query', 'en', '2014-07-05 18:33:40', '402880e64705a8ce014705af94280052', 'admin', '2014-07-05 18:33:40', '402880e64705a8ce014705af94280052', 'admin');
INSERT INTO `t_s_muti_lang` VALUES ('402880e64705eca90147061123451232', 'common.schedule.task', '定时任务', 'zh-cn', '2014-07-05 18:33:40', '402880e64705a8ce014705af94280052', 'admin', '2014-07-05 18:33:40', '402880e64705a8ce014705af94280052', 'admin');
INSERT INTO `t_s_muti_lang` VALUES ('402880e64705eca90147061123451233', 'common.schedule.task', 'Timed Task', 'en', '2014-07-05 18:33:40', '402880e64705a8ce014705af94280052', 'admin', '2014-07-05 18:33:40', '402880e64705a8ce014705af94280052', 'admin');
INSERT INTO `t_s_muti_lang` VALUES ('402880e64705eca90147061123451234', 'system.log', '系统日志', 'zh-cn', '2014-07-05 18:33:40', '402880e64705a8ce014705af94280052', 'admin', '2014-07-05 18:33:40', '402880e64705a8ce014705af94280052', 'admin');
INSERT INTO `t_s_muti_lang` VALUES ('402880e64705eca90147061123451235', 'system.log', 'Sys Log', 'en', '2014-07-05 18:33:40', '402880e64705a8ce014705af94280052', 'admin', '2014-07-05 18:33:40', '402880e64705a8ce014705af94280052', 'admin');
INSERT INTO `t_s_muti_lang` VALUES ('402880e64705eca90147061123451236', 'data.monitor', '数据监控', 'zh-cn', '2014-07-05 18:33:40', '402880e64705a8ce014705af94280052', 'admin', '2014-07-05 18:33:40', '402880e64705a8ce014705af94280052', 'admin');
INSERT INTO `t_s_muti_lang` VALUES ('402880e64705eca90147061123451237', 'data.monitor', 'Data Monitor', 'en', '2014-07-05 18:33:40', '402880e64705a8ce014705af94280052', 'admin', '2014-07-05 18:33:40', '402880e64705a8ce014705af94280052', 'admin');
INSERT INTO `t_s_muti_lang` VALUES ('402880e64705eca90147061123451238', 'form.config', '表单配置', 'zh-cn', '2014-07-05 18:33:40', '402880e64705a8ce014705af94280052', 'admin', '2014-07-05 18:33:40', '402880e64705a8ce014705af94280052', 'admin');
INSERT INTO `t_s_muti_lang` VALUES ('402880e64705eca90147061123451239', 'form.config', 'Form Config', 'en', '2014-07-05 18:33:40', '402880e64705a8ce014705af94280052', 'admin', '2014-07-05 18:33:40', '402880e64705a8ce014705af94280052', 'admin');
INSERT INTO `t_s_muti_lang` VALUES ('402880e64705eca90147061123451240', 'dynamic.form.config', '动态报表配置', 'zh-cn', '2014-07-05 18:33:40', '402880e64705a8ce014705af94280052', 'admin', '2014-07-05 18:33:40', '402880e64705a8ce014705af94280052', 'admin');
INSERT INTO `t_s_muti_lang` VALUES ('402880e64705eca90147061123451241', 'dynamic.form.config', 'Dynamic Report Config', 'en', '2014-07-05 18:33:40', '402880e64705a8ce014705af94280052', 'admin', '2014-07-05 18:33:40', '402880e64705a8ce014705af94280052', 'admin');
INSERT INTO `t_s_muti_lang` VALUES ('402880e64705eca90147061123451242', 'user.analysis', '用户分析', 'zh-cn', '2014-07-05 18:33:40', '402880e64705a8ce014705af94280052', 'admin', '2014-07-05 18:33:40', '402880e64705a8ce014705af94280052', 'admin');
INSERT INTO `t_s_muti_lang` VALUES ('402880e64705eca90147061123451243', 'user.analysis', 'User Analysis', 'en', '2014-07-05 18:33:40', '402880e64705a8ce014705af94280052', 'admin', '2014-07-05 18:33:40', '402880e64705a8ce014705af94280052', 'admin');
INSERT INTO `t_s_muti_lang` VALUES ('402880e64705eca90147061365350027', 'lang.class', 'Class', 'en', '2014-07-05 18:30:40', '402880e64705a8ce014705af94280052', 'admin', '2014-07-20 11:56:18', '8a8ab0b246dc81120146dc8181950052', 'admin');
INSERT INTO `t_s_muti_lang` VALUES ('402880e64705eca901470614932d0029', 'lang.class', '班级', 'zh-cn', '2014-07-05 18:31:57', '402880e64705a8ce014705af94280052', 'admin', '2014-07-20 11:56:24', '8a8ab0b246dc81120146dc8181950052', 'admin');
INSERT INTO `t_s_muti_lang` VALUES ('402880e64705eca9014706152c0a002b', 'number.ofpeople', ' Number of people', 'en', '2014-07-05 18:32:36', '402880e64705a8ce014705af94280052', 'admin', '2014-07-04 23:17:44', '297e201046d3660a0146d36d7b7a01e7', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('402880e64705eca901470615588b002d', 'number.ofpeople', '人数', 'zh-cn', '2014-07-05 18:32:48', '402880e64705a8ce014705af94280052', 'admin', '2014-07-04 23:17:44', '297e201046d3660a0146d36d7b7a01e7', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('402880e64705eca901470615f986002f', 'common.proportion', 'Proportion', 'en', '2014-07-05 18:33:29', '402880e64705a8ce014705af94280052', 'admin', '2014-07-04 23:17:44', '297e201046d3660a0146d36d7b7a01e7', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('402880e64705eca90147061627450031', 'common.proportion', '比例', 'zh-cn', '2014-07-05 18:33:40', '402880e64705a8ce014705af94280052', 'admin', '2014-07-04 23:17:44', '297e201046d3660a0146d36d7b7a01e7', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('402881034728d95a014728dc0fdf0005', 'has.sync', '已同步', 'zh-cn', '2014-07-12 12:36:56', '8a8ab0b246dc81120146dc8181950052', 'admin', '2014-07-12 12:36:56', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('402881034728d95a014728dcc32c0007', 'has.sync', 'Synchronized', 'en', '2014-07-12 12:37:42', '8a8ab0b246dc81120146dc8181950052', 'admin', '2014-07-12 13:10:45', '8a8ab0b246dc81120146dc8181950052', 'admin');
INSERT INTO `t_s_muti_lang` VALUES ('402881034728d95a014728dd29140009', 'have.nosync', '未同步', 'zh-cn', '2014-07-12 12:38:08', '8a8ab0b246dc81120146dc8181950052', 'admin', '2014-07-12 12:38:08', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('402881034728d95a014728dd8161000b', 'have.nosync', 'No Synchronize', 'en', '2014-07-12 12:38:31', '8a8ab0b246dc81120146dc8181950052', 'admin', '2014-07-12 12:38:31', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('402881034728d95a014728dfe5610013', 'single.table', '单表', 'zh-cn', '2014-07-12 12:41:07', '8a8ab0b246dc81120146dc8181950052', 'admin', '2014-07-12 12:41:07', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('402881034728d95a014728e0077e0015', 'single.table', 'Single Table', 'en', '2014-07-12 12:41:16', '8a8ab0b246dc81120146dc8181950052', 'admin', '2014-07-12 12:41:16', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('402881034728d95a014728e0f6500017', 'slave.table', '附表', 'zh-cn', '2014-07-12 12:42:17', '8a8ab0b246dc81120146dc8181950052', 'admin', '2014-07-12 12:42:17', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('402881034728d95a014728e1183d0019', 'slave.table', 'Slave Table', 'en', '2014-07-12 12:42:26', '8a8ab0b246dc81120146dc8181950052', 'admin', '2014-07-12 12:42:26', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('402881034728fa28014728fd5f160003', 'smart.form.setting', '智能表单配置', 'zh-cn', '2014-07-12 13:13:19', '8a8ab0b246dc81120146dc8181950052', 'admin', '2014-07-12 13:13:19', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('402881034728fa28014728fd89ff0005', 'smart.form.setting', 'Smart Form Setting', 'en', '2014-07-12 13:13:30', '8a8ab0b246dc81120146dc8181950052', 'admin', '2014-07-12 13:13:30', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('402881034728fa28014728feca7b0007', 'generate.form', '生成表单', 'zh-cn', '2014-07-12 13:14:52', '8a8ab0b246dc81120146dc8181950052', 'admin', '2014-07-12 13:14:52', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('402881034728fa28014728feedfa0009', 'generate.form', 'Generate Form', 'en', '2014-07-12 13:15:01', '8a8ab0b246dc81120146dc8181950052', 'admin', '2014-07-12 13:15:01', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('402881034728fa28014728ff5a4e000b', 'generate.success', '生成成功', 'zh-cn', '2014-07-12 13:15:29', '8a8ab0b246dc81120146dc8181950052', 'admin', '2014-07-12 13:15:29', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('402881034728fa28014728ff7e81000d', 'generate.success', 'Generate Success', 'en', '2014-07-12 13:15:38', '8a8ab0b246dc81120146dc8181950052', 'admin', '2014-07-12 13:15:38', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('402881034728fa2801472900fe10000f', 'please.select.generate.item', '请选择要生成表单的项!', 'zh-cn', '2014-07-12 13:17:16', '8a8ab0b246dc81120146dc8181950052', 'admin', '2014-07-12 13:17:16', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('402881034728fa2801472901dab10011', 'please.select.generate.item', 'Please select should be generated item.', 'en', '2014-07-12 13:18:13', '8a8ab0b246dc81120146dc8181950052', 'admin', '2014-07-12 13:18:13', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('402881034728fa280147290fad990013', 'button.code', '按钮编码', 'zh-cn', '2014-07-12 13:33:19', '8a8ab0b246dc81120146dc8181950052', 'admin', '2014-07-12 13:33:19', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('402881034728fa280147290fcac30015', 'button.code', 'Button Code', 'en', '2014-07-12 13:33:26', '8a8ab0b246dc81120146dc8181950052', 'admin', '2014-07-12 13:33:26', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('402881034728fa2801472910045f0017', 'button.name', '按钮名称', 'zh-cn', '2014-07-12 13:33:41', '8a8ab0b246dc81120146dc8181950052', 'admin', '2014-07-12 13:33:41', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('402881034728fa28014729101a4a0019', 'button.name', 'Button Name', 'en', '2014-07-12 13:33:46', '8a8ab0b246dc81120146dc8181950052', 'admin', '2014-07-12 13:33:46', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('402881034728fa280147291059ca001b', 'button.style', '按钮样式', 'zh-cn', '2014-07-12 13:34:03', '8a8ab0b246dc81120146dc8181950052', 'admin', '2014-07-12 13:34:03', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('402881034728fa2801472910776c001d', 'button.style', 'Button Style', 'en', '2014-07-12 13:34:10', '8a8ab0b246dc81120146dc8181950052', 'admin', '2014-07-12 13:34:10', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('402881034728fa2801472910a634001f', 'action.type', '动作类型', 'zh-cn', '2014-07-12 13:34:22', '8a8ab0b246dc81120146dc8181950052', 'admin', '2014-07-12 13:34:22', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('402881034728fa2801472910bdd70021', 'action.type', 'Action Type', 'en', '2014-07-12 13:34:28', '8a8ab0b246dc81120146dc8181950052', 'admin', '2014-07-12 13:34:28', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('4028810347292c730147293008280009', 'super.admin', '超级管理员', 'zh-cn', '2014-07-12 14:08:39', '8a8ab0b246dc81120146dc8181950052', 'admin', '2014-07-12 14:08:39', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('4028810347292c730147293021c7000b', 'super.admin', 'Super Admin', 'en', '2014-07-12 14:08:46', '8a8ab0b246dc81120146dc8181950052', 'admin', '2014-07-12 14:08:46', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('4028810347292c73014729308a0e000d', 'please.select.lock.item', '请选择锁定项目', 'zh-cn', '2014-07-12 14:09:12', '8a8ab0b246dc81120146dc8181950052', 'admin', '2014-07-12 14:09:12', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('4028810347292c7301472930ae9e000f', 'please.select.lock.item', 'Please select locked item', 'en', '2014-07-12 14:09:22', '8a8ab0b246dc81120146dc8181950052', 'admin', '2014-07-12 14:09:22', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('4028810347292c7301472931c5900011', 'is.confirm', '确定吗', 'zh-cn', '2014-07-12 14:10:33', '8a8ab0b246dc81120146dc8181950052', 'admin', '2014-07-12 14:10:33', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('4028810347292c73014729320e310013', 'is.confirm', 'Confirm?', 'en', '2014-07-12 14:10:52', '8a8ab0b246dc81120146dc8181950052', 'admin', '2014-07-12 14:10:52', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('4028810347292c73014729369dde0015', 'current.permission', '当前权限', 'zh-cn', '2014-07-12 14:15:51', '8a8ab0b246dc81120146dc8181950052', 'admin', '2014-07-12 14:15:51', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('4028810347292c7301472936c80f0017', 'current.permission', 'Current Permission', 'en', '2014-07-12 14:16:01', '8a8ab0b246dc81120146dc8181950052', 'admin', '2014-07-12 14:16:01', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('4028810347292c73014729386dce0019', 'confirm.delete.this.record', '确定删除该记录吗', 'zh-cn', '2014-07-12 14:17:49', '8a8ab0b246dc81120146dc8181950052', 'admin', '2014-07-12 14:17:49', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('4028810347292c7301472938c6f9001b', 'confirm.delete.this.record', 'Delete this record, Confirm?', 'en', '2014-07-12 14:18:12', '8a8ab0b246dc81120146dc8181950052', 'admin', '2014-07-12 14:18:12', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('4028810347292c7301472939f98b001d', 'menu.list', '菜单列表', 'zh-cn', '2014-07-12 14:19:31', '8a8ab0b246dc81120146dc8181950052', 'admin', '2014-07-12 14:19:31', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('4028810347292c730147293a157d001f', 'menu.list', 'Menu List', 'en', '2014-07-12 14:19:38', '8a8ab0b246dc81120146dc8181950052', 'admin', '2014-07-12 14:19:38', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('4028810347292c730147293ab7a10021', 'operate.button.list', '操作按钮列表', 'zh-cn', '2014-07-12 14:20:19', '8a8ab0b246dc81120146dc8181950052', 'admin', '2014-07-12 14:20:19', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('4028810347292c730147293aefc40023', 'operate.button.list', 'Button List', 'en', '2014-07-12 14:20:34', '8a8ab0b246dc81120146dc8181950052', 'admin', '2014-07-12 14:20:34', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('4028810347292c730147293b76f80025', 'select.all', '全选', 'zh-cn', '2014-07-12 14:21:08', '8a8ab0b246dc81120146dc8181950052', 'admin', '2014-07-12 14:21:08', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('4028810347292c730147293b8dc60027', 'select.all', 'Select All', 'en', '2014-07-12 14:21:14', '8a8ab0b246dc81120146dc8181950052', 'admin', '2014-07-12 14:21:14', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('40288103472948880147294b26420002', 'button.setting', '按钮设置', 'zh-cn', '2014-07-12 14:38:16', '8a8ab0b246dc81120146dc8181950052', 'admin', '2014-07-12 14:38:16', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('40288103472948880147294b432a0004', 'button.setting', 'Button Setting', 'en', '2014-07-12 14:38:24', '8a8ab0b246dc81120146dc8181950052', 'admin', '2014-07-12 14:38:24', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('4028810b474cecc301474cf3de950001', 'common.button.code', '按钮编码', 'zh-cn', '2014-07-19 12:49:16', '8a8ab0b246dc81120146dc8181950052', 'admin', '2014-07-19 12:49:16', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('4028810b474cecc301474cf407a90003', 'common.button.code', 'Button Code', 'en', '2014-07-19 12:49:26', '8a8ab0b246dc81120146dc8181950052', 'admin', '2014-07-19 12:49:26', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('4028810b474cecc301474cf46f7f0005', 'common.button.name', '按钮名称', 'zh-cn', '2014-07-19 12:49:53', '8a8ab0b246dc81120146dc8181950052', 'admin', '2014-07-19 12:49:53', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('4028810b474cecc301474cf4994d0007', 'common.button.name', 'Button Name', 'en', '2014-07-19 12:50:04', '8a8ab0b246dc81120146dc8181950052', 'admin', '2014-07-19 12:50:04', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('4028810b474cecc301474cf4f6430009', 'common.button.style', '按钮样式', 'zh-cn', '2014-07-19 12:50:28', '8a8ab0b246dc81120146dc8181950052', 'admin', '2014-07-19 12:50:28', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('4028810b474cecc301474cf517aa000b', 'common.button.style', 'Button Style', 'en', '2014-07-19 12:50:36', '8a8ab0b246dc81120146dc8181950052', 'admin', '2014-07-19 12:50:36', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('4028810b474cecc301474cf5930c000d', 'common.action.type', '动作类型', 'zh-cn', '2014-07-19 12:51:08', '8a8ab0b246dc81120146dc8181950052', 'admin', '2014-07-19 12:51:08', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('4028810b474cecc301474cf5af11000f', 'common.action.type', 'Action Type', 'en', '2014-07-19 12:51:15', '8a8ab0b246dc81120146dc8181950052', 'admin', '2014-07-19 12:51:15', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('4028810b474cecc301474cf652c20011', 'common.show.sequence', 'Show Sequence', 'en', '2014-07-19 12:51:57', '8a8ab0b246dc81120146dc8181950052', 'admin', '2014-07-19 13:04:07', '8a8ab0b246dc81120146dc8181950052', 'admin');
INSERT INTO `t_s_muti_lang` VALUES ('4028810b474cecc301474cf694a20013', 'common.show.sequence', '显示顺序', 'zh-cn', '2014-07-19 12:52:14', '8a8ab0b246dc81120146dc8181950052', 'admin', '2014-07-19 12:52:14', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('4028810b474cecc301474cf6fa160015', 'common.show.icon.style', '显示图标样式', 'zh-cn', '2014-07-19 12:52:40', '8a8ab0b246dc81120146dc8181950052', 'admin', '2014-07-19 12:52:40', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('4028810b474cecc301474cf71da40017', 'common.show.icon.style', 'Show Icon Style', 'en', '2014-07-19 12:52:49', '8a8ab0b246dc81120146dc8181950052', 'admin', '2014-07-19 12:52:49', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('4028810b474cecc301474cf776390019', 'common.show.expression', '显示表达式', 'zh-cn', '2014-07-19 12:53:11', '8a8ab0b246dc81120146dc8181950052', 'admin', '2014-07-19 12:53:11', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('4028810b474cecc301474cf7972c001b', 'common.show.expression', 'Show Expression', 'en', '2014-07-19 12:53:20', '8a8ab0b246dc81120146dc8181950052', 'admin', '2014-07-19 12:53:20', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('4028810b474cecc301474d025ae20024', 'lang.code.cannot.add.update.delete', '编码不能是add/update/delete', 'zh-cn', '2014-07-19 13:05:05', '8a8ab0b246dc81120146dc8181950052', 'admin', '2014-07-19 13:05:05', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('4028810b474cecc301474d0294e30026', 'lang.code.cannot.add.update.delete', 'Code cannot be add/update/delete', 'en', '2014-07-19 13:05:20', '8a8ab0b246dc81120146dc8181950052', 'admin', '2014-07-19 13:05:20', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('4028810b474d25ab01474d28a1fe0002', 'lang.user.online', '人在线', 'zh-cn', '2014-07-19 13:46:54', '8a8ab0b246dc81120146dc8181950052', 'admin', '2014-07-19 13:46:54', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('4028810b474d25ab01474d28cef50004', 'lang.user.online', 'user online', 'en', '2014-07-19 13:47:05', '8a8ab0b246dc81120146dc8181950052', 'admin', '2014-07-19 13:47:05', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('4028810b474d25ab01474d2cc7d80006', 'common.login.name', '登录名', 'zh-cn', '2014-07-19 13:51:26', '8a8ab0b246dc81120146dc8181950052', 'admin', '2014-07-19 13:51:26', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('4028810b474d25ab01474d2cf5650008', 'common.login.name', 'Login Name', 'en', '2014-07-19 13:51:37', '8a8ab0b246dc81120146dc8181950052', 'admin', '2014-07-19 13:51:37', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('4028810b474d25ab01474d2ed970000a', 'common.login.time', '登录时间', 'zh-cn', '2014-07-19 13:53:41', '8a8ab0b246dc81120146dc8181950052', 'admin', '2014-07-19 13:53:41', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('4028810b474d25ab01474d2f0340000c', 'common.login.time', 'Login Time', 'en', '2014-07-19 13:53:52', '8a8ab0b246dc81120146dc8181950052', 'admin', '2014-07-19 13:53:52', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('4028810b474d25ab01474d3ad8c9000f', 'common.select', '选择', 'zh-cn', '2014-07-19 14:06:48', '8a8ab0b246dc81120146dc8181950052', 'admin', '2014-07-19 14:06:48', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('4028810b474d25ab01474d3b14bb0011', 'common.select', 'Select', 'en', '2014-07-19 14:07:03', '8a8ab0b246dc81120146dc8181950052', 'admin', '2014-07-19 14:07:03', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('4028810b474d25ab01474d3b61020013', 'common.clear', '清空', 'zh-cn', '2014-07-19 14:07:22', '8a8ab0b246dc81120146dc8181950052', 'admin', '2014-07-19 14:07:22', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('4028810b474d25ab01474d3b78f30015', 'common.clear', 'Clear', 'en', '2014-07-19 14:07:29', '8a8ab0b246dc81120146dc8181950052', 'admin', '2014-07-19 14:07:29', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('4028813f4752b0d7014752b35e4f0001', 'username.rang2to10', 'Username need 2~10 bits', 'en', '2014-07-20 15:36:32', '8a8ab0b246dc81120146dc8181950052', 'admin', '2014-07-20 15:36:32', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('4028813f4752c793014752cd3369000a', 'common.delete.success.param', '{0}删除成功', 'zh-cn', '2014-07-20 16:04:45', '8a8ab0b246dc81120146dc8181950052', 'admin', '2014-07-20 16:04:45', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('4028813f4752dc11014752e731930003', 'lang.dictionary.type', '字典分类', 'zh-cn', '2014-07-20 16:33:09', '8a8ab0b246dc81120146dc8181950052', 'admin', '2014-07-20 16:33:09', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('4028813f4752dc11014752e765dd0005', 'lang.dictionary.type', 'Dictionary Type', 'en', '2014-07-20 16:33:22', '8a8ab0b246dc81120146dc8181950052', 'admin', '2014-07-20 16:33:22', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('4028813f4752dc11014752e98bf90007', 'lang.dictionary.value', '字典值', 'zh-cn', '2014-07-20 16:35:43', '8a8ab0b246dc81120146dc8181950052', 'admin', '2014-07-20 16:35:43', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('4028813f4752dc11014752e9eba60009', 'lang.dictionary.value', 'Dictionary Value', 'en', '2014-07-20 16:36:07', '8a8ab0b246dc81120146dc8181950052', 'admin', '2014-07-21 14:06:50', '8a8ab0b246dc81120146dc8181950052', 'admin');
INSERT INTO `t_s_muti_lang` VALUES ('4028818d46f7832b0146f793fd690016', 'common.taskid', 'Task Id', 'en', '2014-07-02 22:56:50', '4028818d46f764fb0146f7661cb60052', 'admin', '2014-07-02 23:41:28', '4028818d46f764fb0146f7661cb60052', 'admin');
INSERT INTO `t_s_muti_lang` VALUES ('4028818d46f7832b0146f794259e0018', 'common.taskid', '任务ID', 'zh-cn', '2014-07-02 22:57:00', '4028818d46f764fb0146f7661cb60052', 'admin', '2014-07-02 23:19:13', '4028818d46f764fb0146f7661cb60052', 'admin');
INSERT INTO `t_s_muti_lang` VALUES ('4028818d46f7832b0146f7949e2d001a', 'common.task.desc', '任务描述', 'zh-cn', '2014-07-02 22:57:31', '4028818d46f764fb0146f7661cb60052', 'admin', '2014-07-03 12:37:08', '4028818d46f764fb0146f7661cb60052', 'admin');
INSERT INTO `t_s_muti_lang` VALUES ('4028818d46f7832b0146f794d224001c', 'common.task.desc', 'Task Describe', 'en', '2014-07-02 22:57:44', '4028818d46f764fb0146f7661cb60052', 'admin', '2014-07-02 23:41:38', '4028818d46f764fb0146f7661cb60052', 'admin');
INSERT INTO `t_s_muti_lang` VALUES ('4028818d46f7832b0146f79550c4001e', 'cron.expression', 'cron表达式', 'zh-cn', '2014-07-02 22:58:16', '4028818d46f764fb0146f7661cb60052', 'admin', '2014-07-02 23:22:37', '4028818d46f764fb0146f7661cb60052', 'admin');
INSERT INTO `t_s_muti_lang` VALUES ('4028818d46f7832b0146f7956b7b0020', 'cron.expression', 'Cron Expression', 'en', '2014-07-02 22:58:23', '4028818d46f764fb0146f7661cb60052', 'admin', '2014-07-02 23:41:44', '4028818d46f764fb0146f7661cb60052', 'admin');
INSERT INTO `t_s_muti_lang` VALUES ('4028818d46f7832b0146f795c74b0022', 'common.iseffect', '是否生效', 'zh-cn', '2014-07-02 22:58:47', '4028818d46f764fb0146f7661cb60052', 'admin', '2014-07-02 23:22:58', '4028818d46f764fb0146f7661cb60052', 'admin');
INSERT INTO `t_s_muti_lang` VALUES ('4028818d46f7832b0146f79643cc0024', 'common.iseffect', 'isEffect', 'en', '2014-07-02 22:59:19', '4028818d46f764fb0146f7661cb60052', 'admin', '2014-07-02 23:23:03', '4028818d46f764fb0146f7661cb60052', 'admin');
INSERT INTO `t_s_muti_lang` VALUES ('4028818d46f7832b0146f796fbd60026', 'running.state', '运行状态', 'zh-cn', '2014-07-02 23:00:06', '4028818d46f764fb0146f7661cb60052', 'admin', '2014-07-02 23:23:19', '4028818d46f764fb0146f7661cb60052', 'admin');
INSERT INTO `t_s_muti_lang` VALUES ('4028818d46f7832b0146f79729ce0028', 'running.state', 'Running State', 'en', '2014-07-02 23:00:17', '4028818d46f764fb0146f7661cb60052', 'admin', '2014-07-02 23:41:52', '4028818d46f764fb0146f7661cb60052', 'admin');
INSERT INTO `t_s_muti_lang` VALUES ('4028818d46f7832b0146f798b8850034', 'common.createby', 'Create By', 'en', '2014-07-02 23:02:00', '4028818d46f764fb0146f7661cb60052', 'admin', '2014-07-02 23:41:58', '4028818d46f764fb0146f7661cb60052', 'admin');
INSERT INTO `t_s_muti_lang` VALUES ('4028818d46f7832b0146f798f9cf0036', 'common.createby', '创建人', 'zh-cn', '2014-07-02 23:02:16', '4028818d46f764fb0146f7661cb60052', 'admin', '2014-07-02 23:23:44', '4028818d46f764fb0146f7661cb60052', 'admin');
INSERT INTO `t_s_muti_lang` VALUES ('4028818d46f7832b0146f7999ffd003c', 'common.updateby', 'Update By', 'en', '2014-07-02 23:02:59', '4028818d46f764fb0146f7661cb60052', 'admin', '2014-07-02 23:42:12', '4028818d46f764fb0146f7661cb60052', 'admin');
INSERT INTO `t_s_muti_lang` VALUES ('4028818d46f7832b0146f799e7e9003e', 'common.updateby', '修改人', 'zh-cn', '2014-07-02 23:03:17', '4028818d46f764fb0146f7661cb60052', 'admin', '2014-07-02 23:24:30', '4028818d46f764fb0146f7661cb60052', 'admin');
INSERT INTO `t_s_muti_lang` VALUES ('4028818d46f7832b0146f79a3aed0040', 'common.updatetime', '修改时间', 'zh-cn', '2014-07-02 23:03:38', '4028818d46f764fb0146f7661cb60052', 'admin', '2014-07-02 23:24:47', '4028818d46f764fb0146f7661cb60052', 'admin');
INSERT INTO `t_s_muti_lang` VALUES ('4028818d46f7832b0146f79a6c310042', 'common.updatetime', 'Update Time', 'en', '2014-07-02 23:03:51', '4028818d46f764fb0146f7661cb60052', 'admin', '2014-07-02 23:42:21', '4028818d46f764fb0146f7661cb60052', 'admin');
INSERT INTO `t_s_muti_lang` VALUES ('4028818d46f7832b0146f79b70e90044', 'common.operation', 'Operation', 'en', '2014-07-02 23:04:58', '4028818d46f764fb0146f7661cb60052', 'admin', '2014-07-02 23:42:27', '4028818d46f764fb0146f7661cb60052', 'admin');
INSERT INTO `t_s_muti_lang` VALUES ('4028818d46f7832b0146f79b9eef0046', 'common.operation', '操作', 'zh-cn', '2014-07-02 23:05:10', '4028818d46f764fb0146f7661cb60052', 'admin', '2014-07-02 23:25:17', '4028818d46f764fb0146f7661cb60052', 'admin');
INSERT INTO `t_s_muti_lang` VALUES ('4028818d46f7832b0146f79d8ea10048', 'common.start', 'Start', 'en', '2014-07-02 23:07:17', '4028818d46f764fb0146f7661cb60052', 'admin', '2014-07-02 23:42:32', '4028818d46f764fb0146f7661cb60052', 'admin');
INSERT INTO `t_s_muti_lang` VALUES ('4028818d46f7832b0146f79df1d8004a', 'common.start', '运行', 'zh-cn', '2014-07-02 23:07:42', '4028818d46f764fb0146f7661cb60052', 'admin', '2014-07-02 23:20:31', '4028818d46f764fb0146f7661cb60052', 'admin');
INSERT INTO `t_s_muti_lang` VALUES ('4028818d46f7832b0146f79e5f54004c', 'common.stop', 'Stop', 'en', '2014-07-02 23:08:10', '4028818d46f764fb0146f7661cb60052', 'admin', '2014-07-02 23:42:38', '4028818d46f764fb0146f7661cb60052', 'admin');
INSERT INTO `t_s_muti_lang` VALUES ('4028818d46f7832b0146f79e7be9004e', 'common.stop', '停止', 'zh-cn', '2014-07-02 23:08:17', '4028818d46f764fb0146f7661cb60052', 'admin', '2014-07-02 23:26:27', '4028818d46f764fb0146f7661cb60052', 'admin');
INSERT INTO `t_s_muti_lang` VALUES ('4028818d46f7832b0146f79faa1d0050', 'effective.immediately', 'Effective Immediately', 'en', '2014-07-02 23:09:35', '4028818d46f764fb0146f7661cb60052', 'admin', '2014-07-02 23:26:35', '4028818d46f764fb0146f7661cb60052', 'admin');
INSERT INTO `t_s_muti_lang` VALUES ('4028818d46f7832b0146f79fcc7f0052', 'effective.immediately', '立即生效', 'zh-cn', '2014-07-02 23:09:43', '4028818d46f764fb0146f7661cb60052', 'admin', '2014-07-02 23:26:39', '4028818d46f764fb0146f7661cb60052', 'admin');
INSERT INTO `t_s_muti_lang` VALUES ('4028818d46f7832b0146f7a011b60054', 'common.delete', 'Delete', 'en', '2014-07-02 23:10:01', '4028818d46f764fb0146f7661cb60052', 'admin', '2014-07-02 23:42:44', '4028818d46f764fb0146f7661cb60052', 'admin');
INSERT INTO `t_s_muti_lang` VALUES ('4028818d46f7832b0146f7a02ccc0056', 'common.delete', '删除', 'zh-cn', '2014-07-02 23:10:08', '4028818d46f764fb0146f7661cb60052', 'admin', '2014-07-02 23:26:55', '4028818d46f764fb0146f7661cb60052', 'admin');
INSERT INTO `t_s_muti_lang` VALUES ('4028818d46f7832b0146f7a0da820059', 'common.add', 'Add', 'en', '2014-07-02 23:10:53', '4028818d46f764fb0146f7661cb60052', 'admin', '2014-07-02 23:42:57', '4028818d46f764fb0146f7661cb60052', 'admin');
INSERT INTO `t_s_muti_lang` VALUES ('4028818d46f7832b0146f7a106cf005b', 'common.add', '录入', 'zh-cn', '2014-07-02 23:11:04', '4028818d46f764fb0146f7661cb60052', 'admin', '2014-07-02 23:27:13', '4028818d46f764fb0146f7661cb60052', 'admin');
INSERT INTO `t_s_muti_lang` VALUES ('4028818d46f7832b0146f7a1500f005d', 'common.edit', 'Edit', 'en', '2014-07-02 23:11:23', '4028818d46f764fb0146f7661cb60052', 'admin', '2014-07-02 23:43:04', '4028818d46f764fb0146f7661cb60052', 'admin');
INSERT INTO `t_s_muti_lang` VALUES ('4028818d46f7832b0146f7a16f90005f', 'common.edit', '编辑', 'zh-cn', '2014-07-02 23:11:31', '4028818d46f764fb0146f7661cb60052', 'admin', '2014-07-02 23:27:24', '4028818d46f764fb0146f7661cb60052', 'admin');
INSERT INTO `t_s_muti_lang` VALUES ('4028818d46f7832b0146f7a186c20061', 'common.view', 'View', 'en', '2014-07-02 23:11:37', '4028818d46f764fb0146f7661cb60052', 'admin', '2014-07-02 23:43:09', '4028818d46f764fb0146f7661cb60052', 'admin');
INSERT INTO `t_s_muti_lang` VALUES ('4028818d46f7832b0146f7a1aa900063', 'common.view', '查看', 'zh-cn', '2014-07-02 23:11:46', '4028818d46f764fb0146f7661cb60052', 'admin', '2014-07-02 23:27:36', '4028818d46f764fb0146f7661cb60052', 'admin');
INSERT INTO `t_s_muti_lang` VALUES ('4028818d46f7832b0146f7a44eb60065', 'schedule.task.manage', 'Timed Task Manage', 'en', '2014-07-02 23:14:39', '4028818d46f764fb0146f7661cb60052', 'admin', '2014-07-02 23:28:08', '4028818d46f764fb0146f7661cb60052', 'admin');
INSERT INTO `t_s_muti_lang` VALUES ('4028818d46f7832b0146f7a471110067', 'schedule.task.manage', '定时任务管理', 'zh-cn', '2014-07-02 23:14:48', '4028818d46f764fb0146f7661cb60052', 'admin', '2014-07-02 23:27:53', '4028818d46f764fb0146f7661cb60052', 'admin');
INSERT INTO `t_s_muti_lang` VALUES ('4028818d46f7832b0146f7b7f88700a0', 'log.content', 'Log Content', 'en', '2014-07-02 23:36:08', '4028818d46f764fb0146f7661cb60052', 'admin', '2014-07-02 23:41:04', '4028818d46f764fb0146f7661cb60052', 'admin');
INSERT INTO `t_s_muti_lang` VALUES ('4028818d46f7832b0146f7b828ee00a2', 'log.content', '日志内容', 'zh-cn', '2014-07-02 23:36:20', '4028818d46f764fb0146f7661cb60052', 'admin', '2014-07-02 23:27:53', '4028818d46f764fb0146f7661cb60052', 'admin');
INSERT INTO `t_s_muti_lang` VALUES ('4028818d46f7832b0146f7b932f600a4', 'operate.ip', 'Operate IP', 'en', '2014-07-02 23:37:28', '4028818d46f764fb0146f7661cb60052', 'admin', '2014-07-02 23:43:30', '4028818d46f764fb0146f7661cb60052', 'admin');
INSERT INTO `t_s_muti_lang` VALUES ('4028818d46f7832b0146f7b9677100a6', 'operate.ip', '操作IP', 'zh-cn', '2014-07-02 23:37:41', '4028818d46f764fb0146f7661cb60052', 'admin', '2014-07-02 23:27:53', '4028818d46f764fb0146f7661cb60052', 'admin');
INSERT INTO `t_s_muti_lang` VALUES ('4028818d46f7832b0146f7b9bd7d00a8', 'common.browser', 'Broswer', 'en', '2014-07-02 23:38:04', '4028818d46f764fb0146f7661cb60052', 'admin', '2014-07-02 23:43:36', '4028818d46f764fb0146f7661cb60052', 'admin');
INSERT INTO `t_s_muti_lang` VALUES ('4028818d46f7832b0146f7b9f40a00aa', 'common.browser', '浏览器', 'zh-cn', '2014-07-02 23:38:17', '4028818d46f764fb0146f7661cb60052', 'admin', '2014-07-02 23:27:53', '4028818d46f764fb0146f7661cb60052', 'admin');
INSERT INTO `t_s_muti_lang` VALUES ('4028818d46f7832b0146f7ba2e7e00ac', 'operate.time', 'Operate Time', 'en', '2014-07-02 23:38:32', '4028818d46f764fb0146f7661cb60052', 'admin', '2014-07-02 23:43:44', '4028818d46f764fb0146f7661cb60052', 'admin');
INSERT INTO `t_s_muti_lang` VALUES ('4028818d46f7832b0146f7ba610e00ae', 'operate.time', '操作时间', 'zh-cn', '2014-07-02 23:38:45', '4028818d46f764fb0146f7661cb60052', 'admin', '2014-07-02 23:27:53', '4028818d46f764fb0146f7661cb60052', 'admin');
INSERT INTO `t_s_muti_lang` VALUES ('4028818d46f7832b0146f7bb601a00b0', 'log.manage', 'Log Manage', 'en', '2014-07-02 23:39:51', '4028818d46f764fb0146f7661cb60052', 'admin', '2014-07-02 23:27:53', '4028818d46f764fb0146f7661cb60052', 'admin');
INSERT INTO `t_s_muti_lang` VALUES ('4028818d46f7832b0146f7bb7ef200b2', 'log.manage', '日志管理', 'zh-cn', '2014-07-02 23:39:59', '4028818d46f764fb0146f7661cb60052', 'admin', '2014-07-02 23:27:53', '4028818d46f764fb0146f7661cb60052', 'admin');
INSERT INTO `t_s_muti_lang` VALUES ('4028818d46f7832b0146f7bbef3600b4', 'log.level', 'Log Level', 'en', '2014-07-02 23:40:27', '4028818d46f764fb0146f7661cb60052', 'admin', '2014-07-02 23:27:53', '4028818d46f764fb0146f7661cb60052', 'admin');
INSERT INTO `t_s_muti_lang` VALUES ('4028818d46f7832b0146f7c012cd00cc', 'select.loglevel', 'Please select log level', 'en', '2014-07-02 23:44:59', '4028818d46f764fb0146f7661cb60052', 'admin', '2014-07-02 23:27:53', '4028818d46f764fb0146f7661cb60052', 'admin');
INSERT INTO `t_s_muti_lang` VALUES ('4028818d46f7832b0146f7c086ff00ce', 'select.loglevel', '选择日志类型', 'zh-cn', '2014-07-02 23:45:28', '4028818d46f764fb0146f7661cb60052', 'admin', '2014-07-02 23:27:53', '4028818d46f764fb0146f7661cb60052', 'admin');
INSERT INTO `t_s_muti_lang` VALUES ('4028818d46f7832b0146f7c0c98a00d0', 'common.login', 'Login', 'en', '2014-07-02 23:45:45', '4028818d46f764fb0146f7661cb60052', 'admin', '2014-07-02 23:27:53', '4028818d46f764fb0146f7661cb60052', 'admin');
INSERT INTO `t_s_muti_lang` VALUES ('4028818d46f7832b0146f7c0ecb900d2', 'common.login', '登录', 'zh-cn', '2014-07-02 23:45:54', '4028818d46f764fb0146f7661cb60052', 'admin', '2014-07-02 23:27:53', '4028818d46f764fb0146f7661cb60052', 'admin');
INSERT INTO `t_s_muti_lang` VALUES ('4028818d46f7832b0146f7c287de00d9', 'common.insert', 'Insert', 'en', '2014-07-02 23:47:40', '4028818d46f764fb0146f7661cb60052', 'admin', '2014-07-02 23:27:53', '4028818d46f764fb0146f7661cb60052', 'admin');
INSERT INTO `t_s_muti_lang` VALUES ('4028818d46f7832b0146f7c2a1f200db', 'common.insert', '插入', 'zh-cn', '2014-07-02 23:47:46', '4028818d46f764fb0146f7661cb60052', 'admin', '2014-07-02 23:27:53', '4028818d46f764fb0146f7661cb60052', 'admin');
INSERT INTO `t_s_muti_lang` VALUES ('4028818d46f7832b0146f7c4ad4600e1', 'common.update', 'Update', 'en', '2014-07-02 23:50:00', '4028818d46f764fb0146f7661cb60052', 'admin', '2014-07-02 23:27:53', '4028818d46f764fb0146f7661cb60052', 'admin');
INSERT INTO `t_s_muti_lang` VALUES ('4028818d46f7832b0146f7c4dc8700e3', 'common.update', '更新', 'zh-cn', '2014-07-02 23:50:12', '4028818d46f764fb0146f7661cb60052', 'admin', '2014-07-02 23:27:53', '4028818d46f764fb0146f7661cb60052', 'admin');
INSERT INTO `t_s_muti_lang` VALUES ('4028818d46f7832b0146f7c5815c00e5', 'common.upload', 'Upload', 'en', '2014-07-02 23:50:55', '4028818d46f764fb0146f7661cb60052', 'admin', '2014-07-02 23:27:53', '4028818d46f764fb0146f7661cb60052', 'admin');
INSERT INTO `t_s_muti_lang` VALUES ('4028818d46f7832b0146f7c5a60600e7', 'common.upload', '上传', 'zh-cn', '2014-07-02 23:51:04', '4028818d46f764fb0146f7661cb60052', 'admin', '2014-07-02 23:27:53', '4028818d46f764fb0146f7661cb60052', 'admin');
INSERT INTO `t_s_muti_lang` VALUES ('4028818d46f7832b0146f7c5fd5700e9', 'common.other', 'Other', 'en', '2014-07-02 23:51:26', '4028818d46f764fb0146f7661cb60052', 'admin', '2014-07-02 23:27:53', '4028818d46f764fb0146f7661cb60052', 'admin');
INSERT INTO `t_s_muti_lang` VALUES ('4028818d46f7832b0146f7c62c2400eb', 'common.other', '其他', 'zh-cn', '2014-07-02 23:51:38', '4028818d46f764fb0146f7661cb60052', 'admin', '2014-07-02 23:27:53', '4028818d46f764fb0146f7661cb60052', 'admin');
INSERT INTO `t_s_muti_lang` VALUES ('4028818d46fa75be0146fa855c60000e', 'log.level', '日志类型', 'zh-cn', '2014-07-03 12:39:42', '4028818d46f764fb0146f7661cb60052', 'admin', '2014-07-02 23:27:53', '4028818d46f764fb0146f7661cb60052', 'admin');
INSERT INTO `t_s_muti_lang` VALUES ('402881c046efce8d0146effd3b0a0001', 'common.language', '语言', 'zh-cn', '2014-07-01 11:34:48', '8a8ab0b246dc81120146dc8181950052', 'admin', '2014-07-21 11:41:20', '8a8ab0b246dc81120146dc8181950052', 'admin');
INSERT INTO `t_s_muti_lang` VALUES ('402881c046efce8d0146effd5d980003', 'language', 'Languge', 'en', '2014-07-01 11:34:57', '8a8ab0b246dc81120146dc8181950052', 'admin', '2014-07-01 12:01:46', '8a8ab0b246dc81120146dc8181950052', 'admin');
INSERT INTO `t_s_muti_lang` VALUES ('402881c046efce8d0146f001f7cd0007', 'common.delete.success.param', '{0} delete success', 'en', '2014-07-01 11:39:59', '8a8ab0b246dc81120146dc8181950052', 'admin', '2014-07-01 11:40:26', '8a8ab0b246dc81120146dc8181950052', 'admin');
INSERT INTO `t_s_muti_lang` VALUES ('402881c046efce8d0146f00e2152000b', 'common.edit.success.param', '{0} 更新成功', 'zh-cn', '2014-07-01 11:53:16', '8a8ab0b246dc81120146dc8181950052', 'admin', '2014-07-01 12:17:01', '8a8ab0b246dc81120146dc8181950052', 'admin');
INSERT INTO `t_s_muti_lang` VALUES ('402881c046efce8d0146f00f05aa000d', 'common.edit.success.param', '{0} update success', 'en', '2014-07-01 11:54:14', '8a8ab0b246dc81120146dc8181950052', 'admin', '2014-07-20 16:03:05', '8a8ab0b246dc81120146dc8181950052', 'admin');
INSERT INTO `t_s_muti_lang` VALUES ('402881c046efce8d0146f01110bc000f', 'common.add.success.param', '{0} 录入成功', 'zh-cn', '2014-07-01 11:56:28', '8a8ab0b246dc81120146dc8181950052', 'admin', '2014-07-01 11:56:28', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('402881c046efce8d0146f01153070011', 'common.add.success.param', '{0} add success', 'en', '2014-07-01 11:56:45', '8a8ab0b246dc81120146dc8181950052', 'admin', '2014-07-01 11:56:45', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('402881c046f02a3f0146f02d9e910002', 'common.refresh.success', '刷新成功', 'zh-cn', '2014-07-01 12:27:40', '8a8ab0b246dc81120146dc8181950052', 'admin', '2014-07-01 12:27:40', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('402881c046f02a3f0146f02df49c0004', 'common.refresh.success', 'Refresh success', 'en', '2014-07-01 12:28:02', '8a8ab0b246dc81120146dc8181950052', 'admin', '2014-07-01 12:28:02', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('402881c046f02a3f0146f0301b150006', 'common.edit.fail.param', '{0} 更新失败', 'zh-cn', '2014-07-01 12:30:22', '8a8ab0b246dc81120146dc8181950052', 'admin', '2014-07-01 12:30:22', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('402881c046f02a3f0146f030cde00008', 'common.edit.fail.param', '{0} update fail', 'en', '2014-07-01 12:31:08', '8a8ab0b246dc81120146dc8181950052', 'admin', '2014-07-01 12:31:08', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('402881c046f02a3f0146f0346009000a', 'common.refresh.fail', '刷新失败', 'zh-cn', '2014-07-01 12:35:02', '8a8ab0b246dc81120146dc8181950052', 'admin', '2014-07-01 12:35:02', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('402881c046f02a3f0146f0348bc9000c', 'common.refresh.fail', 'Refresh Fail', 'en', '2014-07-01 12:35:13', '8a8ab0b246dc81120146dc8181950052', 'admin', '2014-07-01 12:35:13', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('402881c1470636fe0147063dc2080001', 'database.property', '数据库属性', 'zh-cn', '2014-07-05 19:16:56', '8a8ab0b246dc81120146dc8181950052', 'admin', '2014-07-05 19:16:56', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('402881c1470636fe0147063e03aa0003', 'database.property', 'Database Property', 'en', '2014-07-05 19:17:13', '8a8ab0b246dc81120146dc8181950052', 'admin', '2014-07-05 19:17:13', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('402881c1470636fe0147063e73640005', 'page.property', '页面属性', 'zh-cn', '2014-07-05 19:17:41', '8a8ab0b246dc81120146dc8181950052', 'admin', '2014-07-05 19:17:41', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('402881c1470636fe0147063e910c0007', 'page.property', 'Page Property', 'en', '2014-07-05 19:17:49', '8a8ab0b246dc81120146dc8181950052', 'admin', '2014-07-05 19:17:49', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('402881c1470636fe0147063f9a4a0009', 'validate.dict', 'Validate Dictionary', 'en', '2014-07-05 19:18:57', '8a8ab0b246dc81120146dc8181950052', 'admin', '2014-07-05 19:18:57', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('402881c1470636fe0147063fe101000b', 'validate.dict', '校验字典', 'zh-cn', '2014-07-05 19:19:15', '8a8ab0b246dc81120146dc8181950052', 'admin', '2014-07-05 19:19:15', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('402881c1470636fe014706408c51000d', 'common.fk', '外键', 'zh-cn', '2014-07-05 19:19:59', '8a8ab0b246dc81120146dc8181950052', 'admin', '2014-07-05 19:19:59', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('402881c1470636fe0147064102b0000f', 'common.fk', 'Foreign Key', 'en', '2014-07-05 19:20:29', '8a8ab0b246dc81120146dc8181950052', 'admin', '2014-07-05 19:20:29', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('402881c1470636fe0147065887a70011', 'smark.form.form.maintain', '智能表单-表单维护', 'zh-cn', '2014-07-05 19:46:10', '8a8ab0b246dc81120146dc8181950052', 'admin', '2014-07-05 19:46:10', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('402881c1470636fe01470658c29d0013', 'smark.form.form.maintain', 'Smart Form', 'en', '2014-07-05 19:46:26', '8a8ab0b246dc81120146dc8181950052', 'admin', '2014-07-05 19:46:26', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('402881c1470636fe0147065a870d0015', 'common.one.to.many', '一对多', 'zh-cn', '2014-07-05 19:48:21', '8a8ab0b246dc81120146dc8181950052', 'admin', '2014-07-05 19:48:21', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('402881c1470636fe0147065acd6d0017', 'common.one.to.many', 'One To Many', 'en', '2014-07-05 19:48:39', '8a8ab0b246dc81120146dc8181950052', 'admin', '2014-07-05 19:48:39', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('402881c1470636fe0147065c1d980019', 'comon.one.to.one', '一对一', 'zh-cn', '2014-07-05 19:50:05', '8a8ab0b246dc81120146dc8181950052', 'admin', '2014-07-05 19:50:05', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('402881c1470636fe0147065c3551001b', 'comon.one.to.one', 'One To One', 'en', '2014-07-05 19:50:12', '8a8ab0b246dc81120146dc8181950052', 'admin', '2014-07-05 19:50:12', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('402881c1470636fe0147066041eb001d', 'common.uuid36bit', 'UUID(36位唯一编码)', 'zh-cn', '2014-07-05 19:54:37', '8a8ab0b246dc81120146dc8181950052', 'admin', '2014-07-05 19:54:37', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('402881c1470636fe01470660a327001f', 'common.uuid36bit', 'UUID(36 Bit Unique Code)', 'en', '2014-07-05 19:55:02', '8a8ab0b246dc81120146dc8181950052', 'admin', '2014-07-05 19:55:02', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('402881c1470636fe0147066267e70021', 'common.native.auto.increment', 'NATIVE(自增长方式)', 'zh-cn', '2014-07-05 19:56:58', '8a8ab0b246dc81120146dc8181950052', 'admin', '2014-07-05 19:56:58', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('402881c1470636fe01470662f1dd0023', 'common.native.auto.increment', 'NATIVE(Auto Increment)', 'en', '2014-07-05 19:57:33', '8a8ab0b246dc81120146dc8181950052', 'admin', '2014-07-05 19:57:33', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('402881c1470636fe01470663fbd00025', 'common.sequence', 'SEQUENCE(序列方式)', 'zh-cn', '2014-07-05 19:58:41', '8a8ab0b246dc81120146dc8181950052', 'admin', '2014-07-05 19:58:41', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('402881c1470636fe014706646c6b0027', 'common.sequence', 'SEQUENCE(Sequence)', 'en', '2014-07-05 19:59:10', '8a8ab0b246dc81120146dc8181950052', 'admin', '2014-07-05 19:59:19', '8a8ab0b246dc81120146dc8181950052', 'admin');
INSERT INTO `t_s_muti_lang` VALUES ('402881c1470636fe014706669f32002a', 'please.input.table.name', '请输入表名！', 'zh-cn', '2014-07-05 20:01:34', '8a8ab0b246dc81120146dc8181950052', 'admin', '2014-07-05 20:01:34', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('402881c1470636fe01470666c8e8002c', 'please.input.table.name', 'Please Input Table Name', 'en', '2014-07-05 20:01:45', '8a8ab0b246dc81120146dc8181950052', 'admin', '2014-07-05 20:01:45', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('402881c347203fcc0147204d69020009', 'input.error', '输入错误', 'zh-cn', '2014-07-10 20:44:09', '8a8ab0b246dc81120146dc8181950052', 'admin', '2014-07-10 20:44:09', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('402881c347203fcc0147204d9ef9000b', 'input.error', 'Input error', 'en', '2014-07-10 20:44:23', '8a8ab0b246dc81120146dc8181950052', 'admin', '2014-07-10 20:44:23', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('402881c347205fc0014720704aa50001', 'menuname.rang4to15', '菜单名称范围4~15位字符,且不为空', 'zh-cn', '2014-07-10 21:22:15', '8a8ab0b246dc81120146dc8181950052', 'admin', '2014-07-10 21:22:15', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('402881c347205fc0014720718d360003', 'menuname.rang4to15', 'Menu name should be 4-15 characters and should not empty', 'en', '2014-07-10 21:23:38', '8a8ab0b246dc81120146dc8181950052', 'admin', '2014-07-10 21:23:38', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('402881e446f486df0146f49af73f0001', 'pk.strategies', 'Primary key strategies', 'en', '2014-07-02 09:05:35', '402881e946e70d550146e70fa0680086', 'admin', '2014-07-02 09:05:35', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('402881e446f486df0146f49c57320003', 'pk.strategies', '主键策略', 'zh-cn', '2014-07-02 09:07:05', '402881e946e70d550146e70fa0680086', 'admin', '2014-07-02 09:07:05', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('402881e446f5ec0b0146f5f492d60001', 'table.name', '表名', 'zh-cn', '2014-07-02 15:23:04', '402881e946e70d550146e70fa0680086', 'admin', '2014-07-02 15:23:04', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('402881e446f5ec0b0146f5f4b8fe0003', 'table.name', 'Table Name', 'en', '2014-07-02 15:23:14', '402881e946e70d550146e70fa0680086', 'admin', '2014-07-02 15:23:14', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('402881e446f5ec0b0146f5f536b50005', 'table.description', 'Table Desc', 'en', '2014-07-02 15:23:46', '402881e946e70d550146e70fa0680086', 'admin', '2014-07-21 10:16:11', '8a8ab0b246dc81120146dc8181950052', 'admin');
INSERT INTO `t_s_muti_lang` VALUES ('402881e446f5ec0b0146f5f56e0d0007', 'table.description', '表描述', 'zh-cn', '2014-07-02 15:24:00', '402881e946e70d550146e70fa0680086', 'admin', '2014-07-21 10:16:15', '8a8ab0b246dc81120146dc8181950052', 'admin');
INSERT INTO `t_s_muti_lang` VALUES ('402881e446f5ec0b0146f5f648c00009', 'table.type', 'Table Type', 'en', '2014-07-02 15:24:56', '402881e946e70d550146e70fa0680086', 'admin', '2014-07-02 15:24:56', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('402881e446f5ec0b0146f5f672b6000b', 'table.type', '表类型', 'zh-cn', '2014-07-02 15:25:07', '402881e946e70d550146e70fa0680086', 'admin', '2014-07-02 15:25:07', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('402881e446f5ec0b0146f61534a0000d', 'sequence.name', 'Sequence Name', 'en', '2014-07-02 15:58:43', '402881e946e70d550146e70fa0680086', 'admin', '2014-07-02 15:58:43', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('402881e446f5ec0b0146f621503b0019', 'master.table', '主表', 'zh-cn', '2014-07-02 16:11:56', '402881e946e70d550146e70fa0680086', 'admin', '2014-07-02 16:11:56', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('402881e446f5ec0b0146f621dddd001b', 'master.table', 'Master Table', 'en', '2014-07-02 16:12:33', '402881e946e70d550146e70fa0680086', 'admin', '2014-07-02 16:12:33', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('402881e446f5ec0b0146f6279e0f001d', 'common.yes', 'Yes', 'en', '2014-07-02 16:18:50', '402881e946e70d550146e70fa0680086', 'admin', '2014-07-02 16:18:49', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('402881e446f5ec0b0146f627cd1f001f', 'common.yes', '是', 'zh-cn', '2014-07-02 16:19:02', '402881e946e70d550146e70fa0680086', 'admin', '2014-07-02 16:19:02', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('402881e446f5ec0b0146f627f2040021', 'common.no', 'No', 'en', '2014-07-02 16:19:11', '402881e946e70d550146e70fa0680086', 'admin', '2014-07-02 16:19:11', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('402881e446f5ec0b0146f6281f900023', 'common.no', '否', 'zh-cn', '2014-07-02 16:19:23', '402881e946e70d550146e70fa0680086', 'admin', '2014-07-02 16:19:23', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('402881e446f5ec0b0146f62fe8800025', 'single.query', 'Single Choice Query', 'en', '2014-07-02 16:27:53', '402881e946e70d550146e70fa0680086', 'admin', '2014-07-02 16:27:53', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('402881e446f5ec0b0146f6302a9f0027', 'single.query', '单表查询', 'zh-cn', '2014-07-02 16:28:10', '402881e946e70d550146e70fa0680086', 'admin', '2014-07-02 16:28:10', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('402881e446f5ec0b0146f630e67d0029', 'combine.query', '组合查询', 'zh-cn', '2014-07-02 16:28:58', '402881e946e70d550146e70fa0680086', 'admin', '2014-07-02 16:28:58', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('402881e446f5ec0b0146f6312721002b', 'combine.query', 'Combined Query', 'en', '2014-07-02 16:29:14', '402881e946e70d550146e70fa0680086', 'admin', '2014-07-02 16:29:14', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('402881e446f5ec0b0146f6422c510036', 'common.isnull', 'Is Null', 'en', '2014-07-02 16:47:50', '402881e946e70d550146e70fa0680086', 'admin', '2014-07-02 16:47:50', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('402881e446f5ec0b0146f6428fd00038', 'common.isnull', '是否为空', 'zh-cn', '2014-07-02 16:48:15', '402881e946e70d550146e70fa0680086', 'admin', '2014-07-02 16:48:15', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('402881e446f5ec0b0146f642e30f003a', 'common.pk', 'Primary Key', 'en', '2014-07-02 16:48:37', '402881e946e70d550146e70fa0680086', 'admin', '2014-07-02 16:48:37', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('402881e446f5ec0b0146f64311fb003c', 'common.pk', '主键', 'zh-cn', '2014-07-02 16:48:49', '402881e946e70d550146e70fa0680086', 'admin', '2014-07-02 16:48:49', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('402881e446f5ec0b0146f6457894003e', 'field.type', 'Filed Type', 'en', '2014-07-02 16:51:26', '402881e946e70d550146e70fa0680086', 'admin', '2014-07-02 16:51:26', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('402881e446f5ec0b0146f6459cd30040', 'field.type', '字段类型', 'zh-cn', '2014-07-02 16:51:35', '402881e946e70d550146e70fa0680086', 'admin', '2014-07-02 16:51:35', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('402881e946eca0a40146eca464640011', 'common.version', 'Version', 'en', '2014-06-30 19:58:55', '402881e946e70d550146e70fa0680086', 'admin', '2014-06-30 19:58:55', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('402881e946eca0a40146eca47e280013', 'common.version', '版本', 'zh-cn', '2014-06-30 19:59:01', '402881e946e70d550146e70fa0680086', 'admin', '2014-06-30 19:59:01', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('402881e946eca0a40146eca4b6bf0015', 'is.tree', 'Is Tree', 'en', '2014-06-30 19:59:16', '402881e946e70d550146e70fa0680086', 'admin', '2014-06-30 19:59:16', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('402881e946eca0a40146eca4d8ba0017', 'is.tree', '是否树', 'zh-cn', '2014-06-30 19:59:24', '402881e946e70d550146e70fa0680086', 'admin', '2014-06-30 19:59:24', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('402881e946eca0a40146eca510d60019', 'is.page', 'Is Page', 'en', '2014-06-30 19:59:39', '402881e946e70d550146e70fa0680086', 'admin', '2014-06-30 19:59:39', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('402881e946eca0a40146eca537b7001b', 'is.page', '是否分页', 'zh-cn', '2014-06-30 19:59:49', '402881e946e70d550146e70fa0680086', 'admin', '2014-06-30 19:59:49', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('402881e946eca0a40146eca6c3b8001d', 'sync.db', 'Sync DB', 'en', '2014-06-30 20:01:30', '402881e946e70d550146e70fa0680086', 'admin', '2014-06-30 20:01:30', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('402881e946eca0a40146eca7193f001f', 'sync.db', '同步数据库', 'zh-cn', '2014-06-30 20:01:52', '402881e946e70d550146e70fa0680086', 'admin', '2014-06-30 20:01:52', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('402881e946eca0a40146eca922890025', 'common.createtime', 'Create Time', 'en', '2014-06-30 20:04:05', '402881e946e70d550146e70fa0680086', 'admin', '2014-06-30 20:04:05', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('402881e946eca0a40146ecab61a50033', 'common.createtime', '创建时间', 'zh-cn', '2014-06-30 20:06:33', '402881e946e70d550146e70fa0680086', 'admin', '2014-06-30 20:53:48', '402881e946e70d550146e70fa0680086', 'admin');
INSERT INTO `t_s_muti_lang` VALUES ('402881e946eca0a40146ecac51520039', 'show.checkbox', 'Show Checkbox', 'en', '2014-06-30 20:07:34', '402881e946e70d550146e70fa0680086', 'admin', '2014-06-30 20:07:34', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('402881e946eca0a40146ecac8bed003b', 'show.checkbox', '显示复选框', 'zh-cn', '2014-06-30 20:07:49', '402881e946e70d550146e70fa0680086', 'admin', '2014-06-30 20:07:49', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('402881e946eca0a40146ecaea5630041', 'edit.form', 'Edit Table', 'en', '2014-06-30 20:10:07', '402881e946e70d550146e70fa0680086', 'admin', '2014-06-30 20:10:07', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('402881e946eca0a40146ecaed7730043', 'edit.form', '编辑表单', 'zh-cn', '2014-06-30 20:10:19', '402881e946e70d550146e70fa0680086', 'admin', '2014-06-30 20:10:19', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('402881e946eca0a40146ecaf39000045', 'create.form', 'Create From', 'en', '2014-06-30 20:10:44', '402881e946e70d550146e70fa0680086', 'admin', '2014-06-30 20:10:44', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('402881e946eca0a40146ecaf63e00047', 'create.form', '创建表单', 'zh-cn', '2014-06-30 20:10:55', '402881e946e70d550146e70fa0680086', 'admin', '2014-06-30 20:10:55', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('402881e946eca0a40146ecb108de0049', 'custom.button', 'Custom Button', 'en', '2014-06-30 20:12:43', '402881e946e70d550146e70fa0680086', 'admin', '2014-06-30 20:12:43', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('402881e946eca0a40146ecb18fa6004b', 'custom.button', '自定义按钮', 'zh-cn', '2014-06-30 20:13:18', '402881e946e70d550146e70fa0680086', 'admin', '2014-06-30 20:13:31', '402881e946e70d550146e70fa0680086', 'admin');
INSERT INTO `t_s_muti_lang` VALUES ('402881e946eca0a40146ecb3bd13004e', 'form.generate', 'Generated From From DB', 'en', '2014-06-30 20:15:40', '402881e946e70d550146e70fa0680086', 'admin', '2014-09-15 11:28:33', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('402881e946eca0a40146ecb3f9df0050', 'form.generate', '数据库导入表单', 'zh-cn', '2014-06-30 20:15:56', '402881e946e70d550146e70fa0680086', 'admin', '2014-09-15 11:28:19', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('402881e946eca0a40146ecb58ed40052', 'form.import', '表单导入', 'zh-cn', '2014-06-30 20:17:40', '402881e946e70d550146e70fa0680086', 'admin', '2014-09-15 11:28:01', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('402881e946eca0a40146ecb5a76b0054', 'form.import', 'From Import', 'en', '2014-06-30 20:17:46', '402881e946e70d550146e70fa0680086', 'admin', '2014-06-30 20:17:46', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('402881e946eca0a40146ecb72e600056', 'form.export', 'From Export', 'en', '2014-06-30 20:19:26', '402881e946e70d550146e70fa0680086', 'admin', '2014-06-30 20:19:26', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('402881e946eca0a40146ecb762b50058', 'form.export', '表单导出', 'zh-cn', '2014-06-30 20:19:39', '402881e946e70d550146e70fa0680086', 'admin', '2014-06-30 20:40:55', '402881e946e70d550146e70fa0680086', 'admin');
INSERT INTO `t_s_muti_lang` VALUES ('402881e946eca0a40146ecc71340005a', 'js.enhance', 'JsEnhance', 'en', '2014-06-30 20:36:48', '402881e946e70d550146e70fa0680086', 'admin', '2014-06-30 20:36:48', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('402881e946eca0a40146ecc74476005c', 'js.enhance', 'js增强', 'zh-cn', '2014-06-30 20:37:00', '402881e946e70d550146e70fa0680086', 'admin', '2014-06-30 20:37:00', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('402881e946eca0a40146ecca27d20062', 'sql.enhance', 'SqlEnhance', 'en', '2014-06-30 20:40:09', '402881e946e70d550146e70fa0680086', 'admin', '2014-06-30 20:40:09', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('402881e946eca0a40146ecca51c60064', 'sql.enhance', 'sql增强', 'zh-cn', '2014-06-30 20:40:20', '402881e946e70d550146e70fa0680086', 'admin', '2014-06-30 20:40:20', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('402881e946eca0a40146ecd312230068', 'smart.form.config', 'Smart Form Config', 'en', '2014-06-30 20:49:54', '402881e946e70d550146e70fa0680086', 'admin', '2014-06-30 20:49:54', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('402881e946eca0a40146ecd3732a006a', 'smart.form.config', '只能表单配置', 'zh-cn', '2014-06-30 20:50:19', '402881e946e70d550146e70fa0680086', 'admin', '2014-06-30 20:50:19', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('402881e946f723300146f728bca20001', 'common.code', 'Code', 'en', '2014-07-02 20:59:40', '402881e946e70d550146e70fa0680086', 'admin', '2014-07-02 20:59:40', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('402881e946f723300146f728e6220003', 'common.code', '编码', 'zh-cn', '2014-07-02 20:59:51', '402881e946e70d550146e70fa0680086', 'admin', '2014-07-02 20:59:51', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('402881e946f723300146f72b42b40015', 'common.batch.delete', 'Batch Delete', 'en', '2014-07-02 21:02:25', '402881e946e70d550146e70fa0680086', 'admin', '2014-07-02 21:02:25', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('402881e946f723300146f72b9a000017', 'common.batch.delete', '批量删除', 'zh-cn', '2014-07-02 21:02:48', '402881e946e70d550146e70fa0680086', 'admin', '2014-07-02 21:02:48', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('402881e946f723300146f72ce5260021', 'query.sql', 'Query Sql', 'en', '2014-07-02 21:04:13', '402881e946e70d550146e70fa0680086', 'admin', '2014-07-02 21:04:13', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('402881e946f723300146f72d1b480023', 'query.sql', '查询sql', 'zh-cn', '2014-07-02 21:04:26', '402881e946e70d550146e70fa0680086', 'admin', '2014-07-02 21:04:26', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('402881e946f723300146f72d54c60025', 'common.name', 'Name', 'en', '2014-07-02 21:04:41', '402881e946e70d550146e70fa0680086', 'admin', '2014-07-02 21:04:41', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('402881e946f723300146f72d72840027', 'common.name', '名称', 'zh-cn', '2014-07-02 21:04:49', '402881e946e70d550146e70fa0680086', 'admin', '2014-07-02 21:04:49', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('402881e946f723300146f72e486c0029', 'dynamic.table.head', 'Dynamic Table', 'en', '2014-07-02 21:05:44', '402881e946e70d550146e70fa0680086', 'admin', '2014-07-02 21:05:44', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('402881e946f723300146f72e7bda002b', 'dynamic.table.head', '动态表头', 'zh-cn', '2014-07-02 21:05:57', '402881e946e70d550146e70fa0680086', 'admin', '2014-07-02 21:05:57', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('402881ea4706d22b014706da32a10009', 'common.order', 'Order', 'en', '2014-07-05 22:07:48', '402881e946e70d550146e70fa0680086', 'admin', '2014-07-05 22:07:48', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('402881ea4706d22b014706da55fa000b', 'common.order', '排序', 'zh-cn', '2014-07-05 22:07:57', '402881e946e70d550146e70fa0680086', 'admin', '2014-07-05 22:07:57', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('402881ea4706d22b014706daa606000d', 'common.text', 'Text', 'en', '2014-07-05 22:08:18', '402881e946e70d550146e70fa0680086', 'admin', '2014-07-05 22:08:18', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('402881ea4706d22b014706dadb74000f', 'common.text', '文本框', 'zh-cn', '2014-07-05 22:08:32', '402881e946e70d550146e70fa0680086', 'admin', '2014-07-05 22:08:32', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('402881ea4706d22b014706db1a6f0011', 'common.type', 'Type', 'en', '2014-07-05 22:08:48', '402881e946e70d550146e70fa0680086', 'admin', '2014-07-05 22:08:48', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('402881ea4706d22b014706db389d0013', 'common.type', '类型', 'zh-cn', '2014-07-05 22:08:55', '402881e946e70d550146e70fa0680086', 'admin', '2014-07-05 22:08:55', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('402881ea4706d22b014706db76390015', 'common.isshow', 'Is Show', 'en', '2014-07-05 22:09:11', '402881e946e70d550146e70fa0680086', 'admin', '2014-07-05 22:09:11', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('402881ea4706d22b014706db99420017', 'common.isshow', '是否显示', 'zh-cn', '2014-07-05 22:09:20', '402881e946e70d550146e70fa0680086', 'admin', '2014-07-05 22:09:20', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('402881ea4706d22b014706dbdb330019', 'common.href', 'Href', 'en', '2014-07-05 22:09:37', '402881e946e70d550146e70fa0680086', 'admin', '2014-07-05 22:09:37', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('402881ea4706d22b014706dc0bfe001b', 'common.href', '字段href', 'zh-cn', '2014-07-05 22:09:50', '402881e946e70d550146e70fa0680086', 'admin', '2014-07-05 22:09:50', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('402881ea4706d22b014706dc5fc0001d', 'common.query.module', 'Query Module', 'en', '2014-07-05 22:10:11', '402881e946e70d550146e70fa0680086', 'admin', '2014-07-05 22:10:11', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('402881ea4706d22b014706dc87df001f', 'common.query.module', '查询模式', 'zh-cn', '2014-07-05 22:10:21', '402881e946e70d550146e70fa0680086', 'admin', '2014-07-05 22:10:21', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('402881ea4706d22b014706dd524d0021', 'dict.code', '字典Code', 'zh-cn', '2014-07-05 22:11:13', '402881e946e70d550146e70fa0680086', 'admin', '2014-07-05 22:11:13', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('402881ea4706d22b014706dd8a300023', 'dict.code', 'Dict Code', 'en', '2014-07-05 22:11:27', '402881e946e70d550146e70fa0680086', 'admin', '2014-07-05 22:11:27', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('402881ea4706d22b014706ddc7570025', 'common.isquery', 'Is Query', 'en', '2014-07-05 22:11:43', '402881e946e70d550146e70fa0680086', 'admin', '2014-07-05 22:11:43', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('402881ea4706d22b014706ddec9e0027', 'common.isquery', '是否查询', 'zh-cn', '2014-07-05 22:11:53', '402881e946e70d550146e70fa0680086', 'admin', '2014-07-05 22:11:53', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('402881ea4706d22b014706e230b80029', 'common.text.type', 'Column Type', 'en', '2014-07-05 22:16:32', '402881e946e70d550146e70fa0680086', 'admin', '2014-07-05 22:16:32', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('402881ea4706d22b014706e25a9f002b', 'common.text.type', '文本类型', 'zh-cn', '2014-07-05 22:16:43', '402881e946e70d550146e70fa0680086', 'admin', '2014-07-05 22:16:43', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('402881ea4706d22b014706e368c9002d', 'common.hide', 'Hideen', 'en', '2014-07-05 22:17:52', '402881e946e70d550146e70fa0680086', 'admin', '2014-07-05 22:17:52', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('402881ea4706d22b014706e3b1e2002f', 'common.hide', '隐藏', 'zh-cn', '2014-07-05 22:18:11', '402881e946e70d550146e70fa0680086', 'admin', '2014-07-05 22:18:11', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('402881ea4706d22b014706e3fe800031', 'common.show', 'Show', 'en', '2014-07-05 22:18:30', '402881e946e70d550146e70fa0680086', 'admin', '2014-07-05 22:18:30', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('402881ea4706d22b014706e423e40033', 'common.show', '显示', 'zh-cn', '2014-07-05 22:18:40', '402881e946e70d550146e70fa0680086', 'admin', '2014-07-05 22:18:40', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('402881ea4706d22b014706eba47c003e', 'dynamic.report.config.detail', 'Dyna Report Detail', 'en', '2014-07-05 22:26:52', '402881e946e70d550146e70fa0680086', 'admin', '2014-07-05 22:29:53', '402881e946e70d550146e70fa0680086', 'admin');
INSERT INTO `t_s_muti_lang` VALUES ('402881ea4706d22b014706ebe1cd0040', 'dynamic.report.config.detail', '动态报表配置明细', 'zh-cn', '2014-07-05 22:27:07', '402881e946e70d550146e70fa0680086', 'admin', '2014-07-05 22:30:02', '402881e946e70d550146e70fa0680086', 'admin');
INSERT INTO `t_s_muti_lang` VALUES ('402881fa470fe92601470fefea200003', 'dict.manage', '数据字典管理', 'zh-cn', '2014-07-07 16:28:07', '4028818d46f764fb0146f7661cb60052', 'admin', '2014-07-07 16:42:54', '4028818d46f764fb0146f7661cb60052', 'admin');
INSERT INTO `t_s_muti_lang` VALUES ('402881fa470fe92601470ff21ddd0009', 'dict.name', 'Dict Name', 'en', '2014-07-07 16:30:31', '4028818d46f764fb0146f7661cb60052', 'admin', '2014-07-07 16:42:54', '4028818d46f764fb0146f7661cb60052', 'admin');
INSERT INTO `t_s_muti_lang` VALUES ('402881fa470fe92601470ff24cb8000b', 'dict.name', '字典名称', 'zh-cn', '2014-07-07 16:30:43', '4028818d46f764fb0146f7661cb60052', 'admin', '2014-07-07 16:42:54', '4028818d46f764fb0146f7661cb60052', 'admin');
INSERT INTO `t_s_muti_lang` VALUES ('402881fa470fe92601470ff4e2830019', 'common.add.param', '{0} Add', 'en', '2014-07-07 16:33:33', '4028818d46f764fb0146f7661cb60052', 'admin', '2014-07-20 16:02:09', '8a8ab0b246dc81120146dc8181950052', 'admin');
INSERT INTO `t_s_muti_lang` VALUES ('402881fa470fe92601470ff51cc9001b', 'common.add.param', '{0}录入', 'zh-cn', '2014-07-07 16:33:48', '4028818d46f764fb0146f7661cb60052', 'admin', '2014-07-20 16:02:23', '8a8ab0b246dc81120146dc8181950052', 'admin');
INSERT INTO `t_s_muti_lang` VALUES ('402881fa470fe92601470ff925da0025', 'dict.information.type', 'Data Dictionary Group Info', 'en', '2014-07-07 16:38:12', '4028818d46f764fb0146f7661cb60052', 'admin', '2014-07-07 16:42:54', '4028818d46f764fb0146f7661cb60052', 'admin');
INSERT INTO `t_s_muti_lang` VALUES ('402881fa470fe92601470ff950100027', 'dict.information.type', '字典类型信息', 'zh-cn', '2014-07-07 16:38:23', '4028818d46f764fb0146f7661cb60052', 'admin', '2014-07-07 16:43:03', '4028818d46f764fb0146f7661cb60052', 'admin');
INSERT INTO `t_s_muti_lang` VALUES ('402881fa470fe92601471005919a0037', 'common.role.list', 'Role List', 'en', '2014-07-07 16:51:46', '4028818d46f764fb0146f7661cb60052', 'admin', '2014-07-07 16:42:54', '4028818d46f764fb0146f7661cb60052', 'admin');
INSERT INTO `t_s_muti_lang` VALUES ('402881fa470fe92601471005f5ac0039', 'common.role.list', '角色列表', 'zh-cn', '2014-07-07 16:52:12', '4028818d46f764fb0146f7661cb60052', 'admin', '2014-07-07 16:42:54', '4028818d46f764fb0146f7661cb60052', 'admin');
INSERT INTO `t_s_muti_lang` VALUES ('402881fa470fe92601471006c0bf003f', 'common.role.code', 'Role Code', 'en', '2014-07-07 16:53:04', '4028818d46f764fb0146f7661cb60052', 'admin', '2014-07-07 16:42:54', '4028818d46f764fb0146f7661cb60052', 'admin');
INSERT INTO `t_s_muti_lang` VALUES ('402881fa470fe92601471006e44a0041', 'common.role.code', '角色编码', 'zh-cn', '2014-07-07 16:53:13', '4028818d46f764fb0146f7661cb60052', 'admin', '2014-07-07 16:42:54', '4028818d46f764fb0146f7661cb60052', 'admin');
INSERT INTO `t_s_muti_lang` VALUES ('402881fa470fe9260147100713840043', 'common.role.name', 'Role Name', 'en', '2014-07-07 16:53:25', '4028818d46f764fb0146f7661cb60052', 'admin', '2014-07-07 16:42:54', '4028818d46f764fb0146f7661cb60052', 'admin');
INSERT INTO `t_s_muti_lang` VALUES ('402881fa470fe926014710073e820045', 'common.role.name', '角色名称', 'zh-cn', '2014-07-07 16:53:36', '4028818d46f764fb0146f7661cb60052', 'admin', '2014-07-07 16:42:54', '4028818d46f764fb0146f7661cb60052', 'admin');
INSERT INTO `t_s_muti_lang` VALUES ('402881fa470fe926014710095eb50053', 'common.edit.param', '{0} Edit', 'en', '2014-07-07 16:55:55', '4028818d46f764fb0146f7661cb60052', 'admin', '2014-07-20 15:07:04', '8a8ab0b246dc81120146dc8181950052', 'admin');
INSERT INTO `t_s_muti_lang` VALUES ('402881fa470fe9260147100980ee0055', 'common.edit.param', '{0}编辑', 'zh-cn', '2014-07-07 16:56:04', '4028818d46f764fb0146f7661cb60052', 'admin', '2014-07-20 15:07:13', '8a8ab0b246dc81120146dc8181950052', 'admin');
INSERT INTO `t_s_muti_lang` VALUES ('402881fa470fe9260147100affff0057', 'common.role.info', 'Role Info', 'en', '2014-07-07 16:57:42', '4028818d46f764fb0146f7661cb60052', 'admin', '2014-07-07 16:42:54', '4028818d46f764fb0146f7661cb60052', 'admin');
INSERT INTO `t_s_muti_lang` VALUES ('402881fa470fe9260147100b20eb0059', 'common.role.info', '角色信息', 'zh-cn', '2014-07-07 16:57:51', '4028818d46f764fb0146f7661cb60052', 'admin', '2014-07-07 16:42:54', '4028818d46f764fb0146f7661cb60052', 'admin');
INSERT INTO `t_s_muti_lang` VALUES ('402881fa470fe9260147100bf680005b', 'permission.set', 'Permission', 'en', '2014-07-07 16:58:45', '4028818d46f764fb0146f7661cb60052', 'admin', '2014-07-07 16:42:54', '4028818d46f764fb0146f7661cb60052', 'admin');
INSERT INTO `t_s_muti_lang` VALUES ('402881fa470fe9260147100c2c96005d', 'permission.set', '权限设置', 'zh-cn', '2014-07-07 16:58:59', '4028818d46f764fb0146f7661cb60052', 'admin', '2014-07-07 16:42:54', '4028818d46f764fb0146f7661cb60052', 'admin');
INSERT INTO `t_s_muti_lang` VALUES ('402881fa470fe9260147100e5051005f', 'permission.manage', 'Permission Manage', 'en', '2014-07-07 17:01:19', '4028818d46f764fb0146f7661cb60052', 'admin', '2014-07-07 16:42:54', '4028818d46f764fb0146f7661cb60052', 'admin');
INSERT INTO `t_s_muti_lang` VALUES ('402881fa470fe9260147100e8a360061', 'permission.manage', '权限管理', 'zh-cn', '2014-07-07 17:01:34', '4028818d46f764fb0146f7661cb60052', 'admin', '2014-07-07 16:42:54', '4028818d46f764fb0146f7661cb60052', 'admin');
INSERT INTO `t_s_muti_lang` VALUES ('402881fa470fe9260147100f73140067', 'permission.name', 'Permission Name', 'en', '2014-07-07 17:02:34', '4028818d46f764fb0146f7661cb60052', 'admin', '2014-07-07 16:42:54', '4028818d46f764fb0146f7661cb60052', 'admin');
INSERT INTO `t_s_muti_lang` VALUES ('402881fa470fe9260147100fa9270069', 'permission.name', '权限名称', 'zh-cn', '2014-07-07 17:02:48', '4028818d46f764fb0146f7661cb60052', 'admin', '2014-07-07 16:42:54', '4028818d46f764fb0146f7661cb60052', 'admin');
INSERT INTO `t_s_muti_lang` VALUES ('402881fa470fe9260147101199f1006f', 'permission.collection', 'Permission Collection', 'en', '2014-07-07 17:04:55', '4028818d46f764fb0146f7661cb60052', 'admin', '2014-07-07 16:42:54', '4028818d46f764fb0146f7661cb60052', 'admin');
INSERT INTO `t_s_muti_lang` VALUES ('402881fa470fe92601471011bb380071', 'permission.collection', '权限集合', 'zh-cn', '2014-07-07 17:05:03', '4028818d46f764fb0146f7661cb60052', 'admin', '2014-07-07 16:42:54', '4028818d46f764fb0146f7661cb60052', 'admin');
INSERT INTO `t_s_muti_lang` VALUES ('402884f146cc37ab0146cc3fc7350002', 'common.change.refresh', '样式修改成功，请刷新页面', 'zh-cn', '2014-06-24 13:01:10', 'admin', '管理员', '2014-06-24 13:01:10', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('402884f146cc37ab0146cc4029a60004', 'common.change.refresh', 'Style change success, please refresh', 'en', '2014-06-24 13:01:35', 'admin', '管理员', '2014-06-24 13:01:35', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('402884f146cc37ab0146cc4541cb0006', 'common.login.again', '请登录后再操作', 'zh-cn', '2014-06-24 13:07:09', 'admin', '管理员', '2014-06-24 13:07:09', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('402884f146cc37ab0146cc45c1270008', 'common.login.again', 'Please login again', 'en', '2014-06-24 13:07:41', 'admin', '管理员', '2014-06-24 13:07:41', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('402884f146cc37ab0146cc4de4da000a', 'common.userinfo', '用户信息', 'zh-cn', '2014-06-24 13:16:35', 'admin', '管理员', '2014-06-24 13:16:35', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('402884f146cc37ab0146cc4e7b25000c', 'common.userinfo', 'My Profile', 'en', '2014-06-24 13:17:13', 'admin', '管理员', '2014-06-24 13:17:13', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('402884f146cc37ab0146cc55cac30012', 'common.surname', '姓名', 'zh-cn', '2014-06-24 13:25:13', 'admin', '管理员', '2014-06-24 13:25:13', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('402884f146cc37ab0146cc55f21b0014', 'common.surname', 'Name', 'en', '2014-06-24 13:25:23', 'admin', '管理员', '2014-06-24 13:25:23', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('40289f45541a226301541a2b084a000b', 'common.start', '启动任务', 'zh-cn', '2016-04-15 21:45:08', 'admin', '管理员', '2016-04-15 21:46:21', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('40289f45541a226301541a2bfaf8000d', 'effective.immediately', '更新任务时间', 'zh-cn', '2016-04-15 21:46:10', 'admin', '管理员', null, null, null);
INSERT INTO `t_s_muti_lang` VALUES ('4028fc4d46c481da0146c4a15aa60003', 'common.calendar', '日历', 'zh-cn', '2014-06-23 01:30:47', 'admin', '管理员', '2014-06-23 01:30:47', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('4028fc4d46c481da0146c4a190580005', 'common.calendar', 'Calendar', 'en', '2014-06-23 01:31:01', 'admin', '管理员', '2014-06-23 01:31:01', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('4028fc4d46c481da0146c4a2dc220007', 'common.map', '地图', 'zh-cn', '2014-06-23 01:32:26', 'admin', '管理员', '2014-06-23 01:32:26', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('4028fc4d46c481da0146c4a2f24e0009', 'common.map', 'Map', 'en', '2014-06-23 01:32:31', 'admin', '管理员', '2014-06-23 01:32:31', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('4028fc4d46c481da0146c4aff7ea000b', 'common.please.select', '---请选择---', 'zh-cn', '2014-06-23 01:46:45', 'admin', '管理员', '2014-06-23 01:46:45', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('4028fc4d46c481da0146c4b03310000d', 'common.please.select', 'Please Select', 'en', '2014-06-23 01:47:00', 'admin', '管理员', '2014-06-23 02:01:20', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('4028fc4d46c481da0146c4b8af79000f', 'common.please.input.keyword', '请输入关键字', 'zh-cn', '2014-06-23 01:56:16', 'admin', '管理员', '2014-06-23 01:56:16', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('4028fc4d46c481da0146c4b8f7aa0011', 'common.please.input.keyword', 'Keyword', 'en', '2014-06-23 01:56:34', 'admin', '管理员', '2014-06-23 01:56:34', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('4028fc4d46c481da0146c4ba979a0013', 'common.please.input.query.keyword', '请输入查询关键字', 'zh-cn', '2014-06-23 01:58:21', 'admin', '管理员', '2014-06-23 01:58:21', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('4028fc4d46c481da0146c4bade820015', 'common.please.input.query.keyword', 'Query keyword', 'en', '2014-06-23 01:58:39', 'admin', '管理员', '2014-06-23 01:58:39', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('4028fc4d46c481da0146c4bee05c0018', 'common.query', '查询', 'zh-cn', '2014-06-23 02:03:02', 'admin', '管理员', '2014-06-23 02:03:02', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('4028fc4d46c481da0146c4bf0575001a', 'common.query', 'Query', 'en', '2014-06-23 02:03:11', 'admin', '管理员', '2014-06-23 02:03:11', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('4028fc4d46c481da0146c4bf4239001c', 'common.reset', '重置', 'zh-cn', '2014-06-23 02:03:27', 'admin', '管理员', '2014-06-23 02:03:27', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('4028fc4d46c481da0146c4bf638a001e', 'common.reset', 'Reset', 'en', '2014-06-23 02:03:35', 'admin', '管理员', '2014-06-23 02:03:35', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('4028fc5346c18cdc0146c19fa9370004', 'common.navegation', '导航菜单', 'zh-cn', '2014-06-22 11:30:04', 'admin', '管理员', '2014-06-22 11:30:04', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('4028fc5346c18cdc0146c1a0a4d50006', 'common.navegation', 'Navegation', 'en', '2014-06-22 11:31:09', 'admin', '管理员', '2014-06-22 11:31:09', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('4028fc5346c18cdc0146c1a1b46e0008', 'common.control.panel', 'Control Panel', 'en', '2014-06-22 11:32:18', 'admin', '管理员', '2014-06-22 11:32:18', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('4028fc5346c18cdc0146c1a1e59b000a', 'common.control.panel', '控制面板', 'zh-cn', '2014-06-22 11:32:31', 'admin', '管理员', '2014-06-22 11:32:31', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('4028fc5346c18cdc0146c1a2d668000c', 'common.profile', '个人信息', 'zh-cn', '2014-06-22 11:33:32', 'admin', '管理员', '2014-06-22 11:33:32', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('4028fc5346c18cdc0146c1a31e02000e', 'common.profile', 'Profile', 'en', '2014-06-22 11:33:51', 'admin', '管理员', '2014-06-22 11:33:51', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('4028fc5346c18cdc0146c1a386000010', 'common.my.style', '首页风格', 'zh-cn', '2014-06-22 11:34:17', 'admin', '管理员', '2014-06-22 11:34:17', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('4028fc5346c18cdc0146c1a3bccd0012', 'common.my.style', 'Style', 'en', '2014-06-22 11:34:31', 'admin', '管理员', '2014-06-22 11:34:31', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('4028fc5346c18cdc0146c1a412670014', 'common.logout', '注销', 'zh-cn', '2014-06-22 11:34:53', 'admin', '管理员', '2014-06-22 11:36:06', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('4028fc5346c18cdc0146c1a4f99a0016', 'common.logout', 'Logout', 'en', '2014-06-22 11:35:52', 'admin', '管理员', '2014-06-22 11:35:52', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('4028fc5346c18cdc0146c1a5edff0019', 'common.exit', '退出', 'zh-cn', '2014-06-22 11:36:55', 'admin', '管理员', '2014-06-22 11:36:55', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('4028fc5346c18cdc0146c1a60dff001b', 'common.exit', 'Exit', 'en', '2014-06-22 11:37:03', 'admin', '管理员', '2014-06-22 11:37:03', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('4028fc5346c18cdc0146c1a85f8e001d', 'common.user', 'User', 'en', '2014-06-22 11:39:35', 'admin', '管理员', '2014-06-22 11:39:35', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('4028fc5346c18cdc0146c1a88d9b001f', 'common.user', '用户', 'zh-cn', '2014-06-22 11:39:47', 'admin', '管理员', '2014-06-22 11:39:47', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('4028fc5346c18cdc0146c1aae98c0025', 'system.title', 'BMS演示系统', 'zh-cn', '2014-06-22 11:42:22', 'admin', '管理员', '2015-10-30 15:02:38', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('4028fc5346c1aec50146c1e09ce00017', 'lang.maintain', '语言信息维护', 'zh-cn', '2014-06-22 12:41:01', 'admin', '管理员', '2014-06-22 12:41:01', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('4028fc5346c1aec50146c1e0f0780019', 'lang.maintain', 'Language Maintain', 'en', '2014-06-22 12:41:22', 'admin', '管理员', '2014-06-23 13:37:39', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('4028fc5346c1aec50146c1ea9872002b', 'online.develop', 'Online Develop', 'en', '2014-06-22 12:51:55', 'admin', '管理员', '2014-06-22 12:51:55', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('4028fc5346c1aec50146c1eaf4d6002d', 'online.develop', 'Online 开发', 'zh-cn', '2014-06-22 12:52:19', 'admin', '管理员', '2014-06-22 12:52:19', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('4028fc5346c1aec50146c1eb749c002f', 'system.manage', '系统管理', 'zh-cn', '2014-06-22 12:52:51', 'admin', '管理员', '2014-06-22 12:52:51', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('4028fc5346c1aec50146c1ebac710031', 'system.manage', 'System Manage', 'en', '2014-06-22 12:53:06', 'admin', '管理员', '2014-06-22 12:53:06', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('4028fc5346c1aec50146c1ec37a10033', 'project.manage', '项目管理', 'zh-cn', '2014-06-22 12:53:41', 'admin', '管理员', '2014-06-22 12:53:41', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('4028fc5346c1aec50146c1ec67a40035', 'project.manage', 'Project Manage', 'en', '2014-06-22 12:53:54', 'admin', '管理员', '2014-06-22 12:53:54', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('4028fc5346c1aec50146c1ed9e6e0037', 'general.demo', '常用示例', 'zh-cn', '2014-06-22 12:55:13', 'admin', '管理员', '2014-06-22 12:55:13', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('4028fc5346c1aec50146c1edcc6d0039', 'general.demo', 'Demo', 'en', '2014-06-22 12:55:25', 'admin', '管理员', '2014-06-22 12:55:25', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('4028fc5346c1aec50146c1ee629d003b', 'system.monitor', '系统监控', 'zh-cn', '2014-06-22 12:56:03', 'admin', '管理员', '2014-06-22 12:56:03', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('4028fc5346c1aec50146c1eebe6c003d', 'system.monitor', 'System Monitor', 'en', '2014-06-22 12:56:27', 'admin', '管理员', '2014-06-22 12:56:27', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('4028fc5346c1aec50146c1ef4206003f', 'workflow.manage', '工作流管理', 'zh-cn', '2014-06-22 12:57:01', 'admin', '管理员', '2014-06-22 12:57:01', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('4028fc5346c1aec50146c1ef78d20041', 'workflow.manage', 'Workflow Manage', 'en', '2014-06-22 12:57:15', 'admin', '管理员', '2014-06-22 12:57:15', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('4028fc5346c1aec50146c1fe512f0045', 'common.change.password', '修改密码', 'zh-cn', '2014-06-22 13:13:28', 'admin', '管理员', '2014-06-22 13:13:28', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('4028fc5346c1aec50146c1fe90260047', 'common.change.password', 'Change Password', 'en', '2014-06-22 13:13:44', 'admin', '管理员', '2014-06-22 13:13:44', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('4028fc5346c1aec50146c202c92c0049', 'common.copyright', 'BMS版权所有', 'zh-cn', '2014-06-22 13:18:20', 'admin', '管理员', '2015-10-29 18:03:44', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('4028fc5346c1aec50146c203cd8d004b', 'common.copyright', 'BMS Copyright Reserved', 'zh-cn', '2014-06-22 13:19:27', 'admin', '管理员', '2015-10-29 18:03:55', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('4028fc5346c1aec50146c20508bf004d', 'common.refresh', '刷新', 'zh-cn', '2014-06-22 13:20:48', 'admin', '管理员', '2014-06-22 13:20:48', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('4028fc5346c1aec50146c2053659004f', 'common.refresh', 'Refresh', 'en', '2014-06-22 13:20:59', 'admin', '管理员', '2014-06-22 13:20:59', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('4028fc5346c1aec50146c2057c580051', 'common.close', 'Close', 'en', '2014-06-22 13:21:17', 'admin', '管理员', '2014-06-22 13:21:17', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('4028fc5346c1aec50146c205aff20053', 'common.close', '关闭', 'zh-cn', '2014-06-22 13:21:31', 'admin', '管理员', '2014-06-22 13:21:31', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('4028fc5346c1aec50146c205f4be0055', 'common.close.all', '全部关闭', 'zh-cn', '2014-06-22 13:21:48', 'admin', '管理员', '2014-06-22 13:21:48', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('4028fc5346c1aec50146c20631f70057', 'common.close.all', 'Close All', 'en', '2014-06-22 13:22:04', 'admin', '管理员', '2014-06-22 13:22:04', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('4028fc5346c1aec50146c2070b8a0059', 'common.close.all.but.this', 'Close all but this', 'en', '2014-06-22 13:23:00', 'admin', '管理员', '2014-06-22 13:23:00', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('4028fc5346c1aec50146c2074657005b', 'common.close.all.but.this', '除此之外全部关闭', 'zh-cn', '2014-06-22 13:23:15', 'admin', '管理员', '2014-06-22 13:23:15', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('4028fc5346c1aec50146c207f0bc005d', 'common.close.all.right', '当前页右侧全部关闭', 'zh-cn', '2014-06-22 13:23:58', 'admin', '管理员', '2014-06-22 13:23:58', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('4028fc5346c1aec50146c2085b89005f', 'common.close.all.right', 'Close all on right', 'en', '2014-06-22 13:24:26', 'admin', '管理员', '2014-06-22 13:24:26', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('4028fc5346c1aec50146c208cabc0061', 'common.close.all.left', '当前页左侧全部关闭', 'zh-cn', '2014-06-22 13:24:54', 'admin', '管理员', '2014-06-22 13:24:54', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('4028fc5346c1aec50146c2094dee0063', 'common.close.all.left', 'Close all on left', 'en', '2014-06-22 13:25:28', 'admin', '管理员', '2014-06-22 13:25:28', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('4028fc5346c1aec50146c2325e890069', 'common.assist.tools', '辅助工具', 'zh-cn', '2014-06-22 14:10:19', 'admin', '管理员', '2014-06-22 14:10:19', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('4028fc5346c1aec50146c2330cf3006b', 'common.assist.tools', 'Tool', 'en', '2014-06-22 14:11:04', 'admin', '管理员', '2014-06-22 14:11:04', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('4028fc5346c1aec50146c238a6eb006d', 'common.online.user', '用户在线列表', 'zh-cn', '2014-06-22 14:17:11', 'admin', '管理员', '2014-06-22 14:17:11', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('4028fc5346c1aec50146c238d41e006f', 'common.online.user', 'Online User', 'en', '2014-06-22 14:17:22', 'admin', '管理员', '2014-06-22 14:17:22', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('4028fd2b471f63bb01471f9575f10001', 'language.manage', '语言管理', 'zh-cn', '2014-07-10 17:23:14', '8a8ab0b246dc81120146dc8181950052', 'admin', '2014-07-10 17:23:14', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('4028fd2b471f63bb01471f95fdd20003', 'language.manage', 'Lang Manage', 'en', '2014-07-10 17:23:49', '8a8ab0b246dc81120146dc8181950052', 'admin', '2014-07-10 17:23:49', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('4028fd2b471f63bb01471fc8bd5d0010', 'form.template', '表单模板', 'zh-cn', '2014-07-10 18:19:15', '8a8ab0b246dc81120146dc8181950052', 'admin', '2014-07-10 18:19:15', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('4028fd2b471f63bb01471fc8dc9b0012', 'form.template', 'Form Template', 'en', '2014-07-10 18:19:23', '8a8ab0b246dc81120146dc8181950052', 'admin', '2014-07-10 18:19:23', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('4028fd2b471f63bb01471fc961b70014', 'function.test', '功能测试', 'zh-cn', '2014-07-10 18:19:57', '8a8ab0b246dc81120146dc8181950052', 'admin', '2014-07-10 18:19:57', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('4028fd2b471f63bb01471fc97f300016', 'function.test', 'Function Test', 'en', '2014-07-10 18:20:04', '8a8ab0b246dc81120146dc8181950052', 'admin', '2014-07-10 18:20:04', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('4028fd2b471f63bb01471fc9e6310018', 'config.place', '配置地址', 'zh-cn', '2014-07-10 18:20:31', '8a8ab0b246dc81120146dc8181950052', 'admin', '2014-07-10 18:20:31', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('4028fd2b471f63bb01471fca0508001a', 'config.place', 'Setting Address', 'en', '2014-07-10 18:20:39', '8a8ab0b246dc81120146dc8181950052', 'admin', '2014-07-10 18:20:39', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('4028fd2b471f63bb01471fcd6c920020', 'table.exit.in.db.confirm', '表在数据库中已存在\\n确认删除', 'zh-cn', '2014-07-10 18:24:22', '8a8ab0b246dc81120146dc8181950052', 'admin', '2014-07-10 18:24:22', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('4028fd2b471f63bb01471fcdd7140022', 'table.exit.in.db.confirm', 'Table exit already\\n Confirm Delete', 'en', '2014-07-10 18:24:49', '8a8ab0b246dc81120146dc8181950052', 'admin', '2014-07-10 18:24:49', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('4028fd2b471f63bb01471fce9e7a0024', 'confirm.delete.record', '确认移除该记录', 'zh-cn', '2014-07-10 18:25:40', '8a8ab0b246dc81120146dc8181950052', 'admin', '2014-07-10 18:25:40', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('4028fd2b471f63bb01471fcec9d60026', 'confirm.delete.record', 'Confirm delete record', 'en', '2014-07-10 18:25:51', '8a8ab0b246dc81120146dc8181950052', 'admin', '2014-07-10 18:25:51', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('4028fd2b471f63bb01471fcf68be0028', 'form.datalist', '表单数据列表', 'zh-cn', '2014-07-10 18:26:32', '8a8ab0b246dc81120146dc8181950052', 'admin', '2014-07-10 18:26:32', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('4028fd2b471f63bb01471fcf948f002a', 'form.datalist', 'Form data list', 'en', '2014-07-10 18:26:43', '8a8ab0b246dc81120146dc8181950052', 'admin', '2014-07-10 18:26:43', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('4028fd2b471f63bb01471fd33eb1002e', 'common.please.select.edit.item', '请选择编辑项目', 'zh-cn', '2014-07-10 18:30:43', '8a8ab0b246dc81120146dc8181950052', 'admin', '2014-07-10 18:30:43', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('4028fd2b471f63bb01471fd36c4d0030', 'common.please.select.edit.item', 'Please select edit item', 'en', '2014-07-10 18:30:55', '8a8ab0b246dc81120146dc8181950052', 'admin', '2014-07-10 18:30:55', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('4028fd2b471f63bb01471fd429130032', 'common.please.select.one.record.to.edit', '请选择一条记录再编辑', 'zh-cn', '2014-07-10 18:31:43', '8a8ab0b246dc81120146dc8181950052', 'admin', '2014-07-10 18:31:43', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('4028fd2b471f63bb01471fd487c40034', 'common.please.select.one.record.to.edit', 'Please select one record to edit', 'en', '2014-07-10 18:32:07', '8a8ab0b246dc81120146dc8181950052', 'admin', '2014-07-10 18:32:07', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('4028fd2b471f63bb01471fd8bd8f003c', 'common.menu.link', '菜单链接', 'zh-cn', '2014-07-10 18:36:43', '8a8ab0b246dc81120146dc8181950052', 'admin', '2014-07-10 18:36:43', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('4028fd2b471f63bb01471fd8d355003e', 'common.menu.link', 'Menu Link', 'en', '2014-07-10 18:36:49', '8a8ab0b246dc81120146dc8181950052', 'admin', '2014-07-10 18:36:49', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('4028fd2b471f63bb01471fdae99f0040', 'form.sqlimport', '表单SQL导入', 'zh-cn', '2014-07-10 18:39:06', '8a8ab0b246dc81120146dc8181950052', 'admin', '2014-07-10 18:39:06', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('4028fd2b471f63bb01471fdb06f60042', 'form.sqlimport', 'Form SQL Import', 'en', '2014-07-10 18:39:13', '8a8ab0b246dc81120146dc8181950052', 'admin', '2014-07-10 18:39:13', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('4028fd2b471f63bb01471fdbd2b60044', 'slave.table.can.not.generate.code', '附表不能代码生成', 'zh-cn', '2014-07-10 18:40:05', '8a8ab0b246dc81120146dc8181950052', 'admin', '2014-07-10 18:40:05', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('4028fd2b471f63bb01471fdc1ba70046', 'slave.table.can.not.generate.code', 'Slave table can not generate code', 'en', '2014-07-10 18:40:24', '8a8ab0b246dc81120146dc8181950052', 'admin', '2014-07-10 18:47:00', '8a8ab0b246dc81120146dc8181950052', 'admin');
INSERT INTO `t_s_muti_lang` VALUES ('4028fd2b471f63bb01471fdd7b230048', 'please.syncdb', '请先同步数据库', 'zh-cn', '2014-07-10 18:41:54', '8a8ab0b246dc81120146dc8181950052', 'admin', '2014-07-10 18:41:54', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('4028fd2b471f63bb01471fde0d02004a', 'please.syncdb', 'Please synchronize database first', 'en', '2014-07-10 18:42:31', '8a8ab0b246dc81120146dc8181950052', 'admin', '2014-07-10 18:42:31', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('4028fd2b471f63bb01471fde8727004c', 'code.generate', '代码生成', 'zh-cn', '2014-07-10 18:43:03', '8a8ab0b246dc81120146dc8181950052', 'admin', '2014-07-10 18:43:03', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('4028fd2b471f63bb01471fdebba6004e', 'code.generate', 'Code Generate', 'en', '2014-07-10 18:43:16', '8a8ab0b246dc81120146dc8181950052', 'admin', '2014-07-10 18:43:16', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('4028fd2b471f63bb01471fdfb0040050', 'please.select.sync.method', '请选择同步方式', 'zh-cn', '2014-07-10 18:44:19', '8a8ab0b246dc81120146dc8181950052', 'admin', '2014-07-10 18:44:19', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('4028fd2b471f63bb01471fdff96f0052', 'please.select.sync.method', 'Please select synchronize method', 'en', '2014-07-10 18:44:37', '8a8ab0b246dc81120146dc8181950052', 'admin', '2014-07-10 18:44:37', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('4028fd2b471f63bb01471fe393f60059', 'normal.sync', '普通同步(保留表数据)', 'zh-cn', '2014-07-10 18:48:34', '8a8ab0b246dc81120146dc8181950052', 'admin', '2014-07-10 18:48:34', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('4028fd2b471f63bb01471fe4c6cb005b', 'normal.sync', 'Normal Sync(Retain Data)', 'en', '2014-07-10 18:49:52', '8a8ab0b246dc81120146dc8181950052', 'admin', '2014-07-10 18:49:52', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('4028fd2b471f63bb01471fe58641005d', 'force.sync', '强制同步(删除表,重新生成)', 'zh-cn', '2014-07-10 18:50:41', '8a8ab0b246dc81120146dc8181950052', 'admin', '2014-07-10 18:50:41', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('4028fd2b471f63bb01471fe611cd005f', 'force.sync', 'Force Sync(Delete Table, ReGenerate)', 'en', '2014-07-10 18:51:17', '8a8ab0b246dc81120146dc8181950052', 'admin', '2014-07-10 18:51:17', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('4028fd2b471f63bb01471ff8d3000061', 'enhance.type', '增强类型', 'zh-cn', '2014-07-10 19:11:46', '8a8ab0b246dc81120146dc8181950052', 'admin', '2014-07-10 19:11:46', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('4028fd2b471f63bb01471ff8fcca0063', 'enhance.type', 'Enhance Type', 'en', '2014-07-10 19:11:57', '8a8ab0b246dc81120146dc8181950052', 'admin', '2014-07-10 19:11:57', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('4028fd2b471f63bb01471ff9ec220065', 'enhance.js', '增强js', 'zh-cn', '2014-07-10 19:12:58', '8a8ab0b246dc81120146dc8181950052', 'admin', '2014-07-10 19:12:58', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('4028fd2b471f63bb01471ffa2ef10067', 'enhance.js', 'Enhance JS', 'en', '2014-07-10 19:13:15', '8a8ab0b246dc81120146dc8181950052', 'admin', '2014-07-10 19:13:15', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('4028fd2b471f63bb01471ffb99300069', 'get.error', '出错了', 'zh-cn', '2014-07-10 19:14:48', '8a8ab0b246dc81120146dc8181950052', 'admin', '2014-07-10 19:14:48', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('4028fd2b471f63bb01471ffbb3d7006b', 'get.error', 'Get Error', 'en', '2014-07-10 19:14:55', '8a8ab0b246dc81120146dc8181950052', 'admin', '2014-07-10 19:14:55', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('4028fd2b471f63bb01471ffcc59f006d', 'operate.code', '操作码', 'zh-cn', '2014-07-10 19:16:05', '8a8ab0b246dc81120146dc8181950052', 'admin', '2014-07-10 19:16:05', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('4028fd2b471f63bb01471ffce066006f', 'operate.code', 'Operate Code', 'en', '2014-07-10 19:16:12', '8a8ab0b246dc81120146dc8181950052', 'admin', '2014-07-10 19:16:12', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('4028fd2b471f63bb01471ffed3280075', 'enhance.sql', '增强sql', 'zh-cn', '2014-07-10 19:18:19', '8a8ab0b246dc81120146dc8181950052', 'admin', '2014-07-10 19:18:19', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('4028fd2b471f63bb01471ffeef0d0077', 'enhance.sql', 'Enhance SQL', 'en', '2014-07-10 19:18:26', '8a8ab0b246dc81120146dc8181950052', 'admin', '2014-07-10 19:18:26', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('41e9ba5d4f2546fd871d0a4a401732a8', 'common.phone', '手机号码', 'zh-cn', '2014-07-03 18:39:43', '4028818d46f764fb0146f7661cb60052', 'admin', '2014-07-02 23:27:53', '4028818d46f764fb0146f7661cb60052', 'admin');
INSERT INTO `t_s_muti_lang` VALUES ('42a24520ac85497d9da92af210113da2', 'common.status', '状态', 'zh-cn', '2014-07-03 18:39:42', '4028818d46f764fb0146f7661cb60052', 'admin', '2014-07-02 23:27:53', '4028818d46f764fb0146f7661cb60052', 'admin');
INSERT INTO `t_s_muti_lang` VALUES ('52ce422654ab40329fe3a0518b5c8f67', 'password.rang6to18', 'The password is at least 6 characters long, up to 18 characters', 'en', '2014-07-04 18:39:43', '4028818d46f764fb0146f7661cb60052', 'admin', '2014-07-04 23:27:53', '4028818d46f764fb0146f7661cb60052', 'admin');
INSERT INTO `t_s_muti_lang` VALUES ('5910b83799b242318f456a4f42303cb0', 'select.byrole', '按角色选择', 'zh-cn', '2014-07-03 18:39:43', '4028818d46f764fb0146f7661cb60052', 'admin', '2014-07-02 23:27:53', '4028818d46f764fb0146f7661cb60052', 'admin');
INSERT INTO `t_s_muti_lang` VALUES ('5e5106b716d6476cae700ab27f2da555', 'common.middle', '中', 'zh-cn', '2014-07-04 18:39:43', '4028818d46f764fb0146f7661cb60052', 'admin', '2014-07-04 23:27:53', '4028818d46f764fb0146f7661cb60052', 'admin');
INSERT INTO `t_s_muti_lang` VALUES ('767053e885704be2b203fbe5c0389b73', 'common.password.reset', '密码重置', 'zh-cn', '2014-07-03 18:39:42', '4028818d46f764fb0146f7661cb60052', 'admin', '2014-07-02 23:27:53', '4028818d46f764fb0146f7661cb60052', 'admin');
INSERT INTO `t_s_muti_lang` VALUES ('7aae85094220429a84158e4db5c05d45', 'common.status', 'Status', 'en', '2014-07-03 18:39:42', '4028818d46f764fb0146f7661cb60052', 'admin', '2014-07-02 23:27:53', '4028818d46f764fb0146f7661cb60052', 'admin');
INSERT INTO `t_s_muti_lang` VALUES ('7f980a800b114020b085530096b95d86', 'role.muti.select', '角色可多选', 'zh-cn', '2014-07-04 18:39:43', '4028818d46f764fb0146f7661cb60052', 'admin', '2014-07-04 23:27:53', '4028818d46f764fb0146f7661cb60052', 'admin');
INSERT INTO `t_s_muti_lang` VALUES ('8a8ab00846c664b70146c741b9ed0045', 'lang.langkey', '语言主键', 'zh-cn', '2014-06-23 13:45:11', 'admin', '管理员', '2014-06-23 13:45:11', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('8a8ab00846c664b70146c74226100047', 'lang.langkey', 'Lang Key', 'en', '2014-06-23 13:45:39', 'admin', '管理员', '2014-06-23 13:45:39', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('8a8ab00846c664b70146c743a8a40049', 'common.content', '内容', 'zh-cn', '2014-06-23 13:47:18', 'admin', '管理员', '2014-06-23 13:47:18', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('8a8ab00846c664b70146c74416f5004b', 'common.content', 'Content', 'en', '2014-06-23 13:47:46', 'admin', '管理员', '2014-06-23 13:47:46', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('8a8ab00846c664b70146c74526330050', 'common.language', 'Language', 'en', '2014-06-23 13:48:56', 'admin', '管理员', '2014-06-23 13:48:56', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('8a8ab00846c664b70146c77efdb60076', 'common.import', '数据导入', 'zh-cn', '2014-06-23 14:52:06', 'admin', '管理员', '2014-06-23 14:52:06', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('8a8ab00846c664b70146c77f95070078', 'common.import', 'Data Import', 'en', '2014-06-23 14:52:45', 'admin', '管理员', '2014-06-23 14:52:45', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('8a8ab00846c664b70146c7802f4f007a', 'common.export', '数据导出', 'zh-cn', '2014-06-23 14:53:25', 'admin', '管理员', '2014-06-23 14:58:50', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('8a8ab00846c664b70146c7809eb6007c', 'common.export', 'Data Export', 'en', '2014-06-23 14:53:53', 'admin', '管理员', '2014-06-23 14:59:00', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('8a8ab00846d1bb660146d1ef63000003', 'user.manage', '用户管理', 'zh-cn', '2014-06-25 15:31:05', 'admin', '管理员', '2014-06-25 15:31:05', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('8a8ab00846d1bb660146d1eff19e0005', 'user.manage', 'User Manage', 'en', '2014-06-25 15:31:41', 'admin', '管理员', '2014-06-25 15:31:41', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('8a8ab00846d1bb660146d1f12ae00007', 'common.data.dictionary', 'Data Dictionary ', 'en', '2014-06-25 15:33:01', 'admin', '管理员', '2014-06-25 16:10:45', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('8a8ab00846d1bb660146d1f1635a0009', 'common.data.dictionary', '数据字典', 'zh-cn', '2014-06-25 15:33:16', 'admin', '管理员', '2014-06-25 15:33:16', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('8a8ab00846d1bb660146d1f24c0b000b', 'role.manage', '角色管理', 'zh-cn', '2014-06-25 15:34:15', 'admin', '管理员', '2014-06-25 15:34:15', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('8a8ab00846d1bb660146d1f35861000f', 'role.manage', 'Role Manage', 'en', '2014-06-25 15:35:24', 'admin', '管理员', '2014-06-25 15:35:24', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('8a8ab00846d1bb660146d1f8e1610015', 'icon.manage', '图标管理', 'zh-cn', '2014-06-25 15:41:27', 'admin', '管理员', '2014-06-25 15:41:27', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('8a8ab00846d1bb660146d1fbc5bf0017', 'icon.manage', 'Icon Manage', 'en', '2014-06-25 15:44:36', 'admin', '管理员', '2014-06-25 15:44:36', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('8a8ab00846d1bb660146d1fffdb40019', 'department.manage', '组织机构管理', 'zh-cn', '2014-06-25 15:49:13', 'admin', '管理员', '2014-06-25 15:49:13', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('8a8ab00846d1bb660146d20cbafe001b', 'department.manage', 'Org Manage', 'en', '2014-06-25 16:03:08', 'admin', '管理员', '2014-06-25 16:03:08', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('8a8ab01b46b7bff40146b7c2eb6f0001', 'common.dash_board', '首页', 'zh-cn', '2014-06-20 13:32:23', 'admin', '管理员', '2014-06-20 14:58:43', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('8a8ab01b46b7bff40146b7c38f560003', 'common.dash_board', 'Dashboard', 'en', '2014-06-20 13:33:05', 'admin', '管理员', '2014-06-20 14:58:51', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('8a8ab01b46b802300146b8038a070001', 'common.add.success', '添加成功', 'zh-cn', '2014-06-20 14:42:58', 'admin', '管理员', '2014-06-20 14:42:58', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('8a8ab01b46b802300146b8048a5e0004', 'common.add.success', 'Add success', 'en', '2014-06-20 14:44:03', 'admin', '管理员', '2014-06-20 14:44:03', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('8a8ab01b46b802300146b806d7bd0006', 'common.edit.success', '更新成功', 'zh-cn', '2014-06-20 14:46:34', 'admin', '管理员', '2014-06-20 14:46:34', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('8a8ab01b46b802300146b807c4e60008', 'common.edit.success', 'Update success', 'en', '2014-06-20 14:47:35', 'admin', '管理员', '2014-06-20 14:47:35', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('8a8ab01b46b80a850146b80cf84d0002', 'common.delete.success', '删除成功', 'zh-cn', '2014-06-20 14:53:16', 'admin', '管理员', '2014-06-20 14:53:16', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('8a8ab01b46b80a850146b80d35b70004', 'common.delete.success', 'Delete success', 'en', '2014-06-20 14:53:31', 'admin', '管理员', '2014-06-20 14:53:31', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('8a8ab01b46b80a850146b80e7d420006', 'common.edit.fail', '更新失败', 'zh-cn', '2014-06-20 14:54:55', 'admin', '管理员', '2014-06-20 14:54:55', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('8a8ab01b46b80a850146b80eddca0008', 'common.edit.fail', 'Update Fail', 'en', '2014-06-20 14:55:20', 'admin', '管理员', '2014-06-20 14:55:20', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('8a8ab01b46b83b0b0146b83ec7070008', 'common.notfind.langkey', '?', 'zh-cn', '2014-06-20 15:55:50', 'admin', '管理员', '2014-06-21 01:18:10', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('8a8ab01b46b83b0b0146b83ec7070009', 'common.notfind.langkey', '?', 'en', '2014-06-20 15:57:14', 'admin', '管理员', '2014-06-21 01:18:16', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('8a8ab02147423c5101474264c8980002', 'common.confirm', '确定', 'zh-cn', '2014-07-17 11:36:47', '8a8ab0b246dc81120146dc8181950052', 'admin', '2014-07-17 11:36:47', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('8a8ab02147423c5101474264e0510004', 'common.confirm', 'Confirm', 'en', '2014-07-17 11:36:53', '8a8ab0b246dc81120146dc8181950052', 'admin', '2014-07-17 11:36:53', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('8a8ab02147423c51014742654bd20006', 'common.remove', 'Remove', 'en', '2014-07-17 11:37:20', '8a8ab0b246dc81120146dc8181950052', 'admin', '2014-07-17 11:37:20', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('8a8ab02147423c510147426569f90008', 'common.remove', '移除', 'zh-cn', '2014-07-17 11:37:28', '8a8ab0b246dc81120146dc8181950052', 'admin', '2014-07-17 11:37:28', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('8a8ab02147423c5101474265ac98000a', 'common.item', '条', 'zh-cn', '2014-07-17 11:37:45', '8a8ab0b246dc81120146dc8181950052', 'admin', '2014-07-17 11:37:45', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('8a8ab02147423c5101474265cdc1000c', 'common.item', 'Item', 'en', '2014-07-17 11:37:53', '8a8ab0b246dc81120146dc8181950052', 'admin', '2014-07-17 11:37:53', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('8a8ab02147423c51014742662411000e', 'common.total', '共', 'zh-cn', '2014-07-17 11:38:15', '8a8ab0b246dc81120146dc8181950052', 'admin', '2014-07-17 11:38:15', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('8a8ab02147423c51014742664c5c0010', 'common.total', 'Total', 'en', '2014-07-17 11:38:26', '8a8ab0b246dc81120146dc8181950052', 'admin', '2014-07-17 11:38:26', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('8a8ab02147423c51014742669c660012', 'common.inactive', '未激活', 'zh-cn', '2014-07-17 11:38:46', '8a8ab0b246dc81120146dc8181950052', 'admin', '2014-07-17 11:38:46', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('8a8ab02147423c5101474266cf100014', 'common.inactive', 'Inactive', 'en', '2014-07-17 11:38:59', '8a8ab0b246dc81120146dc8181950052', 'admin', '2014-07-17 11:38:59', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('8a8ab02147423c5101474267077d0016', 'common.active', '激活', 'zh-cn', '2014-07-17 11:39:14', '8a8ab0b246dc81120146dc8181950052', 'admin', '2014-07-17 11:39:14', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('8a8ab02147423c510147426722730018', 'common.active', 'Active', 'en', '2014-07-17 11:39:21', '8a8ab0b246dc81120146dc8181950052', 'admin', '2014-07-17 11:39:21', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('8a8ab02147423c5101474267fdef001e', 'common.languagekey', 'Lang Key', 'en', '2014-07-17 11:40:17', '8a8ab0b246dc81120146dc8181950052', 'admin', '2014-07-17 11:40:17', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('8a8ab02147423c51014742687da20020', 'common.languagekey', '语言Key', 'zh-cn', '2014-07-17 11:40:49', '8a8ab0b246dc81120146dc8181950052', 'admin', '2014-07-17 11:40:49', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('8a8ab0af476afe8501476b05f8860005', 'common.remember.user', '是否记住用户名', 'zh-cn', '2014-07-25 08:57:39', '8a8ab0b246dc81120146dc8181950052', 'admin', '2014-07-25 08:57:39', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('8a8ab0af476afe8501476b0642280007', 'common.remember.user', 'Remember User', 'en', '2014-07-25 08:57:58', '8a8ab0b246dc81120146dc8181950052', 'admin', '2014-07-25 08:57:58', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('8a8ab0af476afe8501476b0b61120009', 'common.login.success.wait', '登陆成功!请稍后....', 'zh-cn', '2014-07-25 09:03:33', '8a8ab0b246dc81120146dc8181950052', 'admin', '2014-07-25 09:03:33', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('8a8ab0af476afe8501476b0bc257000b', 'common.login.success.wait', 'Login success, waiting....', 'en', '2014-07-25 09:03:58', '8a8ab0b246dc81120146dc8181950052', 'admin', '2014-07-25 09:03:58', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('8a8ab0af476afe8501476b0d4233000d', 'common.init.data', '是否初始化数据', 'zh-cn', '2014-07-25 09:05:36', '8a8ab0b246dc81120146dc8181950052', 'admin', '2014-07-25 09:05:36', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('8a8ab0af476afe8501476b0db938000f', 'common.init.data', 'Initialize data?', 'en', '2014-07-25 09:06:07', '8a8ab0b246dc81120146dc8181950052', 'admin', '2014-07-25 09:06:07', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('8a8ab0af476afe8501476b162e630012', 'lang.order.type', '订单类型', 'zh-cn', '2014-07-25 09:15:21', '8a8ab0b246dc81120146dc8181950052', 'admin', '2014-07-25 09:15:21', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('8a8ab0af476afe8501476b164ceb0014', 'lang.order.type', 'Order Type', 'en', '2014-07-25 09:15:29', '8a8ab0b246dc81120146dc8181950052', 'admin', '2014-07-25 09:15:29', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('8a8ab0af476afe8501476b16a56e0016', 'lang.customer.type', '客户类型', 'zh-cn', '2014-07-25 09:15:52', '8a8ab0b246dc81120146dc8181950052', 'admin', '2014-07-25 09:15:52', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('8a8ab0af476afe8501476b16c0d50018', 'lang.customer.type', 'Customer Type', 'en', '2014-07-25 09:15:59', '8a8ab0b246dc81120146dc8181950052', 'admin', '2014-07-25 09:15:59', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('8a8ab0af476afe8501476b170b9a001a', 'lang.service.item.type', '服务项目类型', 'zh-cn', '2014-07-25 09:16:18', '8a8ab0b246dc81120146dc8181950052', 'admin', '2014-07-25 09:16:18', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('8a8ab0af476afe8501476b1749cc001c', 'lang.service.item.type', 'Service Item Type', 'en', '2014-07-25 09:16:34', '8a8ab0b246dc81120146dc8181950052', 'admin', '2014-07-25 09:16:34', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('8a8ab0af476afe8501476b1936c60020', 'common.logic.condition', '逻辑条件', 'zh-cn', '2014-07-25 09:18:40', '8a8ab0b246dc81120146dc8181950052', 'admin', '2014-07-25 09:18:40', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('8a8ab0af476afe8501476b1956dd0022', 'common.logic.condition', 'Logic Condition', 'en', '2014-07-25 09:18:48', '8a8ab0b246dc81120146dc8181950052', 'admin', '2014-07-25 09:18:48', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('8a8ab0af476afe8501476b1a1cc30024', 'common.data.table', '数据表', 'zh-cn', '2014-07-25 09:19:39', '8a8ab0b246dc81120146dc8181950052', 'admin', '2014-07-25 09:19:39', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('8a8ab0af476afe8501476b1a3c0a0026', 'common.data.table', 'Data Table', 'en', '2014-07-25 09:19:47', '8a8ab0b246dc81120146dc8181950052', 'admin', '2014-07-25 09:19:47', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('8a8ab0af476afe8501476b1ac59e0028', 'common.document.category', '文档分类', 'zh-cn', '2014-07-25 09:20:22', '8a8ab0b246dc81120146dc8181950052', 'admin', '2014-07-25 09:20:22', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('8a8ab0af476afe8501476b1aeaa3002a', 'common.document.category', 'Document Category', 'en', '2014-07-25 09:20:31', '8a8ab0b246dc81120146dc8181950052', 'admin', '2014-07-25 09:20:31', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('8a8ab0af476afe8501476b1b3e55002c', 'common.sex.type', '性别类', 'zh-cn', '2014-07-25 09:20:53', '8a8ab0b246dc81120146dc8181950052', 'admin', '2014-07-25 09:20:53', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('8a8ab0af476afe8501476b1b59af002e', 'common.sex.type', 'Sex Type', 'en', '2014-07-25 09:21:00', '8a8ab0b246dc81120146dc8181950052', 'admin', '2014-07-25 09:21:00', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('8a8ab0af476afe8501476b1c08ba0030', 'common.attachment', '附件', 'zh-cn', '2014-07-25 09:21:45', '8a8ab0b246dc81120146dc8181950052', 'admin', '2014-07-25 09:21:45', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('8a8ab0af476afe8501476b1c22dd0032', 'common.attachment', 'Attachment', 'en', '2014-07-25 09:21:51', '8a8ab0b246dc81120146dc8181950052', 'admin', '2014-07-25 09:21:51', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('8a8ab0af476afe8501476b1d4e400034', 'lang.excellent.order', '优质订单', 'zh-cn', '2014-07-25 09:23:08', '8a8ab0b246dc81120146dc8181950052', 'admin', '2014-07-25 09:23:08', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('8a8ab0af476afe8501476b1d7ece0036', 'lang.excellent.order', 'Excellent Order', 'en', '2014-07-25 09:23:20', '8a8ab0b246dc81120146dc8181950052', 'admin', '2014-07-25 09:23:20', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('8a8ab0af476afe8501476b1de2050038', 'lang.normal.order', '普通订单', 'zh-cn', '2014-07-25 09:23:46', '8a8ab0b246dc81120146dc8181950052', 'admin', '2014-07-25 09:23:46', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('8a8ab0af476afe8501476b1dfde4003a', 'lang.normal.order', 'Normal Order', 'en', '2014-07-25 09:23:53', '8a8ab0b246dc81120146dc8181950052', 'admin', '2014-07-25 09:23:53', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('8a8ab0af476afe8501476b1ef393003c', 'lang.contract.customer', '签约客户', 'zh-cn', '2014-07-25 09:24:56', '8a8ab0b246dc81120146dc8181950052', 'admin', '2014-07-25 09:24:56', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('8a8ab0af476afe8501476b1f0b32003e', 'lang.contract.customer', 'Contract Customer', 'en', '2014-07-25 09:25:02', '8a8ab0b246dc81120146dc8181950052', 'admin', '2014-07-25 09:25:02', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('8a8ab0af476afe8501476b1f4fea0040', 'lang.normal.customer', '普通客户', 'zh-cn', '2014-07-25 09:25:19', '8a8ab0b246dc81120146dc8181950052', 'admin', '2014-07-25 09:25:19', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('8a8ab0af476afe8501476b1f67050042', 'lang.normal.customer', 'Normal Customer', 'en', '2014-07-25 09:25:25', '8a8ab0b246dc81120146dc8181950052', 'admin', '2014-07-25 09:25:25', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('8a8ab0af476afe8501476b1fa93d0044', 'lang.special.servcie', '特殊服务', 'zh-cn', '2014-07-25 09:25:42', '8a8ab0b246dc81120146dc8181950052', 'admin', '2014-07-25 09:25:42', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('8a8ab0af476afe8501476b1fceec0046', 'lang.special.servcie', 'Special Service', 'en', '2014-07-25 09:25:52', '8a8ab0b246dc81120146dc8181950052', 'admin', '2014-07-25 09:25:52', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('8a8ab0af476afe8501476b2014720048', 'lang.normal.service', '普通服务', 'zh-cn', '2014-07-25 09:26:10', '8a8ab0b246dc81120146dc8181950052', 'admin', '2014-07-25 09:26:10', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('8a8ab0af476afe8501476b203ca4004a', 'lang.normal.service', 'Normal Service', 'en', '2014-07-25 09:26:20', '8a8ab0b246dc81120146dc8181950052', 'admin', '2014-07-25 09:26:20', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('8a8ab0af476afe8501476b20bf5a004c', 'common.single.condition.query', '单条件查询', 'zh-cn', '2014-07-25 09:26:54', '8a8ab0b246dc81120146dc8181950052', 'admin', '2014-07-25 09:26:54', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('8a8ab0af476afe8501476b20e447004e', 'common.single.condition.query', 'Single Condition Query', 'en', '2014-07-25 09:27:03', '8a8ab0b246dc81120146dc8181950052', 'admin', '2014-07-25 09:27:03', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('8a8ab0af476afe8501476b214fe20050', 'common.scope.query', '范围查询', 'zh-cn', '2014-07-25 09:27:31', '8a8ab0b246dc81120146dc8181950052', 'admin', '2014-07-25 09:27:31', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('8a8ab0af476afe8501476b2171de0052', 'common.scope.query', 'Scope Queyr', 'en', '2014-07-25 09:27:39', '8a8ab0b246dc81120146dc8181950052', 'admin', '2014-07-25 09:27:39', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('8a8ab0af476afe8501476b21ffbf0054', 'common.db.integer', 'Integer', 'en', '2014-07-25 09:28:16', '8a8ab0b246dc81120146dc8181950052', 'admin', '2014-07-25 09:29:19', '8a8ab0b246dc81120146dc8181950052', 'admin');
INSERT INTO `t_s_muti_lang` VALUES ('8a8ab0af476afe8501476b2227930056', 'common.db.integer', '数值类型', 'zh-cn', '2014-07-25 09:28:26', '8a8ab0b246dc81120146dc8181950052', 'admin', '2014-07-25 09:29:23', '8a8ab0b246dc81120146dc8181950052', 'admin');
INSERT INTO `t_s_muti_lang` VALUES ('8a8ab0af476afe8501476b234ba5005a', 'common.db.date', 'Date', 'en', '2014-07-25 09:29:41', '8a8ab0b246dc81120146dc8181950052', 'admin', '2014-07-25 09:29:41', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('8a8ab0af476afe8501476b238657005c', 'common.db.date', '日期类型', 'zh-cn', '2014-07-25 09:29:56', '8a8ab0b246dc81120146dc8181950052', 'admin', '2014-07-25 09:29:56', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('8a8ab0af476afe8501476b23efed005e', 'common.db.string', '字符类型', 'zh-cn', '2014-07-25 09:30:23', '8a8ab0b246dc81120146dc8181950052', 'admin', '2014-07-25 09:30:23', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('8a8ab0af476afe8501476b2404d30060', 'common.db.string', 'String', 'en', '2014-07-25 09:30:28', '8a8ab0b246dc81120146dc8181950052', 'admin', '2014-07-25 09:30:28', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('8a8ab0af476afe8501476b245e800062', 'common.db.long', 'Long', 'en', '2014-07-25 09:30:51', '8a8ab0b246dc81120146dc8181950052', 'admin', '2014-07-25 09:30:51', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('8a8ab0af476afe8501476b248ee60064', 'common.db.long', '长整型', 'zh-cn', '2014-07-25 09:31:03', '8a8ab0b246dc81120146dc8181950052', 'admin', '2014-07-25 09:31:03', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('8a8ab0af476afe8501476b253d760066', 'common.workflow.engine.table', '工作流引擎表', 'zh-cn', '2014-07-25 09:31:48', '8a8ab0b246dc81120146dc8181950052', 'admin', '2014-07-25 09:31:48', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('8a8ab0af476afe8501476b256e3a0068', 'common.workflow.engine.table', 'Workflow Engine Table', 'en', '2014-07-25 09:32:00', '8a8ab0b246dc81120146dc8181950052', 'admin', '2014-07-25 09:32:00', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('8a8ab0af476afe8501476b25c1d4006a', 'common.system.table', '系统基础表', 'zh-cn', '2014-07-25 09:32:22', '8a8ab0b246dc81120146dc8181950052', 'admin', '2014-07-25 09:32:22', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('8a8ab0af476afe8501476b25d9b3006c', 'common.system.table', 'System Table', 'en', '2014-07-25 09:32:28', '8a8ab0b246dc81120146dc8181950052', 'admin', '2014-07-25 09:32:28', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('8a8ab0af476afe8501476b267773006e', 'common.business.table', '业务表', 'zh-cn', '2014-07-25 09:33:08', '8a8ab0b246dc81120146dc8181950052', 'admin', '2014-07-25 09:33:08', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('8a8ab0af476afe8501476b26a71c0070', 'common.business.table', 'Business Table', 'en', '2014-07-25 09:33:21', '8a8ab0b246dc81120146dc8181950052', 'admin', '2014-07-25 09:33:21', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('8a8ab0af476afe8501476b2761320072', 'common.customer.engine.table', '自定义引擎表', 'zh-cn', '2014-07-25 09:34:08', '8a8ab0b246dc81120146dc8181950052', 'admin', '2014-07-25 09:34:08', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('8a8ab0af476afe8501476b2791440074', 'common.customer.engine.table', 'Customer Engine Table', 'en', '2014-07-25 09:34:20', '8a8ab0b246dc81120146dc8181950052', 'admin', '2014-07-25 09:34:20', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('8a8ab0af476afe8501476b27d3790076', 'common.news', '新闻', 'zh-cn', '2014-07-25 09:34:37', '8a8ab0b246dc81120146dc8181950052', 'admin', '2014-07-25 09:34:37', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('8a8ab0af476afe8501476b27f9b30078', '新闻', 'News', 'en', '2014-07-25 09:34:47', '8a8ab0b246dc81120146dc8181950052', 'admin', '2014-07-25 09:34:47', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('8a8ab0af476afe8501476b28e56e007a', 'common.male', '男性', 'zh-cn', '2014-07-25 09:35:48', '8a8ab0b246dc81120146dc8181950052', 'admin', '2014-07-25 09:35:48', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('8a8ab0af476afe8501476b28fa30007c', 'common.male', 'Male', 'en', '2014-07-25 09:35:53', '8a8ab0b246dc81120146dc8181950052', 'admin', '2014-07-25 09:35:53', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('8a8ab0af476afe8501476b291a73007e', 'common.female', '女性', 'zh-cn', '2014-07-25 09:36:01', '8a8ab0b246dc81120146dc8181950052', 'admin', '2014-07-25 09:36:01', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('8a8ab0af476afe8501476b29466c0080', 'common.female', 'Female', 'en', '2014-07-25 09:36:12', '8a8ab0b246dc81120146dc8181950052', 'admin', '2014-07-25 09:36:12', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('8a8ab0ba487c37d001487c488a4d0006', 'common.datasource.manage', '多数据源管理', 'zh-cn', '2014-09-16 10:26:41', '8a8ab0b246dc81120146dc8181950052', 'admin', '2014-09-16 10:30:20', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('8a8ab0ba487c37d001487c491f480008', 'common.datasource.manage', 'Multiple DataSource Manage', 'en', '2014-09-16 10:27:20', '8a8ab0b246dc81120146dc8181950052', 'admin', '2014-09-16 10:30:56', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('8a8ab0ba487c527201487c5f6d400001', 'common.datasrouce.key', '多数据源主键', 'zh-cn', '2014-09-16 10:51:41', '8a8ab0b246dc81120146dc8181950052', 'admin', null, null, null);
INSERT INTO `t_s_muti_lang` VALUES ('8a8ab0ba487c527201487c5fba980003', 'common.datasrouce.key', 'Mutipule DataSource Key', 'en', '2014-09-16 10:52:01', '8a8ab0b246dc81120146dc8181950052', 'admin', null, null, null);
INSERT INTO `t_s_muti_lang` VALUES ('8a8ab0ba487c527201487c6193ec0005', 'common.driverclass', '驱动类', 'zh-cn', '2014-09-16 10:54:02', '8a8ab0b246dc81120146dc8181950052', 'admin', null, null, null);
INSERT INTO `t_s_muti_lang` VALUES ('8a8ab0ba487c527201487c61b73d0007', 'common.driverclass', 'Driver Class', 'en', '2014-09-16 10:54:11', '8a8ab0b246dc81120146dc8181950052', 'admin', null, null, null);
INSERT INTO `t_s_muti_lang` VALUES ('8a8ab0ba487c527201487c62b0b00009', 'common.datasrouce.url', '数据源地址', 'zh-cn', '2014-09-16 10:55:15', '8a8ab0b246dc81120146dc8181950052', 'admin', null, null, null);
INSERT INTO `t_s_muti_lang` VALUES ('8a8ab0ba487c527201487c62f4d8000b', 'common.datasrouce.url', 'DataSource URL', 'en', '2014-09-16 10:55:33', '8a8ab0b246dc81120146dc8181950052', 'admin', null, null, null);
INSERT INTO `t_s_muti_lang` VALUES ('8a8ab0ba487c527201487c63c17c000d', 'common.dbuser', '数据库用户名', 'zh-cn', '2014-09-16 10:56:25', '8a8ab0b246dc81120146dc8181950052', 'admin', null, null, null);
INSERT INTO `t_s_muti_lang` VALUES ('8a8ab0ba487c527201487c63f0bf000f', 'common.dbuser', 'DB User', 'en', '2014-09-16 10:56:37', '8a8ab0b246dc81120146dc8181950052', 'admin', null, null, null);
INSERT INTO `t_s_muti_lang` VALUES ('8a8ab0ba487c527201487c6430510011', 'common.dbpassword', '数据库密码', 'zh-cn', '2014-09-16 10:56:53', '8a8ab0b246dc81120146dc8181950052', 'admin', null, null, null);
INSERT INTO `t_s_muti_lang` VALUES ('8a8ab0ba487c527201487c6456940013', 'common.dbpassword', 'DB Password', 'en', '2014-09-16 10:57:03', '8a8ab0b246dc81120146dc8181950052', 'admin', null, null, null);
INSERT INTO `t_s_muti_lang` VALUES ('8a8ab0ba487c527201487c66d45d0015', 'common.dbtype', '数据库类型', 'zh-cn', '2014-09-16 10:59:46', '8a8ab0b246dc81120146dc8181950052', 'admin', null, null, null);
INSERT INTO `t_s_muti_lang` VALUES ('8a8ab0ba487c527201487c66ffe00017', 'common.dbtype', 'DB Type', 'en', '2014-09-16 10:59:58', '8a8ab0b246dc81120146dc8181950052', 'admin', null, null, null);
INSERT INTO `t_s_muti_lang` VALUES ('8a8ab0ba487c527201487c79d0660021', 'common.oracle', '甲骨文Oracle数据库', 'zh-cn', '2014-09-16 11:20:31', '8a8ab0b246dc81120146dc8181950052', 'admin', '2014-09-16 11:21:58', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('8a8ab0ba487c527201487c7aee7b0024', 'common.oracle', 'Oracle', 'en', '2014-09-16 11:21:44', '8a8ab0b246dc81120146dc8181950052', 'admin', null, null, null);
INSERT INTO `t_s_muti_lang` VALUES ('8a8ab0ba487c527201487c8f0bfc0027', 'common.sqlserver2008', '微软SQL Server2008', 'zh-cn', '2014-09-16 11:43:42', '8a8ab0b246dc81120146dc8181950052', 'admin', '2014-09-16 11:48:44', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('8a8ab0ba487c527201487c8f57910029', 'common.sqlserver2008', 'SQL Server2008', 'en', '2014-09-16 11:44:01', '8a8ab0b246dc81120146dc8181950052', 'admin', null, null, null);
INSERT INTO `t_s_muti_lang` VALUES ('8a8ab0ba487c527201487c94614b002d', 'common.mysql', '甲骨文MySQL', 'zh-cn', '2014-09-16 11:49:32', '8a8ab0b246dc81120146dc8181950052', 'admin', null, null, null);
INSERT INTO `t_s_muti_lang` VALUES ('8a8ab0ba487c527201487c948fc0002f', 'common.mysql', 'MySQL', 'en', '2014-09-16 11:49:44', '8a8ab0b246dc81120146dc8181950052', 'admin', null, null, null);
INSERT INTO `t_s_muti_lang` VALUES ('8a8ab0c34761c347014761dfb98c0001', 'common.english', 'English', 'en', '2014-07-23 14:19:17', '8a8ab0b246dc81120146dc8181950052', 'admin', '2014-07-23 14:19:17', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('8a8ab0c34761c347014761dfde030003', 'common.english', 'English', 'zh-cn', '2014-07-23 14:19:27', '8a8ab0b246dc81120146dc8181950052', 'admin', '2014-07-25 08:51:07', '8a8ab0b246dc81120146dc8181950052', 'admin');
INSERT INTO `t_s_muti_lang` VALUES ('8a8ab0c34761c347014761e00f350005', 'common.chinese', '中文', 'en', '2014-07-23 14:19:39', '8a8ab0b246dc81120146dc8181950052', 'admin', '2014-07-25 08:51:20', '8a8ab0b246dc81120146dc8181950052', 'admin');
INSERT INTO `t_s_muti_lang` VALUES ('8a8ab0c34761c347014761e0305c0007', 'common.chinese', '中文', 'zh-cn', '2014-07-23 14:19:48', '8a8ab0b246dc81120146dc8181950052', 'admin', '2014-07-23 14:19:48', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('8a8ab0d44756a3bd014756ad82990002', 'user.analysis.histogram', '用户分析直方图', 'zh-cn', '2014-07-21 10:08:37', '8a8ab0b246dc81120146dc8181950052', 'admin', '2014-07-21 10:08:37', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('8a8ab0d44756a3bd014756ae22ce0004', 'usename.range2to10', '用户名长度范围在2~10', 'zh-cn', '2014-07-21 10:09:18', '8a8ab0b246dc81120146dc8181950052', 'admin', '2014-07-21 10:09:18', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('8a8ab0d44756a3bd014756ae9c2a0006', 'sequence.name', '序号名称', 'zh-cn', '2014-07-21 10:09:49', '8a8ab0b246dc81120146dc8181950052', 'admin', '2014-07-21 10:09:49', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('8a8ab0d44756ec17014756eff8410001', 'common.menu', '菜单', 'zh-cn', '2014-07-21 11:21:13', '8a8ab0b246dc81120146dc8181950052', 'admin', '2014-07-21 11:21:13', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('8a8ab0d44756ec17014756f0122e0003', 'common.menu', 'Menu', 'en', '2014-07-21 11:21:19', '8a8ab0b246dc81120146dc8181950052', 'admin', '2014-07-21 11:21:19', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('8a8ab0d44756ec17014756f5940d0007', 'common.area', '地域', 'zh-cn', '2014-07-21 11:27:20', '8a8ab0b246dc81120146dc8181950052', 'admin', '2014-07-21 11:27:20', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('8a8ab0d44756ec17014756f5b12e0009', 'common.area', 'Area', 'en', '2014-07-21 11:27:28', '8a8ab0b246dc81120146dc8181950052', 'admin', '2014-07-21 11:27:28', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('8a8ab0d447576a86014757a4266d0004', 'common.role.select', '角色选择', 'zh-cn', '2014-07-21 14:38:01', '8a8ab0b246dc81120146dc8181950052', 'admin', '2014-07-21 14:38:01', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('8a8ab0d447576a86014757a44a7b0006', 'common.role.select', 'Role Select', 'en', '2014-07-21 14:38:10', '8a8ab0b246dc81120146dc8181950052', 'admin', '2014-07-21 14:38:10', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('8a8ab0d44757b3f2014757b802010004', 'common.cancel', 'Cancel', 'en', '2014-07-21 14:59:42', '8a8ab0b246dc81120146dc8181950052', 'admin', '2014-07-21 14:59:42', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('8a8ab0d44757b3f2014757b821e00006', 'common.cancel', '取消', 'zh-cn', '2014-07-21 14:59:50', '8a8ab0b246dc81120146dc8181950052', 'admin', '2014-07-21 14:59:50', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('8a8ab0de46c66d490146c674f6ee0002', 'common.data.loading', '数据加载中...', 'zh-cn', '2014-06-23 10:01:32', 'admin', '管理员', '2014-06-23 10:01:32', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('8a8ab0de46c66d490146c675351b0004', 'common.data.loading', 'Data Loading......', 'en', '2014-06-23 10:01:48', 'admin', '管理员', '2014-06-23 10:01:48', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('8a8ab0de46c66d490146c6788e550006', 'common.exit.confirm', '确定退出该系统吗 ?', 'zh-cn', '2014-06-23 10:05:28', 'admin', '管理员', '2014-06-23 10:05:28', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('8a8ab0de46c66d490146c678d8600008', 'common.exit.confirm', 'Confirm Exit?', 'en', '2014-06-23 10:05:46', 'admin', '管理员', '2014-06-23 10:05:46', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('8a8ab0de46c66d490146c67af864000a', 'common.change.style', '修改首页风格', 'zh-cn', '2014-06-23 10:08:06', 'admin', '管理员', '2014-06-23 10:08:06', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('8a8ab0de46c66d490146c67b3590000c', 'common.change.style', 'Change Style', 'en', '2014-06-23 10:08:21', 'admin', '管理员', '2014-06-23 10:08:21', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('8a8ab0de46c66d490146c683c4ea0012', 'common.browser.recommend', '(推荐使用IE8+,谷歌浏览器可以获得更快,更安全的页面响应速度) 技术支持：', 'zh-cn', '2014-06-23 10:17:42', 'admin', '管理员', '2014-06-23 11:05:48', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('8a8ab0de46c66d490146c68486160014', 'common.browser.recommend', '(Recommend IE+, Google browser) Support: ', 'en', '2014-06-23 10:18:32', 'admin', '管理员', '2014-06-23 10:18:32', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('8a8ab0e8476756d8014767594f500001', 'common.mutilang', '多语言', 'zh-cn', '2014-07-24 15:50:12', '8a8ab0b246dc81120146dc8181950052', 'admin', '2014-07-24 15:50:12', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('8a8ab0e8476756d801476759b8930003', 'common.mutilang', 'Muti Language', 'en', '2014-07-24 15:50:38', '8a8ab0b246dc81120146dc8181950052', 'admin', '2014-07-24 15:50:38', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('8a8c8d1c475192970147519e89800004', 'common.description', 'Description', 'en', '2014-07-20 10:34:10', '8a8ab0b246dc81120146dc8181950052', 'admin', '2014-07-20 10:35:01', '8a8ab0b246dc81120146dc8181950052', 'admin');
INSERT INTO `t_s_muti_lang` VALUES ('8a8c8d1c475192970147519eae6d0006', 'common.description', '描述', 'zh-cn', '2014-07-20 10:34:19', '8a8ab0b246dc81120146dc8181950052', 'admin', '2014-07-20 10:34:19', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('8a8c8d1c4751c965014751cb1ff50001', 'common.langcontext.exist', '该内容已经存在，请不要重复添加', 'zh-cn', '2014-07-20 11:22:52', '8a8ab0b246dc81120146dc8181950052', 'admin', '2014-07-20 11:22:52', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('8a8c8d1c4751c965014751cd221a0003', 'common.langcontext.exist', 'Lang context exist already, don\'t add it again', 'en', '2014-07-20 11:00:00', '8a8ab0b246dc81120146dc8181950052', 'admin', '2014-07-20 11:00:00', 'admin', '管理员');
INSERT INTO `t_s_muti_lang` VALUES ('8b4f561992c84eaa958b10c7912896b8', 'common.weak', '弱', 'zh-cn', '2014-07-04 18:39:43', '4028818d46f764fb0146f7661cb60052', 'admin', '2014-07-04 23:27:53', '4028818d46f764fb0146f7661cb60052', 'admin');
INSERT INTO `t_s_muti_lang` VALUES ('8ca84db9bbcb44bfb39746822a976907', 'common.role', 'Role', 'en', '2014-07-03 18:39:43', '4028818d46f764fb0146f7661cb60052', 'admin', '2014-07-02 23:27:53', '4028818d46f764fb0146f7661cb60052', 'admin');
INSERT INTO `t_s_muti_lang` VALUES ('95903aa116c74bdb95b5be510a89c79d', 'common.tel', '办公电话', 'zh-cn', '2014-07-03 18:39:43', '4028818d46f764fb0146f7661cb60052', 'admin', '2014-07-02 23:27:53', '4028818d46f764fb0146f7661cb60052', 'admin');
INSERT INTO `t_s_muti_lang` VALUES ('9c3a8db4891a4d4390f6093ae2fd81af', 'common.strong', '强', 'zh-cn', '2014-07-04 18:39:43', '4028818d46f764fb0146f7661cb60052', 'admin', '2014-07-04 23:27:53', '4028818d46f764fb0146f7661cb60052', 'admin');
INSERT INTO `t_s_muti_lang` VALUES ('9f750fb969ed4bdcbbdb212c43746112', 'common.lock.user', 'Lock User', 'en', '2014-07-03 18:39:42', '4028818d46f764fb0146f7661cb60052', 'admin', '2014-07-02 23:27:53', '4028818d46f764fb0146f7661cb60052', 'admin');
INSERT INTO `t_s_muti_lang` VALUES ('a8e5a8e8c5e44576a1500c3b5f57937b', 'select.byrole', 'According to the role select', 'en', '2014-07-03 18:39:43', '4028818d46f764fb0146f7661cb60052', 'admin', '2014-07-02 23:27:53', '4028818d46f764fb0146f7661cb60052', 'admin');
INSERT INTO `t_s_muti_lang` VALUES ('ac43aecc3356487c8eb5fa869149412f', 'common.repeat.password', '重复密码', 'zh-cn', '2014-07-03 18:39:43', '4028818d46f764fb0146f7661cb60052', 'admin', '2014-07-02 23:27:53', '4028818d46f764fb0146f7661cb60052', 'admin');
INSERT INTO `t_s_muti_lang` VALUES ('aec73ffa01b5499db0253b3b34194560', 'username.rang2to10', '用户名范围在2~10位字符', 'zh-cn', '2014-07-04 18:39:43', '4028818d46f764fb0146f7661cb60052', 'admin', '2014-07-02 23:27:53', '4028818d46f764fb0146f7661cb60052', 'admin');
INSERT INTO `t_s_muti_lang` VALUES ('b8865c9032054772b39d43efda9ba0c8', 'role.muti.select', 'The role of multiple choices', 'en', '2014-07-04 18:39:43', '4028818d46f764fb0146f7661cb60052', 'admin', '2014-07-04 23:27:53', '4028818d46f764fb0146f7661cb60052', 'admin');
INSERT INTO `t_s_muti_lang` VALUES ('b8dae445b3ef468db87167ddd8cd1b64', 'please.select.department', '请选择组织机构', 'zh-cn', '2014-07-04 18:39:43', '4028818d46f764fb0146f7661cb60052', 'admin', '2014-07-04 23:27:53', '4028818d46f764fb0146f7661cb60052', 'admin');
INSERT INTO `t_s_muti_lang` VALUES ('c150726fac0d43fd9bf28f4590018950', 'common.username', 'User Name', 'en', '2014-07-03 18:39:42', '4028818d46f764fb0146f7661cb60052', 'admin', '2014-07-02 23:27:53', '4028818d46f764fb0146f7661cb60052', 'admin');
INSERT INTO `t_s_muti_lang` VALUES ('caaf209a7acb413ea59bbdf30e944f20', 'common.common.mail', 'Mail', 'en', '2014-07-03 18:39:43', '4028818d46f764fb0146f7661cb60052', 'admin', '2014-07-02 23:27:53', '4028818d46f764fb0146f7661cb60052', 'admin');
INSERT INTO `t_s_muti_lang` VALUES ('ce8b2968f1fc49bba1a636ca18e7f08f', 'usename.range2to10', 'The user name in the range of 2~10 characters', 'en', '2014-07-03 18:39:43', '4028818d46f764fb0146f7661cb60052', 'admin', '2014-07-02 23:27:53', '4028818d46f764fb0146f7661cb60052', 'admin');
INSERT INTO `t_s_muti_lang` VALUES ('d136cd1f25cc42fe8a0fae2dddc5de23', 'common.weak', 'Weak', 'en', '2014-07-04 18:39:43', '4028818d46f764fb0146f7661cb60052', 'admin', '2014-07-04 23:27:53', '4028818d46f764fb0146f7661cb60052', 'admin');
INSERT INTO `t_s_muti_lang` VALUES ('dc787a2087ea4f248a394f8a88a5792c', 'common.real.name', '真实姓名', 'zh-cn', '2014-07-03 18:39:42', '4028818d46f764fb0146f7661cb60052', 'admin', '2014-07-02 23:27:53', '4028818d46f764fb0146f7661cb60052', 'admin');
INSERT INTO `t_s_muti_lang` VALUES ('df075bc6373b4658afcfaff33b088952', 'common.role', '角色', 'zh-cn', '2014-07-03 18:39:43', '4028818d46f764fb0146f7661cb60052', 'admin', '2014-07-02 23:27:53', '4028818d46f764fb0146f7661cb60052', 'admin');
INSERT INTO `t_s_muti_lang` VALUES ('e1fb12b3993b4d1ea35bd536801ada1f', 'common.common.mail', '常用邮箱', 'zh-cn', '2014-07-03 18:39:43', '4028818d46f764fb0146f7661cb60052', 'admin', '2014-07-02 23:27:53', '4028818d46f764fb0146f7661cb60052', 'admin');
INSERT INTO `t_s_muti_lang` VALUES ('e547fec1826c4811b6d759f2d81153f8', 'common.password.reset', 'Password Reset', 'en', '2014-07-03 18:39:42', '4028818d46f764fb0146f7661cb60052', 'admin', '2014-07-02 23:27:53', '4028818d46f764fb0146f7661cb60052', 'admin');
INSERT INTO `t_s_muti_lang` VALUES ('f9f74528bde04a0f9e25e29cbc87d9fb', 'fill.realname', '填写个人真实姓名', 'zh-cn', '2014-07-04 18:39:43', '4028818d46f764fb0146f7661cb60052', 'admin', '2014-07-04 23:27:53', '4028818d46f764fb0146f7661cb60052', 'admin');
INSERT INTO `t_s_muti_lang` VALUES ('fa07850cb8ed4c268cc91ffd31e7ace1', 'common.password', 'Password', 'en', '2014-07-03 18:39:43', '4028818d46f764fb0146f7661cb60052', 'admin', '2014-07-02 23:27:53', '4028818d46f764fb0146f7661cb60052', 'admin');

-- ----------------------------
-- Table structure for t_s_operation
-- ----------------------------
DROP TABLE IF EXISTS `t_s_operation`;
CREATE TABLE `t_s_operation` (
  `ID` varchar(32) NOT NULL,
  `operationtype` smallint(6) DEFAULT NULL,
  `operationcode` varchar(50) DEFAULT NULL,
  `operationicon` varchar(100) DEFAULT NULL,
  `operationname` varchar(50) DEFAULT NULL,
  `status` smallint(6) DEFAULT NULL,
  `functionid` varchar(32) DEFAULT NULL,
  `iconid` varchar(32) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `FK_pceuy41wr2fjbcilyc7mk3m1f` (`functionid`) USING BTREE,
  KEY `FK_ny5de7922l39ta2pkhyspd5f` (`iconid`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of t_s_operation
-- ----------------------------
INSERT INTO `t_s_operation` VALUES ('40280081544c16d601544c173cfb0057', null, 'add', null, '录入', null, '40280081544c16d601544c173cb60036', '40280081544c16d601544c173c3a0001');
INSERT INTO `t_s_operation` VALUES ('40280081544c16d601544c173cfd0058', null, 'edit', null, '编辑', null, '40280081544c16d601544c173cb60036', '40280081544c16d601544c173c3a0001');
INSERT INTO `t_s_operation` VALUES ('40280081544c16d601544c173cfe0059', null, 'del', null, '删除', null, '40280081544c16d601544c173cb60036', '40280081544c16d601544c173c3a0001');
INSERT INTO `t_s_operation` VALUES ('40280081544c16d601544c173d00005a', null, 'szqm', null, '审核', null, '40280081544c16d601544c173cb60036', '40280081544c16d601544c173c3a0001');

-- ----------------------------
-- Table structure for t_s_opintemplate
-- ----------------------------
DROP TABLE IF EXISTS `t_s_opintemplate`;
CREATE TABLE `t_s_opintemplate` (
  `ID` varchar(32) NOT NULL,
  `descript` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of t_s_opintemplate
-- ----------------------------

-- ----------------------------
-- Table structure for t_s_role
-- ----------------------------
DROP TABLE IF EXISTS `t_s_role`;
CREATE TABLE `t_s_role` (
  `ID` varchar(32) NOT NULL,
  `rolecode` varchar(10) DEFAULT NULL,
  `rolename` varchar(100) NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of t_s_role
-- ----------------------------
INSERT INTO `t_s_role` VALUES ('40280081544c16d601544c173c49000a', 'admin', '管理员');
INSERT INTO `t_s_role` VALUES ('40280081544c16d601544c173c4c000b', 'manager', '普通用户');

-- ----------------------------
-- Table structure for t_s_role_function
-- ----------------------------
DROP TABLE IF EXISTS `t_s_role_function`;
CREATE TABLE `t_s_role_function` (
  `ID` varchar(32) NOT NULL,
  `datarule` varchar(100) DEFAULT NULL,
  `operation` varchar(100) DEFAULT NULL,
  `functionid` varchar(32) DEFAULT NULL,
  `roleid` varchar(32) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `FK_fvsillj2cxyk5thnuu625urab` (`functionid`) USING BTREE,
  KEY `FK_9dww3p4w8jwvlrgwhpitsbfif` (`roleid`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of t_s_role_function
-- ----------------------------
INSERT INTO `t_s_role_function` VALUES ('40280081544c16d601544c173d06005b', null, null, '40280081544c16d601544c173cb60036', '40280081544c16d601544c173c49000a');
INSERT INTO `t_s_role_function` VALUES ('40280081544c16d601544c173d08005c', null, null, '40280081544c16d601544c173cb60036', '40280081544c16d601544c173c4c000b');
INSERT INTO `t_s_role_function` VALUES ('40280081544c16d601544c173d09005d', null, null, '40280081544c16d601544c173cba0038', '40280081544c16d601544c173c49000a');
INSERT INTO `t_s_role_function` VALUES ('40280081544c16d601544c173d0a005e', null, null, '40280081544c16d601544c173cba0038', '40280081544c16d601544c173c4c000b');
INSERT INTO `t_s_role_function` VALUES ('40280081544c16d601544c173d0b005f', null, null, '40280081544c16d601544c173cbe003a', '40280081544c16d601544c173c49000a');
INSERT INTO `t_s_role_function` VALUES ('40280081544c16d601544c173d0e0060', null, null, '40280081544c16d601544c173cbe003a', '40280081544c16d601544c173c4c000b');
INSERT INTO `t_s_role_function` VALUES ('40280081544c16d601544c173d0f0061', null, null, '40280081544c16d601544c173cc1003c', '40280081544c16d601544c173c49000a');
INSERT INTO `t_s_role_function` VALUES ('40280081544c16d601544c173d100062', null, null, '40280081544c16d601544c173cc1003c', '40280081544c16d601544c173c4c000b');
INSERT INTO `t_s_role_function` VALUES ('40280081544c16d601544c173d120063', null, null, '40280081544c16d601544c173cc7003e', '40280081544c16d601544c173c49000a');
INSERT INTO `t_s_role_function` VALUES ('40280081544c16d601544c173d140064', null, null, '40280081544c16d601544c173cc7003e', '40280081544c16d601544c173c4c000b');
INSERT INTO `t_s_role_function` VALUES ('40280081544c16d601544c173d160065', null, null, '40280081544c16d601544c173ccc0040', '40280081544c16d601544c173c49000a');
INSERT INTO `t_s_role_function` VALUES ('40280081544c16d601544c173d180066', null, null, '40280081544c16d601544c173ccc0040', '40280081544c16d601544c173c4c000b');
INSERT INTO `t_s_role_function` VALUES ('40280081544c16d601544c173d1b0067', null, null, '40280081544c16d601544c173cd10042', '40280081544c16d601544c173c49000a');
INSERT INTO `t_s_role_function` VALUES ('40280081544c16d601544c173d1d0068', null, null, '40280081544c16d601544c173cd10042', '40280081544c16d601544c173c4c000b');
INSERT INTO `t_s_role_function` VALUES ('40280081544c16d601544c173d1f0069', null, null, '40280081544c16d601544c173cd30044', '40280081544c16d601544c173c49000a');
INSERT INTO `t_s_role_function` VALUES ('40280081544c16d601544c173d21006a', null, null, '40280081544c16d601544c173cd30044', '40280081544c16d601544c173c4c000b');
INSERT INTO `t_s_role_function` VALUES ('40280081544c16d601544c173d23006b', null, null, '40280081544c16d601544c173cd80046', '40280081544c16d601544c173c49000a');
INSERT INTO `t_s_role_function` VALUES ('40280081544c16d601544c173d25006c', null, null, '40280081544c16d601544c173cd80046', '40280081544c16d601544c173c4c000b');
INSERT INTO `t_s_role_function` VALUES ('40280081544c16d601544c173d26006d', null, null, '40280081544c16d601544c173cdb0048', '40280081544c16d601544c173c49000a');
INSERT INTO `t_s_role_function` VALUES ('40280081544c16d601544c173d27006e', null, null, '40280081544c16d601544c173cdb0048', '40280081544c16d601544c173c4c000b');
INSERT INTO `t_s_role_function` VALUES ('40280081544c16d601544c173d28006f', null, null, '40280081544c16d601544c173cdd004a', '40280081544c16d601544c173c49000a');
INSERT INTO `t_s_role_function` VALUES ('40280081544c16d601544c173d2a0070', null, null, '40280081544c16d601544c173cdd004a', '40280081544c16d601544c173c4c000b');
INSERT INTO `t_s_role_function` VALUES ('40280081544c16d601544c173d2b0071', null, null, '40280081544c16d601544c173ce0004c', '40280081544c16d601544c173c49000a');
INSERT INTO `t_s_role_function` VALUES ('40280081544c16d601544c173d2c0072', null, null, '40280081544c16d601544c173ce0004c', '40280081544c16d601544c173c4c000b');
INSERT INTO `t_s_role_function` VALUES ('40280081544c16d601544c173d2d0073', null, null, '40280081544c16d601544c173ce2004e', '40280081544c16d601544c173c49000a');
INSERT INTO `t_s_role_function` VALUES ('40280081544c16d601544c173d2e0074', null, null, '40280081544c16d601544c173ce2004e', '40280081544c16d601544c173c4c000b');
INSERT INTO `t_s_role_function` VALUES ('40280081544c16d601544c173d300075', null, null, '40280081544c16d601544c173ce50050', '40280081544c16d601544c173c49000a');
INSERT INTO `t_s_role_function` VALUES ('40280081544c16d601544c173d310076', null, null, '40280081544c16d601544c173ce50050', '40280081544c16d601544c173c4c000b');
INSERT INTO `t_s_role_function` VALUES ('40280081544c16d601544c173d320077', null, null, '40280081544c16d601544c173cf20052', '40280081544c16d601544c173c49000a');
INSERT INTO `t_s_role_function` VALUES ('40280081544c16d601544c173d330078', null, null, '40280081544c16d601544c173cf20052', '40280081544c16d601544c173c4c000b');
INSERT INTO `t_s_role_function` VALUES ('40280081544c16d601544c173d340079', null, null, '40280081544c16d601544c173cf40054', '40280081544c16d601544c173c49000a');
INSERT INTO `t_s_role_function` VALUES ('40280081544c16d601544c173d36007a', null, null, '40280081544c16d601544c173cf40054', '40280081544c16d601544c173c4c000b');
INSERT INTO `t_s_role_function` VALUES ('40280081544c16d601544c173d37007b', null, null, '40280081544c16d601544c173cf70056', '40280081544c16d601544c173c49000a');
INSERT INTO `t_s_role_function` VALUES ('40280081544c16d601544c173d38007c', null, null, '40280081544c16d601544c173cf70056', '40280081544c16d601544c173c4c000b');
INSERT INTO `t_s_role_function` VALUES ('4028008154668b440154670424390004', null, null, '4028008154668b44015466fd39ec0002', '40280081544c16d601544c173c49000a');

-- ----------------------------
-- Table structure for t_s_role_org
-- ----------------------------
DROP TABLE IF EXISTS `t_s_role_org`;
CREATE TABLE `t_s_role_org` (
  `ID` varchar(32) NOT NULL,
  `org_id` varchar(32) DEFAULT NULL,
  `role_id` varchar(32) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `FK_1cu6fg5e7va6729j6vtxwb3om` (`org_id`) USING BTREE,
  KEY `FK_85t42fmicn6w723xvdw7h3xvl` (`role_id`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of t_s_role_org
-- ----------------------------

-- ----------------------------
-- Table structure for t_s_role_user
-- ----------------------------
DROP TABLE IF EXISTS `t_s_role_user`;
CREATE TABLE `t_s_role_user` (
  `ID` varchar(32) NOT NULL,
  `roleid` varchar(32) DEFAULT NULL,
  `userid` varchar(32) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `FK_n2ucxeorvpjy7qhnmuem01kbx` (`roleid`) USING BTREE,
  KEY `FK_d4qb5xld2pfb0bkjx9iwtolda` (`userid`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of t_s_role_user
-- ----------------------------
INSERT INTO `t_s_role_user` VALUES ('40280081544c16d601544c173c620010', '40280081544c16d601544c173c4c000b', '40280081544c16d601544c173c5a000e');
INSERT INTO `t_s_role_user` VALUES ('40280081544c16d601544c173c660011', '40280081544c16d601544c173c49000a', '40280081544c16d601544c173c50000c');
INSERT INTO `t_s_role_user` VALUES ('40280081544c16d601544c173c680012', '40280081544c16d601544c173c49000a', '40280081544c16d601544c173c50000c');

-- ----------------------------
-- Table structure for t_s_template
-- ----------------------------
DROP TABLE IF EXISTS `t_s_template`;
CREATE TABLE `t_s_template` (
  `id` varchar(32) NOT NULL COMMENT '主键',
  `code` varchar(50) NOT NULL COMMENT '模版编码',
  `name` varchar(50) NOT NULL COMMENT '模版名称',
  `image` varchar(500) NOT NULL COMMENT '模版图片',
  `status` int(11) NOT NULL DEFAULT '0' COMMENT '状态0-未设置，1-已设置',
  `update_date` datetime DEFAULT NULL COMMENT '更新日期',
  `update_by` varchar(50) DEFAULT NULL COMMENT '更新人编号',
  `update_name` varchar(50) DEFAULT NULL COMMENT '更新人姓名',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of t_s_template
-- ----------------------------
INSERT INTO `t_s_template` VALUES ('40280081544c16d601544c173d3a007d', '经典风格', '经典风格', 'resource/image/template/default.png', '0', null, null, null);
INSERT INTO `t_s_template` VALUES ('40280081544c16d601544c173d3d007e', 'shortcut', 'shortcut风格', 'resource/image/template/shortcut.png', '0', null, null, null);
INSERT INTO `t_s_template` VALUES ('40280081544c16d601544c173d3e007f', 'sliding', 'Sliding云桌面', 'resource/image/template/sliding.png', '0', null, null, null);
INSERT INTO `t_s_template` VALUES ('40280081544c16d601544c173d3f0080', 'ace', 'ACE平面风格', 'resource/image/template/ace.png', '1', null, null, null);
INSERT INTO `t_s_template` VALUES ('40280081544c16d601544c173d410081', 'bootstrap', 'bootstrap风格', 'resource/image/template/bootstrap.png', '0', null, null, null);

-- ----------------------------
-- Table structure for t_s_territory
-- ----------------------------
DROP TABLE IF EXISTS `t_s_territory`;
CREATE TABLE `t_s_territory` (
  `ID` varchar(32) NOT NULL,
  `territorycode` varchar(10) NOT NULL,
  `territorylevel` smallint(6) NOT NULL,
  `territoryname` varchar(50) NOT NULL,
  `territory_pinyin` varchar(40) DEFAULT NULL,
  `territorysort` varchar(3) NOT NULL,
  `x_wgs84` double NOT NULL,
  `y_wgs84` double NOT NULL,
  `territoryparentid` varchar(32) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of t_s_territory
-- ----------------------------
INSERT INTO `t_s_territory` VALUES ('110000', '', '1', '北京', null, '2', '0', '0', '1');
INSERT INTO `t_s_territory` VALUES ('110100', '', '2', '北京市', null, '0', '0', '0', '110000');
INSERT INTO `t_s_territory` VALUES ('110101', '', '0', '东城区', null, '', '0', '0', '110100');
INSERT INTO `t_s_territory` VALUES ('110102', '', '0', '西城区', null, '', '0', '0', '110100');
INSERT INTO `t_s_territory` VALUES ('110105', '', '0', '朝阳区', null, '', '0', '0', '110100');
INSERT INTO `t_s_territory` VALUES ('110106', '', '0', '丰台区', null, '', '0', '0', '110100');
INSERT INTO `t_s_territory` VALUES ('110107', '', '0', '石景山区', null, '', '0', '0', '110100');
INSERT INTO `t_s_territory` VALUES ('110108', '', '0', '海淀区', null, '', '0', '0', '110100');
INSERT INTO `t_s_territory` VALUES ('110109', '', '0', '门头沟区', null, '', '0', '0', '110100');
INSERT INTO `t_s_territory` VALUES ('110111', '', '0', '房山区', null, '', '0', '0', '110100');
INSERT INTO `t_s_territory` VALUES ('110112', '', '0', '通州区', null, '', '0', '0', '110100');
INSERT INTO `t_s_territory` VALUES ('110113', '', '0', '顺义区', null, '', '0', '0', '110100');
INSERT INTO `t_s_territory` VALUES ('110114', '', '0', '昌平区', null, '', '0', '0', '110100');
INSERT INTO `t_s_territory` VALUES ('110115', '', '0', '大兴区', null, '', '0', '0', '110100');
INSERT INTO `t_s_territory` VALUES ('110116', '', '0', '怀柔区', null, '', '0', '0', '110100');
INSERT INTO `t_s_territory` VALUES ('110117', '', '0', '平谷区', null, '', '0', '0', '110100');
INSERT INTO `t_s_territory` VALUES ('110228', '', '1', '密云县', null, '0', '0', '0', '110100');
INSERT INTO `t_s_territory` VALUES ('110229', '', '0', '延庆县', null, '', '0', '0', '110100');
INSERT INTO `t_s_territory` VALUES ('120000', '', '1', '天津', null, '6', '0', '0', '1');
INSERT INTO `t_s_territory` VALUES ('120100', '', '0', '天津市', null, '', '0', '0', '120000');
INSERT INTO `t_s_territory` VALUES ('120101', '', '0', '和平区', null, '', '0', '0', '120100');
INSERT INTO `t_s_territory` VALUES ('120102', '', '0', '河东区', null, '', '0', '0', '120100');
INSERT INTO `t_s_territory` VALUES ('120103', '', '0', '河西区', null, '', '0', '0', '120100');
INSERT INTO `t_s_territory` VALUES ('120104', '', '0', '南开区', null, '', '0', '0', '120100');
INSERT INTO `t_s_territory` VALUES ('120105', '', '0', '河北区', null, '', '0', '0', '120100');
INSERT INTO `t_s_territory` VALUES ('120106', '', '0', '红桥区', null, '', '0', '0', '120100');
INSERT INTO `t_s_territory` VALUES ('120110', '', '0', '东丽区', null, '', '0', '0', '120100');
INSERT INTO `t_s_territory` VALUES ('120111', '', '0', '西青区', null, '', '0', '0', '120100');
INSERT INTO `t_s_territory` VALUES ('120112', '', '0', '津南区', null, '', '0', '0', '120100');
INSERT INTO `t_s_territory` VALUES ('120113', '', '0', '北辰区', null, '', '0', '0', '120100');
INSERT INTO `t_s_territory` VALUES ('120114', '', '0', '武清区', null, '', '0', '0', '120100');
INSERT INTO `t_s_territory` VALUES ('120115', '', '0', '宝坻区', null, '', '0', '0', '120100');
INSERT INTO `t_s_territory` VALUES ('120116', '', '0', '滨海新区', null, '', '0', '0', '120100');
INSERT INTO `t_s_territory` VALUES ('120221', '', '0', '宁河县', null, '', '0', '0', '120100');
INSERT INTO `t_s_territory` VALUES ('120223', '', '0', '静海县', null, '', '0', '0', '120100');
INSERT INTO `t_s_territory` VALUES ('120225', '', '0', '蓟县', null, '', '0', '0', '120100');
INSERT INTO `t_s_territory` VALUES ('130000', '', '0', '河北省', null, '', '0', '0', '1');
INSERT INTO `t_s_territory` VALUES ('130100', '', '0', '石家庄市', null, '', '0', '0', '130000');
INSERT INTO `t_s_territory` VALUES ('130101', '', '0', '市辖区', null, '', '0', '0', '130100');
INSERT INTO `t_s_territory` VALUES ('130102', '', '0', '长安区', null, '', '0', '0', '130100');
INSERT INTO `t_s_territory` VALUES ('130104', '', '0', '桥西区', null, '', '0', '0', '130100');
INSERT INTO `t_s_territory` VALUES ('130105', '', '0', '新华区', null, '', '0', '0', '130100');
INSERT INTO `t_s_territory` VALUES ('130107', '', '0', '井陉矿区', null, '', '0', '0', '130100');
INSERT INTO `t_s_territory` VALUES ('130108', '', '0', '裕华区', null, '', '0', '0', '130100');
INSERT INTO `t_s_territory` VALUES ('130109', '', '0', '藁城区', null, '', '0', '0', '130100');
INSERT INTO `t_s_territory` VALUES ('130110', '', '0', '鹿泉区', null, '', '0', '0', '130100');
INSERT INTO `t_s_territory` VALUES ('130111', '', '0', '栾城区', null, '', '0', '0', '130100');
INSERT INTO `t_s_territory` VALUES ('130121', '', '0', '井陉县', null, '', '0', '0', '130100');
INSERT INTO `t_s_territory` VALUES ('130123', '', '0', '正定县', null, '', '0', '0', '130100');
INSERT INTO `t_s_territory` VALUES ('130125', '', '0', '行唐县', null, '', '0', '0', '130100');
INSERT INTO `t_s_territory` VALUES ('130126', '', '0', '灵寿县', null, '', '0', '0', '130100');
INSERT INTO `t_s_territory` VALUES ('130127', '', '0', '高邑县', null, '', '0', '0', '130100');
INSERT INTO `t_s_territory` VALUES ('130128', '', '0', '深泽县', null, '', '0', '0', '130100');
INSERT INTO `t_s_territory` VALUES ('130129', '', '0', '赞皇县', null, '', '0', '0', '130100');
INSERT INTO `t_s_territory` VALUES ('130130', '', '0', '无极县', null, '', '0', '0', '130100');
INSERT INTO `t_s_territory` VALUES ('130131', '', '0', '平山县', null, '', '0', '0', '130100');
INSERT INTO `t_s_territory` VALUES ('130132', '', '0', '元氏县', null, '', '0', '0', '130100');
INSERT INTO `t_s_territory` VALUES ('130133', '', '0', '赵县', null, '', '0', '0', '130100');
INSERT INTO `t_s_territory` VALUES ('130183', '', '0', '晋州市', null, '', '0', '0', '130100');
INSERT INTO `t_s_territory` VALUES ('130184', '', '0', '新乐市', null, '', '0', '0', '130100');
INSERT INTO `t_s_territory` VALUES ('130200', '', '0', '唐山市', null, '', '0', '0', '130000');
INSERT INTO `t_s_territory` VALUES ('130201', '', '0', '市辖区', null, '', '0', '0', '130200');
INSERT INTO `t_s_territory` VALUES ('130202', '', '0', '路南区', null, '', '0', '0', '130200');
INSERT INTO `t_s_territory` VALUES ('130203', '', '0', '路北区', null, '', '0', '0', '130200');
INSERT INTO `t_s_territory` VALUES ('130204', '', '0', '古冶区', null, '', '0', '0', '130200');
INSERT INTO `t_s_territory` VALUES ('130205', '', '0', '开平区', null, '', '0', '0', '130200');
INSERT INTO `t_s_territory` VALUES ('130207', '', '0', '丰南区', null, '', '0', '0', '130200');
INSERT INTO `t_s_territory` VALUES ('130208', '', '0', '丰润区', null, '', '0', '0', '130200');
INSERT INTO `t_s_territory` VALUES ('130209', '', '0', '曹妃甸区', null, '', '0', '0', '130200');
INSERT INTO `t_s_territory` VALUES ('130223', '', '0', '滦县', null, '', '0', '0', '130200');
INSERT INTO `t_s_territory` VALUES ('130224', '', '0', '滦南县', null, '', '0', '0', '130200');
INSERT INTO `t_s_territory` VALUES ('130225', '', '0', '乐亭县', null, '', '0', '0', '130200');
INSERT INTO `t_s_territory` VALUES ('130227', '', '0', '迁西县', null, '', '0', '0', '130200');
INSERT INTO `t_s_territory` VALUES ('130229', '', '0', '玉田县', null, '', '0', '0', '130200');
INSERT INTO `t_s_territory` VALUES ('130281', '', '0', '遵化市', null, '', '0', '0', '130200');
INSERT INTO `t_s_territory` VALUES ('130283', '', '0', '迁安市', null, '', '0', '0', '130200');
INSERT INTO `t_s_territory` VALUES ('130300', '', '0', '秦皇岛市', null, '', '0', '0', '130000');
INSERT INTO `t_s_territory` VALUES ('130301', '', '0', '市辖区', null, '', '0', '0', '130300');
INSERT INTO `t_s_territory` VALUES ('130302', '', '0', '海港区', null, '', '0', '0', '130300');
INSERT INTO `t_s_territory` VALUES ('130303', '', '0', '山海关区', null, '', '0', '0', '130300');
INSERT INTO `t_s_territory` VALUES ('130304', '', '0', '北戴河区', null, '', '0', '0', '130300');
INSERT INTO `t_s_territory` VALUES ('130321', '', '0', '青龙满族自治县', null, '', '0', '0', '130300');
INSERT INTO `t_s_territory` VALUES ('130322', '', '0', '昌黎县', null, '', '0', '0', '130300');
INSERT INTO `t_s_territory` VALUES ('130323', '', '0', '抚宁县', null, '', '0', '0', '130300');
INSERT INTO `t_s_territory` VALUES ('130324', '', '0', '卢龙县', null, '', '0', '0', '130300');
INSERT INTO `t_s_territory` VALUES ('130400', '', '0', '邯郸市', null, '', '0', '0', '130000');
INSERT INTO `t_s_territory` VALUES ('130401', '', '0', '市辖区', null, '', '0', '0', '130400');
INSERT INTO `t_s_territory` VALUES ('130402', '', '0', '邯山区', null, '', '0', '0', '130400');
INSERT INTO `t_s_territory` VALUES ('130403', '', '0', '丛台区', null, '', '0', '0', '130400');
INSERT INTO `t_s_territory` VALUES ('130404', '', '0', '复兴区', null, '', '0', '0', '130400');
INSERT INTO `t_s_territory` VALUES ('130406', '', '0', '峰峰矿区', null, '', '0', '0', '130400');
INSERT INTO `t_s_territory` VALUES ('130421', '', '0', '邯郸县', null, '', '0', '0', '130400');
INSERT INTO `t_s_territory` VALUES ('130423', '', '0', '临漳县', null, '', '0', '0', '130400');
INSERT INTO `t_s_territory` VALUES ('130424', '', '0', '成安县', null, '', '0', '0', '130400');
INSERT INTO `t_s_territory` VALUES ('130425', '', '0', '大名县', null, '', '0', '0', '130400');
INSERT INTO `t_s_territory` VALUES ('130426', '', '0', '涉县', null, '', '0', '0', '130400');
INSERT INTO `t_s_territory` VALUES ('130427', '', '0', '磁县', null, '', '0', '0', '130400');
INSERT INTO `t_s_territory` VALUES ('130428', '', '0', '肥乡县', null, '', '0', '0', '130400');
INSERT INTO `t_s_territory` VALUES ('130429', '', '0', '永年县', null, '', '0', '0', '130400');
INSERT INTO `t_s_territory` VALUES ('130430', '', '0', '邱县', null, '', '0', '0', '130400');
INSERT INTO `t_s_territory` VALUES ('130431', '', '0', '鸡泽县', null, '', '0', '0', '130400');
INSERT INTO `t_s_territory` VALUES ('130432', '', '0', '广平县', null, '', '0', '0', '130400');
INSERT INTO `t_s_territory` VALUES ('130433', '', '0', '馆陶县', null, '', '0', '0', '130400');
INSERT INTO `t_s_territory` VALUES ('130434', '', '0', '魏县', null, '', '0', '0', '130400');
INSERT INTO `t_s_territory` VALUES ('130435', '', '0', '曲周县', null, '', '0', '0', '130400');
INSERT INTO `t_s_territory` VALUES ('130481', '', '0', '武安市', null, '', '0', '0', '130400');
INSERT INTO `t_s_territory` VALUES ('130500', '', '0', '邢台市', null, '', '0', '0', '130000');
INSERT INTO `t_s_territory` VALUES ('130501', '', '0', '市辖区', null, '', '0', '0', '130500');
INSERT INTO `t_s_territory` VALUES ('130502', '', '0', '桥东区', null, '', '0', '0', '130500');
INSERT INTO `t_s_territory` VALUES ('130503', '', '0', '桥西区', null, '', '0', '0', '130500');
INSERT INTO `t_s_territory` VALUES ('130521', '', '0', '邢台县', null, '', '0', '0', '130500');
INSERT INTO `t_s_territory` VALUES ('130522', '', '0', '临城县', null, '', '0', '0', '130500');
INSERT INTO `t_s_territory` VALUES ('130523', '', '0', '内丘县', null, '', '0', '0', '130500');
INSERT INTO `t_s_territory` VALUES ('130524', '', '0', '柏乡县', null, '', '0', '0', '130500');
INSERT INTO `t_s_territory` VALUES ('130525', '', '0', '隆尧县', null, '', '0', '0', '130500');
INSERT INTO `t_s_territory` VALUES ('130526', '', '0', '任县', null, '', '0', '0', '130500');
INSERT INTO `t_s_territory` VALUES ('130527', '', '0', '南和县', null, '', '0', '0', '130500');
INSERT INTO `t_s_territory` VALUES ('130528', '', '0', '宁晋县', null, '', '0', '0', '130500');
INSERT INTO `t_s_territory` VALUES ('130529', '', '0', '巨鹿县', null, '', '0', '0', '130500');
INSERT INTO `t_s_territory` VALUES ('130530', '', '0', '新河县', null, '', '0', '0', '130500');
INSERT INTO `t_s_territory` VALUES ('130531', '', '0', '广宗县', null, '', '0', '0', '130500');
INSERT INTO `t_s_territory` VALUES ('130532', '', '0', '平乡县', null, '', '0', '0', '130500');
INSERT INTO `t_s_territory` VALUES ('130533', '', '0', '威县', null, '', '0', '0', '130500');
INSERT INTO `t_s_territory` VALUES ('130534', '', '0', '清河县', null, '', '0', '0', '130500');
INSERT INTO `t_s_territory` VALUES ('130535', '', '0', '临西县', null, '', '0', '0', '130500');
INSERT INTO `t_s_territory` VALUES ('130581', '', '0', '南宫市', null, '', '0', '0', '130500');
INSERT INTO `t_s_territory` VALUES ('130582', '', '0', '沙河市', null, '', '0', '0', '130500');
INSERT INTO `t_s_territory` VALUES ('130600', '', '0', '保定市', null, '', '0', '0', '130000');
INSERT INTO `t_s_territory` VALUES ('130601', '', '0', '市辖区', null, '', '0', '0', '130600');
INSERT INTO `t_s_territory` VALUES ('130602', '', '0', '新市区', null, '', '0', '0', '130600');
INSERT INTO `t_s_territory` VALUES ('130603', '', '0', '北市区', null, '', '0', '0', '130600');
INSERT INTO `t_s_territory` VALUES ('130604', '', '0', '南市区', null, '', '0', '0', '130600');
INSERT INTO `t_s_territory` VALUES ('130621', '', '0', '满城县', null, '', '0', '0', '130600');
INSERT INTO `t_s_territory` VALUES ('130622', '', '0', '清苑县', null, '', '0', '0', '130600');
INSERT INTO `t_s_territory` VALUES ('130623', '', '0', '涞水县', null, '', '0', '0', '130600');
INSERT INTO `t_s_territory` VALUES ('130624', '', '0', '阜平县', null, '', '0', '0', '130600');
INSERT INTO `t_s_territory` VALUES ('130625', '', '0', '徐水县', null, '', '0', '0', '130600');
INSERT INTO `t_s_territory` VALUES ('130626', '', '0', '定兴县', null, '', '0', '0', '130600');
INSERT INTO `t_s_territory` VALUES ('130627', '', '0', '唐县', null, '', '0', '0', '130600');
INSERT INTO `t_s_territory` VALUES ('130628', '', '0', '高阳县', null, '', '0', '0', '130600');
INSERT INTO `t_s_territory` VALUES ('130629', '', '0', '容城县', null, '', '0', '0', '130600');
INSERT INTO `t_s_territory` VALUES ('130630', '', '0', '涞源县', null, '', '0', '0', '130600');
INSERT INTO `t_s_territory` VALUES ('130631', '', '0', '望都县', null, '', '0', '0', '130600');
INSERT INTO `t_s_territory` VALUES ('130632', '', '0', '安新县', null, '', '0', '0', '130600');
INSERT INTO `t_s_territory` VALUES ('130633', '', '0', '易县', null, '', '0', '0', '130600');
INSERT INTO `t_s_territory` VALUES ('130634', '', '0', '曲阳县', null, '', '0', '0', '130600');
INSERT INTO `t_s_territory` VALUES ('130635', '', '0', '蠡县', null, '', '0', '0', '130600');
INSERT INTO `t_s_territory` VALUES ('130636', '', '0', '顺平县', null, '', '0', '0', '130600');
INSERT INTO `t_s_territory` VALUES ('130637', '', '0', '博野县', null, '', '0', '0', '130600');
INSERT INTO `t_s_territory` VALUES ('130638', '', '0', '雄县', null, '', '0', '0', '130600');
INSERT INTO `t_s_territory` VALUES ('130681', '', '0', '涿州市', null, '', '0', '0', '130600');
INSERT INTO `t_s_territory` VALUES ('130683', '', '0', '安国市', null, '', '0', '0', '130600');
INSERT INTO `t_s_territory` VALUES ('130684', '', '0', '高碑店市', null, '', '0', '0', '130600');
INSERT INTO `t_s_territory` VALUES ('130700', '', '0', '张家口市', null, '', '0', '0', '130000');
INSERT INTO `t_s_territory` VALUES ('130701', '', '0', '市辖区', null, '', '0', '0', '130700');
INSERT INTO `t_s_territory` VALUES ('130702', '', '0', '桥东区', null, '', '0', '0', '130700');
INSERT INTO `t_s_territory` VALUES ('130703', '', '0', '桥西区', null, '', '0', '0', '130700');
INSERT INTO `t_s_territory` VALUES ('130705', '', '0', '宣化区', null, '', '0', '0', '130700');
INSERT INTO `t_s_territory` VALUES ('130706', '', '0', '下花园区', null, '', '0', '0', '130700');
INSERT INTO `t_s_territory` VALUES ('130721', '', '0', '宣化县', null, '', '0', '0', '130700');
INSERT INTO `t_s_territory` VALUES ('130722', '', '0', '张北县', null, '', '0', '0', '130700');
INSERT INTO `t_s_territory` VALUES ('130723', '', '0', '康保县', null, '', '0', '0', '130700');
INSERT INTO `t_s_territory` VALUES ('130724', '', '0', '沽源县', null, '', '0', '0', '130700');
INSERT INTO `t_s_territory` VALUES ('130725', '', '0', '尚义县', null, '', '0', '0', '130700');
INSERT INTO `t_s_territory` VALUES ('130726', '', '0', '蔚县', null, '', '0', '0', '130700');
INSERT INTO `t_s_territory` VALUES ('130727', '', '0', '阳原县', null, '', '0', '0', '130700');
INSERT INTO `t_s_territory` VALUES ('130728', '', '0', '怀安县', null, '', '0', '0', '130700');
INSERT INTO `t_s_territory` VALUES ('130729', '', '0', '万全县', null, '', '0', '0', '130700');
INSERT INTO `t_s_territory` VALUES ('130730', '', '0', '怀来县', null, '', '0', '0', '130700');
INSERT INTO `t_s_territory` VALUES ('130731', '', '0', '涿鹿县', null, '', '0', '0', '130700');
INSERT INTO `t_s_territory` VALUES ('130732', '', '0', '赤城县', null, '', '0', '0', '130700');
INSERT INTO `t_s_territory` VALUES ('130733', '', '0', '崇礼县', null, '', '0', '0', '130700');
INSERT INTO `t_s_territory` VALUES ('130800', '', '0', '承德市', null, '', '0', '0', '130000');
INSERT INTO `t_s_territory` VALUES ('130801', '', '0', '市辖区', null, '', '0', '0', '130800');
INSERT INTO `t_s_territory` VALUES ('130802', '', '0', '双桥区', null, '', '0', '0', '130800');
INSERT INTO `t_s_territory` VALUES ('130803', '', '0', '双滦区', null, '', '0', '0', '130800');
INSERT INTO `t_s_territory` VALUES ('130804', '', '0', '鹰手营子矿区', null, '', '0', '0', '130800');
INSERT INTO `t_s_territory` VALUES ('130821', '', '0', '承德县', null, '', '0', '0', '130800');
INSERT INTO `t_s_territory` VALUES ('130822', '', '0', '兴隆县', null, '', '0', '0', '130800');
INSERT INTO `t_s_territory` VALUES ('130823', '', '0', '平泉县', null, '', '0', '0', '130800');
INSERT INTO `t_s_territory` VALUES ('130824', '', '0', '滦平县', null, '', '0', '0', '130800');
INSERT INTO `t_s_territory` VALUES ('130825', '', '0', '隆化县', null, '', '0', '0', '130800');
INSERT INTO `t_s_territory` VALUES ('130826', '', '0', '丰宁满族自治县', null, '', '0', '0', '130800');
INSERT INTO `t_s_territory` VALUES ('130827', '', '0', '宽城满族自治县', null, '', '0', '0', '130800');
INSERT INTO `t_s_territory` VALUES ('130828', '', '0', '围场满族蒙古族自治县', null, '', '0', '0', '130800');
INSERT INTO `t_s_territory` VALUES ('130900', '', '0', '沧州市', null, '', '0', '0', '130000');
INSERT INTO `t_s_territory` VALUES ('130901', '', '0', '市辖区', null, '', '0', '0', '130900');
INSERT INTO `t_s_territory` VALUES ('130902', '', '0', '新华区', null, '', '0', '0', '130900');
INSERT INTO `t_s_territory` VALUES ('130903', '', '0', '运河区', null, '', '0', '0', '130900');
INSERT INTO `t_s_territory` VALUES ('130921', '', '0', '沧县', null, '', '0', '0', '130900');
INSERT INTO `t_s_territory` VALUES ('130922', '', '0', '青县', null, '', '0', '0', '130900');
INSERT INTO `t_s_territory` VALUES ('130923', '', '0', '东光县', null, '', '0', '0', '130900');
INSERT INTO `t_s_territory` VALUES ('130924', '', '0', '海兴县', null, '', '0', '0', '130900');
INSERT INTO `t_s_territory` VALUES ('130925', '', '0', '盐山县', null, '', '0', '0', '130900');
INSERT INTO `t_s_territory` VALUES ('130926', '', '0', '肃宁县', null, '', '0', '0', '130900');
INSERT INTO `t_s_territory` VALUES ('130927', '', '0', '南皮县', null, '', '0', '0', '130900');
INSERT INTO `t_s_territory` VALUES ('130928', '', '0', '吴桥县', null, '', '0', '0', '130900');
INSERT INTO `t_s_territory` VALUES ('130929', '', '0', '献县', null, '', '0', '0', '130900');
INSERT INTO `t_s_territory` VALUES ('130930', '', '0', '孟村回族自治县', null, '', '0', '0', '130900');
INSERT INTO `t_s_territory` VALUES ('130981', '', '0', '泊头市', null, '', '0', '0', '130900');
INSERT INTO `t_s_territory` VALUES ('130982', '', '0', '任丘市', null, '', '0', '0', '130900');
INSERT INTO `t_s_territory` VALUES ('130983', '', '0', '黄骅市', null, '', '0', '0', '130900');
INSERT INTO `t_s_territory` VALUES ('130984', '', '0', '河间市', null, '', '0', '0', '130900');
INSERT INTO `t_s_territory` VALUES ('131000', '', '0', '廊坊市', null, '', '0', '0', '130000');
INSERT INTO `t_s_territory` VALUES ('131001', '', '0', '市辖区', null, '', '0', '0', '131000');
INSERT INTO `t_s_territory` VALUES ('131002', '', '0', '安次区', null, '', '0', '0', '131000');
INSERT INTO `t_s_territory` VALUES ('131003', '', '0', '广阳区', null, '', '0', '0', '131000');
INSERT INTO `t_s_territory` VALUES ('131022', '', '0', '固安县', null, '', '0', '0', '131000');
INSERT INTO `t_s_territory` VALUES ('131023', '', '0', '永清县', null, '', '0', '0', '131000');
INSERT INTO `t_s_territory` VALUES ('131024', '', '0', '香河县', null, '', '0', '0', '131000');
INSERT INTO `t_s_territory` VALUES ('131025', '', '0', '大城县', null, '', '0', '0', '131000');
INSERT INTO `t_s_territory` VALUES ('131026', '', '0', '文安县', null, '', '0', '0', '131000');
INSERT INTO `t_s_territory` VALUES ('131028', '', '0', '大厂回族自治县', null, '', '0', '0', '131000');
INSERT INTO `t_s_territory` VALUES ('131081', '', '0', '霸州市', null, '', '0', '0', '131000');
INSERT INTO `t_s_territory` VALUES ('131082', '', '0', '三河市', null, '', '0', '0', '131000');
INSERT INTO `t_s_territory` VALUES ('131100', '', '0', '衡水市', null, '', '0', '0', '130000');
INSERT INTO `t_s_territory` VALUES ('131101', '', '0', '市辖区', null, '', '0', '0', '131100');
INSERT INTO `t_s_territory` VALUES ('131102', '', '0', '桃城区', null, '', '0', '0', '131100');
INSERT INTO `t_s_territory` VALUES ('131121', '', '0', '枣强县', null, '', '0', '0', '131100');
INSERT INTO `t_s_territory` VALUES ('131122', '', '0', '武邑县', null, '', '0', '0', '131100');
INSERT INTO `t_s_territory` VALUES ('131123', '', '0', '武强县', null, '', '0', '0', '131100');
INSERT INTO `t_s_territory` VALUES ('131124', '', '0', '饶阳县', null, '', '0', '0', '131100');
INSERT INTO `t_s_territory` VALUES ('131125', '', '0', '安平县', null, '', '0', '0', '131100');
INSERT INTO `t_s_territory` VALUES ('131126', '', '0', '故城县', null, '', '0', '0', '131100');
INSERT INTO `t_s_territory` VALUES ('131127', '', '0', '景县', null, '', '0', '0', '131100');
INSERT INTO `t_s_territory` VALUES ('131128', '', '0', '阜城县', null, '', '0', '0', '131100');
INSERT INTO `t_s_territory` VALUES ('131181', '', '0', '冀州市', null, '', '0', '0', '131100');
INSERT INTO `t_s_territory` VALUES ('131182', '', '0', '深州市', null, '', '0', '0', '131100');
INSERT INTO `t_s_territory` VALUES ('139001', '', '0', '定州市', null, '', '0', '0', '130000');
INSERT INTO `t_s_territory` VALUES ('139002', '', '0', '辛集市', null, '', '0', '0', '130000');
INSERT INTO `t_s_territory` VALUES ('140000', '', '0', '山西省', null, '', '0', '0', '1');
INSERT INTO `t_s_territory` VALUES ('140100', '', '0', '太原市', null, '', '0', '0', '140000');
INSERT INTO `t_s_territory` VALUES ('140101', '', '0', '市辖区', null, '', '0', '0', '140100');
INSERT INTO `t_s_territory` VALUES ('140105', '', '0', '小店区', null, '', '0', '0', '140100');
INSERT INTO `t_s_territory` VALUES ('140106', '', '0', '迎泽区', null, '', '0', '0', '140100');
INSERT INTO `t_s_territory` VALUES ('140107', '', '0', '杏花岭区', null, '', '0', '0', '140100');
INSERT INTO `t_s_territory` VALUES ('140108', '', '0', '尖草坪区', null, '', '0', '0', '140100');
INSERT INTO `t_s_territory` VALUES ('140109', '', '0', '万柏林区', null, '', '0', '0', '140100');
INSERT INTO `t_s_territory` VALUES ('140110', '', '0', '晋源区', null, '', '0', '0', '140100');
INSERT INTO `t_s_territory` VALUES ('140121', '', '0', '清徐县', null, '', '0', '0', '140100');
INSERT INTO `t_s_territory` VALUES ('140122', '', '0', '阳曲县', null, '', '0', '0', '140100');
INSERT INTO `t_s_territory` VALUES ('140123', '', '0', '娄烦县', null, '', '0', '0', '140100');
INSERT INTO `t_s_territory` VALUES ('140181', '', '0', '古交市', null, '', '0', '0', '140100');
INSERT INTO `t_s_territory` VALUES ('140200', '', '0', '大同市', null, '', '0', '0', '140000');
INSERT INTO `t_s_territory` VALUES ('140201', '', '0', '市辖区', null, '', '0', '0', '140200');
INSERT INTO `t_s_territory` VALUES ('140202', '', '0', '城区', null, '', '0', '0', '140200');
INSERT INTO `t_s_territory` VALUES ('140203', '', '0', '矿区', null, '', '0', '0', '140200');
INSERT INTO `t_s_territory` VALUES ('140211', '', '0', '南郊区', null, '', '0', '0', '140200');
INSERT INTO `t_s_territory` VALUES ('140212', '', '0', '新荣区', null, '', '0', '0', '140200');
INSERT INTO `t_s_territory` VALUES ('140221', '', '0', '阳高县', null, '', '0', '0', '140200');
INSERT INTO `t_s_territory` VALUES ('140222', '', '0', '天镇县', null, '', '0', '0', '140200');
INSERT INTO `t_s_territory` VALUES ('140223', '', '0', '广灵县', null, '', '0', '0', '140200');
INSERT INTO `t_s_territory` VALUES ('140224', '', '0', '灵丘县', null, '', '0', '0', '140200');
INSERT INTO `t_s_territory` VALUES ('140225', '', '0', '浑源县', null, '', '0', '0', '140200');
INSERT INTO `t_s_territory` VALUES ('140226', '', '0', '左云县', null, '', '0', '0', '140200');
INSERT INTO `t_s_territory` VALUES ('140227', '', '0', '大同县', null, '', '0', '0', '140200');
INSERT INTO `t_s_territory` VALUES ('140300', '', '0', '阳泉市', null, '', '0', '0', '140000');
INSERT INTO `t_s_territory` VALUES ('140301', '', '0', '市辖区', null, '', '0', '0', '140300');
INSERT INTO `t_s_territory` VALUES ('140302', '', '0', '城区', null, '', '0', '0', '140300');
INSERT INTO `t_s_territory` VALUES ('140303', '', '0', '矿区', null, '', '0', '0', '140300');
INSERT INTO `t_s_territory` VALUES ('140311', '', '0', '郊区', null, '', '0', '0', '140300');
INSERT INTO `t_s_territory` VALUES ('140321', '', '0', '平定县', null, '', '0', '0', '140300');
INSERT INTO `t_s_territory` VALUES ('140322', '', '0', '盂县', null, '', '0', '0', '140300');
INSERT INTO `t_s_territory` VALUES ('140400', '', '0', '长治市', null, '', '0', '0', '140000');
INSERT INTO `t_s_territory` VALUES ('140401', '', '0', '市辖区', null, '', '0', '0', '140400');
INSERT INTO `t_s_territory` VALUES ('140402', '', '0', '城区', null, '', '0', '0', '140400');
INSERT INTO `t_s_territory` VALUES ('140411', '', '0', '郊区', null, '', '0', '0', '140400');
INSERT INTO `t_s_territory` VALUES ('140421', '', '0', '长治县', null, '', '0', '0', '140400');
INSERT INTO `t_s_territory` VALUES ('140423', '', '0', '襄垣县', null, '', '0', '0', '140400');
INSERT INTO `t_s_territory` VALUES ('140424', '', '0', '屯留县', null, '', '0', '0', '140400');
INSERT INTO `t_s_territory` VALUES ('140425', '', '0', '平顺县', null, '', '0', '0', '140400');
INSERT INTO `t_s_territory` VALUES ('140426', '', '0', '黎城县', null, '', '0', '0', '140400');
INSERT INTO `t_s_territory` VALUES ('140427', '', '0', '壶关县', null, '', '0', '0', '140400');
INSERT INTO `t_s_territory` VALUES ('140428', '', '0', '长子县', null, '', '0', '0', '140400');
INSERT INTO `t_s_territory` VALUES ('140429', '', '0', '武乡县', null, '', '0', '0', '140400');
INSERT INTO `t_s_territory` VALUES ('140430', '', '0', '沁县', null, '', '0', '0', '140400');
INSERT INTO `t_s_territory` VALUES ('140431', '', '0', '沁源县', null, '', '0', '0', '140400');
INSERT INTO `t_s_territory` VALUES ('140481', '', '0', '潞城市', null, '', '0', '0', '140400');
INSERT INTO `t_s_territory` VALUES ('140500', '', '0', '晋城市', null, '', '0', '0', '140000');
INSERT INTO `t_s_territory` VALUES ('140501', '', '0', '市辖区', null, '', '0', '0', '140500');
INSERT INTO `t_s_territory` VALUES ('140502', '', '0', '城区', null, '', '0', '0', '140500');
INSERT INTO `t_s_territory` VALUES ('140521', '', '0', '沁水县', null, '', '0', '0', '140500');
INSERT INTO `t_s_territory` VALUES ('140522', '', '0', '阳城县', null, '', '0', '0', '140500');
INSERT INTO `t_s_territory` VALUES ('140524', '', '0', '陵川县', null, '', '0', '0', '140500');
INSERT INTO `t_s_territory` VALUES ('140525', '', '0', '泽州县', null, '', '0', '0', '140500');
INSERT INTO `t_s_territory` VALUES ('140581', '', '0', '高平市', null, '', '0', '0', '140500');
INSERT INTO `t_s_territory` VALUES ('140600', '', '0', '朔州市', null, '', '0', '0', '140000');
INSERT INTO `t_s_territory` VALUES ('140601', '', '0', '市辖区', null, '', '0', '0', '140600');
INSERT INTO `t_s_territory` VALUES ('140602', '', '0', '朔城区', null, '', '0', '0', '140600');
INSERT INTO `t_s_territory` VALUES ('140603', '', '0', '平鲁区', null, '', '0', '0', '140600');
INSERT INTO `t_s_territory` VALUES ('140621', '', '0', '山阴县', null, '', '0', '0', '140600');
INSERT INTO `t_s_territory` VALUES ('140622', '', '0', '应县', null, '', '0', '0', '140600');
INSERT INTO `t_s_territory` VALUES ('140623', '', '0', '右玉县', null, '', '0', '0', '140600');
INSERT INTO `t_s_territory` VALUES ('140624', '', '0', '怀仁县', null, '', '0', '0', '140600');
INSERT INTO `t_s_territory` VALUES ('140700', '', '0', '晋中市', null, '', '0', '0', '140000');
INSERT INTO `t_s_territory` VALUES ('140701', '', '0', '市辖区', null, '', '0', '0', '140700');
INSERT INTO `t_s_territory` VALUES ('140702', '', '0', '榆次区', null, '', '0', '0', '140700');
INSERT INTO `t_s_territory` VALUES ('140721', '', '0', '榆社县', null, '', '0', '0', '140700');
INSERT INTO `t_s_territory` VALUES ('140722', '', '0', '左权县', null, '', '0', '0', '140700');
INSERT INTO `t_s_territory` VALUES ('140723', '', '0', '和顺县', null, '', '0', '0', '140700');
INSERT INTO `t_s_territory` VALUES ('140724', '', '0', '昔阳县', null, '', '0', '0', '140700');
INSERT INTO `t_s_territory` VALUES ('140725', '', '0', '寿阳县', null, '', '0', '0', '140700');
INSERT INTO `t_s_territory` VALUES ('140726', '', '0', '太谷县', null, '', '0', '0', '140700');
INSERT INTO `t_s_territory` VALUES ('140727', '', '0', '祁县', null, '', '0', '0', '140700');
INSERT INTO `t_s_territory` VALUES ('140728', '', '0', '平遥县', null, '', '0', '0', '140700');
INSERT INTO `t_s_territory` VALUES ('140729', '', '0', '灵石县', null, '', '0', '0', '140700');
INSERT INTO `t_s_territory` VALUES ('140781', '', '0', '介休市', null, '', '0', '0', '140700');
INSERT INTO `t_s_territory` VALUES ('140800', '', '0', '运城市', null, '', '0', '0', '140000');
INSERT INTO `t_s_territory` VALUES ('140801', '', '0', '市辖区', null, '', '0', '0', '140800');
INSERT INTO `t_s_territory` VALUES ('140802', '', '0', '盐湖区', null, '', '0', '0', '140800');
INSERT INTO `t_s_territory` VALUES ('140821', '', '0', '临猗县', null, '', '0', '0', '140800');
INSERT INTO `t_s_territory` VALUES ('140822', '', '0', '万荣县', null, '', '0', '0', '140800');
INSERT INTO `t_s_territory` VALUES ('140823', '', '0', '闻喜县', null, '', '0', '0', '140800');
INSERT INTO `t_s_territory` VALUES ('140824', '', '0', '稷山县', null, '', '0', '0', '140800');
INSERT INTO `t_s_territory` VALUES ('140825', '', '0', '新绛县', null, '', '0', '0', '140800');
INSERT INTO `t_s_territory` VALUES ('140826', '', '0', '绛县', null, '', '0', '0', '140800');
INSERT INTO `t_s_territory` VALUES ('140827', '', '0', '垣曲县', null, '', '0', '0', '140800');
INSERT INTO `t_s_territory` VALUES ('140828', '', '0', '夏县', null, '', '0', '0', '140800');
INSERT INTO `t_s_territory` VALUES ('140829', '', '0', '平陆县', null, '', '0', '0', '140800');
INSERT INTO `t_s_territory` VALUES ('140830', '', '0', '芮城县', null, '', '0', '0', '140800');
INSERT INTO `t_s_territory` VALUES ('140881', '', '0', '永济市', null, '', '0', '0', '140800');
INSERT INTO `t_s_territory` VALUES ('140882', '', '0', '河津市', null, '', '0', '0', '140800');
INSERT INTO `t_s_territory` VALUES ('140900', '', '0', '忻州市', null, '', '0', '0', '140000');
INSERT INTO `t_s_territory` VALUES ('140901', '', '0', '市辖区', null, '', '0', '0', '140900');
INSERT INTO `t_s_territory` VALUES ('140902', '', '0', '忻府区', null, '', '0', '0', '140900');
INSERT INTO `t_s_territory` VALUES ('140921', '', '0', '定襄县', null, '', '0', '0', '140900');
INSERT INTO `t_s_territory` VALUES ('140922', '', '0', '五台县', null, '', '0', '0', '140900');
INSERT INTO `t_s_territory` VALUES ('140923', '', '0', '代县', null, '', '0', '0', '140900');
INSERT INTO `t_s_territory` VALUES ('140924', '', '0', '繁峙县', null, '', '0', '0', '140900');
INSERT INTO `t_s_territory` VALUES ('140925', '', '0', '宁武县', null, '', '0', '0', '140900');
INSERT INTO `t_s_territory` VALUES ('140926', '', '0', '静乐县', null, '', '0', '0', '140900');
INSERT INTO `t_s_territory` VALUES ('140927', '', '0', '神池县', null, '', '0', '0', '140900');
INSERT INTO `t_s_territory` VALUES ('140928', '', '0', '五寨县', null, '', '0', '0', '140900');
INSERT INTO `t_s_territory` VALUES ('140929', '', '0', '岢岚县', null, '', '0', '0', '140900');
INSERT INTO `t_s_territory` VALUES ('140930', '', '0', '河曲县', null, '', '0', '0', '140900');
INSERT INTO `t_s_territory` VALUES ('140931', '', '0', '保德县', null, '', '0', '0', '140900');
INSERT INTO `t_s_territory` VALUES ('140932', '', '0', '偏关县', null, '', '0', '0', '140900');
INSERT INTO `t_s_territory` VALUES ('140981', '', '0', '原平市', null, '', '0', '0', '140900');
INSERT INTO `t_s_territory` VALUES ('141000', '', '0', '临汾市', null, '', '0', '0', '140000');
INSERT INTO `t_s_territory` VALUES ('141001', '', '0', '市辖区', null, '', '0', '0', '141000');
INSERT INTO `t_s_territory` VALUES ('141002', '', '0', '尧都区', null, '', '0', '0', '141000');
INSERT INTO `t_s_territory` VALUES ('141021', '', '0', '曲沃县', null, '', '0', '0', '141000');
INSERT INTO `t_s_territory` VALUES ('141022', '', '0', '翼城县', null, '', '0', '0', '141000');
INSERT INTO `t_s_territory` VALUES ('141023', '', '0', '襄汾县', null, '', '0', '0', '141000');
INSERT INTO `t_s_territory` VALUES ('141024', '', '0', '洪洞县', null, '', '0', '0', '141000');
INSERT INTO `t_s_territory` VALUES ('141025', '', '0', '古县', null, '', '0', '0', '141000');
INSERT INTO `t_s_territory` VALUES ('141026', '', '0', '安泽县', null, '', '0', '0', '141000');
INSERT INTO `t_s_territory` VALUES ('141027', '', '0', '浮山县', null, '', '0', '0', '141000');
INSERT INTO `t_s_territory` VALUES ('141028', '', '0', '吉县', null, '', '0', '0', '141000');
INSERT INTO `t_s_territory` VALUES ('141029', '', '0', '乡宁县', null, '', '0', '0', '141000');
INSERT INTO `t_s_territory` VALUES ('141030', '', '0', '大宁县', null, '', '0', '0', '141000');
INSERT INTO `t_s_territory` VALUES ('141031', '', '0', '隰县', null, '', '0', '0', '141000');
INSERT INTO `t_s_territory` VALUES ('141032', '', '0', '永和县', null, '', '0', '0', '141000');
INSERT INTO `t_s_territory` VALUES ('141033', '', '0', '蒲县', null, '', '0', '0', '141000');
INSERT INTO `t_s_territory` VALUES ('141034', '', '0', '汾西县', null, '', '0', '0', '141000');
INSERT INTO `t_s_territory` VALUES ('141081', '', '0', '侯马市', null, '', '0', '0', '141000');
INSERT INTO `t_s_territory` VALUES ('141082', '', '0', '霍州市', null, '', '0', '0', '141000');
INSERT INTO `t_s_territory` VALUES ('141100', '', '0', '吕梁市', null, '', '0', '0', '140000');
INSERT INTO `t_s_territory` VALUES ('141101', '', '0', '市辖区', null, '', '0', '0', '141100');
INSERT INTO `t_s_territory` VALUES ('141102', '', '0', '离石区', null, '', '0', '0', '141100');
INSERT INTO `t_s_territory` VALUES ('141121', '', '0', '文水县', null, '', '0', '0', '141100');
INSERT INTO `t_s_territory` VALUES ('141122', '', '0', '交城县', null, '', '0', '0', '141100');
INSERT INTO `t_s_territory` VALUES ('141123', '', '0', '兴县', null, '', '0', '0', '141100');
INSERT INTO `t_s_territory` VALUES ('141124', '', '0', '临县', null, '', '0', '0', '141100');
INSERT INTO `t_s_territory` VALUES ('141125', '', '0', '柳林县', null, '', '0', '0', '141100');
INSERT INTO `t_s_territory` VALUES ('141126', '', '0', '石楼县', null, '', '0', '0', '141100');
INSERT INTO `t_s_territory` VALUES ('141127', '', '0', '岚县', null, '', '0', '0', '141100');
INSERT INTO `t_s_territory` VALUES ('141128', '', '0', '方山县', null, '', '0', '0', '141100');
INSERT INTO `t_s_territory` VALUES ('141129', '', '0', '中阳县', null, '', '0', '0', '141100');
INSERT INTO `t_s_territory` VALUES ('141130', '', '0', '交口县', null, '', '0', '0', '141100');
INSERT INTO `t_s_territory` VALUES ('141181', '', '0', '孝义市', null, '', '0', '0', '141100');
INSERT INTO `t_s_territory` VALUES ('141182', '', '0', '汾阳市', null, '', '0', '0', '141100');
INSERT INTO `t_s_territory` VALUES ('150000', '', '0', '内蒙古自治区', null, '', '0', '0', '1');
INSERT INTO `t_s_territory` VALUES ('150100', '', '0', '呼和浩特市', null, '', '0', '0', '150000');
INSERT INTO `t_s_territory` VALUES ('150101', '', '0', '市辖区', null, '', '0', '0', '150100');
INSERT INTO `t_s_territory` VALUES ('150102', '', '0', '新城区', null, '', '0', '0', '150100');
INSERT INTO `t_s_territory` VALUES ('150103', '', '0', '回民区', null, '', '0', '0', '150100');
INSERT INTO `t_s_territory` VALUES ('150104', '', '0', '玉泉区', null, '', '0', '0', '150100');
INSERT INTO `t_s_territory` VALUES ('150105', '', '0', '赛罕区', null, '', '0', '0', '150100');
INSERT INTO `t_s_territory` VALUES ('150121', '', '0', '土默特左旗', null, '', '0', '0', '150100');
INSERT INTO `t_s_territory` VALUES ('150122', '', '0', '托克托县', null, '', '0', '0', '150100');
INSERT INTO `t_s_territory` VALUES ('150123', '', '0', '和林格尔县', null, '', '0', '0', '150100');
INSERT INTO `t_s_territory` VALUES ('150124', '', '0', '清水河县', null, '', '0', '0', '150100');
INSERT INTO `t_s_territory` VALUES ('150125', '', '0', '武川县', null, '', '0', '0', '150100');
INSERT INTO `t_s_territory` VALUES ('150200', '', '0', '包头市', null, '', '0', '0', '150000');
INSERT INTO `t_s_territory` VALUES ('150201', '', '0', '市辖区', null, '', '0', '0', '150200');
INSERT INTO `t_s_territory` VALUES ('150202', '', '0', '东河区', null, '', '0', '0', '150200');
INSERT INTO `t_s_territory` VALUES ('150203', '', '0', '昆都仑区', null, '', '0', '0', '150200');
INSERT INTO `t_s_territory` VALUES ('150204', '', '0', '青山区', null, '', '0', '0', '150200');
INSERT INTO `t_s_territory` VALUES ('150205', '', '0', '石拐区', null, '', '0', '0', '150200');
INSERT INTO `t_s_territory` VALUES ('150206', '', '0', '白云鄂博矿区', null, '', '0', '0', '150200');
INSERT INTO `t_s_territory` VALUES ('150207', '', '0', '九原区', null, '', '0', '0', '150200');
INSERT INTO `t_s_territory` VALUES ('150221', '', '0', '土默特右旗', null, '', '0', '0', '150200');
INSERT INTO `t_s_territory` VALUES ('150222', '', '0', '固阳县', null, '', '0', '0', '150200');
INSERT INTO `t_s_territory` VALUES ('150223', '', '0', '达尔罕茂明安联合旗', null, '', '0', '0', '150200');
INSERT INTO `t_s_territory` VALUES ('150300', '', '0', '乌海市', null, '', '0', '0', '150000');
INSERT INTO `t_s_territory` VALUES ('150301', '', '0', '市辖区', null, '', '0', '0', '150300');
INSERT INTO `t_s_territory` VALUES ('150302', '', '0', '海勃湾区', null, '', '0', '0', '150300');
INSERT INTO `t_s_territory` VALUES ('150303', '', '0', '海南区', null, '', '0', '0', '150300');
INSERT INTO `t_s_territory` VALUES ('150304', '', '0', '乌达区', null, '', '0', '0', '150300');
INSERT INTO `t_s_territory` VALUES ('150400', '', '0', '赤峰市', null, '', '0', '0', '150000');
INSERT INTO `t_s_territory` VALUES ('150401', '', '0', '市辖区', null, '', '0', '0', '150400');
INSERT INTO `t_s_territory` VALUES ('150402', '', '0', '红山区', null, '', '0', '0', '150400');
INSERT INTO `t_s_territory` VALUES ('150403', '', '0', '元宝山区', null, '', '0', '0', '150400');
INSERT INTO `t_s_territory` VALUES ('150404', '', '0', '松山区', null, '', '0', '0', '150400');
INSERT INTO `t_s_territory` VALUES ('150421', '', '0', '阿鲁科尔沁旗', null, '', '0', '0', '150400');
INSERT INTO `t_s_territory` VALUES ('150422', '', '0', '巴林左旗', null, '', '0', '0', '150400');
INSERT INTO `t_s_territory` VALUES ('150423', '', '0', '巴林右旗', null, '', '0', '0', '150400');
INSERT INTO `t_s_territory` VALUES ('150424', '', '0', '林西县', null, '', '0', '0', '150400');
INSERT INTO `t_s_territory` VALUES ('150425', '', '0', '克什克腾旗', null, '', '0', '0', '150400');
INSERT INTO `t_s_territory` VALUES ('150426', '', '0', '翁牛特旗', null, '', '0', '0', '150400');
INSERT INTO `t_s_territory` VALUES ('150428', '', '0', '喀喇沁旗', null, '', '0', '0', '150400');
INSERT INTO `t_s_territory` VALUES ('150429', '', '0', '宁城县', null, '', '0', '0', '150400');
INSERT INTO `t_s_territory` VALUES ('150430', '', '0', '敖汉旗', null, '', '0', '0', '150400');
INSERT INTO `t_s_territory` VALUES ('150500', '', '0', '通辽市', null, '', '0', '0', '150000');
INSERT INTO `t_s_territory` VALUES ('150501', '', '0', '市辖区', null, '', '0', '0', '150500');
INSERT INTO `t_s_territory` VALUES ('150502', '', '0', '科尔沁区', null, '', '0', '0', '150500');
INSERT INTO `t_s_territory` VALUES ('150521', '', '0', '科尔沁左翼中旗', null, '', '0', '0', '150500');
INSERT INTO `t_s_territory` VALUES ('150522', '', '0', '科尔沁左翼后旗', null, '', '0', '0', '150500');
INSERT INTO `t_s_territory` VALUES ('150523', '', '0', '开鲁县', null, '', '0', '0', '150500');
INSERT INTO `t_s_territory` VALUES ('150524', '', '0', '库伦旗', null, '', '0', '0', '150500');
INSERT INTO `t_s_territory` VALUES ('150525', '', '0', '奈曼旗', null, '', '0', '0', '150500');
INSERT INTO `t_s_territory` VALUES ('150526', '', '0', '扎鲁特旗', null, '', '0', '0', '150500');
INSERT INTO `t_s_territory` VALUES ('150581', '', '0', '霍林郭勒市', null, '', '0', '0', '150500');
INSERT INTO `t_s_territory` VALUES ('150600', '', '0', '鄂尔多斯市', null, '', '0', '0', '150000');
INSERT INTO `t_s_territory` VALUES ('150601', '', '0', '市辖区', null, '', '0', '0', '150600');
INSERT INTO `t_s_territory` VALUES ('150602', '', '0', '东胜区', null, '', '0', '0', '150600');
INSERT INTO `t_s_territory` VALUES ('150621', '', '0', '达拉特旗', null, '', '0', '0', '150600');
INSERT INTO `t_s_territory` VALUES ('150622', '', '0', '准格尔旗', null, '', '0', '0', '150600');
INSERT INTO `t_s_territory` VALUES ('150623', '', '0', '鄂托克前旗', null, '', '0', '0', '150600');
INSERT INTO `t_s_territory` VALUES ('150624', '', '0', '鄂托克旗', null, '', '0', '0', '150600');
INSERT INTO `t_s_territory` VALUES ('150625', '', '0', '杭锦旗', null, '', '0', '0', '150600');
INSERT INTO `t_s_territory` VALUES ('150626', '', '0', '乌审旗', null, '', '0', '0', '150600');
INSERT INTO `t_s_territory` VALUES ('150627', '', '0', '伊金霍洛旗', null, '', '0', '0', '150600');
INSERT INTO `t_s_territory` VALUES ('150700', '', '0', '呼伦贝尔市', null, '', '0', '0', '150000');
INSERT INTO `t_s_territory` VALUES ('150701', '', '0', '市辖区', null, '', '0', '0', '150700');
INSERT INTO `t_s_territory` VALUES ('150702', '', '0', '海拉尔区', null, '', '0', '0', '150700');
INSERT INTO `t_s_territory` VALUES ('150703', '', '0', '扎赉诺尔区', null, '', '0', '0', '150700');
INSERT INTO `t_s_territory` VALUES ('150721', '', '0', '阿荣旗', null, '', '0', '0', '150700');
INSERT INTO `t_s_territory` VALUES ('150722', '', '0', '莫力达瓦达斡尔族自治旗', null, '', '0', '0', '150700');
INSERT INTO `t_s_territory` VALUES ('150723', '', '0', '鄂伦春自治旗', null, '', '0', '0', '150700');
INSERT INTO `t_s_territory` VALUES ('150724', '', '0', '鄂温克族自治旗', null, '', '0', '0', '150700');
INSERT INTO `t_s_territory` VALUES ('150725', '', '0', '陈巴尔虎旗', null, '', '0', '0', '150700');
INSERT INTO `t_s_territory` VALUES ('150726', '', '0', '新巴尔虎左旗', null, '', '0', '0', '150700');
INSERT INTO `t_s_territory` VALUES ('150727', '', '0', '新巴尔虎右旗', null, '', '0', '0', '150700');
INSERT INTO `t_s_territory` VALUES ('150781', '', '0', '满洲里市', null, '', '0', '0', '150700');
INSERT INTO `t_s_territory` VALUES ('150782', '', '0', '牙克石市', null, '', '0', '0', '150700');
INSERT INTO `t_s_territory` VALUES ('150783', '', '0', '扎兰屯市', null, '', '0', '0', '150700');
INSERT INTO `t_s_territory` VALUES ('150784', '', '0', '额尔古纳市', null, '', '0', '0', '150700');
INSERT INTO `t_s_territory` VALUES ('150785', '', '0', '根河市', null, '', '0', '0', '150700');
INSERT INTO `t_s_territory` VALUES ('150800', '', '0', '巴彦淖尔市', null, '', '0', '0', '150000');
INSERT INTO `t_s_territory` VALUES ('150801', '', '0', '市辖区', null, '', '0', '0', '150800');
INSERT INTO `t_s_territory` VALUES ('150802', '', '0', '临河区', null, '', '0', '0', '150800');
INSERT INTO `t_s_territory` VALUES ('150821', '', '0', '五原县', null, '', '0', '0', '150800');
INSERT INTO `t_s_territory` VALUES ('150822', '', '0', '磴口县', null, '', '0', '0', '150800');
INSERT INTO `t_s_territory` VALUES ('150823', '', '0', '乌拉特前旗', null, '', '0', '0', '150800');
INSERT INTO `t_s_territory` VALUES ('150824', '', '0', '乌拉特中旗', null, '', '0', '0', '150800');
INSERT INTO `t_s_territory` VALUES ('150825', '', '0', '乌拉特后旗', null, '', '0', '0', '150800');
INSERT INTO `t_s_territory` VALUES ('150826', '', '0', '杭锦后旗', null, '', '0', '0', '150800');
INSERT INTO `t_s_territory` VALUES ('150900', '', '0', '乌兰察布市', null, '', '0', '0', '150000');
INSERT INTO `t_s_territory` VALUES ('150901', '', '0', '市辖区', null, '', '0', '0', '150900');
INSERT INTO `t_s_territory` VALUES ('150902', '', '0', '集宁区', null, '', '0', '0', '150900');
INSERT INTO `t_s_territory` VALUES ('150921', '', '0', '卓资县', null, '', '0', '0', '150900');
INSERT INTO `t_s_territory` VALUES ('150922', '', '0', '化德县', null, '', '0', '0', '150900');
INSERT INTO `t_s_territory` VALUES ('150923', '', '0', '商都县', null, '', '0', '0', '150900');
INSERT INTO `t_s_territory` VALUES ('150924', '', '0', '兴和县', null, '', '0', '0', '150900');
INSERT INTO `t_s_territory` VALUES ('150925', '', '0', '凉城县', null, '', '0', '0', '150900');
INSERT INTO `t_s_territory` VALUES ('150926', '', '0', '察哈尔右翼前旗', null, '', '0', '0', '150900');
INSERT INTO `t_s_territory` VALUES ('150927', '', '0', '察哈尔右翼中旗', null, '', '0', '0', '150900');
INSERT INTO `t_s_territory` VALUES ('150928', '', '0', '察哈尔右翼后旗', null, '', '0', '0', '150900');
INSERT INTO `t_s_territory` VALUES ('150929', '', '0', '四子王旗', null, '', '0', '0', '150900');
INSERT INTO `t_s_territory` VALUES ('150981', '', '0', '丰镇市', null, '', '0', '0', '150900');
INSERT INTO `t_s_territory` VALUES ('152200', '', '0', '兴安盟', null, '', '0', '0', '150000');
INSERT INTO `t_s_territory` VALUES ('152201', '', '0', '乌兰浩特市', null, '', '0', '0', '152200');
INSERT INTO `t_s_territory` VALUES ('152202', '', '0', '阿尔山市', null, '', '0', '0', '152200');
INSERT INTO `t_s_territory` VALUES ('152221', '', '0', '科尔沁右翼前旗', null, '', '0', '0', '152200');
INSERT INTO `t_s_territory` VALUES ('152222', '', '0', '科尔沁右翼中旗', null, '', '0', '0', '152200');
INSERT INTO `t_s_territory` VALUES ('152223', '', '0', '扎赉特旗', null, '', '0', '0', '152200');
INSERT INTO `t_s_territory` VALUES ('152224', '', '0', '突泉县', null, '', '0', '0', '152200');
INSERT INTO `t_s_territory` VALUES ('152500', '', '0', '锡林郭勒盟', null, '', '0', '0', '150000');
INSERT INTO `t_s_territory` VALUES ('152501', '', '0', '二连浩特市', null, '', '0', '0', '152500');
INSERT INTO `t_s_territory` VALUES ('152502', '', '0', '锡林浩特市', null, '', '0', '0', '152500');
INSERT INTO `t_s_territory` VALUES ('152522', '', '0', '阿巴嘎旗', null, '', '0', '0', '152500');
INSERT INTO `t_s_territory` VALUES ('152523', '', '0', '苏尼特左旗', null, '', '0', '0', '152500');
INSERT INTO `t_s_territory` VALUES ('152524', '', '0', '苏尼特右旗', null, '', '0', '0', '152500');
INSERT INTO `t_s_territory` VALUES ('152525', '', '0', '东乌珠穆沁旗', null, '', '0', '0', '152500');
INSERT INTO `t_s_territory` VALUES ('152526', '', '0', '西乌珠穆沁旗', null, '', '0', '0', '152500');
INSERT INTO `t_s_territory` VALUES ('152527', '', '0', '太仆寺旗', null, '', '0', '0', '152500');
INSERT INTO `t_s_territory` VALUES ('152528', '', '0', '镶黄旗', null, '', '0', '0', '152500');
INSERT INTO `t_s_territory` VALUES ('152529', '', '0', '正镶白旗', null, '', '0', '0', '152500');
INSERT INTO `t_s_territory` VALUES ('152530', '', '0', '正蓝旗', null, '', '0', '0', '152500');
INSERT INTO `t_s_territory` VALUES ('152531', '', '0', '多伦县', null, '', '0', '0', '152500');
INSERT INTO `t_s_territory` VALUES ('152900', '', '0', '阿拉善盟', null, '', '0', '0', '150000');
INSERT INTO `t_s_territory` VALUES ('152921', '', '0', '阿拉善左旗', null, '', '0', '0', '152900');
INSERT INTO `t_s_territory` VALUES ('152922', '', '0', '阿拉善右旗', null, '', '0', '0', '152900');
INSERT INTO `t_s_territory` VALUES ('152923', '', '0', '额济纳旗', null, '', '0', '0', '152900');
INSERT INTO `t_s_territory` VALUES ('210000', '', '0', '辽宁省', null, '', '0', '0', '1');
INSERT INTO `t_s_territory` VALUES ('210100', '', '0', '沈阳市', null, '', '0', '0', '210000');
INSERT INTO `t_s_territory` VALUES ('210101', '', '0', '市辖区', null, '', '0', '0', '210100');
INSERT INTO `t_s_territory` VALUES ('210102', '', '0', '和平区', null, '', '0', '0', '210100');
INSERT INTO `t_s_territory` VALUES ('210103', '', '0', '沈河区', null, '', '0', '0', '210100');
INSERT INTO `t_s_territory` VALUES ('210104', '', '0', '大东区', null, '', '0', '0', '210100');
INSERT INTO `t_s_territory` VALUES ('210105', '', '0', '皇姑区', null, '', '0', '0', '210100');
INSERT INTO `t_s_territory` VALUES ('210106', '', '0', '铁西区', null, '', '0', '0', '210100');
INSERT INTO `t_s_territory` VALUES ('210111', '', '0', '苏家屯区', null, '', '0', '0', '210100');
INSERT INTO `t_s_territory` VALUES ('210112', '', '0', '浑南区', null, '', '0', '0', '210100');
INSERT INTO `t_s_territory` VALUES ('210113', '', '0', '沈北新区', null, '', '0', '0', '210100');
INSERT INTO `t_s_territory` VALUES ('210114', '', '0', '于洪区', null, '', '0', '0', '210100');
INSERT INTO `t_s_territory` VALUES ('210122', '', '0', '辽中县', null, '', '0', '0', '210100');
INSERT INTO `t_s_territory` VALUES ('210123', '', '0', '康平县', null, '', '0', '0', '210100');
INSERT INTO `t_s_territory` VALUES ('210124', '', '0', '法库县', null, '', '0', '0', '210100');
INSERT INTO `t_s_territory` VALUES ('210181', '', '0', '新民市', null, '', '0', '0', '210100');
INSERT INTO `t_s_territory` VALUES ('210200', '', '0', '大连市', null, '', '0', '0', '210000');
INSERT INTO `t_s_territory` VALUES ('210201', '', '0', '市辖区', null, '', '0', '0', '210200');
INSERT INTO `t_s_territory` VALUES ('210202', '', '0', '中山区', null, '', '0', '0', '210200');
INSERT INTO `t_s_territory` VALUES ('210203', '', '0', '西岗区', null, '', '0', '0', '210200');
INSERT INTO `t_s_territory` VALUES ('210204', '', '0', '沙河口区', null, '', '0', '0', '210200');
INSERT INTO `t_s_territory` VALUES ('210211', '', '0', '甘井子区', null, '', '0', '0', '210200');
INSERT INTO `t_s_territory` VALUES ('210212', '', '0', '旅顺口区', null, '', '0', '0', '210200');
INSERT INTO `t_s_territory` VALUES ('210213', '', '0', '金州区', null, '', '0', '0', '210200');
INSERT INTO `t_s_territory` VALUES ('210224', '', '0', '长海县', null, '', '0', '0', '210200');
INSERT INTO `t_s_territory` VALUES ('210281', '', '0', '瓦房店市', null, '', '0', '0', '210200');
INSERT INTO `t_s_territory` VALUES ('210282', '', '0', '普兰店市', null, '', '0', '0', '210200');
INSERT INTO `t_s_territory` VALUES ('210283', '', '0', '庄河市', null, '', '0', '0', '210200');
INSERT INTO `t_s_territory` VALUES ('210300', '', '0', '鞍山市', null, '', '0', '0', '210000');
INSERT INTO `t_s_territory` VALUES ('210301', '', '0', '市辖区', null, '', '0', '0', '210300');
INSERT INTO `t_s_territory` VALUES ('210302', '', '0', '铁东区', null, '', '0', '0', '210300');
INSERT INTO `t_s_territory` VALUES ('210303', '', '0', '铁西区', null, '', '0', '0', '210300');
INSERT INTO `t_s_territory` VALUES ('210304', '', '0', '立山区', null, '', '0', '0', '210300');
INSERT INTO `t_s_territory` VALUES ('210311', '', '0', '千山区', null, '', '0', '0', '210300');
INSERT INTO `t_s_territory` VALUES ('210321', '', '0', '台安县', null, '', '0', '0', '210300');
INSERT INTO `t_s_territory` VALUES ('210323', '', '0', '岫岩满族自治县', null, '', '0', '0', '210300');
INSERT INTO `t_s_territory` VALUES ('210381', '', '0', '海城市', null, '', '0', '0', '210300');
INSERT INTO `t_s_territory` VALUES ('210400', '', '0', '抚顺市', null, '', '0', '0', '210000');
INSERT INTO `t_s_territory` VALUES ('210401', '', '0', '市辖区', null, '', '0', '0', '210400');
INSERT INTO `t_s_territory` VALUES ('210402', '', '0', '新抚区', null, '', '0', '0', '210400');
INSERT INTO `t_s_territory` VALUES ('210403', '', '0', '东洲区', null, '', '0', '0', '210400');
INSERT INTO `t_s_territory` VALUES ('210404', '', '0', '望花区', null, '', '0', '0', '210400');
INSERT INTO `t_s_territory` VALUES ('210411', '', '0', '顺城区', null, '', '0', '0', '210400');
INSERT INTO `t_s_territory` VALUES ('210421', '', '0', '抚顺县', null, '', '0', '0', '210400');
INSERT INTO `t_s_territory` VALUES ('210422', '', '0', '新宾满族自治县', null, '', '0', '0', '210400');
INSERT INTO `t_s_territory` VALUES ('210423', '', '0', '清原满族自治县', null, '', '0', '0', '210400');
INSERT INTO `t_s_territory` VALUES ('210500', '', '0', '本溪市', null, '', '0', '0', '210000');
INSERT INTO `t_s_territory` VALUES ('210501', '', '0', '市辖区', null, '', '0', '0', '210500');
INSERT INTO `t_s_territory` VALUES ('210502', '', '0', '平山区', null, '', '0', '0', '210500');
INSERT INTO `t_s_territory` VALUES ('210503', '', '0', '溪湖区', null, '', '0', '0', '210500');
INSERT INTO `t_s_territory` VALUES ('210504', '', '0', '明山区', null, '', '0', '0', '210500');
INSERT INTO `t_s_territory` VALUES ('210505', '', '0', '南芬区', null, '', '0', '0', '210500');
INSERT INTO `t_s_territory` VALUES ('210521', '', '0', '本溪满族自治县', null, '', '0', '0', '210500');
INSERT INTO `t_s_territory` VALUES ('210522', '', '0', '桓仁满族自治县', null, '', '0', '0', '210500');
INSERT INTO `t_s_territory` VALUES ('210600', '', '0', '丹东市', null, '', '0', '0', '210000');
INSERT INTO `t_s_territory` VALUES ('210601', '', '0', '市辖区', null, '', '0', '0', '210600');
INSERT INTO `t_s_territory` VALUES ('210602', '', '0', '元宝区', null, '', '0', '0', '210600');
INSERT INTO `t_s_territory` VALUES ('210603', '', '0', '振兴区', null, '', '0', '0', '210600');
INSERT INTO `t_s_territory` VALUES ('210604', '', '0', '振安区', null, '', '0', '0', '210600');
INSERT INTO `t_s_territory` VALUES ('210624', '', '0', '宽甸满族自治县', null, '', '0', '0', '210600');
INSERT INTO `t_s_territory` VALUES ('210681', '', '0', '东港市', null, '', '0', '0', '210600');
INSERT INTO `t_s_territory` VALUES ('210682', '', '0', '凤城市', null, '', '0', '0', '210600');
INSERT INTO `t_s_territory` VALUES ('210700', '', '0', '锦州市', null, '', '0', '0', '210000');
INSERT INTO `t_s_territory` VALUES ('210701', '', '0', '市辖区', null, '', '0', '0', '210700');
INSERT INTO `t_s_territory` VALUES ('210702', '', '0', '古塔区', null, '', '0', '0', '210700');
INSERT INTO `t_s_territory` VALUES ('210703', '', '0', '凌河区', null, '', '0', '0', '210700');
INSERT INTO `t_s_territory` VALUES ('210711', '', '0', '太和区', null, '', '0', '0', '210700');
INSERT INTO `t_s_territory` VALUES ('210726', '', '0', '黑山县', null, '', '0', '0', '210700');
INSERT INTO `t_s_territory` VALUES ('210727', '', '0', '义县', null, '', '0', '0', '210700');
INSERT INTO `t_s_territory` VALUES ('210781', '', '0', '凌海市', null, '', '0', '0', '210700');
INSERT INTO `t_s_territory` VALUES ('210782', '', '0', '北镇市', null, '', '0', '0', '210700');
INSERT INTO `t_s_territory` VALUES ('210800', '', '0', '营口市', null, '', '0', '0', '210000');
INSERT INTO `t_s_territory` VALUES ('210801', '', '0', '市辖区', null, '', '0', '0', '210800');
INSERT INTO `t_s_territory` VALUES ('210802', '', '0', '站前区', null, '', '0', '0', '210800');
INSERT INTO `t_s_territory` VALUES ('210803', '', '0', '西市区', null, '', '0', '0', '210800');
INSERT INTO `t_s_territory` VALUES ('210804', '', '0', '鲅鱼圈区', null, '', '0', '0', '210800');
INSERT INTO `t_s_territory` VALUES ('210811', '', '0', '老边区', null, '', '0', '0', '210800');
INSERT INTO `t_s_territory` VALUES ('210881', '', '0', '盖州市', null, '', '0', '0', '210800');
INSERT INTO `t_s_territory` VALUES ('210882', '', '0', '大石桥市', null, '', '0', '0', '210800');
INSERT INTO `t_s_territory` VALUES ('210900', '', '0', '阜新市', null, '', '0', '0', '210000');
INSERT INTO `t_s_territory` VALUES ('210901', '', '0', '市辖区', null, '', '0', '0', '210900');
INSERT INTO `t_s_territory` VALUES ('210902', '', '0', '海州区', null, '', '0', '0', '210900');
INSERT INTO `t_s_territory` VALUES ('210903', '', '0', '新邱区', null, '', '0', '0', '210900');
INSERT INTO `t_s_territory` VALUES ('210904', '', '0', '太平区', null, '', '0', '0', '210900');
INSERT INTO `t_s_territory` VALUES ('210905', '', '0', '清河门区', null, '', '0', '0', '210900');
INSERT INTO `t_s_territory` VALUES ('210911', '', '0', '细河区', null, '', '0', '0', '210900');
INSERT INTO `t_s_territory` VALUES ('210921', '', '0', '阜新蒙古族自治县', null, '', '0', '0', '210900');
INSERT INTO `t_s_territory` VALUES ('210922', '', '0', '彰武县', null, '', '0', '0', '210900');
INSERT INTO `t_s_territory` VALUES ('211000', '', '0', '辽阳市', null, '', '0', '0', '210000');
INSERT INTO `t_s_territory` VALUES ('211001', '', '0', '市辖区', null, '', '0', '0', '211000');
INSERT INTO `t_s_territory` VALUES ('211002', '', '0', '白塔区', null, '', '0', '0', '211000');
INSERT INTO `t_s_territory` VALUES ('211003', '', '0', '文圣区', null, '', '0', '0', '211000');
INSERT INTO `t_s_territory` VALUES ('211004', '', '0', '宏伟区', null, '', '0', '0', '211000');
INSERT INTO `t_s_territory` VALUES ('211005', '', '0', '弓长岭区', null, '', '0', '0', '211000');
INSERT INTO `t_s_territory` VALUES ('211011', '', '0', '太子河区', null, '', '0', '0', '211000');
INSERT INTO `t_s_territory` VALUES ('211021', '', '0', '辽阳县', null, '', '0', '0', '211000');
INSERT INTO `t_s_territory` VALUES ('211081', '', '0', '灯塔市', null, '', '0', '0', '211000');
INSERT INTO `t_s_territory` VALUES ('211100', '', '0', '盘锦市', null, '', '0', '0', '210000');
INSERT INTO `t_s_territory` VALUES ('211101', '', '0', '市辖区', null, '', '0', '0', '211100');
INSERT INTO `t_s_territory` VALUES ('211102', '', '0', '双台子区', null, '', '0', '0', '211100');
INSERT INTO `t_s_territory` VALUES ('211103', '', '0', '兴隆台区', null, '', '0', '0', '211100');
INSERT INTO `t_s_territory` VALUES ('211121', '', '0', '大洼县', null, '', '0', '0', '211100');
INSERT INTO `t_s_territory` VALUES ('211122', '', '0', '盘山县', null, '', '0', '0', '211100');
INSERT INTO `t_s_territory` VALUES ('211200', '', '0', '铁岭市', null, '', '0', '0', '210000');
INSERT INTO `t_s_territory` VALUES ('211201', '', '0', '市辖区', null, '', '0', '0', '211200');
INSERT INTO `t_s_territory` VALUES ('211202', '', '0', '银州区', null, '', '0', '0', '211200');
INSERT INTO `t_s_territory` VALUES ('211204', '', '0', '清河区', null, '', '0', '0', '211200');
INSERT INTO `t_s_territory` VALUES ('211221', '', '0', '铁岭县', null, '', '0', '0', '211200');
INSERT INTO `t_s_territory` VALUES ('211223', '', '0', '西丰县', null, '', '0', '0', '211200');
INSERT INTO `t_s_territory` VALUES ('211224', '', '0', '昌图县', null, '', '0', '0', '211200');
INSERT INTO `t_s_territory` VALUES ('211281', '', '0', '调兵山市', null, '', '0', '0', '211200');
INSERT INTO `t_s_territory` VALUES ('211282', '', '0', '开原市', null, '', '0', '0', '211200');
INSERT INTO `t_s_territory` VALUES ('211300', '', '0', '朝阳市', null, '', '0', '0', '210000');
INSERT INTO `t_s_territory` VALUES ('211301', '', '0', '市辖区', null, '', '0', '0', '211300');
INSERT INTO `t_s_territory` VALUES ('211302', '', '0', '双塔区', null, '', '0', '0', '211300');
INSERT INTO `t_s_territory` VALUES ('211303', '', '0', '龙城区', null, '', '0', '0', '211300');
INSERT INTO `t_s_territory` VALUES ('211321', '', '0', '朝阳县', null, '', '0', '0', '211300');
INSERT INTO `t_s_territory` VALUES ('211322', '', '0', '建平县', null, '', '0', '0', '211300');
INSERT INTO `t_s_territory` VALUES ('211324', '', '0', '喀喇沁左翼蒙古族自治县', null, '', '0', '0', '211300');
INSERT INTO `t_s_territory` VALUES ('211381', '', '0', '北票市', null, '', '0', '0', '211300');
INSERT INTO `t_s_territory` VALUES ('211382', '', '0', '凌源市', null, '', '0', '0', '211300');
INSERT INTO `t_s_territory` VALUES ('211400', '', '0', '葫芦岛市', null, '', '0', '0', '210000');
INSERT INTO `t_s_territory` VALUES ('211401', '', '0', '市辖区', null, '', '0', '0', '211400');
INSERT INTO `t_s_territory` VALUES ('211402', '', '0', '连山区', null, '', '0', '0', '211400');
INSERT INTO `t_s_territory` VALUES ('211403', '', '0', '龙港区', null, '', '0', '0', '211400');
INSERT INTO `t_s_territory` VALUES ('211404', '', '0', '南票区', null, '', '0', '0', '211400');
INSERT INTO `t_s_territory` VALUES ('211421', '', '0', '绥中县', null, '', '0', '0', '211400');
INSERT INTO `t_s_territory` VALUES ('211422', '', '0', '建昌县', null, '', '0', '0', '211400');
INSERT INTO `t_s_territory` VALUES ('211481', '', '0', '兴城市', null, '', '0', '0', '211400');
INSERT INTO `t_s_territory` VALUES ('220000', '', '0', '吉林省', null, '', '0', '0', '1');
INSERT INTO `t_s_territory` VALUES ('220100', '', '0', '长春市', null, '', '0', '0', '220000');
INSERT INTO `t_s_territory` VALUES ('220101', '', '0', '市辖区', null, '', '0', '0', '220100');
INSERT INTO `t_s_territory` VALUES ('220102', '', '0', '南关区', null, '', '0', '0', '220100');
INSERT INTO `t_s_territory` VALUES ('220103', '', '0', '宽城区', null, '', '0', '0', '220100');
INSERT INTO `t_s_territory` VALUES ('220104', '', '0', '朝阳区', null, '', '0', '0', '220100');
INSERT INTO `t_s_territory` VALUES ('220105', '', '0', '二道区', null, '', '0', '0', '220100');
INSERT INTO `t_s_territory` VALUES ('220106', '', '0', '绿园区', null, '', '0', '0', '220100');
INSERT INTO `t_s_territory` VALUES ('220112', '', '0', '双阳区', null, '', '0', '0', '220100');
INSERT INTO `t_s_territory` VALUES ('220113', '', '0', '九台区', null, '', '0', '0', '220100');
INSERT INTO `t_s_territory` VALUES ('220122', '', '0', '农安县', null, '', '0', '0', '220100');
INSERT INTO `t_s_territory` VALUES ('220182', '', '0', '榆树市', null, '', '0', '0', '220100');
INSERT INTO `t_s_territory` VALUES ('220183', '', '0', '德惠市', null, '', '0', '0', '220100');
INSERT INTO `t_s_territory` VALUES ('220200', '', '0', '吉林市', null, '', '0', '0', '220000');
INSERT INTO `t_s_territory` VALUES ('220201', '', '0', '市辖区', null, '', '0', '0', '220200');
INSERT INTO `t_s_territory` VALUES ('220202', '', '0', '昌邑区', null, '', '0', '0', '220200');
INSERT INTO `t_s_territory` VALUES ('220203', '', '0', '龙潭区', null, '', '0', '0', '220200');
INSERT INTO `t_s_territory` VALUES ('220204', '', '0', '船营区', null, '', '0', '0', '220200');
INSERT INTO `t_s_territory` VALUES ('220211', '', '0', '丰满区', null, '', '0', '0', '220200');
INSERT INTO `t_s_territory` VALUES ('220221', '', '0', '永吉县', null, '', '0', '0', '220200');
INSERT INTO `t_s_territory` VALUES ('220281', '', '0', '蛟河市', null, '', '0', '0', '220200');
INSERT INTO `t_s_territory` VALUES ('220282', '', '0', '桦甸市', null, '', '0', '0', '220200');
INSERT INTO `t_s_territory` VALUES ('220283', '', '0', '舒兰市', null, '', '0', '0', '220200');
INSERT INTO `t_s_territory` VALUES ('220284', '', '0', '磐石市', null, '', '0', '0', '220200');
INSERT INTO `t_s_territory` VALUES ('220300', '', '0', '四平市', null, '', '0', '0', '220000');
INSERT INTO `t_s_territory` VALUES ('220301', '', '0', '市辖区', null, '', '0', '0', '220300');
INSERT INTO `t_s_territory` VALUES ('220302', '', '0', '铁西区', null, '', '0', '0', '220300');
INSERT INTO `t_s_territory` VALUES ('220303', '', '0', '铁东区', null, '', '0', '0', '220300');
INSERT INTO `t_s_territory` VALUES ('220322', '', '0', '梨树县', null, '', '0', '0', '220300');
INSERT INTO `t_s_territory` VALUES ('220323', '', '0', '伊通满族自治县', null, '', '0', '0', '220300');
INSERT INTO `t_s_territory` VALUES ('220381', '', '0', '公主岭市', null, '', '0', '0', '220300');
INSERT INTO `t_s_territory` VALUES ('220382', '', '0', '双辽市', null, '', '0', '0', '220300');
INSERT INTO `t_s_territory` VALUES ('220400', '', '0', '辽源市', null, '', '0', '0', '220000');
INSERT INTO `t_s_territory` VALUES ('220401', '', '0', '市辖区', null, '', '0', '0', '220400');
INSERT INTO `t_s_territory` VALUES ('220402', '', '0', '龙山区', null, '', '0', '0', '220400');
INSERT INTO `t_s_territory` VALUES ('220403', '', '0', '西安区', null, '', '0', '0', '220400');
INSERT INTO `t_s_territory` VALUES ('220421', '', '0', '东丰县', null, '', '0', '0', '220400');
INSERT INTO `t_s_territory` VALUES ('220422', '', '0', '东辽县', null, '', '0', '0', '220400');
INSERT INTO `t_s_territory` VALUES ('220500', '', '0', '通化市', null, '', '0', '0', '220000');
INSERT INTO `t_s_territory` VALUES ('220501', '', '0', '市辖区', null, '', '0', '0', '220500');
INSERT INTO `t_s_territory` VALUES ('220502', '', '0', '东昌区', null, '', '0', '0', '220500');
INSERT INTO `t_s_territory` VALUES ('220503', '', '0', '二道江区', null, '', '0', '0', '220500');
INSERT INTO `t_s_territory` VALUES ('220521', '', '0', '通化县', null, '', '0', '0', '220500');
INSERT INTO `t_s_territory` VALUES ('220523', '', '0', '辉南县', null, '', '0', '0', '220500');
INSERT INTO `t_s_territory` VALUES ('220524', '', '0', '柳河县', null, '', '0', '0', '220500');
INSERT INTO `t_s_territory` VALUES ('220581', '', '0', '梅河口市', null, '', '0', '0', '220500');
INSERT INTO `t_s_territory` VALUES ('220582', '', '0', '集安市', null, '', '0', '0', '220500');
INSERT INTO `t_s_territory` VALUES ('220600', '', '0', '白山市', null, '', '0', '0', '220000');
INSERT INTO `t_s_territory` VALUES ('220601', '', '0', '市辖区', null, '', '0', '0', '220600');
INSERT INTO `t_s_territory` VALUES ('220602', '', '0', '浑江区', null, '', '0', '0', '220600');
INSERT INTO `t_s_territory` VALUES ('220605', '', '0', '江源区', null, '', '0', '0', '220600');
INSERT INTO `t_s_territory` VALUES ('220621', '', '0', '抚松县', null, '', '0', '0', '220600');
INSERT INTO `t_s_territory` VALUES ('220622', '', '0', '靖宇县', null, '', '0', '0', '220600');
INSERT INTO `t_s_territory` VALUES ('220623', '', '0', '长白朝鲜族自治县', null, '', '0', '0', '220600');
INSERT INTO `t_s_territory` VALUES ('220681', '', '0', '临江市', null, '', '0', '0', '220600');
INSERT INTO `t_s_territory` VALUES ('220700', '', '0', '松原市', null, '', '0', '0', '220000');
INSERT INTO `t_s_territory` VALUES ('220701', '', '0', '市辖区', null, '', '0', '0', '220700');
INSERT INTO `t_s_territory` VALUES ('220702', '', '0', '宁江区', null, '', '0', '0', '220700');
INSERT INTO `t_s_territory` VALUES ('220721', '', '0', '前郭尔罗斯蒙古族自治县', null, '', '0', '0', '220700');
INSERT INTO `t_s_territory` VALUES ('220722', '', '0', '长岭县', null, '', '0', '0', '220700');
INSERT INTO `t_s_territory` VALUES ('220723', '', '0', '乾安县', null, '', '0', '0', '220700');
INSERT INTO `t_s_territory` VALUES ('220781', '', '0', '扶余市', null, '', '0', '0', '220700');
INSERT INTO `t_s_territory` VALUES ('220800', '', '0', '白城市', null, '', '0', '0', '220000');
INSERT INTO `t_s_territory` VALUES ('220801', '', '0', '市辖区', null, '', '0', '0', '220800');
INSERT INTO `t_s_territory` VALUES ('220802', '', '0', '洮北区', null, '', '0', '0', '220800');
INSERT INTO `t_s_territory` VALUES ('220821', '', '0', '镇赉县', null, '', '0', '0', '220800');
INSERT INTO `t_s_territory` VALUES ('220822', '', '0', '通榆县', null, '', '0', '0', '220800');
INSERT INTO `t_s_territory` VALUES ('220881', '', '0', '洮南市', null, '', '0', '0', '220800');
INSERT INTO `t_s_territory` VALUES ('220882', '', '0', '大安市', null, '', '0', '0', '220800');
INSERT INTO `t_s_territory` VALUES ('222400', '', '0', '延边朝鲜族自治州', null, '', '0', '0', '220000');
INSERT INTO `t_s_territory` VALUES ('222401', '', '0', '延吉市', null, '', '0', '0', '222400');
INSERT INTO `t_s_territory` VALUES ('222402', '', '0', '图们市', null, '', '0', '0', '222400');
INSERT INTO `t_s_territory` VALUES ('222403', '', '0', '敦化市', null, '', '0', '0', '222400');
INSERT INTO `t_s_territory` VALUES ('222404', '', '0', '珲春市', null, '', '0', '0', '222400');
INSERT INTO `t_s_territory` VALUES ('222405', '', '0', '龙井市', null, '', '0', '0', '222400');
INSERT INTO `t_s_territory` VALUES ('222406', '', '0', '和龙市', null, '', '0', '0', '222400');
INSERT INTO `t_s_territory` VALUES ('222424', '', '0', '汪清县', null, '', '0', '0', '222400');
INSERT INTO `t_s_territory` VALUES ('222426', '', '0', '安图县', null, '', '0', '0', '222400');
INSERT INTO `t_s_territory` VALUES ('230000', '', '0', '黑龙江省', null, '', '0', '0', '1');
INSERT INTO `t_s_territory` VALUES ('230100', '', '0', '哈尔滨市', null, '', '0', '0', '230000');
INSERT INTO `t_s_territory` VALUES ('230101', '', '0', '市辖区', null, '', '0', '0', '230100');
INSERT INTO `t_s_territory` VALUES ('230102', '', '0', '道里区', null, '', '0', '0', '230100');
INSERT INTO `t_s_territory` VALUES ('230103', '', '0', '南岗区', null, '', '0', '0', '230100');
INSERT INTO `t_s_territory` VALUES ('230104', '', '0', '道外区', null, '', '0', '0', '230100');
INSERT INTO `t_s_territory` VALUES ('230108', '', '0', '平房区', null, '', '0', '0', '230100');
INSERT INTO `t_s_territory` VALUES ('230109', '', '0', '松北区', null, '', '0', '0', '230100');
INSERT INTO `t_s_territory` VALUES ('230110', '', '0', '香坊区', null, '', '0', '0', '230100');
INSERT INTO `t_s_territory` VALUES ('230111', '', '0', '呼兰区', null, '', '0', '0', '230100');
INSERT INTO `t_s_territory` VALUES ('230112', '', '0', '阿城区', null, '', '0', '0', '230100');
INSERT INTO `t_s_territory` VALUES ('230123', '', '0', '依兰县', null, '', '0', '0', '230100');
INSERT INTO `t_s_territory` VALUES ('230124', '', '0', '方正县', null, '', '0', '0', '230100');
INSERT INTO `t_s_territory` VALUES ('230125', '', '0', '宾县', null, '', '0', '0', '230100');
INSERT INTO `t_s_territory` VALUES ('230126', '', '0', '巴彦县', null, '', '0', '0', '230100');
INSERT INTO `t_s_territory` VALUES ('230127', '', '0', '木兰县', null, '', '0', '0', '230100');
INSERT INTO `t_s_territory` VALUES ('230128', '', '0', '通河县', null, '', '0', '0', '230100');
INSERT INTO `t_s_territory` VALUES ('230129', '', '0', '延寿县', null, '', '0', '0', '230100');
INSERT INTO `t_s_territory` VALUES ('230182', '', '0', '双城市', null, '', '0', '0', '230100');
INSERT INTO `t_s_territory` VALUES ('230183', '', '0', '尚志市', null, '', '0', '0', '230100');
INSERT INTO `t_s_territory` VALUES ('230184', '', '0', '五常市', null, '', '0', '0', '230100');
INSERT INTO `t_s_territory` VALUES ('230200', '', '0', '齐齐哈尔市', null, '', '0', '0', '230000');
INSERT INTO `t_s_territory` VALUES ('230201', '', '0', '市辖区', null, '', '0', '0', '230200');
INSERT INTO `t_s_territory` VALUES ('230202', '', '0', '龙沙区', null, '', '0', '0', '230200');
INSERT INTO `t_s_territory` VALUES ('230203', '', '0', '建华区', null, '', '0', '0', '230200');
INSERT INTO `t_s_territory` VALUES ('230204', '', '0', '铁锋区', null, '', '0', '0', '230200');
INSERT INTO `t_s_territory` VALUES ('230205', '', '0', '昂昂溪区', null, '', '0', '0', '230200');
INSERT INTO `t_s_territory` VALUES ('230206', '', '0', '富拉尔基区', null, '', '0', '0', '230200');
INSERT INTO `t_s_territory` VALUES ('230207', '', '0', '碾子山区', null, '', '0', '0', '230200');
INSERT INTO `t_s_territory` VALUES ('230208', '', '0', '梅里斯达斡尔族区', null, '', '0', '0', '230200');
INSERT INTO `t_s_territory` VALUES ('230221', '', '0', '龙江县', null, '', '0', '0', '230200');
INSERT INTO `t_s_territory` VALUES ('230223', '', '0', '依安县', null, '', '0', '0', '230200');
INSERT INTO `t_s_territory` VALUES ('230224', '', '0', '泰来县', null, '', '0', '0', '230200');
INSERT INTO `t_s_territory` VALUES ('230225', '', '0', '甘南县', null, '', '0', '0', '230200');
INSERT INTO `t_s_territory` VALUES ('230227', '', '0', '富裕县', null, '', '0', '0', '230200');
INSERT INTO `t_s_territory` VALUES ('230229', '', '0', '克山县', null, '', '0', '0', '230200');
INSERT INTO `t_s_territory` VALUES ('230230', '', '0', '克东县', null, '', '0', '0', '230200');
INSERT INTO `t_s_territory` VALUES ('230231', '', '0', '拜泉县', null, '', '0', '0', '230200');
INSERT INTO `t_s_territory` VALUES ('230281', '', '0', '讷河市', null, '', '0', '0', '230200');
INSERT INTO `t_s_territory` VALUES ('230300', '', '0', '鸡西市', null, '', '0', '0', '230000');
INSERT INTO `t_s_territory` VALUES ('230301', '', '0', '市辖区', null, '', '0', '0', '230300');
INSERT INTO `t_s_territory` VALUES ('230302', '', '0', '鸡冠区', null, '', '0', '0', '230300');
INSERT INTO `t_s_territory` VALUES ('230303', '', '0', '恒山区', null, '', '0', '0', '230300');
INSERT INTO `t_s_territory` VALUES ('230304', '', '0', '滴道区', null, '', '0', '0', '230300');
INSERT INTO `t_s_territory` VALUES ('230305', '', '0', '梨树区', null, '', '0', '0', '230300');
INSERT INTO `t_s_territory` VALUES ('230306', '', '0', '城子河区', null, '', '0', '0', '230300');
INSERT INTO `t_s_territory` VALUES ('230307', '', '0', '麻山区', null, '', '0', '0', '230300');
INSERT INTO `t_s_territory` VALUES ('230321', '', '0', '鸡东县', null, '', '0', '0', '230300');
INSERT INTO `t_s_territory` VALUES ('230381', '', '0', '虎林市', null, '', '0', '0', '230300');
INSERT INTO `t_s_territory` VALUES ('230382', '', '0', '密山市', null, '', '0', '0', '230300');
INSERT INTO `t_s_territory` VALUES ('230400', '', '0', '鹤岗市', null, '', '0', '0', '230000');
INSERT INTO `t_s_territory` VALUES ('230401', '', '0', '市辖区', null, '', '0', '0', '230400');
INSERT INTO `t_s_territory` VALUES ('230402', '', '0', '向阳区', null, '', '0', '0', '230400');
INSERT INTO `t_s_territory` VALUES ('230403', '', '0', '工农区', null, '', '0', '0', '230400');
INSERT INTO `t_s_territory` VALUES ('230404', '', '0', '南山区', null, '', '0', '0', '230400');
INSERT INTO `t_s_territory` VALUES ('230405', '', '0', '兴安区', null, '', '0', '0', '230400');
INSERT INTO `t_s_territory` VALUES ('230406', '', '0', '东山区', null, '', '0', '0', '230400');
INSERT INTO `t_s_territory` VALUES ('230407', '', '0', '兴山区', null, '', '0', '0', '230400');
INSERT INTO `t_s_territory` VALUES ('230421', '', '0', '萝北县', null, '', '0', '0', '230400');
INSERT INTO `t_s_territory` VALUES ('230422', '', '0', '绥滨县', null, '', '0', '0', '230400');
INSERT INTO `t_s_territory` VALUES ('230500', '', '0', '双鸭山市', null, '', '0', '0', '230000');
INSERT INTO `t_s_territory` VALUES ('230501', '', '0', '市辖区', null, '', '0', '0', '230500');
INSERT INTO `t_s_territory` VALUES ('230502', '', '0', '尖山区', null, '', '0', '0', '230500');
INSERT INTO `t_s_territory` VALUES ('230503', '', '0', '岭东区', null, '', '0', '0', '230500');
INSERT INTO `t_s_territory` VALUES ('230505', '', '0', '四方台区', null, '', '0', '0', '230500');
INSERT INTO `t_s_territory` VALUES ('230506', '', '0', '宝山区', null, '', '0', '0', '230500');
INSERT INTO `t_s_territory` VALUES ('230521', '', '0', '集贤县', null, '', '0', '0', '230500');
INSERT INTO `t_s_territory` VALUES ('230522', '', '0', '友谊县', null, '', '0', '0', '230500');
INSERT INTO `t_s_territory` VALUES ('230523', '', '0', '宝清县', null, '', '0', '0', '230500');
INSERT INTO `t_s_territory` VALUES ('230524', '', '0', '饶河县', null, '', '0', '0', '230500');
INSERT INTO `t_s_territory` VALUES ('230600', '', '0', '大庆市', null, '', '0', '0', '230000');
INSERT INTO `t_s_territory` VALUES ('230601', '', '0', '市辖区', null, '', '0', '0', '230600');
INSERT INTO `t_s_territory` VALUES ('230602', '', '0', '萨尔图区', null, '', '0', '0', '230600');
INSERT INTO `t_s_territory` VALUES ('230603', '', '0', '龙凤区', null, '', '0', '0', '230600');
INSERT INTO `t_s_territory` VALUES ('230604', '', '0', '让胡路区', null, '', '0', '0', '230600');
INSERT INTO `t_s_territory` VALUES ('230605', '', '0', '红岗区', null, '', '0', '0', '230600');
INSERT INTO `t_s_territory` VALUES ('230606', '', '0', '大同区', null, '', '0', '0', '230600');
INSERT INTO `t_s_territory` VALUES ('230621', '', '0', '肇州县', null, '', '0', '0', '230600');
INSERT INTO `t_s_territory` VALUES ('230622', '', '0', '肇源县', null, '', '0', '0', '230600');
INSERT INTO `t_s_territory` VALUES ('230623', '', '0', '林甸县', null, '', '0', '0', '230600');
INSERT INTO `t_s_territory` VALUES ('230624', '', '0', '杜尔伯特蒙古族自治县', null, '', '0', '0', '230600');
INSERT INTO `t_s_territory` VALUES ('230700', '', '0', '伊春市', null, '', '0', '0', '230000');
INSERT INTO `t_s_territory` VALUES ('230701', '', '0', '市辖区', null, '', '0', '0', '230700');
INSERT INTO `t_s_territory` VALUES ('230702', '', '0', '伊春区', null, '', '0', '0', '230700');
INSERT INTO `t_s_territory` VALUES ('230703', '', '0', '南岔区', null, '', '0', '0', '230700');
INSERT INTO `t_s_territory` VALUES ('230704', '', '0', '友好区', null, '', '0', '0', '230700');
INSERT INTO `t_s_territory` VALUES ('230705', '', '0', '西林区', null, '', '0', '0', '230700');
INSERT INTO `t_s_territory` VALUES ('230706', '', '0', '翠峦区', null, '', '0', '0', '230700');
INSERT INTO `t_s_territory` VALUES ('230707', '', '0', '新青区', null, '', '0', '0', '230700');
INSERT INTO `t_s_territory` VALUES ('230708', '', '0', '美溪区', null, '', '0', '0', '230700');
INSERT INTO `t_s_territory` VALUES ('230709', '', '0', '金山屯区', null, '', '0', '0', '230700');
INSERT INTO `t_s_territory` VALUES ('230710', '', '0', '五营区', null, '', '0', '0', '230700');
INSERT INTO `t_s_territory` VALUES ('230711', '', '0', '乌马河区', null, '', '0', '0', '230700');
INSERT INTO `t_s_territory` VALUES ('230712', '', '0', '汤旺河区', null, '', '0', '0', '230700');
INSERT INTO `t_s_territory` VALUES ('230713', '', '0', '带岭区', null, '', '0', '0', '230700');
INSERT INTO `t_s_territory` VALUES ('230714', '', '0', '乌伊岭区', null, '', '0', '0', '230700');
INSERT INTO `t_s_territory` VALUES ('230715', '', '0', '红星区', null, '', '0', '0', '230700');
INSERT INTO `t_s_territory` VALUES ('230716', '', '0', '上甘岭区', null, '', '0', '0', '230700');
INSERT INTO `t_s_territory` VALUES ('230722', '', '0', '嘉荫县', null, '', '0', '0', '230700');
INSERT INTO `t_s_territory` VALUES ('230781', '', '0', '铁力市', null, '', '0', '0', '230700');
INSERT INTO `t_s_territory` VALUES ('230800', '', '0', '佳木斯市', null, '', '0', '0', '230000');
INSERT INTO `t_s_territory` VALUES ('230801', '', '0', '市辖区', null, '', '0', '0', '230800');
INSERT INTO `t_s_territory` VALUES ('230803', '', '0', '向阳区', null, '', '0', '0', '230800');
INSERT INTO `t_s_territory` VALUES ('230804', '', '0', '前进区', null, '', '0', '0', '230800');
INSERT INTO `t_s_territory` VALUES ('230805', '', '0', '东风区', null, '', '0', '0', '230800');
INSERT INTO `t_s_territory` VALUES ('230811', '', '0', '郊区', null, '', '0', '0', '230800');
INSERT INTO `t_s_territory` VALUES ('230822', '', '0', '桦南县', null, '', '0', '0', '230800');
INSERT INTO `t_s_territory` VALUES ('230826', '', '0', '桦川县', null, '', '0', '0', '230800');
INSERT INTO `t_s_territory` VALUES ('230828', '', '0', '汤原县', null, '', '0', '0', '230800');
INSERT INTO `t_s_territory` VALUES ('230833', '', '0', '抚远县', null, '', '0', '0', '230800');
INSERT INTO `t_s_territory` VALUES ('230881', '', '0', '同江市', null, '', '0', '0', '230800');
INSERT INTO `t_s_territory` VALUES ('230882', '', '0', '富锦市', null, '', '0', '0', '230800');
INSERT INTO `t_s_territory` VALUES ('230900', '', '0', '七台河市', null, '', '0', '0', '230000');
INSERT INTO `t_s_territory` VALUES ('230901', '', '0', '市辖区', null, '', '0', '0', '230900');
INSERT INTO `t_s_territory` VALUES ('230902', '', '0', '新兴区', null, '', '0', '0', '230900');
INSERT INTO `t_s_territory` VALUES ('230903', '', '0', '桃山区', null, '', '0', '0', '230900');
INSERT INTO `t_s_territory` VALUES ('230904', '', '0', '茄子河区', null, '', '0', '0', '230900');
INSERT INTO `t_s_territory` VALUES ('230921', '', '0', '勃利县', null, '', '0', '0', '230900');
INSERT INTO `t_s_territory` VALUES ('231000', '', '0', '牡丹江市', null, '', '0', '0', '230000');
INSERT INTO `t_s_territory` VALUES ('231001', '', '0', '市辖区', null, '', '0', '0', '231000');
INSERT INTO `t_s_territory` VALUES ('231002', '', '0', '东安区', null, '', '0', '0', '231000');
INSERT INTO `t_s_territory` VALUES ('231003', '', '0', '阳明区', null, '', '0', '0', '231000');
INSERT INTO `t_s_territory` VALUES ('231004', '', '0', '爱民区', null, '', '0', '0', '231000');
INSERT INTO `t_s_territory` VALUES ('231005', '', '0', '西安区', null, '', '0', '0', '231000');
INSERT INTO `t_s_territory` VALUES ('231024', '', '0', '东宁县', null, '', '0', '0', '231000');
INSERT INTO `t_s_territory` VALUES ('231025', '', '0', '林口县', null, '', '0', '0', '231000');
INSERT INTO `t_s_territory` VALUES ('231081', '', '0', '绥芬河市', null, '', '0', '0', '231000');
INSERT INTO `t_s_territory` VALUES ('231083', '', '0', '海林市', null, '', '0', '0', '231000');
INSERT INTO `t_s_territory` VALUES ('231084', '', '0', '宁安市', null, '', '0', '0', '231000');
INSERT INTO `t_s_territory` VALUES ('231085', '', '0', '穆棱市', null, '', '0', '0', '231000');
INSERT INTO `t_s_territory` VALUES ('231100', '', '0', '黑河市', null, '', '0', '0', '230000');
INSERT INTO `t_s_territory` VALUES ('231101', '', '0', '市辖区', null, '', '0', '0', '231100');
INSERT INTO `t_s_territory` VALUES ('231102', '', '0', '爱辉区', null, '', '0', '0', '231100');
INSERT INTO `t_s_territory` VALUES ('231121', '', '0', '嫩江县', null, '', '0', '0', '231100');
INSERT INTO `t_s_territory` VALUES ('231123', '', '0', '逊克县', null, '', '0', '0', '231100');
INSERT INTO `t_s_territory` VALUES ('231124', '', '0', '孙吴县', null, '', '0', '0', '231100');
INSERT INTO `t_s_territory` VALUES ('231181', '', '0', '北安市', null, '', '0', '0', '231100');
INSERT INTO `t_s_territory` VALUES ('231182', '', '0', '五大连池市', null, '', '0', '0', '231100');
INSERT INTO `t_s_territory` VALUES ('231200', '', '0', '绥化市', null, '', '0', '0', '230000');
INSERT INTO `t_s_territory` VALUES ('231201', '', '0', '市辖区', null, '', '0', '0', '231200');
INSERT INTO `t_s_territory` VALUES ('231202', '', '0', '北林区', null, '', '0', '0', '231200');
INSERT INTO `t_s_territory` VALUES ('231221', '', '0', '望奎县', null, '', '0', '0', '231200');
INSERT INTO `t_s_territory` VALUES ('231222', '', '0', '兰西县', null, '', '0', '0', '231200');
INSERT INTO `t_s_territory` VALUES ('231223', '', '0', '青冈县', null, '', '0', '0', '231200');
INSERT INTO `t_s_territory` VALUES ('231224', '', '0', '庆安县', null, '', '0', '0', '231200');
INSERT INTO `t_s_territory` VALUES ('231225', '', '0', '明水县', null, '', '0', '0', '231200');
INSERT INTO `t_s_territory` VALUES ('231226', '', '0', '绥棱县', null, '', '0', '0', '231200');
INSERT INTO `t_s_territory` VALUES ('231281', '', '0', '安达市', null, '', '0', '0', '231200');
INSERT INTO `t_s_territory` VALUES ('231282', '', '0', '肇东市', null, '', '0', '0', '231200');
INSERT INTO `t_s_territory` VALUES ('231283', '', '0', '海伦市', null, '', '0', '0', '231200');
INSERT INTO `t_s_territory` VALUES ('232700', '', '0', '大兴安岭地区', null, '', '0', '0', '230000');
INSERT INTO `t_s_territory` VALUES ('232721', '', '0', '呼玛县', null, '', '0', '0', '232700');
INSERT INTO `t_s_territory` VALUES ('232722', '', '0', '塔河县', null, '', '0', '0', '232700');
INSERT INTO `t_s_territory` VALUES ('232723', '', '0', '漠河县', null, '', '0', '0', '232700');
INSERT INTO `t_s_territory` VALUES ('310000', '', '1', '上海', null, '4', '0', '0', '1');
INSERT INTO `t_s_territory` VALUES ('310100', '', '0', '市区', null, '', '0', '0', '310000');
INSERT INTO `t_s_territory` VALUES ('310101', '', '0', '黄浦区', null, '', '0', '0', '310100');
INSERT INTO `t_s_territory` VALUES ('310104', '', '0', '徐汇区', null, '', '0', '0', '310100');
INSERT INTO `t_s_territory` VALUES ('310105', '', '0', '长宁区', null, '', '0', '0', '310100');
INSERT INTO `t_s_territory` VALUES ('310106', '', '0', '静安区', null, '', '0', '0', '310100');
INSERT INTO `t_s_territory` VALUES ('310107', '', '0', '普陀区', null, '', '0', '0', '310100');
INSERT INTO `t_s_territory` VALUES ('310108', '', '0', '闸北区', null, '', '0', '0', '310100');
INSERT INTO `t_s_territory` VALUES ('310109', '', '0', '虹口区', null, '', '0', '0', '310100');
INSERT INTO `t_s_territory` VALUES ('310110', '', '0', '杨浦区', null, '', '0', '0', '310100');
INSERT INTO `t_s_territory` VALUES ('310112', '', '0', '闵行区', null, '', '0', '0', '310100');
INSERT INTO `t_s_territory` VALUES ('310113', '', '0', '宝山区', null, '', '0', '0', '310100');
INSERT INTO `t_s_territory` VALUES ('310114', '', '0', '嘉定区', null, '', '0', '0', '310100');
INSERT INTO `t_s_territory` VALUES ('310115', '', '0', '浦东新区', null, '', '0', '0', '310100');
INSERT INTO `t_s_territory` VALUES ('310116', '', '0', '金山区', null, '', '0', '0', '310100');
INSERT INTO `t_s_territory` VALUES ('310117', '', '0', '松江区', null, '', '0', '0', '310100');
INSERT INTO `t_s_territory` VALUES ('310118', '', '0', '青浦区', null, '', '0', '0', '310100');
INSERT INTO `t_s_territory` VALUES ('310120', '', '0', '奉贤区', null, '', '0', '0', '310100');
INSERT INTO `t_s_territory` VALUES ('310200', '', '0', '县', null, '', '0', '0', '310000');
INSERT INTO `t_s_territory` VALUES ('310230', '', '0', '崇明县', null, '', '0', '0', '310200');
INSERT INTO `t_s_territory` VALUES ('320000', '', '0', '江苏省', null, '', '0', '0', '1');
INSERT INTO `t_s_territory` VALUES ('320100', '', '0', '南京市', null, '', '0', '0', '320000');
INSERT INTO `t_s_territory` VALUES ('320101', '', '0', '市辖区', null, '', '0', '0', '320100');
INSERT INTO `t_s_territory` VALUES ('320102', '', '0', '玄武区', null, '', '0', '0', '320100');
INSERT INTO `t_s_territory` VALUES ('320104', '', '0', '秦淮区', null, '', '0', '0', '320100');
INSERT INTO `t_s_territory` VALUES ('320105', '', '0', '建邺区', null, '', '0', '0', '320100');
INSERT INTO `t_s_territory` VALUES ('320106', '', '0', '鼓楼区', null, '', '0', '0', '320100');
INSERT INTO `t_s_territory` VALUES ('320111', '', '0', '浦口区', null, '', '0', '0', '320100');
INSERT INTO `t_s_territory` VALUES ('320113', '', '0', '栖霞区', null, '', '0', '0', '320100');
INSERT INTO `t_s_territory` VALUES ('320114', '', '0', '雨花台区', null, '', '0', '0', '320100');
INSERT INTO `t_s_territory` VALUES ('320115', '', '0', '江宁区', null, '', '0', '0', '320100');
INSERT INTO `t_s_territory` VALUES ('320116', '', '0', '六合区', null, '', '0', '0', '320100');
INSERT INTO `t_s_territory` VALUES ('320117', '', '0', '溧水区', null, '', '0', '0', '320100');
INSERT INTO `t_s_territory` VALUES ('320118', '', '0', '高淳区', null, '', '0', '0', '320100');
INSERT INTO `t_s_territory` VALUES ('320200', '', '0', '无锡市', null, '', '0', '0', '320000');
INSERT INTO `t_s_territory` VALUES ('320201', '', '0', '市辖区', null, '', '0', '0', '320200');
INSERT INTO `t_s_territory` VALUES ('320202', '', '0', '崇安区', null, '', '0', '0', '320200');
INSERT INTO `t_s_territory` VALUES ('320203', '', '0', '南长区', null, '', '0', '0', '320200');
INSERT INTO `t_s_territory` VALUES ('320204', '', '0', '北塘区', null, '', '0', '0', '320200');
INSERT INTO `t_s_territory` VALUES ('320205', '', '0', '锡山区', null, '', '0', '0', '320200');
INSERT INTO `t_s_territory` VALUES ('320206', '', '0', '惠山区', null, '', '0', '0', '320200');
INSERT INTO `t_s_territory` VALUES ('320211', '', '0', '滨湖区', null, '', '0', '0', '320200');
INSERT INTO `t_s_territory` VALUES ('320281', '', '0', '江阴市', null, '', '0', '0', '320200');
INSERT INTO `t_s_territory` VALUES ('320282', '', '0', '宜兴市', null, '', '0', '0', '320200');
INSERT INTO `t_s_territory` VALUES ('320300', '', '0', '徐州市', null, '', '0', '0', '320000');
INSERT INTO `t_s_territory` VALUES ('320301', '', '0', '市辖区', null, '', '0', '0', '320300');
INSERT INTO `t_s_territory` VALUES ('320302', '', '0', '鼓楼区', null, '', '0', '0', '320300');
INSERT INTO `t_s_territory` VALUES ('320303', '', '0', '云龙区', null, '', '0', '0', '320300');
INSERT INTO `t_s_territory` VALUES ('320305', '', '0', '贾汪区', null, '', '0', '0', '320300');
INSERT INTO `t_s_territory` VALUES ('320311', '', '0', '泉山区', null, '', '0', '0', '320300');
INSERT INTO `t_s_territory` VALUES ('320312', '', '0', '铜山区', null, '', '0', '0', '320300');
INSERT INTO `t_s_territory` VALUES ('320321', '', '0', '丰县', null, '', '0', '0', '320300');
INSERT INTO `t_s_territory` VALUES ('320322', '', '0', '沛县', null, '', '0', '0', '320300');
INSERT INTO `t_s_territory` VALUES ('320324', '', '0', '睢宁县', null, '', '0', '0', '320300');
INSERT INTO `t_s_territory` VALUES ('320381', '', '0', '新沂市', null, '', '0', '0', '320300');
INSERT INTO `t_s_territory` VALUES ('320382', '', '0', '邳州市', null, '', '0', '0', '320300');
INSERT INTO `t_s_territory` VALUES ('320400', '', '0', '常州市', null, '', '0', '0', '320000');
INSERT INTO `t_s_territory` VALUES ('320401', '', '0', '市辖区', null, '', '0', '0', '320400');
INSERT INTO `t_s_territory` VALUES ('320402', '', '0', '天宁区', null, '', '0', '0', '320400');
INSERT INTO `t_s_territory` VALUES ('320404', '', '0', '钟楼区', null, '', '0', '0', '320400');
INSERT INTO `t_s_territory` VALUES ('320405', '', '0', '戚墅堰区', null, '', '0', '0', '320400');
INSERT INTO `t_s_territory` VALUES ('320411', '', '0', '新北区', null, '', '0', '0', '320400');
INSERT INTO `t_s_territory` VALUES ('320412', '', '0', '武进区', null, '', '0', '0', '320400');
INSERT INTO `t_s_territory` VALUES ('320481', '', '0', '溧阳市', null, '', '0', '0', '320400');
INSERT INTO `t_s_territory` VALUES ('320482', '', '0', '金坛市', null, '', '0', '0', '320400');
INSERT INTO `t_s_territory` VALUES ('320500', '', '0', '苏州市', null, '', '0', '0', '320000');
INSERT INTO `t_s_territory` VALUES ('320501', '', '0', '市辖区', null, '', '0', '0', '320500');
INSERT INTO `t_s_territory` VALUES ('320505', '', '0', '虎丘区', null, '', '0', '0', '320500');
INSERT INTO `t_s_territory` VALUES ('320506', '', '0', '吴中区', null, '', '0', '0', '320500');
INSERT INTO `t_s_territory` VALUES ('320507', '', '0', '相城区', null, '', '0', '0', '320500');
INSERT INTO `t_s_territory` VALUES ('320508', '', '0', '姑苏区', null, '', '0', '0', '320500');
INSERT INTO `t_s_territory` VALUES ('320509', '', '0', '吴江区', null, '', '0', '0', '320500');
INSERT INTO `t_s_territory` VALUES ('320581', '', '0', '常熟市', null, '', '0', '0', '320500');
INSERT INTO `t_s_territory` VALUES ('320582', '', '0', '张家港市', null, '', '0', '0', '320500');
INSERT INTO `t_s_territory` VALUES ('320583', '', '0', '昆山市', null, '', '0', '0', '320500');
INSERT INTO `t_s_territory` VALUES ('320585', '', '0', '太仓市', null, '', '0', '0', '320500');
INSERT INTO `t_s_territory` VALUES ('320600', '', '0', '南通市', null, '', '0', '0', '320000');
INSERT INTO `t_s_territory` VALUES ('320601', '', '0', '市辖区', null, '', '0', '0', '320600');
INSERT INTO `t_s_territory` VALUES ('320602', '', '0', '崇川区', null, '', '0', '0', '320600');
INSERT INTO `t_s_territory` VALUES ('320611', '', '0', '港闸区', null, '', '0', '0', '320600');
INSERT INTO `t_s_territory` VALUES ('320612', '', '0', '通州区', null, '', '0', '0', '320600');
INSERT INTO `t_s_territory` VALUES ('320621', '', '0', '海安县', null, '', '0', '0', '320600');
INSERT INTO `t_s_territory` VALUES ('320623', '', '0', '如东县', null, '', '0', '0', '320600');
INSERT INTO `t_s_territory` VALUES ('320681', '', '0', '启东市', null, '', '0', '0', '320600');
INSERT INTO `t_s_territory` VALUES ('320682', '', '0', '如皋市', null, '', '0', '0', '320600');
INSERT INTO `t_s_territory` VALUES ('320684', '', '0', '海门市', null, '', '0', '0', '320600');
INSERT INTO `t_s_territory` VALUES ('320700', '', '0', '连云港市', null, '', '0', '0', '320000');
INSERT INTO `t_s_territory` VALUES ('320701', '', '0', '市辖区', null, '', '0', '0', '320700');
INSERT INTO `t_s_territory` VALUES ('320703', '', '0', '连云区', null, '', '0', '0', '320700');
INSERT INTO `t_s_territory` VALUES ('320706', '', '0', '海州区', null, '', '0', '0', '320700');
INSERT INTO `t_s_territory` VALUES ('320707', '', '0', '赣榆区', null, '', '0', '0', '320700');
INSERT INTO `t_s_territory` VALUES ('320722', '', '0', '东海县', null, '', '0', '0', '320700');
INSERT INTO `t_s_territory` VALUES ('320723', '', '0', '灌云县', null, '', '0', '0', '320700');
INSERT INTO `t_s_territory` VALUES ('320724', '', '0', '灌南县', null, '', '0', '0', '320700');
INSERT INTO `t_s_territory` VALUES ('320800', '', '0', '淮安市', null, '', '0', '0', '320000');
INSERT INTO `t_s_territory` VALUES ('320801', '', '0', '市辖区', null, '', '0', '0', '320800');
INSERT INTO `t_s_territory` VALUES ('320802', '', '0', '清河区', null, '', '0', '0', '320800');
INSERT INTO `t_s_territory` VALUES ('320803', '', '0', '淮安区', null, '', '0', '0', '320800');
INSERT INTO `t_s_territory` VALUES ('320804', '', '0', '淮阴区', null, '', '0', '0', '320800');
INSERT INTO `t_s_territory` VALUES ('320811', '', '0', '清浦区', null, '', '0', '0', '320800');
INSERT INTO `t_s_territory` VALUES ('320826', '', '0', '涟水县', null, '', '0', '0', '320800');
INSERT INTO `t_s_territory` VALUES ('320829', '', '0', '洪泽县', null, '', '0', '0', '320800');
INSERT INTO `t_s_territory` VALUES ('320830', '', '0', '盱眙县', null, '', '0', '0', '320800');
INSERT INTO `t_s_territory` VALUES ('320831', '', '0', '金湖县', null, '', '0', '0', '320800');
INSERT INTO `t_s_territory` VALUES ('320900', '', '0', '盐城市', null, '', '0', '0', '320000');
INSERT INTO `t_s_territory` VALUES ('320901', '', '0', '市辖区', null, '', '0', '0', '320900');
INSERT INTO `t_s_territory` VALUES ('320902', '', '0', '亭湖区', null, '', '0', '0', '320900');
INSERT INTO `t_s_territory` VALUES ('320903', '', '0', '盐都区', null, '', '0', '0', '320900');
INSERT INTO `t_s_territory` VALUES ('320921', '', '0', '响水县', null, '', '0', '0', '320900');
INSERT INTO `t_s_territory` VALUES ('320922', '', '0', '滨海县', null, '', '0', '0', '320900');
INSERT INTO `t_s_territory` VALUES ('320923', '', '0', '阜宁县', null, '', '0', '0', '320900');
INSERT INTO `t_s_territory` VALUES ('320924', '', '0', '射阳县', null, '', '0', '0', '320900');
INSERT INTO `t_s_territory` VALUES ('320925', '', '0', '建湖县', null, '', '0', '0', '320900');
INSERT INTO `t_s_territory` VALUES ('320981', '', '0', '东台市', null, '', '0', '0', '320900');
INSERT INTO `t_s_territory` VALUES ('320982', '', '0', '大丰市', null, '', '0', '0', '320900');
INSERT INTO `t_s_territory` VALUES ('321000', '', '0', '扬州市', null, '', '0', '0', '320000');
INSERT INTO `t_s_territory` VALUES ('321001', '', '0', '市辖区', null, '', '0', '0', '321000');
INSERT INTO `t_s_territory` VALUES ('321002', '', '0', '广陵区', null, '', '0', '0', '321000');
INSERT INTO `t_s_territory` VALUES ('321003', '', '0', '邗江区', null, '', '0', '0', '321000');
INSERT INTO `t_s_territory` VALUES ('321012', '', '0', '江都区', null, '', '0', '0', '321000');
INSERT INTO `t_s_territory` VALUES ('321023', '', '0', '宝应县', null, '', '0', '0', '321000');
INSERT INTO `t_s_territory` VALUES ('321081', '', '0', '仪征市', null, '', '0', '0', '321000');
INSERT INTO `t_s_territory` VALUES ('321084', '', '0', '高邮市', null, '', '0', '0', '321000');
INSERT INTO `t_s_territory` VALUES ('321100', '', '0', '镇江市', null, '', '0', '0', '320000');
INSERT INTO `t_s_territory` VALUES ('321101', '', '0', '市辖区', null, '', '0', '0', '321100');
INSERT INTO `t_s_territory` VALUES ('321102', '', '0', '京口区', null, '', '0', '0', '321100');
INSERT INTO `t_s_territory` VALUES ('321111', '', '0', '润州区', null, '', '0', '0', '321100');
INSERT INTO `t_s_territory` VALUES ('321112', '', '0', '丹徒区', null, '', '0', '0', '321100');
INSERT INTO `t_s_territory` VALUES ('321181', '', '0', '丹阳市', null, '', '0', '0', '321100');
INSERT INTO `t_s_territory` VALUES ('321182', '', '0', '扬中市', null, '', '0', '0', '321100');
INSERT INTO `t_s_territory` VALUES ('321183', '', '0', '句容市', null, '', '0', '0', '321100');
INSERT INTO `t_s_territory` VALUES ('321200', '', '0', '泰州市', null, '', '0', '0', '320000');
INSERT INTO `t_s_territory` VALUES ('321201', '', '0', '市辖区', null, '', '0', '0', '321200');
INSERT INTO `t_s_territory` VALUES ('321202', '', '0', '海陵区', null, '', '0', '0', '321200');
INSERT INTO `t_s_territory` VALUES ('321203', '', '0', '高港区', null, '', '0', '0', '321200');
INSERT INTO `t_s_territory` VALUES ('321204', '', '0', '姜堰区', null, '', '0', '0', '321200');
INSERT INTO `t_s_territory` VALUES ('321281', '', '0', '兴化市', null, '', '0', '0', '321200');
INSERT INTO `t_s_territory` VALUES ('321282', '', '0', '靖江市', null, '', '0', '0', '321200');
INSERT INTO `t_s_territory` VALUES ('321283', '', '0', '泰兴市', null, '', '0', '0', '321200');
INSERT INTO `t_s_territory` VALUES ('321300', '', '0', '宿迁市', null, '', '0', '0', '320000');
INSERT INTO `t_s_territory` VALUES ('321301', '', '0', '市辖区', null, '', '0', '0', '321300');
INSERT INTO `t_s_territory` VALUES ('321302', '', '0', '宿城区', null, '', '0', '0', '321300');
INSERT INTO `t_s_territory` VALUES ('321311', '', '0', '宿豫区', null, '', '0', '0', '321300');
INSERT INTO `t_s_territory` VALUES ('321322', '', '0', '沭阳县', null, '', '0', '0', '321300');
INSERT INTO `t_s_territory` VALUES ('321323', '', '0', '泗阳县', null, '', '0', '0', '321300');
INSERT INTO `t_s_territory` VALUES ('321324', '', '0', '泗洪县', null, '', '0', '0', '321300');
INSERT INTO `t_s_territory` VALUES ('330000', '', '0', '浙江省', null, '', '0', '0', '1');
INSERT INTO `t_s_territory` VALUES ('330100', '', '0', '杭州市', null, '', '0', '0', '330000');
INSERT INTO `t_s_territory` VALUES ('330101', '', '0', '市辖区', null, '', '0', '0', '330100');
INSERT INTO `t_s_territory` VALUES ('330102', '', '0', '上城区', null, '', '0', '0', '330100');
INSERT INTO `t_s_territory` VALUES ('330103', '', '0', '下城区', null, '', '0', '0', '330100');
INSERT INTO `t_s_territory` VALUES ('330104', '', '0', '江干区', null, '', '0', '0', '330100');
INSERT INTO `t_s_territory` VALUES ('330105', '', '0', '拱墅区', null, '', '0', '0', '330100');
INSERT INTO `t_s_territory` VALUES ('330106', '', '0', '西湖区', null, '', '0', '0', '330100');
INSERT INTO `t_s_territory` VALUES ('330108', '', '0', '滨江区', null, '', '0', '0', '330100');
INSERT INTO `t_s_territory` VALUES ('330109', '', '0', '萧山区', null, '', '0', '0', '330100');
INSERT INTO `t_s_territory` VALUES ('330110', '', '0', '余杭区', null, '', '0', '0', '330100');
INSERT INTO `t_s_territory` VALUES ('330122', '', '0', '桐庐县', null, '', '0', '0', '330100');
INSERT INTO `t_s_territory` VALUES ('330127', '', '0', '淳安县', null, '', '0', '0', '330100');
INSERT INTO `t_s_territory` VALUES ('330182', '', '0', '建德市', null, '', '0', '0', '330100');
INSERT INTO `t_s_territory` VALUES ('330183', '', '0', '富阳市', null, '', '0', '0', '330100');
INSERT INTO `t_s_territory` VALUES ('330185', '', '0', '临安市', null, '', '0', '0', '330100');
INSERT INTO `t_s_territory` VALUES ('330200', '', '0', '宁波市', null, '', '0', '0', '330000');
INSERT INTO `t_s_territory` VALUES ('330201', '', '0', '市辖区', null, '', '0', '0', '330200');
INSERT INTO `t_s_territory` VALUES ('330203', '', '0', '海曙区', null, '', '0', '0', '330200');
INSERT INTO `t_s_territory` VALUES ('330204', '', '0', '江东区', null, '', '0', '0', '330200');
INSERT INTO `t_s_territory` VALUES ('330205', '', '0', '江北区', null, '', '0', '0', '330200');
INSERT INTO `t_s_territory` VALUES ('330206', '', '0', '北仑区', null, '', '0', '0', '330200');
INSERT INTO `t_s_territory` VALUES ('330211', '', '0', '镇海区', null, '', '0', '0', '330200');
INSERT INTO `t_s_territory` VALUES ('330212', '', '0', '鄞州区', null, '', '0', '0', '330200');
INSERT INTO `t_s_territory` VALUES ('330225', '', '0', '象山县', null, '', '0', '0', '330200');
INSERT INTO `t_s_territory` VALUES ('330226', '', '0', '宁海县', null, '', '0', '0', '330200');
INSERT INTO `t_s_territory` VALUES ('330281', '', '0', '余姚市', null, '', '0', '0', '330200');
INSERT INTO `t_s_territory` VALUES ('330282', '', '0', '慈溪市', null, '', '0', '0', '330200');
INSERT INTO `t_s_territory` VALUES ('330283', '', '0', '奉化市', null, '', '0', '0', '330200');
INSERT INTO `t_s_territory` VALUES ('330300', '', '0', '温州市', null, '', '0', '0', '330000');
INSERT INTO `t_s_territory` VALUES ('330301', '', '0', '市辖区', null, '', '0', '0', '330300');
INSERT INTO `t_s_territory` VALUES ('330302', '', '0', '鹿城区', null, '', '0', '0', '330300');
INSERT INTO `t_s_territory` VALUES ('330303', '', '0', '龙湾区', null, '', '0', '0', '330300');
INSERT INTO `t_s_territory` VALUES ('330304', '', '0', '瓯海区', null, '', '0', '0', '330300');
INSERT INTO `t_s_territory` VALUES ('330322', '', '0', '洞头县', null, '', '0', '0', '330300');
INSERT INTO `t_s_territory` VALUES ('330324', '', '0', '永嘉县', null, '', '0', '0', '330300');
INSERT INTO `t_s_territory` VALUES ('330326', '', '0', '平阳县', null, '', '0', '0', '330300');
INSERT INTO `t_s_territory` VALUES ('330327', '', '0', '苍南县', null, '', '0', '0', '330300');
INSERT INTO `t_s_territory` VALUES ('330328', '', '0', '文成县', null, '', '0', '0', '330300');
INSERT INTO `t_s_territory` VALUES ('330329', '', '0', '泰顺县', null, '', '0', '0', '330300');
INSERT INTO `t_s_territory` VALUES ('330381', '', '0', '瑞安市', null, '', '0', '0', '330300');
INSERT INTO `t_s_territory` VALUES ('330382', '', '0', '乐清市', null, '', '0', '0', '330300');
INSERT INTO `t_s_territory` VALUES ('330400', '', '0', '嘉兴市', null, '', '0', '0', '330000');
INSERT INTO `t_s_territory` VALUES ('330401', '', '0', '市辖区', null, '', '0', '0', '330400');
INSERT INTO `t_s_territory` VALUES ('330402', '', '0', '南湖区', null, '', '0', '0', '330400');
INSERT INTO `t_s_territory` VALUES ('330411', '', '0', '秀洲区', null, '', '0', '0', '330400');
INSERT INTO `t_s_territory` VALUES ('330421', '', '0', '嘉善县', null, '', '0', '0', '330400');
INSERT INTO `t_s_territory` VALUES ('330424', '', '0', '海盐县', null, '', '0', '0', '330400');
INSERT INTO `t_s_territory` VALUES ('330481', '', '0', '海宁市', null, '', '0', '0', '330400');
INSERT INTO `t_s_territory` VALUES ('330482', '', '0', '平湖市', null, '', '0', '0', '330400');
INSERT INTO `t_s_territory` VALUES ('330483', '', '0', '桐乡市', null, '', '0', '0', '330400');
INSERT INTO `t_s_territory` VALUES ('330500', '', '0', '湖州市', null, '', '0', '0', '330000');
INSERT INTO `t_s_territory` VALUES ('330501', '', '0', '市辖区', null, '', '0', '0', '330500');
INSERT INTO `t_s_territory` VALUES ('330502', '', '0', '吴兴区', null, '', '0', '0', '330500');
INSERT INTO `t_s_territory` VALUES ('330503', '', '0', '南浔区', null, '', '0', '0', '330500');
INSERT INTO `t_s_territory` VALUES ('330521', '', '0', '德清县', null, '', '0', '0', '330500');
INSERT INTO `t_s_territory` VALUES ('330522', '', '0', '长兴县', null, '', '0', '0', '330500');
INSERT INTO `t_s_territory` VALUES ('330523', '', '0', '安吉县', null, '', '0', '0', '330500');
INSERT INTO `t_s_territory` VALUES ('330600', '', '0', '绍兴市', null, '', '0', '0', '330000');
INSERT INTO `t_s_territory` VALUES ('330601', '', '0', '市辖区', null, '', '0', '0', '330600');
INSERT INTO `t_s_territory` VALUES ('330602', '', '0', '越城区', null, '', '0', '0', '330600');
INSERT INTO `t_s_territory` VALUES ('330603', '', '0', '柯桥区', null, '', '0', '0', '330600');
INSERT INTO `t_s_territory` VALUES ('330604', '', '0', '上虞区', null, '', '0', '0', '330600');
INSERT INTO `t_s_territory` VALUES ('330624', '', '0', '新昌县', null, '', '0', '0', '330600');
INSERT INTO `t_s_territory` VALUES ('330681', '', '0', '诸暨市', null, '', '0', '0', '330600');
INSERT INTO `t_s_territory` VALUES ('330683', '', '0', '嵊州市', null, '', '0', '0', '330600');
INSERT INTO `t_s_territory` VALUES ('330700', '', '0', '金华市', null, '', '0', '0', '330000');
INSERT INTO `t_s_territory` VALUES ('330701', '', '0', '市辖区', null, '', '0', '0', '330700');
INSERT INTO `t_s_territory` VALUES ('330702', '', '0', '婺城区', null, '', '0', '0', '330700');
INSERT INTO `t_s_territory` VALUES ('330703', '', '0', '金东区', null, '', '0', '0', '330700');
INSERT INTO `t_s_territory` VALUES ('330723', '', '0', '武义县', null, '', '0', '0', '330700');
INSERT INTO `t_s_territory` VALUES ('330726', '', '0', '浦江县', null, '', '0', '0', '330700');
INSERT INTO `t_s_territory` VALUES ('330727', '', '0', '磐安县', null, '', '0', '0', '330700');
INSERT INTO `t_s_territory` VALUES ('330781', '', '0', '兰溪市', null, '', '0', '0', '330700');
INSERT INTO `t_s_territory` VALUES ('330782', '', '0', '义乌市', null, '', '0', '0', '330700');
INSERT INTO `t_s_territory` VALUES ('330783', '', '0', '东阳市', null, '', '0', '0', '330700');
INSERT INTO `t_s_territory` VALUES ('330784', '', '0', '永康市', null, '', '0', '0', '330700');
INSERT INTO `t_s_territory` VALUES ('330800', '', '0', '衢州市', null, '', '0', '0', '330000');
INSERT INTO `t_s_territory` VALUES ('330801', '', '0', '市辖区', null, '', '0', '0', '330800');
INSERT INTO `t_s_territory` VALUES ('330802', '', '0', '柯城区', null, '', '0', '0', '330800');
INSERT INTO `t_s_territory` VALUES ('330803', '', '0', '衢江区', null, '', '0', '0', '330800');
INSERT INTO `t_s_territory` VALUES ('330822', '', '0', '常山县', null, '', '0', '0', '330800');
INSERT INTO `t_s_territory` VALUES ('330824', '', '0', '开化县', null, '', '0', '0', '330800');
INSERT INTO `t_s_territory` VALUES ('330825', '', '0', '龙游县', null, '', '0', '0', '330800');
INSERT INTO `t_s_territory` VALUES ('330881', '', '0', '江山市', null, '', '0', '0', '330800');
INSERT INTO `t_s_territory` VALUES ('330900', '', '0', '舟山市', null, '', '0', '0', '330000');
INSERT INTO `t_s_territory` VALUES ('330901', '', '0', '市辖区', null, '', '0', '0', '330900');
INSERT INTO `t_s_territory` VALUES ('330902', '', '0', '定海区', null, '', '0', '0', '330900');
INSERT INTO `t_s_territory` VALUES ('330903', '', '0', '普陀区', null, '', '0', '0', '330900');
INSERT INTO `t_s_territory` VALUES ('330921', '', '0', '岱山县', null, '', '0', '0', '330900');
INSERT INTO `t_s_territory` VALUES ('330922', '', '0', '嵊泗县', null, '', '0', '0', '330900');
INSERT INTO `t_s_territory` VALUES ('331000', '', '0', '台州市', null, '', '0', '0', '330000');
INSERT INTO `t_s_territory` VALUES ('331001', '', '0', '市辖区', null, '', '0', '0', '331000');
INSERT INTO `t_s_territory` VALUES ('331002', '', '0', '椒江区', null, '', '0', '0', '331000');
INSERT INTO `t_s_territory` VALUES ('331003', '', '0', '黄岩区', null, '', '0', '0', '331000');
INSERT INTO `t_s_territory` VALUES ('331004', '', '0', '路桥区', null, '', '0', '0', '331000');
INSERT INTO `t_s_territory` VALUES ('331021', '', '0', '玉环县', null, '', '0', '0', '331000');
INSERT INTO `t_s_territory` VALUES ('331022', '', '0', '三门县', null, '', '0', '0', '331000');
INSERT INTO `t_s_territory` VALUES ('331023', '', '0', '天台县', null, '', '0', '0', '331000');
INSERT INTO `t_s_territory` VALUES ('331024', '', '0', '仙居县', null, '', '0', '0', '331000');
INSERT INTO `t_s_territory` VALUES ('331081', '', '0', '温岭市', null, '', '0', '0', '331000');
INSERT INTO `t_s_territory` VALUES ('331082', '', '0', '临海市', null, '', '0', '0', '331000');
INSERT INTO `t_s_territory` VALUES ('331100', '', '0', '丽水市', null, '', '0', '0', '330000');
INSERT INTO `t_s_territory` VALUES ('331101', '', '0', '市辖区', null, '', '0', '0', '331100');
INSERT INTO `t_s_territory` VALUES ('331102', '', '0', '莲都区', null, '', '0', '0', '331100');
INSERT INTO `t_s_territory` VALUES ('331121', '', '0', '青田县', null, '', '0', '0', '331100');
INSERT INTO `t_s_territory` VALUES ('331122', '', '0', '缙云县', null, '', '0', '0', '331100');
INSERT INTO `t_s_territory` VALUES ('331123', '', '0', '遂昌县', null, '', '0', '0', '331100');
INSERT INTO `t_s_territory` VALUES ('331124', '', '0', '松阳县', null, '', '0', '0', '331100');
INSERT INTO `t_s_territory` VALUES ('331125', '', '0', '云和县', null, '', '0', '0', '331100');
INSERT INTO `t_s_territory` VALUES ('331126', '', '0', '庆元县', null, '', '0', '0', '331100');
INSERT INTO `t_s_territory` VALUES ('331127', '', '0', '景宁畲族自治县', null, '', '0', '0', '331100');
INSERT INTO `t_s_territory` VALUES ('331181', '', '0', '龙泉市', null, '', '0', '0', '331100');
INSERT INTO `t_s_territory` VALUES ('340000', '', '0', '安徽省', null, '10', '0', '0', '1');
INSERT INTO `t_s_territory` VALUES ('340100', '', '0', '合肥市', null, '', '0', '0', '340000');
INSERT INTO `t_s_territory` VALUES ('340101', '', '0', '市辖区', null, '', '0', '0', '340100');
INSERT INTO `t_s_territory` VALUES ('340102', '', '0', '瑶海区', null, '', '0', '0', '340100');
INSERT INTO `t_s_territory` VALUES ('340103', '', '0', '庐阳区', null, '', '0', '0', '340100');
INSERT INTO `t_s_territory` VALUES ('340104', '', '0', '蜀山区', null, '', '0', '0', '340100');
INSERT INTO `t_s_territory` VALUES ('340111', '', '0', '包河区', null, '', '0', '0', '340100');
INSERT INTO `t_s_territory` VALUES ('340121', '', '0', '长丰县', null, '', '0', '0', '340100');
INSERT INTO `t_s_territory` VALUES ('340122', '', '0', '肥东县', null, '', '0', '0', '340100');
INSERT INTO `t_s_territory` VALUES ('340123', '', '0', '肥西县', null, '', '0', '0', '340100');
INSERT INTO `t_s_territory` VALUES ('340124', '', '0', '庐江县', null, '', '0', '0', '340100');
INSERT INTO `t_s_territory` VALUES ('340181', '', '0', '巢湖市', null, '', '0', '0', '340100');
INSERT INTO `t_s_territory` VALUES ('340200', '', '0', '芜湖市', null, '', '0', '0', '340000');
INSERT INTO `t_s_territory` VALUES ('340201', '', '0', '市辖区', null, '', '0', '0', '340200');
INSERT INTO `t_s_territory` VALUES ('340202', '', '0', '镜湖区', null, '', '0', '0', '340200');
INSERT INTO `t_s_territory` VALUES ('340203', '', '0', '弋江区', null, '', '0', '0', '340200');
INSERT INTO `t_s_territory` VALUES ('340207', '', '0', '鸠江区', null, '', '0', '0', '340200');
INSERT INTO `t_s_territory` VALUES ('340208', '', '0', '三山区', null, '', '0', '0', '340200');
INSERT INTO `t_s_territory` VALUES ('340221', '', '0', '芜湖县', null, '', '0', '0', '340200');
INSERT INTO `t_s_territory` VALUES ('340222', '', '0', '繁昌县', null, '', '0', '0', '340200');
INSERT INTO `t_s_territory` VALUES ('340223', '', '0', '南陵县', null, '', '0', '0', '340200');
INSERT INTO `t_s_territory` VALUES ('340225', '', '0', '无为县', null, '', '0', '0', '340200');
INSERT INTO `t_s_territory` VALUES ('340300', '', '0', '蚌埠市', null, '', '0', '0', '340000');
INSERT INTO `t_s_territory` VALUES ('340301', '', '0', '市辖区', null, '', '0', '0', '340300');
INSERT INTO `t_s_territory` VALUES ('340302', '', '0', '龙子湖区', null, '', '0', '0', '340300');
INSERT INTO `t_s_territory` VALUES ('340303', '', '0', '蚌山区', null, '', '0', '0', '340300');
INSERT INTO `t_s_territory` VALUES ('340304', '', '0', '禹会区', null, '', '0', '0', '340300');
INSERT INTO `t_s_territory` VALUES ('340311', '', '0', '淮上区', null, '', '0', '0', '340300');
INSERT INTO `t_s_territory` VALUES ('340321', '', '0', '怀远县', null, '', '0', '0', '340300');
INSERT INTO `t_s_territory` VALUES ('340322', '', '0', '五河县', null, '', '0', '0', '340300');
INSERT INTO `t_s_territory` VALUES ('340323', '', '0', '固镇县', null, '', '0', '0', '340300');
INSERT INTO `t_s_territory` VALUES ('340400', '', '0', '淮南市', null, '', '0', '0', '340000');
INSERT INTO `t_s_territory` VALUES ('340401', '', '0', '市辖区', null, '', '0', '0', '340400');
INSERT INTO `t_s_territory` VALUES ('340402', '', '0', '大通区', null, '', '0', '0', '340400');
INSERT INTO `t_s_territory` VALUES ('340403', '', '0', '田家庵区', null, '', '0', '0', '340400');
INSERT INTO `t_s_territory` VALUES ('340404', '', '0', '谢家集区', null, '', '0', '0', '340400');
INSERT INTO `t_s_territory` VALUES ('340405', '', '0', '八公山区', null, '', '0', '0', '340400');
INSERT INTO `t_s_territory` VALUES ('340406', '', '0', '潘集区', null, '', '0', '0', '340400');
INSERT INTO `t_s_territory` VALUES ('340421', '', '0', '凤台县', null, '', '0', '0', '340400');
INSERT INTO `t_s_territory` VALUES ('340500', '', '0', '马鞍山市', null, '', '0', '0', '340000');
INSERT INTO `t_s_territory` VALUES ('340501', '', '0', '市辖区', null, '', '0', '0', '340500');
INSERT INTO `t_s_territory` VALUES ('340503', '', '0', '花山区', null, '', '0', '0', '340500');
INSERT INTO `t_s_territory` VALUES ('340504', '', '0', '雨山区', null, '', '0', '0', '340500');
INSERT INTO `t_s_territory` VALUES ('340506', '', '0', '博望区', null, '', '0', '0', '340500');
INSERT INTO `t_s_territory` VALUES ('340521', '', '0', '当涂县', null, '', '0', '0', '340500');
INSERT INTO `t_s_territory` VALUES ('340522', '', '0', '含山县', null, '', '0', '0', '340500');
INSERT INTO `t_s_territory` VALUES ('340523', '', '0', '和县', null, '', '0', '0', '340500');
INSERT INTO `t_s_territory` VALUES ('340600', '', '0', '淮北市', null, '', '0', '0', '340000');
INSERT INTO `t_s_territory` VALUES ('340601', '', '0', '市辖区', null, '', '0', '0', '340600');
INSERT INTO `t_s_territory` VALUES ('340602', '', '0', '杜集区', null, '', '0', '0', '340600');
INSERT INTO `t_s_territory` VALUES ('340603', '', '0', '相山区', null, '', '0', '0', '340600');
INSERT INTO `t_s_territory` VALUES ('340604', '', '0', '烈山区', null, '', '0', '0', '340600');
INSERT INTO `t_s_territory` VALUES ('340621', '', '0', '濉溪县', null, '', '0', '0', '340600');
INSERT INTO `t_s_territory` VALUES ('340700', '', '0', '铜陵市', null, '', '0', '0', '340000');
INSERT INTO `t_s_territory` VALUES ('340701', '', '0', '市辖区', null, '', '0', '0', '340700');
INSERT INTO `t_s_territory` VALUES ('340702', '', '0', '铜官山区', null, '', '0', '0', '340700');
INSERT INTO `t_s_territory` VALUES ('340703', '', '0', '狮子山区', null, '', '0', '0', '340700');
INSERT INTO `t_s_territory` VALUES ('340711', '', '0', '郊区', null, '', '0', '0', '340700');
INSERT INTO `t_s_territory` VALUES ('340721', '', '0', '铜陵县', null, '', '0', '0', '340700');
INSERT INTO `t_s_territory` VALUES ('340800', '', '0', '安庆市', null, '', '0', '0', '340000');
INSERT INTO `t_s_territory` VALUES ('340801', '', '0', '市辖区', null, '', '0', '0', '340800');
INSERT INTO `t_s_territory` VALUES ('340802', '', '0', '迎江区', null, '', '0', '0', '340800');
INSERT INTO `t_s_territory` VALUES ('340803', '', '0', '大观区', null, '', '0', '0', '340800');
INSERT INTO `t_s_territory` VALUES ('340811', '', '0', '宜秀区', null, '', '0', '0', '340800');
INSERT INTO `t_s_territory` VALUES ('340822', '', '0', '怀宁县', null, '', '0', '0', '340800');
INSERT INTO `t_s_territory` VALUES ('340823', '', '0', '枞阳县', null, '', '0', '0', '340800');
INSERT INTO `t_s_territory` VALUES ('340824', '', '0', '潜山县', null, '', '0', '0', '340800');
INSERT INTO `t_s_territory` VALUES ('340825', '', '0', '太湖县', null, '', '0', '0', '340800');
INSERT INTO `t_s_territory` VALUES ('340826', '', '0', '宿松县', null, '', '0', '0', '340800');
INSERT INTO `t_s_territory` VALUES ('340827', '', '0', '望江县', null, '', '0', '0', '340800');
INSERT INTO `t_s_territory` VALUES ('340828', '', '0', '岳西县', null, '', '0', '0', '340800');
INSERT INTO `t_s_territory` VALUES ('340881', '', '0', '桐城市', null, '', '0', '0', '340800');
INSERT INTO `t_s_territory` VALUES ('341000', '', '0', '黄山市', null, '', '0', '0', '340000');
INSERT INTO `t_s_territory` VALUES ('341001', '', '0', '市辖区', null, '', '0', '0', '341000');
INSERT INTO `t_s_territory` VALUES ('341002', '', '0', '屯溪区', null, '', '0', '0', '341000');
INSERT INTO `t_s_territory` VALUES ('341003', '', '0', '黄山区', null, '', '0', '0', '341000');
INSERT INTO `t_s_territory` VALUES ('341004', '', '0', '徽州区', null, '', '0', '0', '341000');
INSERT INTO `t_s_territory` VALUES ('341021', '', '0', '歙县', null, '', '0', '0', '341000');
INSERT INTO `t_s_territory` VALUES ('341022', '', '0', '休宁县', null, '', '0', '0', '341000');
INSERT INTO `t_s_territory` VALUES ('341023', '', '0', '黟县', null, '', '0', '0', '341000');
INSERT INTO `t_s_territory` VALUES ('341024', '', '0', '祁门县', null, '', '0', '0', '341000');
INSERT INTO `t_s_territory` VALUES ('341100', '', '0', '滁州市', null, '', '0', '0', '340000');
INSERT INTO `t_s_territory` VALUES ('341101', '', '0', '市辖区', null, '', '0', '0', '341100');
INSERT INTO `t_s_territory` VALUES ('341102', '', '0', '琅琊区', null, '', '0', '0', '341100');
INSERT INTO `t_s_territory` VALUES ('341103', '', '0', '南谯区', null, '', '0', '0', '341100');
INSERT INTO `t_s_territory` VALUES ('341122', '', '0', '来安县', null, '', '0', '0', '341100');
INSERT INTO `t_s_territory` VALUES ('341124', '', '0', '全椒县', null, '', '0', '0', '341100');
INSERT INTO `t_s_territory` VALUES ('341125', '', '0', '定远县', null, '', '0', '0', '341100');
INSERT INTO `t_s_territory` VALUES ('341126', '', '0', '凤阳县', null, '', '0', '0', '341100');
INSERT INTO `t_s_territory` VALUES ('341181', '', '0', '天长市', null, '', '0', '0', '341100');
INSERT INTO `t_s_territory` VALUES ('341182', '', '0', '明光市', null, '', '0', '0', '341100');
INSERT INTO `t_s_territory` VALUES ('341200', '', '0', '阜阳市', null, '', '0', '0', '340000');
INSERT INTO `t_s_territory` VALUES ('341201', '', '0', '市辖区', null, '', '0', '0', '341200');
INSERT INTO `t_s_territory` VALUES ('341202', '', '0', '颍州区', null, '', '0', '0', '341200');
INSERT INTO `t_s_territory` VALUES ('341203', '', '0', '颍东区', null, '', '0', '0', '341200');
INSERT INTO `t_s_territory` VALUES ('341204', '', '0', '颍泉区', null, '', '0', '0', '341200');
INSERT INTO `t_s_territory` VALUES ('341221', '', '0', '临泉县', null, '', '0', '0', '341200');
INSERT INTO `t_s_territory` VALUES ('341222', '', '0', '太和县', null, '', '0', '0', '341200');
INSERT INTO `t_s_territory` VALUES ('341225', '', '0', '阜南县', null, '', '0', '0', '341200');
INSERT INTO `t_s_territory` VALUES ('341226', '', '0', '颍上县', null, '', '0', '0', '341200');
INSERT INTO `t_s_territory` VALUES ('341282', '', '0', '界首市', null, '', '0', '0', '341200');
INSERT INTO `t_s_territory` VALUES ('341300', '', '0', '宿州市', null, '', '0', '0', '340000');
INSERT INTO `t_s_territory` VALUES ('341301', '', '0', '市辖区', null, '', '0', '0', '341300');
INSERT INTO `t_s_territory` VALUES ('341302', '', '0', '埇桥区', null, '', '0', '0', '341300');
INSERT INTO `t_s_territory` VALUES ('341321', '', '0', '砀山县', null, '', '0', '0', '341300');
INSERT INTO `t_s_territory` VALUES ('341322', '', '0', '萧县', null, '', '0', '0', '341300');
INSERT INTO `t_s_territory` VALUES ('341323', '', '0', '灵璧县', null, '', '0', '0', '341300');
INSERT INTO `t_s_territory` VALUES ('341324', '', '0', '泗县', null, '', '0', '0', '341300');
INSERT INTO `t_s_territory` VALUES ('341500', '', '0', '六安市', null, '', '0', '0', '340000');
INSERT INTO `t_s_territory` VALUES ('341501', '', '0', '市辖区', null, '', '0', '0', '341500');
INSERT INTO `t_s_territory` VALUES ('341502', '', '0', '金安区', null, '', '0', '0', '341500');
INSERT INTO `t_s_territory` VALUES ('341503', '', '0', '裕安区', null, '', '0', '0', '341500');
INSERT INTO `t_s_territory` VALUES ('341521', '', '0', '寿县', null, '', '0', '0', '341500');
INSERT INTO `t_s_territory` VALUES ('341522', '', '0', '霍邱县', null, '', '0', '0', '341500');
INSERT INTO `t_s_territory` VALUES ('341523', '', '0', '舒城县', null, '', '0', '0', '341500');
INSERT INTO `t_s_territory` VALUES ('341524', '', '0', '金寨县', null, '', '0', '0', '341500');
INSERT INTO `t_s_territory` VALUES ('341525', '', '0', '霍山县', null, '', '0', '0', '341500');
INSERT INTO `t_s_territory` VALUES ('341600', '', '0', '亳州市', null, '', '0', '0', '340000');
INSERT INTO `t_s_territory` VALUES ('341601', '', '0', '市辖区', null, '', '0', '0', '341600');
INSERT INTO `t_s_territory` VALUES ('341602', '', '0', '谯城区', null, '', '0', '0', '341600');
INSERT INTO `t_s_territory` VALUES ('341621', '', '0', '涡阳县', null, '', '0', '0', '341600');
INSERT INTO `t_s_territory` VALUES ('341622', '', '0', '蒙城县', null, '', '0', '0', '341600');
INSERT INTO `t_s_territory` VALUES ('341623', '', '0', '利辛县', null, '', '0', '0', '341600');
INSERT INTO `t_s_territory` VALUES ('341700', '', '0', '池州市', null, '', '0', '0', '340000');
INSERT INTO `t_s_territory` VALUES ('341701', '', '0', '市辖区', null, '', '0', '0', '341700');
INSERT INTO `t_s_territory` VALUES ('341702', '', '0', '贵池区', null, '', '0', '0', '341700');
INSERT INTO `t_s_territory` VALUES ('341721', '', '0', '东至县', null, '', '0', '0', '341700');
INSERT INTO `t_s_territory` VALUES ('341722', '', '0', '石台县', null, '', '0', '0', '341700');
INSERT INTO `t_s_territory` VALUES ('341723', '', '0', '青阳县', null, '', '0', '0', '341700');
INSERT INTO `t_s_territory` VALUES ('341800', '', '0', '宣城市', null, '', '0', '0', '340000');
INSERT INTO `t_s_territory` VALUES ('341801', '', '0', '市辖区', null, '', '0', '0', '341800');
INSERT INTO `t_s_territory` VALUES ('341802', '', '0', '宣州区', null, '', '0', '0', '341800');
INSERT INTO `t_s_territory` VALUES ('341821', '', '0', '郎溪县', null, '', '0', '0', '341800');
INSERT INTO `t_s_territory` VALUES ('341822', '', '0', '广德县', null, '', '0', '0', '341800');
INSERT INTO `t_s_territory` VALUES ('341823', '', '0', '泾县', null, '', '0', '0', '341800');
INSERT INTO `t_s_territory` VALUES ('341824', '', '0', '绩溪县', null, '', '0', '0', '341800');
INSERT INTO `t_s_territory` VALUES ('341825', '', '0', '旌德县', null, '', '0', '0', '341800');
INSERT INTO `t_s_territory` VALUES ('341881', '', '0', '宁国市', null, '', '0', '0', '341800');
INSERT INTO `t_s_territory` VALUES ('350000', '', '0', '福建省', null, '12', '0', '0', '1');
INSERT INTO `t_s_territory` VALUES ('350100', '', '0', '福州市', null, '', '0', '0', '350000');
INSERT INTO `t_s_territory` VALUES ('350101', '', '0', '市辖区', null, '', '0', '0', '350100');
INSERT INTO `t_s_territory` VALUES ('350102', '', '0', '鼓楼区', null, '', '0', '0', '350100');
INSERT INTO `t_s_territory` VALUES ('350103', '', '0', '台江区', null, '', '0', '0', '350100');
INSERT INTO `t_s_territory` VALUES ('350104', '', '0', '仓山区', null, '', '0', '0', '350100');
INSERT INTO `t_s_territory` VALUES ('350105', '', '0', '马尾区', null, '', '0', '0', '350100');
INSERT INTO `t_s_territory` VALUES ('350111', '', '0', '晋安区', null, '', '0', '0', '350100');
INSERT INTO `t_s_territory` VALUES ('350121', '', '0', '闽侯县', null, '', '0', '0', '350100');
INSERT INTO `t_s_territory` VALUES ('350122', '', '0', '连江县', null, '', '0', '0', '350100');
INSERT INTO `t_s_territory` VALUES ('350123', '', '0', '罗源县', null, '', '0', '0', '350100');
INSERT INTO `t_s_territory` VALUES ('350124', '', '0', '闽清县', null, '', '0', '0', '350100');
INSERT INTO `t_s_territory` VALUES ('350125', '', '0', '永泰县', null, '', '0', '0', '350100');
INSERT INTO `t_s_territory` VALUES ('350128', '', '0', '平潭县', null, '', '0', '0', '350100');
INSERT INTO `t_s_territory` VALUES ('350181', '', '0', '福清市', null, '', '0', '0', '350100');
INSERT INTO `t_s_territory` VALUES ('350182', '', '0', '长乐市', null, '', '0', '0', '350100');
INSERT INTO `t_s_territory` VALUES ('350200', '', '0', '厦门市', null, '', '0', '0', '350000');
INSERT INTO `t_s_territory` VALUES ('350201', '', '0', '市辖区', null, '', '0', '0', '350200');
INSERT INTO `t_s_territory` VALUES ('350203', '', '0', '思明区', null, '', '0', '0', '350200');
INSERT INTO `t_s_territory` VALUES ('350205', '', '0', '海沧区', null, '', '0', '0', '350200');
INSERT INTO `t_s_territory` VALUES ('350206', '', '0', '湖里区', null, '', '0', '0', '350200');
INSERT INTO `t_s_territory` VALUES ('350211', '', '0', '集美区', null, '', '0', '0', '350200');
INSERT INTO `t_s_territory` VALUES ('350212', '', '0', '同安区', null, '', '0', '0', '350200');
INSERT INTO `t_s_territory` VALUES ('350213', '', '0', '翔安区', null, '', '0', '0', '350200');
INSERT INTO `t_s_territory` VALUES ('350300', '', '0', '莆田市', null, '', '0', '0', '350000');
INSERT INTO `t_s_territory` VALUES ('350301', '', '0', '市辖区', null, '', '0', '0', '350300');
INSERT INTO `t_s_territory` VALUES ('350302', '', '0', '城厢区', null, '', '0', '0', '350300');
INSERT INTO `t_s_territory` VALUES ('350303', '', '0', '涵江区', null, '', '0', '0', '350300');
INSERT INTO `t_s_territory` VALUES ('350304', '', '0', '荔城区', null, '', '0', '0', '350300');
INSERT INTO `t_s_territory` VALUES ('350305', '', '0', '秀屿区', null, '', '0', '0', '350300');
INSERT INTO `t_s_territory` VALUES ('350322', '', '0', '仙游县', null, '', '0', '0', '350300');
INSERT INTO `t_s_territory` VALUES ('350400', '', '0', '三明市', null, '', '0', '0', '350000');
INSERT INTO `t_s_territory` VALUES ('350401', '', '0', '市辖区', null, '', '0', '0', '350400');
INSERT INTO `t_s_territory` VALUES ('350402', '', '0', '梅列区', null, '', '0', '0', '350400');
INSERT INTO `t_s_territory` VALUES ('350403', '', '0', '三元区', null, '', '0', '0', '350400');
INSERT INTO `t_s_territory` VALUES ('350421', '', '0', '明溪县', null, '', '0', '0', '350400');
INSERT INTO `t_s_territory` VALUES ('350423', '', '0', '清流县', null, '', '0', '0', '350400');
INSERT INTO `t_s_territory` VALUES ('350424', '', '0', '宁化县', null, '', '0', '0', '350400');
INSERT INTO `t_s_territory` VALUES ('350425', '', '0', '大田县', null, '', '0', '0', '350400');
INSERT INTO `t_s_territory` VALUES ('350426', '', '0', '尤溪县', null, '', '0', '0', '350400');
INSERT INTO `t_s_territory` VALUES ('350427', '', '0', '沙县', null, '', '0', '0', '350400');
INSERT INTO `t_s_territory` VALUES ('350428', '', '0', '将乐县', null, '', '0', '0', '350400');
INSERT INTO `t_s_territory` VALUES ('350429', '', '0', '泰宁县', null, '', '0', '0', '350400');
INSERT INTO `t_s_territory` VALUES ('350430', '', '0', '建宁县', null, '', '0', '0', '350400');
INSERT INTO `t_s_territory` VALUES ('350481', '', '0', '永安市', null, '', '0', '0', '350400');
INSERT INTO `t_s_territory` VALUES ('350500', '', '0', '泉州市', null, '', '0', '0', '350000');
INSERT INTO `t_s_territory` VALUES ('350501', '', '0', '市辖区', null, '', '0', '0', '350500');
INSERT INTO `t_s_territory` VALUES ('350502', '', '0', '鲤城区', null, '', '0', '0', '350500');
INSERT INTO `t_s_territory` VALUES ('350503', '', '0', '丰泽区', null, '', '0', '0', '350500');
INSERT INTO `t_s_territory` VALUES ('350504', '', '0', '洛江区', null, '', '0', '0', '350500');
INSERT INTO `t_s_territory` VALUES ('350505', '', '0', '泉港区', null, '', '0', '0', '350500');
INSERT INTO `t_s_territory` VALUES ('350521', '', '0', '惠安县', null, '', '0', '0', '350500');
INSERT INTO `t_s_territory` VALUES ('350524', '', '0', '安溪县', null, '', '0', '0', '350500');
INSERT INTO `t_s_territory` VALUES ('350525', '', '0', '永春县', null, '', '0', '0', '350500');
INSERT INTO `t_s_territory` VALUES ('350526', '', '0', '德化县', null, '', '0', '0', '350500');
INSERT INTO `t_s_territory` VALUES ('350527', '', '0', '金门县', null, '', '0', '0', '350500');
INSERT INTO `t_s_territory` VALUES ('350581', '', '0', '石狮市', null, '', '0', '0', '350500');
INSERT INTO `t_s_territory` VALUES ('350582', '', '0', '晋江市', null, '', '0', '0', '350500');
INSERT INTO `t_s_territory` VALUES ('350583', '', '0', '南安市', null, '', '0', '0', '350500');
INSERT INTO `t_s_territory` VALUES ('350600', '', '0', '漳州市', null, '', '0', '0', '350000');
INSERT INTO `t_s_territory` VALUES ('350601', '', '0', '市辖区', null, '', '0', '0', '350600');
INSERT INTO `t_s_territory` VALUES ('350602', '', '0', '芗城区', null, '', '0', '0', '350600');
INSERT INTO `t_s_territory` VALUES ('350603', '', '0', '龙文区', null, '', '0', '0', '350600');
INSERT INTO `t_s_territory` VALUES ('350622', '', '0', '云霄县', null, '', '0', '0', '350600');
INSERT INTO `t_s_territory` VALUES ('350623', '', '0', '漳浦县', null, '', '0', '0', '350600');
INSERT INTO `t_s_territory` VALUES ('350624', '', '0', '诏安县', null, '', '0', '0', '350600');
INSERT INTO `t_s_territory` VALUES ('350625', '', '0', '长泰县', null, '', '0', '0', '350600');
INSERT INTO `t_s_territory` VALUES ('350626', '', '0', '东山县', null, '', '0', '0', '350600');
INSERT INTO `t_s_territory` VALUES ('350627', '', '0', '南靖县', null, '', '0', '0', '350600');
INSERT INTO `t_s_territory` VALUES ('350628', '', '0', '平和县', null, '', '0', '0', '350600');
INSERT INTO `t_s_territory` VALUES ('350629', '', '0', '华安县', null, '', '0', '0', '350600');
INSERT INTO `t_s_territory` VALUES ('350681', '', '0', '龙海市', null, '', '0', '0', '350600');
INSERT INTO `t_s_territory` VALUES ('350700', '', '0', '南平市', null, '', '0', '0', '350000');
INSERT INTO `t_s_territory` VALUES ('350701', '', '0', '市辖区', null, '', '0', '0', '350700');
INSERT INTO `t_s_territory` VALUES ('350702', '', '0', '延平区', null, '', '0', '0', '350700');
INSERT INTO `t_s_territory` VALUES ('350721', '', '0', '顺昌县', null, '', '0', '0', '350700');
INSERT INTO `t_s_territory` VALUES ('350722', '', '0', '浦城县', null, '', '0', '0', '350700');
INSERT INTO `t_s_territory` VALUES ('350723', '', '0', '光泽县', null, '', '0', '0', '350700');
INSERT INTO `t_s_territory` VALUES ('350724', '', '0', '松溪县', null, '', '0', '0', '350700');
INSERT INTO `t_s_territory` VALUES ('350725', '', '0', '政和县', null, '', '0', '0', '350700');
INSERT INTO `t_s_territory` VALUES ('350781', '', '0', '邵武市', null, '', '0', '0', '350700');
INSERT INTO `t_s_territory` VALUES ('350782', '', '0', '武夷山市', null, '', '0', '0', '350700');
INSERT INTO `t_s_territory` VALUES ('350783', '', '0', '建瓯市', null, '', '0', '0', '350700');
INSERT INTO `t_s_territory` VALUES ('350784', '', '0', '建阳市', null, '', '0', '0', '350700');
INSERT INTO `t_s_territory` VALUES ('350800', '', '0', '龙岩市', null, '', '0', '0', '350000');
INSERT INTO `t_s_territory` VALUES ('350801', '', '0', '市辖区', null, '', '0', '0', '350800');
INSERT INTO `t_s_territory` VALUES ('350802', '', '0', '新罗区', null, '', '0', '0', '350800');
INSERT INTO `t_s_territory` VALUES ('350821', '', '0', '长汀县', null, '', '0', '0', '350800');
INSERT INTO `t_s_territory` VALUES ('350822', '', '0', '永定县', null, '', '0', '0', '350800');
INSERT INTO `t_s_territory` VALUES ('350823', '', '0', '上杭县', null, '', '0', '0', '350800');
INSERT INTO `t_s_territory` VALUES ('350824', '', '0', '武平县', null, '', '0', '0', '350800');
INSERT INTO `t_s_territory` VALUES ('350825', '', '0', '连城县', null, '', '0', '0', '350800');
INSERT INTO `t_s_territory` VALUES ('350881', '', '0', '漳平市', null, '', '0', '0', '350800');
INSERT INTO `t_s_territory` VALUES ('350900', '', '0', '宁德市', null, '', '0', '0', '350000');
INSERT INTO `t_s_territory` VALUES ('350901', '', '0', '市辖区', null, '', '0', '0', '350900');
INSERT INTO `t_s_territory` VALUES ('350902', '', '0', '蕉城区', null, '', '0', '0', '350900');
INSERT INTO `t_s_territory` VALUES ('350921', '', '0', '霞浦县', null, '', '0', '0', '350900');
INSERT INTO `t_s_territory` VALUES ('350922', '', '0', '古田县', null, '', '0', '0', '350900');
INSERT INTO `t_s_territory` VALUES ('350923', '', '0', '屏南县', null, '', '0', '0', '350900');
INSERT INTO `t_s_territory` VALUES ('350924', '', '0', '寿宁县', null, '', '0', '0', '350900');
INSERT INTO `t_s_territory` VALUES ('350925', '', '0', '周宁县', null, '', '0', '0', '350900');
INSERT INTO `t_s_territory` VALUES ('350926', '', '0', '柘荣县', null, '', '0', '0', '350900');
INSERT INTO `t_s_territory` VALUES ('350981', '', '0', '福安市', null, '', '0', '0', '350900');
INSERT INTO `t_s_territory` VALUES ('350982', '', '0', '福鼎市', null, '', '0', '0', '350900');
INSERT INTO `t_s_territory` VALUES ('360000', '', '0', '江西省', null, '', '0', '0', '1');
INSERT INTO `t_s_territory` VALUES ('360100', '', '0', '南昌市', null, '', '0', '0', '360000');
INSERT INTO `t_s_territory` VALUES ('360101', '', '0', '市辖区', null, '', '0', '0', '360100');
INSERT INTO `t_s_territory` VALUES ('360102', '', '0', '东湖区', null, '', '0', '0', '360100');
INSERT INTO `t_s_territory` VALUES ('360103', '', '0', '西湖区', null, '', '0', '0', '360100');
INSERT INTO `t_s_territory` VALUES ('360104', '', '0', '青云谱区', null, '', '0', '0', '360100');
INSERT INTO `t_s_territory` VALUES ('360105', '', '0', '湾里区', null, '', '0', '0', '360100');
INSERT INTO `t_s_territory` VALUES ('360111', '', '0', '青山湖区', null, '', '0', '0', '360100');
INSERT INTO `t_s_territory` VALUES ('360121', '', '0', '南昌县', null, '', '0', '0', '360100');
INSERT INTO `t_s_territory` VALUES ('360122', '', '0', '新建县', null, '', '0', '0', '360100');
INSERT INTO `t_s_territory` VALUES ('360123', '', '0', '安义县', null, '', '0', '0', '360100');
INSERT INTO `t_s_territory` VALUES ('360124', '', '0', '进贤县', null, '', '0', '0', '360100');
INSERT INTO `t_s_territory` VALUES ('360200', '', '0', '景德镇市', null, '', '0', '0', '360000');
INSERT INTO `t_s_territory` VALUES ('360201', '', '0', '市辖区', null, '', '0', '0', '360200');
INSERT INTO `t_s_territory` VALUES ('360202', '', '0', '昌江区', null, '', '0', '0', '360200');
INSERT INTO `t_s_territory` VALUES ('360203', '', '0', '珠山区', null, '', '0', '0', '360200');
INSERT INTO `t_s_territory` VALUES ('360222', '', '0', '浮梁县', null, '', '0', '0', '360200');
INSERT INTO `t_s_territory` VALUES ('360281', '', '0', '乐平市', null, '', '0', '0', '360200');
INSERT INTO `t_s_territory` VALUES ('360300', '', '0', '萍乡市', null, '', '0', '0', '360000');
INSERT INTO `t_s_territory` VALUES ('360301', '', '0', '市辖区', null, '', '0', '0', '360300');
INSERT INTO `t_s_territory` VALUES ('360302', '', '0', '安源区', null, '', '0', '0', '360300');
INSERT INTO `t_s_territory` VALUES ('360313', '', '0', '湘东区', null, '', '0', '0', '360300');
INSERT INTO `t_s_territory` VALUES ('360321', '', '0', '莲花县', null, '', '0', '0', '360300');
INSERT INTO `t_s_territory` VALUES ('360322', '', '0', '上栗县', null, '', '0', '0', '360300');
INSERT INTO `t_s_territory` VALUES ('360323', '', '0', '芦溪县', null, '', '0', '0', '360300');
INSERT INTO `t_s_territory` VALUES ('360400', '', '0', '九江市', null, '', '0', '0', '360000');
INSERT INTO `t_s_territory` VALUES ('360401', '', '0', '市辖区', null, '', '0', '0', '360400');
INSERT INTO `t_s_territory` VALUES ('360402', '', '0', '庐山区', null, '', '0', '0', '360400');
INSERT INTO `t_s_territory` VALUES ('360403', '', '0', '浔阳区', null, '', '0', '0', '360400');
INSERT INTO `t_s_territory` VALUES ('360421', '', '0', '九江县', null, '', '0', '0', '360400');
INSERT INTO `t_s_territory` VALUES ('360423', '', '0', '武宁县', null, '', '0', '0', '360400');
INSERT INTO `t_s_territory` VALUES ('360424', '', '0', '修水县', null, '', '0', '0', '360400');
INSERT INTO `t_s_territory` VALUES ('360425', '', '0', '永修县', null, '', '0', '0', '360400');
INSERT INTO `t_s_territory` VALUES ('360426', '', '0', '德安县', null, '', '0', '0', '360400');
INSERT INTO `t_s_territory` VALUES ('360427', '', '0', '星子县', null, '', '0', '0', '360400');
INSERT INTO `t_s_territory` VALUES ('360428', '', '0', '都昌县', null, '', '0', '0', '360400');
INSERT INTO `t_s_territory` VALUES ('360429', '', '0', '湖口县', null, '', '0', '0', '360400');
INSERT INTO `t_s_territory` VALUES ('360430', '', '0', '彭泽县', null, '', '0', '0', '360400');
INSERT INTO `t_s_territory` VALUES ('360481', '', '0', '瑞昌市', null, '', '0', '0', '360400');
INSERT INTO `t_s_territory` VALUES ('360482', '', '0', '共青城市', null, '', '0', '0', '360400');
INSERT INTO `t_s_territory` VALUES ('360500', '', '0', '新余市', null, '', '0', '0', '360000');
INSERT INTO `t_s_territory` VALUES ('360501', '', '0', '市辖区', null, '', '0', '0', '360500');
INSERT INTO `t_s_territory` VALUES ('360502', '', '0', '渝水区', null, '', '0', '0', '360500');
INSERT INTO `t_s_territory` VALUES ('360521', '', '0', '分宜县', null, '', '0', '0', '360500');
INSERT INTO `t_s_territory` VALUES ('360600', '', '0', '鹰潭市', null, '', '0', '0', '360000');
INSERT INTO `t_s_territory` VALUES ('360601', '', '0', '市辖区', null, '', '0', '0', '360600');
INSERT INTO `t_s_territory` VALUES ('360602', '', '0', '月湖区', null, '', '0', '0', '360600');
INSERT INTO `t_s_territory` VALUES ('360622', '', '0', '余江县', null, '', '0', '0', '360600');
INSERT INTO `t_s_territory` VALUES ('360681', '', '0', '贵溪市', null, '', '0', '0', '360600');
INSERT INTO `t_s_territory` VALUES ('360700', '', '0', '赣州市', null, '', '0', '0', '360000');
INSERT INTO `t_s_territory` VALUES ('360701', '', '0', '市辖区', null, '', '0', '0', '360700');
INSERT INTO `t_s_territory` VALUES ('360702', '', '0', '章贡区', null, '', '0', '0', '360700');
INSERT INTO `t_s_territory` VALUES ('360703', '', '0', '南康区', null, '', '0', '0', '360700');
INSERT INTO `t_s_territory` VALUES ('360721', '', '0', '赣县', null, '', '0', '0', '360700');
INSERT INTO `t_s_territory` VALUES ('360722', '', '0', '信丰县', null, '', '0', '0', '360700');
INSERT INTO `t_s_territory` VALUES ('360723', '', '0', '大余县', null, '', '0', '0', '360700');
INSERT INTO `t_s_territory` VALUES ('360724', '', '0', '上犹县', null, '', '0', '0', '360700');
INSERT INTO `t_s_territory` VALUES ('360725', '', '0', '崇义县', null, '', '0', '0', '360700');
INSERT INTO `t_s_territory` VALUES ('360726', '', '0', '安远县', null, '', '0', '0', '360700');
INSERT INTO `t_s_territory` VALUES ('360727', '', '0', '龙南县', null, '', '0', '0', '360700');
INSERT INTO `t_s_territory` VALUES ('360728', '', '0', '定南县', null, '', '0', '0', '360700');
INSERT INTO `t_s_territory` VALUES ('360729', '', '0', '全南县', null, '', '0', '0', '360700');
INSERT INTO `t_s_territory` VALUES ('360730', '', '0', '宁都县', null, '', '0', '0', '360700');
INSERT INTO `t_s_territory` VALUES ('360731', '', '0', '于都县', null, '', '0', '0', '360700');
INSERT INTO `t_s_territory` VALUES ('360732', '', '0', '兴国县', null, '', '0', '0', '360700');
INSERT INTO `t_s_territory` VALUES ('360733', '', '0', '会昌县', null, '', '0', '0', '360700');
INSERT INTO `t_s_territory` VALUES ('360734', '', '0', '寻乌县', null, '', '0', '0', '360700');
INSERT INTO `t_s_territory` VALUES ('360735', '', '0', '石城县', null, '', '0', '0', '360700');
INSERT INTO `t_s_territory` VALUES ('360781', '', '0', '瑞金市', null, '', '0', '0', '360700');
INSERT INTO `t_s_territory` VALUES ('360800', '', '0', '吉安市', null, '', '0', '0', '360000');
INSERT INTO `t_s_territory` VALUES ('360801', '', '0', '市辖区', null, '', '0', '0', '360800');
INSERT INTO `t_s_territory` VALUES ('360802', '', '0', '吉州区', null, '', '0', '0', '360800');
INSERT INTO `t_s_territory` VALUES ('360803', '', '0', '青原区', null, '', '0', '0', '360800');
INSERT INTO `t_s_territory` VALUES ('360821', '', '0', '吉安县', null, '', '0', '0', '360800');
INSERT INTO `t_s_territory` VALUES ('360822', '', '0', '吉水县', null, '', '0', '0', '360800');
INSERT INTO `t_s_territory` VALUES ('360823', '', '0', '峡江县', null, '', '0', '0', '360800');
INSERT INTO `t_s_territory` VALUES ('360824', '', '0', '新干县', null, '', '0', '0', '360800');
INSERT INTO `t_s_territory` VALUES ('360825', '', '0', '永丰县', null, '', '0', '0', '360800');
INSERT INTO `t_s_territory` VALUES ('360826', '', '0', '泰和县', null, '', '0', '0', '360800');
INSERT INTO `t_s_territory` VALUES ('360827', '', '0', '遂川县', null, '', '0', '0', '360800');
INSERT INTO `t_s_territory` VALUES ('360828', '', '0', '万安县', null, '', '0', '0', '360800');
INSERT INTO `t_s_territory` VALUES ('360829', '', '0', '安福县', null, '', '0', '0', '360800');
INSERT INTO `t_s_territory` VALUES ('360830', '', '0', '永新县', null, '', '0', '0', '360800');
INSERT INTO `t_s_territory` VALUES ('360881', '', '0', '井冈山市', null, '', '0', '0', '360800');
INSERT INTO `t_s_territory` VALUES ('360900', '', '0', '宜春市', null, '', '0', '0', '360000');
INSERT INTO `t_s_territory` VALUES ('360901', '', '0', '市辖区', null, '', '0', '0', '360900');
INSERT INTO `t_s_territory` VALUES ('360902', '', '0', '袁州区', null, '', '0', '0', '360900');
INSERT INTO `t_s_territory` VALUES ('360921', '', '0', '奉新县', null, '', '0', '0', '360900');
INSERT INTO `t_s_territory` VALUES ('360922', '', '0', '万载县', null, '', '0', '0', '360900');
INSERT INTO `t_s_territory` VALUES ('360923', '', '0', '上高县', null, '', '0', '0', '360900');
INSERT INTO `t_s_territory` VALUES ('360924', '', '0', '宜丰县', null, '', '0', '0', '360900');
INSERT INTO `t_s_territory` VALUES ('360925', '', '0', '靖安县', null, '', '0', '0', '360900');
INSERT INTO `t_s_territory` VALUES ('360926', '', '0', '铜鼓县', null, '', '0', '0', '360900');
INSERT INTO `t_s_territory` VALUES ('360981', '', '0', '丰城市', null, '', '0', '0', '360900');
INSERT INTO `t_s_territory` VALUES ('360982', '', '0', '樟树市', null, '', '0', '0', '360900');
INSERT INTO `t_s_territory` VALUES ('360983', '', '0', '高安市', null, '', '0', '0', '360900');
INSERT INTO `t_s_territory` VALUES ('361000', '', '0', '抚州市', null, '', '0', '0', '360000');
INSERT INTO `t_s_territory` VALUES ('361001', '', '0', '市辖区', null, '', '0', '0', '361000');
INSERT INTO `t_s_territory` VALUES ('361002', '', '0', '临川区', null, '', '0', '0', '361000');
INSERT INTO `t_s_territory` VALUES ('361021', '', '0', '南城县', null, '', '0', '0', '361000');
INSERT INTO `t_s_territory` VALUES ('361022', '', '0', '黎川县', null, '', '0', '0', '361000');
INSERT INTO `t_s_territory` VALUES ('361023', '', '0', '南丰县', null, '', '0', '0', '361000');
INSERT INTO `t_s_territory` VALUES ('361024', '', '0', '崇仁县', null, '', '0', '0', '361000');
INSERT INTO `t_s_territory` VALUES ('361025', '', '0', '乐安县', null, '', '0', '0', '361000');
INSERT INTO `t_s_territory` VALUES ('361026', '', '0', '宜黄县', null, '', '0', '0', '361000');
INSERT INTO `t_s_territory` VALUES ('361027', '', '0', '金溪县', null, '', '0', '0', '361000');
INSERT INTO `t_s_territory` VALUES ('361028', '', '0', '资溪县', null, '', '0', '0', '361000');
INSERT INTO `t_s_territory` VALUES ('361029', '', '0', '东乡县', null, '', '0', '0', '361000');
INSERT INTO `t_s_territory` VALUES ('361030', '', '0', '广昌县', null, '', '0', '0', '361000');
INSERT INTO `t_s_territory` VALUES ('361100', '', '0', '上饶市', null, '', '0', '0', '360000');
INSERT INTO `t_s_territory` VALUES ('361101', '', '0', '市辖区', null, '', '0', '0', '361100');
INSERT INTO `t_s_territory` VALUES ('361102', '', '0', '信州区', null, '', '0', '0', '361100');
INSERT INTO `t_s_territory` VALUES ('361121', '', '0', '上饶县', null, '', '0', '0', '361100');
INSERT INTO `t_s_territory` VALUES ('361122', '', '0', '广丰县', null, '', '0', '0', '361100');
INSERT INTO `t_s_territory` VALUES ('361123', '', '0', '玉山县', null, '', '0', '0', '361100');
INSERT INTO `t_s_territory` VALUES ('361124', '', '0', '铅山县', null, '', '0', '0', '361100');
INSERT INTO `t_s_territory` VALUES ('361125', '', '0', '横峰县', null, '', '0', '0', '361100');
INSERT INTO `t_s_territory` VALUES ('361126', '', '0', '弋阳县', null, '', '0', '0', '361100');
INSERT INTO `t_s_territory` VALUES ('361127', '', '0', '余干县', null, '', '0', '0', '361100');
INSERT INTO `t_s_territory` VALUES ('361128', '', '0', '鄱阳县', null, '', '0', '0', '361100');
INSERT INTO `t_s_territory` VALUES ('361129', '', '0', '万年县', null, '', '0', '0', '361100');
INSERT INTO `t_s_territory` VALUES ('361130', '', '0', '婺源县', null, '', '0', '0', '361100');
INSERT INTO `t_s_territory` VALUES ('361181', '', '0', '德兴市', null, '', '0', '0', '361100');
INSERT INTO `t_s_territory` VALUES ('370000', '', '0', '山东省', null, '', '0', '0', '1');
INSERT INTO `t_s_territory` VALUES ('370100', '', '0', '济南市', null, '', '0', '0', '370000');
INSERT INTO `t_s_territory` VALUES ('370101', '', '0', '市辖区', null, '', '0', '0', '370100');
INSERT INTO `t_s_territory` VALUES ('370102', '', '0', '历下区', null, '', '0', '0', '370100');
INSERT INTO `t_s_territory` VALUES ('370103', '', '0', '市中区', null, '', '0', '0', '370100');
INSERT INTO `t_s_territory` VALUES ('370104', '', '0', '槐荫区', null, '', '0', '0', '370100');
INSERT INTO `t_s_territory` VALUES ('370105', '', '0', '天桥区', null, '', '0', '0', '370100');
INSERT INTO `t_s_territory` VALUES ('370112', '', '0', '历城区', null, '', '0', '0', '370100');
INSERT INTO `t_s_territory` VALUES ('370113', '', '0', '长清区', null, '', '0', '0', '370100');
INSERT INTO `t_s_territory` VALUES ('370124', '', '0', '平阴县', null, '', '0', '0', '370100');
INSERT INTO `t_s_territory` VALUES ('370125', '', '0', '济阳县', null, '', '0', '0', '370100');
INSERT INTO `t_s_territory` VALUES ('370126', '', '0', '商河县', null, '', '0', '0', '370100');
INSERT INTO `t_s_territory` VALUES ('370181', '', '0', '章丘市', null, '', '0', '0', '370100');
INSERT INTO `t_s_territory` VALUES ('370200', '', '0', '青岛市', null, '', '0', '0', '370000');
INSERT INTO `t_s_territory` VALUES ('370201', '', '0', '市辖区', null, '', '0', '0', '370200');
INSERT INTO `t_s_territory` VALUES ('370202', '', '0', '市南区', null, '', '0', '0', '370200');
INSERT INTO `t_s_territory` VALUES ('370203', '', '0', '市北区', null, '', '0', '0', '370200');
INSERT INTO `t_s_territory` VALUES ('370211', '', '0', '黄岛区', null, '', '0', '0', '370200');
INSERT INTO `t_s_territory` VALUES ('370212', '', '0', '崂山区', null, '', '0', '0', '370200');
INSERT INTO `t_s_territory` VALUES ('370213', '', '0', '李沧区', null, '', '0', '0', '370200');
INSERT INTO `t_s_territory` VALUES ('370214', '', '0', '城阳区', null, '', '0', '0', '370200');
INSERT INTO `t_s_territory` VALUES ('370281', '', '0', '胶州市', null, '', '0', '0', '370200');
INSERT INTO `t_s_territory` VALUES ('370282', '', '0', '即墨市', null, '', '0', '0', '370200');
INSERT INTO `t_s_territory` VALUES ('370283', '', '0', '平度市', null, '', '0', '0', '370200');
INSERT INTO `t_s_territory` VALUES ('370285', '', '0', '莱西市', null, '', '0', '0', '370200');
INSERT INTO `t_s_territory` VALUES ('370300', '', '0', '淄博市', null, '', '0', '0', '370000');
INSERT INTO `t_s_territory` VALUES ('370301', '', '0', '市辖区', null, '', '0', '0', '370300');
INSERT INTO `t_s_territory` VALUES ('370302', '', '0', '淄川区', null, '', '0', '0', '370300');
INSERT INTO `t_s_territory` VALUES ('370303', '', '0', '张店区', null, '', '0', '0', '370300');
INSERT INTO `t_s_territory` VALUES ('370304', '', '0', '博山区', null, '', '0', '0', '370300');
INSERT INTO `t_s_territory` VALUES ('370305', '', '0', '临淄区', null, '', '0', '0', '370300');
INSERT INTO `t_s_territory` VALUES ('370306', '', '0', '周村区', null, '', '0', '0', '370300');
INSERT INTO `t_s_territory` VALUES ('370321', '', '0', '桓台县', null, '', '0', '0', '370300');
INSERT INTO `t_s_territory` VALUES ('370322', '', '0', '高青县', null, '', '0', '0', '370300');
INSERT INTO `t_s_territory` VALUES ('370323', '', '0', '沂源县', null, '', '0', '0', '370300');
INSERT INTO `t_s_territory` VALUES ('370400', '', '0', '枣庄市', null, '', '0', '0', '370000');
INSERT INTO `t_s_territory` VALUES ('370401', '', '0', '市辖区', null, '', '0', '0', '370400');
INSERT INTO `t_s_territory` VALUES ('370402', '', '0', '市中区', null, '', '0', '0', '370400');
INSERT INTO `t_s_territory` VALUES ('370403', '', '0', '薛城区', null, '', '0', '0', '370400');
INSERT INTO `t_s_territory` VALUES ('370404', '', '0', '峄城区', null, '', '0', '0', '370400');
INSERT INTO `t_s_territory` VALUES ('370405', '', '0', '台儿庄区', null, '', '0', '0', '370400');
INSERT INTO `t_s_territory` VALUES ('370406', '', '0', '山亭区', null, '', '0', '0', '370400');
INSERT INTO `t_s_territory` VALUES ('370481', '', '0', '滕州市', null, '', '0', '0', '370400');
INSERT INTO `t_s_territory` VALUES ('370500', '', '0', '东营市', null, '', '0', '0', '370000');
INSERT INTO `t_s_territory` VALUES ('370501', '', '0', '市辖区', null, '', '0', '0', '370500');
INSERT INTO `t_s_territory` VALUES ('370502', '', '0', '东营区', null, '', '0', '0', '370500');
INSERT INTO `t_s_territory` VALUES ('370503', '', '0', '河口区', null, '', '0', '0', '370500');
INSERT INTO `t_s_territory` VALUES ('370521', '', '0', '垦利县', null, '', '0', '0', '370500');
INSERT INTO `t_s_territory` VALUES ('370522', '', '0', '利津县', null, '', '0', '0', '370500');
INSERT INTO `t_s_territory` VALUES ('370523', '', '0', '广饶县', null, '', '0', '0', '370500');
INSERT INTO `t_s_territory` VALUES ('370600', '', '0', '烟台市', null, '', '0', '0', '370000');
INSERT INTO `t_s_territory` VALUES ('370601', '', '0', '市辖区', null, '', '0', '0', '370600');
INSERT INTO `t_s_territory` VALUES ('370602', '', '0', '芝罘区', null, '', '0', '0', '370600');
INSERT INTO `t_s_territory` VALUES ('370611', '', '0', '福山区', null, '', '0', '0', '370600');
INSERT INTO `t_s_territory` VALUES ('370612', '', '0', '牟平区', null, '', '0', '0', '370600');
INSERT INTO `t_s_territory` VALUES ('370613', '', '0', '莱山区', null, '', '0', '0', '370600');
INSERT INTO `t_s_territory` VALUES ('370634', '', '0', '长岛县', null, '', '0', '0', '370600');
INSERT INTO `t_s_territory` VALUES ('370681', '', '0', '龙口市', null, '', '0', '0', '370600');
INSERT INTO `t_s_territory` VALUES ('370682', '', '0', '莱阳市', null, '', '0', '0', '370600');
INSERT INTO `t_s_territory` VALUES ('370683', '', '0', '莱州市', null, '', '0', '0', '370600');
INSERT INTO `t_s_territory` VALUES ('370684', '', '0', '蓬莱市', null, '', '0', '0', '370600');
INSERT INTO `t_s_territory` VALUES ('370685', '', '0', '招远市', null, '', '0', '0', '370600');
INSERT INTO `t_s_territory` VALUES ('370686', '', '0', '栖霞市', null, '', '0', '0', '370600');
INSERT INTO `t_s_territory` VALUES ('370687', '', '0', '海阳市', null, '', '0', '0', '370600');
INSERT INTO `t_s_territory` VALUES ('370700', '', '0', '潍坊市', null, '', '0', '0', '370000');
INSERT INTO `t_s_territory` VALUES ('370701', '', '0', '市辖区', null, '', '0', '0', '370700');
INSERT INTO `t_s_territory` VALUES ('370702', '', '0', '潍城区', null, '', '0', '0', '370700');
INSERT INTO `t_s_territory` VALUES ('370703', '', '0', '寒亭区', null, '', '0', '0', '370700');
INSERT INTO `t_s_territory` VALUES ('370704', '', '0', '坊子区', null, '', '0', '0', '370700');
INSERT INTO `t_s_territory` VALUES ('370705', '', '0', '奎文区', null, '', '0', '0', '370700');
INSERT INTO `t_s_territory` VALUES ('370724', '', '0', '临朐县', null, '', '0', '0', '370700');
INSERT INTO `t_s_territory` VALUES ('370725', '', '0', '昌乐县', null, '', '0', '0', '370700');
INSERT INTO `t_s_territory` VALUES ('370781', '', '0', '青州市', null, '', '0', '0', '370700');
INSERT INTO `t_s_territory` VALUES ('370782', '', '0', '诸城市', null, '', '0', '0', '370700');
INSERT INTO `t_s_territory` VALUES ('370783', '', '0', '寿光市', null, '', '0', '0', '370700');
INSERT INTO `t_s_territory` VALUES ('370784', '', '0', '安丘市', null, '', '0', '0', '370700');
INSERT INTO `t_s_territory` VALUES ('370785', '', '0', '高密市', null, '', '0', '0', '370700');
INSERT INTO `t_s_territory` VALUES ('370786', '', '0', '昌邑市', null, '', '0', '0', '370700');
INSERT INTO `t_s_territory` VALUES ('370800', '', '0', '济宁市', null, '', '0', '0', '370000');
INSERT INTO `t_s_territory` VALUES ('370801', '', '0', '市辖区', null, '', '0', '0', '370800');
INSERT INTO `t_s_territory` VALUES ('370811', '', '0', '任城区', null, '', '0', '0', '370800');
INSERT INTO `t_s_territory` VALUES ('370812', '', '0', '兖州区', null, '', '0', '0', '370800');
INSERT INTO `t_s_territory` VALUES ('370826', '', '0', '微山县', null, '', '0', '0', '370800');
INSERT INTO `t_s_territory` VALUES ('370827', '', '0', '鱼台县', null, '', '0', '0', '370800');
INSERT INTO `t_s_territory` VALUES ('370828', '', '0', '金乡县', null, '', '0', '0', '370800');
INSERT INTO `t_s_territory` VALUES ('370829', '', '0', '嘉祥县', null, '', '0', '0', '370800');
INSERT INTO `t_s_territory` VALUES ('370830', '', '0', '汶上县', null, '', '0', '0', '370800');
INSERT INTO `t_s_territory` VALUES ('370831', '', '0', '泗水县', null, '', '0', '0', '370800');
INSERT INTO `t_s_territory` VALUES ('370832', '', '0', '梁山县', null, '', '0', '0', '370800');
INSERT INTO `t_s_territory` VALUES ('370881', '', '0', '曲阜市', null, '', '0', '0', '370800');
INSERT INTO `t_s_territory` VALUES ('370883', '', '0', '邹城市', null, '', '0', '0', '370800');
INSERT INTO `t_s_territory` VALUES ('370900', '', '0', '泰安市', null, '', '0', '0', '370000');
INSERT INTO `t_s_territory` VALUES ('370901', '', '0', '市辖区', null, '', '0', '0', '370900');
INSERT INTO `t_s_territory` VALUES ('370902', '', '0', '泰山区', null, '', '0', '0', '370900');
INSERT INTO `t_s_territory` VALUES ('370911', '', '0', '岱岳区', null, '', '0', '0', '370900');
INSERT INTO `t_s_territory` VALUES ('370921', '', '0', '宁阳县', null, '', '0', '0', '370900');
INSERT INTO `t_s_territory` VALUES ('370923', '', '0', '东平县', null, '', '0', '0', '370900');
INSERT INTO `t_s_territory` VALUES ('370982', '', '0', '新泰市', null, '', '0', '0', '370900');
INSERT INTO `t_s_territory` VALUES ('370983', '', '0', '肥城市', null, '', '0', '0', '370900');
INSERT INTO `t_s_territory` VALUES ('371000', '', '0', '威海市', null, '', '0', '0', '370000');
INSERT INTO `t_s_territory` VALUES ('371001', '', '0', '市辖区', null, '', '0', '0', '371000');
INSERT INTO `t_s_territory` VALUES ('371002', '', '0', '环翠区', null, '', '0', '0', '371000');
INSERT INTO `t_s_territory` VALUES ('371003', '', '0', '文登区', null, '', '0', '0', '371000');
INSERT INTO `t_s_territory` VALUES ('371082', '', '0', '荣成市', null, '', '0', '0', '371000');
INSERT INTO `t_s_territory` VALUES ('371083', '', '0', '乳山市', null, '', '0', '0', '371000');
INSERT INTO `t_s_territory` VALUES ('371100', '', '0', '日照市', null, '', '0', '0', '370000');
INSERT INTO `t_s_territory` VALUES ('371101', '', '0', '市辖区', null, '', '0', '0', '371100');
INSERT INTO `t_s_territory` VALUES ('371102', '', '0', '东港区', null, '', '0', '0', '371100');
INSERT INTO `t_s_territory` VALUES ('371103', '', '0', '岚山区', null, '', '0', '0', '371100');
INSERT INTO `t_s_territory` VALUES ('371121', '', '0', '五莲县', null, '', '0', '0', '371100');
INSERT INTO `t_s_territory` VALUES ('371122', '', '0', '莒县', null, '', '0', '0', '371100');
INSERT INTO `t_s_territory` VALUES ('371200', '', '0', '莱芜市', null, '', '0', '0', '370000');
INSERT INTO `t_s_territory` VALUES ('371201', '', '0', '市辖区', null, '', '0', '0', '371200');
INSERT INTO `t_s_territory` VALUES ('371202', '', '0', '莱城区', null, '', '0', '0', '371200');
INSERT INTO `t_s_territory` VALUES ('371203', '', '0', '钢城区', null, '', '0', '0', '371200');
INSERT INTO `t_s_territory` VALUES ('371300', '', '0', '临沂市', null, '', '0', '0', '370000');
INSERT INTO `t_s_territory` VALUES ('371301', '', '0', '市辖区', null, '', '0', '0', '371300');
INSERT INTO `t_s_territory` VALUES ('371302', '', '0', '兰山区', null, '', '0', '0', '371300');
INSERT INTO `t_s_territory` VALUES ('371311', '', '0', '罗庄区', null, '', '0', '0', '371300');
INSERT INTO `t_s_territory` VALUES ('371312', '', '0', '河东区', null, '', '0', '0', '371300');
INSERT INTO `t_s_territory` VALUES ('371321', '', '0', '沂南县', null, '', '0', '0', '371300');
INSERT INTO `t_s_territory` VALUES ('371322', '', '0', '郯城县', null, '', '0', '0', '371300');
INSERT INTO `t_s_territory` VALUES ('371323', '', '0', '沂水县', null, '', '0', '0', '371300');
INSERT INTO `t_s_territory` VALUES ('371324', '', '0', '兰陵县', null, '', '0', '0', '371300');
INSERT INTO `t_s_territory` VALUES ('371325', '', '0', '费县', null, '', '0', '0', '371300');
INSERT INTO `t_s_territory` VALUES ('371326', '', '0', '平邑县', null, '', '0', '0', '371300');
INSERT INTO `t_s_territory` VALUES ('371327', '', '0', '莒南县', null, '', '0', '0', '371300');
INSERT INTO `t_s_territory` VALUES ('371328', '', '0', '蒙阴县', null, '', '0', '0', '371300');
INSERT INTO `t_s_territory` VALUES ('371329', '', '0', '临沭县', null, '', '0', '0', '371300');
INSERT INTO `t_s_territory` VALUES ('371400', '', '0', '德州市', null, '', '0', '0', '370000');
INSERT INTO `t_s_territory` VALUES ('371401', '', '0', '市辖区', null, '', '0', '0', '371400');
INSERT INTO `t_s_territory` VALUES ('371402', '', '0', '德城区', null, '', '0', '0', '371400');
INSERT INTO `t_s_territory` VALUES ('371403', '', '0', '陵城区', null, '', '0', '0', '371400');
INSERT INTO `t_s_territory` VALUES ('371422', '', '0', '宁津县', null, '', '0', '0', '371400');
INSERT INTO `t_s_territory` VALUES ('371423', '', '0', '庆云县', null, '', '0', '0', '371400');
INSERT INTO `t_s_territory` VALUES ('371424', '', '0', '临邑县', null, '', '0', '0', '371400');
INSERT INTO `t_s_territory` VALUES ('371425', '', '0', '齐河县', null, '', '0', '0', '371400');
INSERT INTO `t_s_territory` VALUES ('371426', '', '0', '平原县', null, '', '0', '0', '371400');
INSERT INTO `t_s_territory` VALUES ('371427', '', '0', '夏津县', null, '', '0', '0', '371400');
INSERT INTO `t_s_territory` VALUES ('371428', '', '0', '武城县', null, '', '0', '0', '371400');
INSERT INTO `t_s_territory` VALUES ('371481', '', '0', '乐陵市', null, '', '0', '0', '371400');
INSERT INTO `t_s_territory` VALUES ('371482', '', '0', '禹城市', null, '', '0', '0', '371400');
INSERT INTO `t_s_territory` VALUES ('371500', '', '0', '聊城市', null, '', '0', '0', '370000');
INSERT INTO `t_s_territory` VALUES ('371501', '', '0', '市辖区', null, '', '0', '0', '371500');
INSERT INTO `t_s_territory` VALUES ('371502', '', '0', '东昌府区', null, '', '0', '0', '371500');
INSERT INTO `t_s_territory` VALUES ('371521', '', '0', '阳谷县', null, '', '0', '0', '371500');
INSERT INTO `t_s_territory` VALUES ('371522', '', '0', '莘县', null, '', '0', '0', '371500');
INSERT INTO `t_s_territory` VALUES ('371523', '', '0', '茌平县', null, '', '0', '0', '371500');
INSERT INTO `t_s_territory` VALUES ('371524', '', '0', '东阿县', null, '', '0', '0', '371500');
INSERT INTO `t_s_territory` VALUES ('371525', '', '0', '冠县', null, '', '0', '0', '371500');
INSERT INTO `t_s_territory` VALUES ('371526', '', '0', '高唐县', null, '', '0', '0', '371500');
INSERT INTO `t_s_territory` VALUES ('371581', '', '0', '临清市', null, '', '0', '0', '371500');
INSERT INTO `t_s_territory` VALUES ('371600', '', '0', '滨州市', null, '', '0', '0', '370000');
INSERT INTO `t_s_territory` VALUES ('371601', '', '0', '市辖区', null, '', '0', '0', '371600');
INSERT INTO `t_s_territory` VALUES ('371602', '', '0', '滨城区', null, '', '0', '0', '371600');
INSERT INTO `t_s_territory` VALUES ('371603', '', '0', '沾化区', null, '', '0', '0', '371600');
INSERT INTO `t_s_territory` VALUES ('371621', '', '0', '惠民县', null, '', '0', '0', '371600');
INSERT INTO `t_s_territory` VALUES ('371622', '', '0', '阳信县', null, '', '0', '0', '371600');
INSERT INTO `t_s_territory` VALUES ('371623', '', '0', '无棣县', null, '', '0', '0', '371600');
INSERT INTO `t_s_territory` VALUES ('371625', '', '0', '博兴县', null, '', '0', '0', '371600');
INSERT INTO `t_s_territory` VALUES ('371626', '', '0', '邹平县', null, '', '0', '0', '371600');
INSERT INTO `t_s_territory` VALUES ('371700', '', '0', '菏泽市', null, '', '0', '0', '370000');
INSERT INTO `t_s_territory` VALUES ('371701', '', '0', '市辖区', null, '', '0', '0', '371700');
INSERT INTO `t_s_territory` VALUES ('371702', '', '0', '牡丹区', null, '', '0', '0', '371700');
INSERT INTO `t_s_territory` VALUES ('371721', '', '0', '曹县', null, '', '0', '0', '371700');
INSERT INTO `t_s_territory` VALUES ('371722', '', '0', '单县', null, '', '0', '0', '371700');
INSERT INTO `t_s_territory` VALUES ('371723', '', '0', '成武县', null, '', '0', '0', '371700');
INSERT INTO `t_s_territory` VALUES ('371724', '', '0', '巨野县', null, '', '0', '0', '371700');
INSERT INTO `t_s_territory` VALUES ('371725', '', '0', '郓城县', null, '', '0', '0', '371700');
INSERT INTO `t_s_territory` VALUES ('371726', '', '0', '鄄城县', null, '', '0', '0', '371700');
INSERT INTO `t_s_territory` VALUES ('371727', '', '0', '定陶县', null, '', '0', '0', '371700');
INSERT INTO `t_s_territory` VALUES ('371728', '', '0', '东明县', null, '', '0', '0', '371700');
INSERT INTO `t_s_territory` VALUES ('410000', '', '0', '河南省', null, '', '0', '0', '1');
INSERT INTO `t_s_territory` VALUES ('410100', '', '0', '郑州市', null, '', '0', '0', '410000');
INSERT INTO `t_s_territory` VALUES ('410101', '', '0', '市辖区', null, '', '0', '0', '410100');
INSERT INTO `t_s_territory` VALUES ('410102', '', '0', '中原区', null, '', '0', '0', '410100');
INSERT INTO `t_s_territory` VALUES ('410103', '', '0', '二七区', null, '', '0', '0', '410100');
INSERT INTO `t_s_territory` VALUES ('410104', '', '0', '管城回族区', null, '', '0', '0', '410100');
INSERT INTO `t_s_territory` VALUES ('410105', '', '0', '金水区', null, '', '0', '0', '410100');
INSERT INTO `t_s_territory` VALUES ('410106', '', '0', '上街区', null, '', '0', '0', '410100');
INSERT INTO `t_s_territory` VALUES ('410108', '', '0', '惠济区', null, '', '0', '0', '410100');
INSERT INTO `t_s_territory` VALUES ('410122', '', '0', '中牟县', null, '', '0', '0', '410100');
INSERT INTO `t_s_territory` VALUES ('410181', '', '0', '巩义市', null, '', '0', '0', '410100');
INSERT INTO `t_s_territory` VALUES ('410182', '', '0', '荥阳市', null, '', '0', '0', '410100');
INSERT INTO `t_s_territory` VALUES ('410183', '', '0', '新密市', null, '', '0', '0', '410100');
INSERT INTO `t_s_territory` VALUES ('410184', '', '0', '新郑市', null, '', '0', '0', '410100');
INSERT INTO `t_s_territory` VALUES ('410185', '', '0', '登封市', null, '', '0', '0', '410100');
INSERT INTO `t_s_territory` VALUES ('410200', '', '0', '开封市', null, '', '0', '0', '410000');
INSERT INTO `t_s_territory` VALUES ('410201', '', '0', '市辖区', null, '', '0', '0', '410200');
INSERT INTO `t_s_territory` VALUES ('410202', '', '0', '龙亭区', null, '', '0', '0', '410200');
INSERT INTO `t_s_territory` VALUES ('410203', '', '0', '顺河回族区', null, '', '0', '0', '410200');
INSERT INTO `t_s_territory` VALUES ('410204', '', '0', '鼓楼区', null, '', '0', '0', '410200');
INSERT INTO `t_s_territory` VALUES ('410205', '', '0', '禹王台区', null, '', '0', '0', '410200');
INSERT INTO `t_s_territory` VALUES ('410211', '', '0', '金明区', null, '', '0', '0', '410200');
INSERT INTO `t_s_territory` VALUES ('410221', '', '0', '杞县', null, '', '0', '0', '410200');
INSERT INTO `t_s_territory` VALUES ('410222', '', '0', '通许县', null, '', '0', '0', '410200');
INSERT INTO `t_s_territory` VALUES ('410223', '', '0', '尉氏县', null, '', '0', '0', '410200');
INSERT INTO `t_s_territory` VALUES ('410224', '', '0', '开封县', null, '', '0', '0', '410200');
INSERT INTO `t_s_territory` VALUES ('410225', '', '0', '兰考县', null, '', '0', '0', '410200');
INSERT INTO `t_s_territory` VALUES ('410300', '', '0', '洛阳市', null, '', '0', '0', '410000');
INSERT INTO `t_s_territory` VALUES ('410301', '', '0', '市辖区', null, '', '0', '0', '410300');
INSERT INTO `t_s_territory` VALUES ('410302', '', '0', '老城区', null, '', '0', '0', '410300');
INSERT INTO `t_s_territory` VALUES ('410303', '', '0', '西工区', null, '', '0', '0', '410300');
INSERT INTO `t_s_territory` VALUES ('410304', '', '0', '瀍河回族区', null, '', '0', '0', '410300');
INSERT INTO `t_s_territory` VALUES ('410305', '', '0', '涧西区', null, '', '0', '0', '410300');
INSERT INTO `t_s_territory` VALUES ('410306', '', '0', '吉利区', null, '', '0', '0', '410300');
INSERT INTO `t_s_territory` VALUES ('410311', '', '0', '洛龙区', null, '', '0', '0', '410300');
INSERT INTO `t_s_territory` VALUES ('410322', '', '0', '孟津县', null, '', '0', '0', '410300');
INSERT INTO `t_s_territory` VALUES ('410323', '', '0', '新安县', null, '', '0', '0', '410300');
INSERT INTO `t_s_territory` VALUES ('410324', '', '0', '栾川县', null, '', '0', '0', '410300');
INSERT INTO `t_s_territory` VALUES ('410325', '', '0', '嵩县', null, '', '0', '0', '410300');
INSERT INTO `t_s_territory` VALUES ('410326', '', '0', '汝阳县', null, '', '0', '0', '410300');
INSERT INTO `t_s_territory` VALUES ('410327', '', '0', '宜阳县', null, '', '0', '0', '410300');
INSERT INTO `t_s_territory` VALUES ('410328', '', '0', '洛宁县', null, '', '0', '0', '410300');
INSERT INTO `t_s_territory` VALUES ('410329', '', '0', '伊川县', null, '', '0', '0', '410300');
INSERT INTO `t_s_territory` VALUES ('410381', '', '0', '偃师市', null, '', '0', '0', '410300');
INSERT INTO `t_s_territory` VALUES ('410400', '', '0', '平顶山市', null, '', '0', '0', '410000');
INSERT INTO `t_s_territory` VALUES ('410401', '', '0', '市辖区', null, '', '0', '0', '410400');
INSERT INTO `t_s_territory` VALUES ('410402', '', '0', '新华区', null, '', '0', '0', '410400');
INSERT INTO `t_s_territory` VALUES ('410403', '', '0', '卫东区', null, '', '0', '0', '410400');
INSERT INTO `t_s_territory` VALUES ('410404', '', '0', '石龙区', null, '', '0', '0', '410400');
INSERT INTO `t_s_territory` VALUES ('410411', '', '0', '湛河区', null, '', '0', '0', '410400');
INSERT INTO `t_s_territory` VALUES ('410421', '', '0', '宝丰县', null, '', '0', '0', '410400');
INSERT INTO `t_s_territory` VALUES ('410422', '', '0', '叶县', null, '', '0', '0', '410400');
INSERT INTO `t_s_territory` VALUES ('410423', '', '0', '鲁山县', null, '', '0', '0', '410400');
INSERT INTO `t_s_territory` VALUES ('410425', '', '0', '郏县', null, '', '0', '0', '410400');
INSERT INTO `t_s_territory` VALUES ('410481', '', '0', '舞钢市', null, '', '0', '0', '410400');
INSERT INTO `t_s_territory` VALUES ('410482', '', '0', '汝州市', null, '', '0', '0', '410400');
INSERT INTO `t_s_territory` VALUES ('410500', '', '0', '安阳市', null, '', '0', '0', '410000');
INSERT INTO `t_s_territory` VALUES ('410501', '', '0', '市辖区', null, '', '0', '0', '410500');
INSERT INTO `t_s_territory` VALUES ('410502', '', '0', '文峰区', null, '', '0', '0', '410500');
INSERT INTO `t_s_territory` VALUES ('410503', '', '0', '北关区', null, '', '0', '0', '410500');
INSERT INTO `t_s_territory` VALUES ('410505', '', '0', '殷都区', null, '', '0', '0', '410500');
INSERT INTO `t_s_territory` VALUES ('410506', '', '0', '龙安区', null, '', '0', '0', '410500');
INSERT INTO `t_s_territory` VALUES ('410522', '', '0', '安阳县', null, '', '0', '0', '410500');
INSERT INTO `t_s_territory` VALUES ('410523', '', '0', '汤阴县', null, '', '0', '0', '410500');
INSERT INTO `t_s_territory` VALUES ('410526', '', '0', '滑县', null, '', '0', '0', '410500');
INSERT INTO `t_s_territory` VALUES ('410527', '', '0', '内黄县', null, '', '0', '0', '410500');
INSERT INTO `t_s_territory` VALUES ('410581', '', '0', '林州市', null, '', '0', '0', '410500');
INSERT INTO `t_s_territory` VALUES ('410600', '', '0', '鹤壁市', null, '', '0', '0', '410000');
INSERT INTO `t_s_territory` VALUES ('410601', '', '0', '市辖区', null, '', '0', '0', '410600');
INSERT INTO `t_s_territory` VALUES ('410602', '', '0', '鹤山区', null, '', '0', '0', '410600');
INSERT INTO `t_s_territory` VALUES ('410603', '', '0', '山城区', null, '', '0', '0', '410600');
INSERT INTO `t_s_territory` VALUES ('410611', '', '0', '淇滨区', null, '', '0', '0', '410600');
INSERT INTO `t_s_territory` VALUES ('410621', '', '0', '浚县', null, '', '0', '0', '410600');
INSERT INTO `t_s_territory` VALUES ('410622', '', '0', '淇县', null, '', '0', '0', '410600');
INSERT INTO `t_s_territory` VALUES ('410700', '', '0', '新乡市', null, '', '0', '0', '410000');
INSERT INTO `t_s_territory` VALUES ('410701', '', '0', '市辖区', null, '', '0', '0', '410700');
INSERT INTO `t_s_territory` VALUES ('410702', '', '0', '红旗区', null, '', '0', '0', '410700');
INSERT INTO `t_s_territory` VALUES ('410703', '', '0', '卫滨区', null, '', '0', '0', '410700');
INSERT INTO `t_s_territory` VALUES ('410704', '', '0', '凤泉区', null, '', '0', '0', '410700');
INSERT INTO `t_s_territory` VALUES ('410711', '', '0', '牧野区', null, '', '0', '0', '410700');
INSERT INTO `t_s_territory` VALUES ('410721', '', '0', '新乡县', null, '', '0', '0', '410700');
INSERT INTO `t_s_territory` VALUES ('410724', '', '0', '获嘉县', null, '', '0', '0', '410700');
INSERT INTO `t_s_territory` VALUES ('410725', '', '0', '原阳县', null, '', '0', '0', '410700');
INSERT INTO `t_s_territory` VALUES ('410726', '', '0', '延津县', null, '', '0', '0', '410700');
INSERT INTO `t_s_territory` VALUES ('410727', '', '0', '封丘县', null, '', '0', '0', '410700');
INSERT INTO `t_s_territory` VALUES ('410728', '', '0', '长垣县', null, '', '0', '0', '410700');
INSERT INTO `t_s_territory` VALUES ('410781', '', '0', '卫辉市', null, '', '0', '0', '410700');
INSERT INTO `t_s_territory` VALUES ('410782', '', '0', '辉县市', null, '', '0', '0', '410700');
INSERT INTO `t_s_territory` VALUES ('410800', '', '0', '焦作市', null, '', '0', '0', '410000');
INSERT INTO `t_s_territory` VALUES ('410801', '', '0', '市辖区', null, '', '0', '0', '410800');
INSERT INTO `t_s_territory` VALUES ('410802', '', '0', '解放区', null, '', '0', '0', '410800');
INSERT INTO `t_s_territory` VALUES ('410803', '', '0', '中站区', null, '', '0', '0', '410800');
INSERT INTO `t_s_territory` VALUES ('410804', '', '0', '马村区', null, '', '0', '0', '410800');
INSERT INTO `t_s_territory` VALUES ('410811', '', '0', '山阳区', null, '', '0', '0', '410800');
INSERT INTO `t_s_territory` VALUES ('410821', '', '0', '修武县', null, '', '0', '0', '410800');
INSERT INTO `t_s_territory` VALUES ('410822', '', '0', '博爱县', null, '', '0', '0', '410800');
INSERT INTO `t_s_territory` VALUES ('410823', '', '0', '武陟县', null, '', '0', '0', '410800');
INSERT INTO `t_s_territory` VALUES ('410825', '', '0', '温县', null, '', '0', '0', '410800');
INSERT INTO `t_s_territory` VALUES ('410882', '', '0', '沁阳市', null, '', '0', '0', '410800');
INSERT INTO `t_s_territory` VALUES ('410883', '', '0', '孟州市', null, '', '0', '0', '410800');
INSERT INTO `t_s_territory` VALUES ('410900', '', '0', '濮阳市', null, '', '0', '0', '410000');
INSERT INTO `t_s_territory` VALUES ('410901', '', '0', '市辖区', null, '', '0', '0', '410900');
INSERT INTO `t_s_territory` VALUES ('410902', '', '0', '华龙区', null, '', '0', '0', '410900');
INSERT INTO `t_s_territory` VALUES ('410922', '', '0', '清丰县', null, '', '0', '0', '410900');
INSERT INTO `t_s_territory` VALUES ('410923', '', '0', '南乐县', null, '', '0', '0', '410900');
INSERT INTO `t_s_territory` VALUES ('410926', '', '0', '范县', null, '', '0', '0', '410900');
INSERT INTO `t_s_territory` VALUES ('410927', '', '0', '台前县', null, '', '0', '0', '410900');
INSERT INTO `t_s_territory` VALUES ('410928', '', '0', '濮阳县', null, '', '0', '0', '410900');
INSERT INTO `t_s_territory` VALUES ('411000', '', '0', '许昌市', null, '', '0', '0', '410000');
INSERT INTO `t_s_territory` VALUES ('411001', '', '0', '市辖区', null, '', '0', '0', '411000');
INSERT INTO `t_s_territory` VALUES ('411002', '', '0', '魏都区', null, '', '0', '0', '411000');
INSERT INTO `t_s_territory` VALUES ('411023', '', '0', '许昌县', null, '', '0', '0', '411000');
INSERT INTO `t_s_territory` VALUES ('411024', '', '0', '鄢陵县', null, '', '0', '0', '411000');
INSERT INTO `t_s_territory` VALUES ('411025', '', '0', '襄城县', null, '', '0', '0', '411000');
INSERT INTO `t_s_territory` VALUES ('411081', '', '0', '禹州市', null, '', '0', '0', '411000');
INSERT INTO `t_s_territory` VALUES ('411082', '', '0', '长葛市', null, '', '0', '0', '411000');
INSERT INTO `t_s_territory` VALUES ('411100', '', '0', '漯河市', null, '', '0', '0', '410000');
INSERT INTO `t_s_territory` VALUES ('411101', '', '0', '市辖区', null, '', '0', '0', '411100');
INSERT INTO `t_s_territory` VALUES ('411102', '', '0', '源汇区', null, '', '0', '0', '411100');
INSERT INTO `t_s_territory` VALUES ('411103', '', '0', '郾城区', null, '', '0', '0', '411100');
INSERT INTO `t_s_territory` VALUES ('411104', '', '0', '召陵区', null, '', '0', '0', '411100');
INSERT INTO `t_s_territory` VALUES ('411121', '', '0', '舞阳县', null, '', '0', '0', '411100');
INSERT INTO `t_s_territory` VALUES ('411122', '', '0', '临颍县', null, '', '0', '0', '411100');
INSERT INTO `t_s_territory` VALUES ('411200', '', '0', '三门峡市', null, '', '0', '0', '410000');
INSERT INTO `t_s_territory` VALUES ('411201', '', '0', '市辖区', null, '', '0', '0', '411200');
INSERT INTO `t_s_territory` VALUES ('411202', '', '0', '湖滨区', null, '', '0', '0', '411200');
INSERT INTO `t_s_territory` VALUES ('411221', '', '0', '渑池县', null, '', '0', '0', '411200');
INSERT INTO `t_s_territory` VALUES ('411222', '', '0', '陕县', null, '', '0', '0', '411200');
INSERT INTO `t_s_territory` VALUES ('411224', '', '0', '卢氏县', null, '', '0', '0', '411200');
INSERT INTO `t_s_territory` VALUES ('411281', '', '0', '义马市', null, '', '0', '0', '411200');
INSERT INTO `t_s_territory` VALUES ('411282', '', '0', '灵宝市', null, '', '0', '0', '411200');
INSERT INTO `t_s_territory` VALUES ('411300', '', '0', '南阳市', null, '', '0', '0', '410000');
INSERT INTO `t_s_territory` VALUES ('411301', '', '0', '市辖区', null, '', '0', '0', '411300');
INSERT INTO `t_s_territory` VALUES ('411302', '', '0', '宛城区', null, '', '0', '0', '411300');
INSERT INTO `t_s_territory` VALUES ('411303', '', '0', '卧龙区', null, '', '0', '0', '411300');
INSERT INTO `t_s_territory` VALUES ('411321', '', '0', '南召县', null, '', '0', '0', '411300');
INSERT INTO `t_s_territory` VALUES ('411322', '', '0', '方城县', null, '', '0', '0', '411300');
INSERT INTO `t_s_territory` VALUES ('411323', '', '0', '西峡县', null, '', '0', '0', '411300');
INSERT INTO `t_s_territory` VALUES ('411324', '', '0', '镇平县', null, '', '0', '0', '411300');
INSERT INTO `t_s_territory` VALUES ('411325', '', '0', '内乡县', null, '', '0', '0', '411300');
INSERT INTO `t_s_territory` VALUES ('411326', '', '0', '淅川县', null, '', '0', '0', '411300');
INSERT INTO `t_s_territory` VALUES ('411327', '', '0', '社旗县', null, '', '0', '0', '411300');
INSERT INTO `t_s_territory` VALUES ('411328', '', '0', '唐河县', null, '', '0', '0', '411300');
INSERT INTO `t_s_territory` VALUES ('411329', '', '0', '新野县', null, '', '0', '0', '411300');
INSERT INTO `t_s_territory` VALUES ('411330', '', '0', '桐柏县', null, '', '0', '0', '411300');
INSERT INTO `t_s_territory` VALUES ('411381', '', '0', '邓州市', null, '', '0', '0', '411300');
INSERT INTO `t_s_territory` VALUES ('411400', '', '0', '商丘市', null, '', '0', '0', '410000');
INSERT INTO `t_s_territory` VALUES ('411401', '', '0', '市辖区', null, '', '0', '0', '411400');
INSERT INTO `t_s_territory` VALUES ('411402', '', '0', '梁园区', null, '', '0', '0', '411400');
INSERT INTO `t_s_territory` VALUES ('411403', '', '0', '睢阳区', null, '', '0', '0', '411400');
INSERT INTO `t_s_territory` VALUES ('411421', '', '0', '民权县', null, '', '0', '0', '411400');
INSERT INTO `t_s_territory` VALUES ('411422', '', '0', '睢县', null, '', '0', '0', '411400');
INSERT INTO `t_s_territory` VALUES ('411423', '', '0', '宁陵县', null, '', '0', '0', '411400');
INSERT INTO `t_s_territory` VALUES ('411424', '', '0', '柘城县', null, '', '0', '0', '411400');
INSERT INTO `t_s_territory` VALUES ('411425', '', '0', '虞城县', null, '', '0', '0', '411400');
INSERT INTO `t_s_territory` VALUES ('411426', '', '0', '夏邑县', null, '', '0', '0', '411400');
INSERT INTO `t_s_territory` VALUES ('411481', '', '0', '永城市', null, '', '0', '0', '411400');
INSERT INTO `t_s_territory` VALUES ('411500', '', '0', '信阳市', null, '', '0', '0', '410000');
INSERT INTO `t_s_territory` VALUES ('411501', '', '0', '市辖区', null, '', '0', '0', '411500');
INSERT INTO `t_s_territory` VALUES ('411502', '', '0', '浉河区', null, '', '0', '0', '411500');
INSERT INTO `t_s_territory` VALUES ('411503', '', '0', '平桥区', null, '', '0', '0', '411500');
INSERT INTO `t_s_territory` VALUES ('411521', '', '0', '罗山县', null, '', '0', '0', '411500');
INSERT INTO `t_s_territory` VALUES ('411522', '', '0', '光山县', null, '', '0', '0', '411500');
INSERT INTO `t_s_territory` VALUES ('411523', '', '0', '新县', null, '', '0', '0', '411500');
INSERT INTO `t_s_territory` VALUES ('411524', '', '0', '商城县', null, '', '0', '0', '411500');
INSERT INTO `t_s_territory` VALUES ('411525', '', '0', '固始县', null, '', '0', '0', '411500');
INSERT INTO `t_s_territory` VALUES ('411526', '', '0', '潢川县', null, '', '0', '0', '411500');
INSERT INTO `t_s_territory` VALUES ('411527', '', '0', '淮滨县', null, '', '0', '0', '411500');
INSERT INTO `t_s_territory` VALUES ('411528', '', '0', '息县', null, '', '0', '0', '411500');
INSERT INTO `t_s_territory` VALUES ('411600', '', '0', '周口市', null, '', '0', '0', '410000');
INSERT INTO `t_s_territory` VALUES ('411601', '', '0', '市辖区', null, '', '0', '0', '411600');
INSERT INTO `t_s_territory` VALUES ('411602', '', '0', '川汇区', null, '', '0', '0', '411600');
INSERT INTO `t_s_territory` VALUES ('411621', '', '0', '扶沟县', null, '', '0', '0', '411600');
INSERT INTO `t_s_territory` VALUES ('411622', '', '0', '西华县', null, '', '0', '0', '411600');
INSERT INTO `t_s_territory` VALUES ('411623', '', '0', '商水县', null, '', '0', '0', '411600');
INSERT INTO `t_s_territory` VALUES ('411624', '', '0', '沈丘县', null, '', '0', '0', '411600');
INSERT INTO `t_s_territory` VALUES ('411625', '', '0', '郸城县', null, '', '0', '0', '411600');
INSERT INTO `t_s_territory` VALUES ('411626', '', '0', '淮阳县', null, '', '0', '0', '411600');
INSERT INTO `t_s_territory` VALUES ('411627', '', '0', '太康县', null, '', '0', '0', '411600');
INSERT INTO `t_s_territory` VALUES ('411628', '', '0', '鹿邑县', null, '', '0', '0', '411600');
INSERT INTO `t_s_territory` VALUES ('411681', '', '0', '项城市', null, '', '0', '0', '411600');
INSERT INTO `t_s_territory` VALUES ('411700', '', '0', '驻马店市', null, '', '0', '0', '410000');
INSERT INTO `t_s_territory` VALUES ('411701', '', '0', '市辖区', null, '', '0', '0', '411700');
INSERT INTO `t_s_territory` VALUES ('411702', '', '0', '驿城区', null, '', '0', '0', '411700');
INSERT INTO `t_s_territory` VALUES ('411721', '', '0', '西平县', null, '', '0', '0', '411700');
INSERT INTO `t_s_territory` VALUES ('411722', '', '0', '上蔡县', null, '', '0', '0', '411700');
INSERT INTO `t_s_territory` VALUES ('411723', '', '0', '平舆县', null, '', '0', '0', '411700');
INSERT INTO `t_s_territory` VALUES ('411724', '', '0', '正阳县', null, '', '0', '0', '411700');
INSERT INTO `t_s_territory` VALUES ('411725', '', '0', '确山县', null, '', '0', '0', '411700');
INSERT INTO `t_s_territory` VALUES ('411726', '', '0', '泌阳县', null, '', '0', '0', '411700');
INSERT INTO `t_s_territory` VALUES ('411727', '', '0', '汝南县', null, '', '0', '0', '411700');
INSERT INTO `t_s_territory` VALUES ('411728', '', '0', '遂平县', null, '', '0', '0', '411700');
INSERT INTO `t_s_territory` VALUES ('411729', '', '0', '新蔡县', null, '', '0', '0', '411700');
INSERT INTO `t_s_territory` VALUES ('419001', '', '0', '济源市', null, '', '0', '0', '410000');
INSERT INTO `t_s_territory` VALUES ('420000', '', '0', '湖北省', null, '', '0', '0', '1');
INSERT INTO `t_s_territory` VALUES ('420100', '', '0', '武汉市', null, '', '0', '0', '420000');
INSERT INTO `t_s_territory` VALUES ('420101', '', '0', '市辖区', null, '', '0', '0', '420100');
INSERT INTO `t_s_territory` VALUES ('420102', '', '0', '江岸区', null, '', '0', '0', '420100');
INSERT INTO `t_s_territory` VALUES ('420103', '', '0', '江汉区', null, '', '0', '0', '420100');
INSERT INTO `t_s_territory` VALUES ('420104', '', '0', '硚口区', null, '', '0', '0', '420100');
INSERT INTO `t_s_territory` VALUES ('420105', '', '0', '汉阳区', null, '', '0', '0', '420100');
INSERT INTO `t_s_territory` VALUES ('420106', '', '0', '武昌区', null, '', '0', '0', '420100');
INSERT INTO `t_s_territory` VALUES ('420107', '', '0', '青山区', null, '', '0', '0', '420100');
INSERT INTO `t_s_territory` VALUES ('420111', '', '0', '洪山区', null, '', '0', '0', '420100');
INSERT INTO `t_s_territory` VALUES ('420112', '', '0', '东西湖区', null, '', '0', '0', '420100');
INSERT INTO `t_s_territory` VALUES ('420113', '', '0', '汉南区', null, '', '0', '0', '420100');
INSERT INTO `t_s_territory` VALUES ('420114', '', '0', '蔡甸区', null, '', '0', '0', '420100');
INSERT INTO `t_s_territory` VALUES ('420115', '', '0', '江夏区', null, '', '0', '0', '420100');
INSERT INTO `t_s_territory` VALUES ('420116', '', '0', '黄陂区', null, '', '0', '0', '420100');
INSERT INTO `t_s_territory` VALUES ('420117', '', '0', '新洲区', null, '', '0', '0', '420100');
INSERT INTO `t_s_territory` VALUES ('420200', '', '0', '黄石市', null, '', '0', '0', '420000');
INSERT INTO `t_s_territory` VALUES ('420201', '', '0', '市辖区', null, '', '0', '0', '420200');
INSERT INTO `t_s_territory` VALUES ('420202', '', '0', '黄石港区', null, '', '0', '0', '420200');
INSERT INTO `t_s_territory` VALUES ('420203', '', '0', '西塞山区', null, '', '0', '0', '420200');
INSERT INTO `t_s_territory` VALUES ('420204', '', '0', '下陆区', null, '', '0', '0', '420200');
INSERT INTO `t_s_territory` VALUES ('420205', '', '0', '铁山区', null, '', '0', '0', '420200');
INSERT INTO `t_s_territory` VALUES ('420222', '', '0', '阳新县', null, '', '0', '0', '420200');
INSERT INTO `t_s_territory` VALUES ('420281', '', '0', '大冶市', null, '', '0', '0', '420200');
INSERT INTO `t_s_territory` VALUES ('420300', '', '0', '十堰市', null, '', '0', '0', '420000');
INSERT INTO `t_s_territory` VALUES ('420301', '', '0', '市辖区', null, '', '0', '0', '420300');
INSERT INTO `t_s_territory` VALUES ('420302', '', '0', '茅箭区', null, '', '0', '0', '420300');
INSERT INTO `t_s_territory` VALUES ('420303', '', '0', '张湾区', null, '', '0', '0', '420300');
INSERT INTO `t_s_territory` VALUES ('420304', '', '0', '郧阳区', null, '', '0', '0', '420300');
INSERT INTO `t_s_territory` VALUES ('420322', '', '0', '郧西县', null, '', '0', '0', '420300');
INSERT INTO `t_s_territory` VALUES ('420323', '', '0', '竹山县', null, '', '0', '0', '420300');
INSERT INTO `t_s_territory` VALUES ('420324', '', '0', '竹溪县', null, '', '0', '0', '420300');
INSERT INTO `t_s_territory` VALUES ('420325', '', '0', '房县', null, '', '0', '0', '420300');
INSERT INTO `t_s_territory` VALUES ('420381', '', '0', '丹江口市', null, '', '0', '0', '420300');
INSERT INTO `t_s_territory` VALUES ('420500', '', '0', '宜昌市', null, '', '0', '0', '420000');
INSERT INTO `t_s_territory` VALUES ('420501', '', '0', '市辖区', null, '', '0', '0', '420500');
INSERT INTO `t_s_territory` VALUES ('420502', '', '0', '西陵区', null, '', '0', '0', '420500');
INSERT INTO `t_s_territory` VALUES ('420503', '', '0', '伍家岗区', null, '', '0', '0', '420500');
INSERT INTO `t_s_territory` VALUES ('420504', '', '0', '点军区', null, '', '0', '0', '420500');
INSERT INTO `t_s_territory` VALUES ('420505', '', '0', '猇亭区', null, '', '0', '0', '420500');
INSERT INTO `t_s_territory` VALUES ('420506', '', '0', '夷陵区', null, '', '0', '0', '420500');
INSERT INTO `t_s_territory` VALUES ('420525', '', '0', '远安县', null, '', '0', '0', '420500');
INSERT INTO `t_s_territory` VALUES ('420526', '', '0', '兴山县', null, '', '0', '0', '420500');
INSERT INTO `t_s_territory` VALUES ('420527', '', '0', '秭归县', null, '', '0', '0', '420500');
INSERT INTO `t_s_territory` VALUES ('420528', '', '0', '长阳土家族自治县', null, '', '0', '0', '420500');
INSERT INTO `t_s_territory` VALUES ('420529', '', '0', '五峰土家族自治县', null, '', '0', '0', '420500');
INSERT INTO `t_s_territory` VALUES ('420581', '', '0', '宜都市', null, '', '0', '0', '420500');
INSERT INTO `t_s_territory` VALUES ('420582', '', '0', '当阳市', null, '', '0', '0', '420500');
INSERT INTO `t_s_territory` VALUES ('420583', '', '0', '枝江市', null, '', '0', '0', '420500');
INSERT INTO `t_s_territory` VALUES ('420600', '', '0', '襄阳市', null, '', '0', '0', '420000');
INSERT INTO `t_s_territory` VALUES ('420601', '', '0', '市辖区', null, '', '0', '0', '420600');
INSERT INTO `t_s_territory` VALUES ('420602', '', '0', '襄城区', null, '', '0', '0', '420600');
INSERT INTO `t_s_territory` VALUES ('420606', '', '0', '樊城区', null, '', '0', '0', '420600');
INSERT INTO `t_s_territory` VALUES ('420607', '', '0', '襄州区', null, '', '0', '0', '420600');
INSERT INTO `t_s_territory` VALUES ('420624', '', '0', '南漳县', null, '', '0', '0', '420600');
INSERT INTO `t_s_territory` VALUES ('420625', '', '0', '谷城县', null, '', '0', '0', '420600');
INSERT INTO `t_s_territory` VALUES ('420626', '', '0', '保康县', null, '', '0', '0', '420600');
INSERT INTO `t_s_territory` VALUES ('420682', '', '0', '老河口市', null, '', '0', '0', '420600');
INSERT INTO `t_s_territory` VALUES ('420683', '', '0', '枣阳市', null, '', '0', '0', '420600');
INSERT INTO `t_s_territory` VALUES ('420684', '', '0', '宜城市', null, '', '0', '0', '420600');
INSERT INTO `t_s_territory` VALUES ('420700', '', '0', '鄂州市', null, '', '0', '0', '420000');
INSERT INTO `t_s_territory` VALUES ('420701', '', '0', '市辖区', null, '', '0', '0', '420700');
INSERT INTO `t_s_territory` VALUES ('420702', '', '0', '梁子湖区', null, '', '0', '0', '420700');
INSERT INTO `t_s_territory` VALUES ('420703', '', '0', '华容区', null, '', '0', '0', '420700');
INSERT INTO `t_s_territory` VALUES ('420704', '', '0', '鄂城区', null, '', '0', '0', '420700');
INSERT INTO `t_s_territory` VALUES ('420800', '', '0', '荆门市', null, '', '0', '0', '420000');
INSERT INTO `t_s_territory` VALUES ('420801', '', '0', '市辖区', null, '', '0', '0', '420800');
INSERT INTO `t_s_territory` VALUES ('420802', '', '0', '东宝区', null, '', '0', '0', '420800');
INSERT INTO `t_s_territory` VALUES ('420804', '', '0', '掇刀区', null, '', '0', '0', '420800');
INSERT INTO `t_s_territory` VALUES ('420821', '', '0', '京山县', null, '', '0', '0', '420800');
INSERT INTO `t_s_territory` VALUES ('420822', '', '0', '沙洋县', null, '', '0', '0', '420800');
INSERT INTO `t_s_territory` VALUES ('420881', '', '0', '钟祥市', null, '', '0', '0', '420800');
INSERT INTO `t_s_territory` VALUES ('420900', '', '0', '孝感市', null, '', '0', '0', '420000');
INSERT INTO `t_s_territory` VALUES ('420901', '', '0', '市辖区', null, '', '0', '0', '420900');
INSERT INTO `t_s_territory` VALUES ('420902', '', '0', '孝南区', null, '', '0', '0', '420900');
INSERT INTO `t_s_territory` VALUES ('420921', '', '0', '孝昌县', null, '', '0', '0', '420900');
INSERT INTO `t_s_territory` VALUES ('420922', '', '0', '大悟县', null, '', '0', '0', '420900');
INSERT INTO `t_s_territory` VALUES ('420923', '', '0', '云梦县', null, '', '0', '0', '420900');
INSERT INTO `t_s_territory` VALUES ('420981', '', '0', '应城市', null, '', '0', '0', '420900');
INSERT INTO `t_s_territory` VALUES ('420982', '', '0', '安陆市', null, '', '0', '0', '420900');
INSERT INTO `t_s_territory` VALUES ('420984', '', '0', '汉川市', null, '', '0', '0', '420900');
INSERT INTO `t_s_territory` VALUES ('421000', '', '0', '荆州市', null, '', '0', '0', '420000');
INSERT INTO `t_s_territory` VALUES ('421001', '', '0', '市辖区', null, '', '0', '0', '421000');
INSERT INTO `t_s_territory` VALUES ('421002', '', '0', '沙市区', null, '', '0', '0', '421000');
INSERT INTO `t_s_territory` VALUES ('421003', '', '0', '荆州区', null, '', '0', '0', '421000');
INSERT INTO `t_s_territory` VALUES ('421022', '', '0', '公安县', null, '', '0', '0', '421000');
INSERT INTO `t_s_territory` VALUES ('421023', '', '0', '监利县', null, '', '0', '0', '421000');
INSERT INTO `t_s_territory` VALUES ('421024', '', '0', '江陵县', null, '', '0', '0', '421000');
INSERT INTO `t_s_territory` VALUES ('421081', '', '0', '石首市', null, '', '0', '0', '421000');
INSERT INTO `t_s_territory` VALUES ('421083', '', '0', '洪湖市', null, '', '0', '0', '421000');
INSERT INTO `t_s_territory` VALUES ('421087', '', '0', '松滋市', null, '', '0', '0', '421000');
INSERT INTO `t_s_territory` VALUES ('421100', '', '0', '黄冈市', null, '', '0', '0', '420000');
INSERT INTO `t_s_territory` VALUES ('421101', '', '0', '市辖区', null, '', '0', '0', '421100');
INSERT INTO `t_s_territory` VALUES ('421102', '', '0', '黄州区', null, '', '0', '0', '421100');
INSERT INTO `t_s_territory` VALUES ('421121', '', '0', '团风县', null, '', '0', '0', '421100');
INSERT INTO `t_s_territory` VALUES ('421122', '', '0', '红安县', null, '', '0', '0', '421100');
INSERT INTO `t_s_territory` VALUES ('421123', '', '0', '罗田县', null, '', '0', '0', '421100');
INSERT INTO `t_s_territory` VALUES ('421124', '', '0', '英山县', null, '', '0', '0', '421100');
INSERT INTO `t_s_territory` VALUES ('421125', '', '0', '浠水县', null, '', '0', '0', '421100');
INSERT INTO `t_s_territory` VALUES ('421126', '', '0', '蕲春县', null, '', '0', '0', '421100');
INSERT INTO `t_s_territory` VALUES ('421127', '', '0', '黄梅县', null, '', '0', '0', '421100');
INSERT INTO `t_s_territory` VALUES ('421181', '', '0', '麻城市', null, '', '0', '0', '421100');
INSERT INTO `t_s_territory` VALUES ('421182', '', '0', '武穴市', null, '', '0', '0', '421100');
INSERT INTO `t_s_territory` VALUES ('421200', '', '0', '咸宁市', null, '', '0', '0', '420000');
INSERT INTO `t_s_territory` VALUES ('421201', '', '0', '市辖区', null, '', '0', '0', '421200');
INSERT INTO `t_s_territory` VALUES ('421202', '', '0', '咸安区', null, '', '0', '0', '421200');
INSERT INTO `t_s_territory` VALUES ('421221', '', '0', '嘉鱼县', null, '', '0', '0', '421200');
INSERT INTO `t_s_territory` VALUES ('421222', '', '0', '通城县', null, '', '0', '0', '421200');
INSERT INTO `t_s_territory` VALUES ('421223', '', '0', '崇阳县', null, '', '0', '0', '421200');
INSERT INTO `t_s_territory` VALUES ('421224', '', '0', '通山县', null, '', '0', '0', '421200');
INSERT INTO `t_s_territory` VALUES ('421281', '', '0', '赤壁市', null, '', '0', '0', '421200');
INSERT INTO `t_s_territory` VALUES ('421300', '', '0', '随州市', null, '', '0', '0', '420000');
INSERT INTO `t_s_territory` VALUES ('421301', '', '0', '市辖区', null, '', '0', '0', '421300');
INSERT INTO `t_s_territory` VALUES ('421303', '', '0', '曾都区', null, '', '0', '0', '421300');
INSERT INTO `t_s_territory` VALUES ('421321', '', '0', '随县', null, '', '0', '0', '421300');
INSERT INTO `t_s_territory` VALUES ('421381', '', '0', '广水市', null, '', '0', '0', '421300');
INSERT INTO `t_s_territory` VALUES ('422800', '', '0', '恩施土家族苗族自治州', null, '', '0', '0', '420000');
INSERT INTO `t_s_territory` VALUES ('422801', '', '0', '恩施市', null, '', '0', '0', '422800');
INSERT INTO `t_s_territory` VALUES ('422802', '', '0', '利川市', null, '', '0', '0', '422800');
INSERT INTO `t_s_territory` VALUES ('422822', '', '0', '建始县', null, '', '0', '0', '422800');
INSERT INTO `t_s_territory` VALUES ('422823', '', '0', '巴东县', null, '', '0', '0', '422800');
INSERT INTO `t_s_territory` VALUES ('422825', '', '0', '宣恩县', null, '', '0', '0', '422800');
INSERT INTO `t_s_territory` VALUES ('422826', '', '0', '咸丰县', null, '', '0', '0', '422800');
INSERT INTO `t_s_territory` VALUES ('422827', '', '0', '来凤县', null, '', '0', '0', '422800');
INSERT INTO `t_s_territory` VALUES ('422828', '', '0', '鹤峰县', null, '', '0', '0', '422800');
INSERT INTO `t_s_territory` VALUES ('429004', '', '0', '仙桃市', null, '', '0', '0', '420000');
INSERT INTO `t_s_territory` VALUES ('429005', '', '0', '潜江市', null, '', '0', '0', '420000');
INSERT INTO `t_s_territory` VALUES ('429006', '', '0', '天门市', null, '', '0', '0', '420000');
INSERT INTO `t_s_territory` VALUES ('429021', '', '0', '神农架林区', null, '', '0', '0', '420000');
INSERT INTO `t_s_territory` VALUES ('430000', '', '0', '湖南省', null, '', '0', '0', '1');
INSERT INTO `t_s_territory` VALUES ('430100', '', '0', '长沙市', null, '', '0', '0', '430000');
INSERT INTO `t_s_territory` VALUES ('430101', '', '0', '市辖区', null, '', '0', '0', '430100');
INSERT INTO `t_s_territory` VALUES ('430102', '', '0', '芙蓉区', null, '', '0', '0', '430100');
INSERT INTO `t_s_territory` VALUES ('430103', '', '0', '天心区', null, '', '0', '0', '430100');
INSERT INTO `t_s_territory` VALUES ('430104', '', '0', '岳麓区', null, '', '0', '0', '430100');
INSERT INTO `t_s_territory` VALUES ('430105', '', '0', '开福区', null, '', '0', '0', '430100');
INSERT INTO `t_s_territory` VALUES ('430111', '', '0', '雨花区', null, '', '0', '0', '430100');
INSERT INTO `t_s_territory` VALUES ('430112', '', '0', '望城区', null, '', '0', '0', '430100');
INSERT INTO `t_s_territory` VALUES ('430121', '', '0', '长沙县', null, '', '0', '0', '430100');
INSERT INTO `t_s_territory` VALUES ('430124', '', '0', '宁乡县', null, '', '0', '0', '430100');
INSERT INTO `t_s_territory` VALUES ('430181', '', '0', '浏阳市', null, '', '0', '0', '430100');
INSERT INTO `t_s_territory` VALUES ('430200', '', '0', '株洲市', null, '', '0', '0', '430000');
INSERT INTO `t_s_territory` VALUES ('430201', '', '0', '市辖区', null, '', '0', '0', '430200');
INSERT INTO `t_s_territory` VALUES ('430202', '', '0', '荷塘区', null, '', '0', '0', '430200');
INSERT INTO `t_s_territory` VALUES ('430203', '', '0', '芦淞区', null, '', '0', '0', '430200');
INSERT INTO `t_s_territory` VALUES ('430204', '', '0', '石峰区', null, '', '0', '0', '430200');
INSERT INTO `t_s_territory` VALUES ('430211', '', '0', '天元区', null, '', '0', '0', '430200');
INSERT INTO `t_s_territory` VALUES ('430221', '', '0', '株洲县', null, '', '0', '0', '430200');
INSERT INTO `t_s_territory` VALUES ('430223', '', '0', '攸县', null, '', '0', '0', '430200');
INSERT INTO `t_s_territory` VALUES ('430224', '', '0', '茶陵县', null, '', '0', '0', '430200');
INSERT INTO `t_s_territory` VALUES ('430225', '', '0', '炎陵县', null, '', '0', '0', '430200');
INSERT INTO `t_s_territory` VALUES ('430281', '', '0', '醴陵市', null, '', '0', '0', '430200');
INSERT INTO `t_s_territory` VALUES ('430300', '', '0', '湘潭市', null, '', '0', '0', '430000');
INSERT INTO `t_s_territory` VALUES ('430301', '', '0', '市辖区', null, '', '0', '0', '430300');
INSERT INTO `t_s_territory` VALUES ('430302', '', '0', '雨湖区', null, '', '0', '0', '430300');
INSERT INTO `t_s_territory` VALUES ('430304', '', '0', '岳塘区', null, '', '0', '0', '430300');
INSERT INTO `t_s_territory` VALUES ('430321', '', '0', '湘潭县', null, '', '0', '0', '430300');
INSERT INTO `t_s_territory` VALUES ('430381', '', '0', '湘乡市', null, '', '0', '0', '430300');
INSERT INTO `t_s_territory` VALUES ('430382', '', '0', '韶山市', null, '', '0', '0', '430300');
INSERT INTO `t_s_territory` VALUES ('430400', '', '0', '衡阳市', null, '', '0', '0', '430000');
INSERT INTO `t_s_territory` VALUES ('430401', '', '0', '市辖区', null, '', '0', '0', '430400');
INSERT INTO `t_s_territory` VALUES ('430405', '', '0', '珠晖区', null, '', '0', '0', '430400');
INSERT INTO `t_s_territory` VALUES ('430406', '', '0', '雁峰区', null, '', '0', '0', '430400');
INSERT INTO `t_s_territory` VALUES ('430407', '', '0', '石鼓区', null, '', '0', '0', '430400');
INSERT INTO `t_s_territory` VALUES ('430408', '', '0', '蒸湘区', null, '', '0', '0', '430400');
INSERT INTO `t_s_territory` VALUES ('430412', '', '0', '南岳区', null, '', '0', '0', '430400');
INSERT INTO `t_s_territory` VALUES ('430421', '', '0', '衡阳县', null, '', '0', '0', '430400');
INSERT INTO `t_s_territory` VALUES ('430422', '', '0', '衡南县', null, '', '0', '0', '430400');
INSERT INTO `t_s_territory` VALUES ('430423', '', '0', '衡山县', null, '', '0', '0', '430400');
INSERT INTO `t_s_territory` VALUES ('430424', '', '0', '衡东县', null, '', '0', '0', '430400');
INSERT INTO `t_s_territory` VALUES ('430426', '', '0', '祁东县', null, '', '0', '0', '430400');
INSERT INTO `t_s_territory` VALUES ('430481', '', '0', '耒阳市', null, '', '0', '0', '430400');
INSERT INTO `t_s_territory` VALUES ('430482', '', '0', '常宁市', null, '', '0', '0', '430400');
INSERT INTO `t_s_territory` VALUES ('430500', '', '0', '邵阳市', null, '', '0', '0', '430000');
INSERT INTO `t_s_territory` VALUES ('430501', '', '0', '市辖区', null, '', '0', '0', '430500');
INSERT INTO `t_s_territory` VALUES ('430502', '', '0', '双清区', null, '', '0', '0', '430500');
INSERT INTO `t_s_territory` VALUES ('430503', '', '0', '大祥区', null, '', '0', '0', '430500');
INSERT INTO `t_s_territory` VALUES ('430511', '', '0', '北塔区', null, '', '0', '0', '430500');
INSERT INTO `t_s_territory` VALUES ('430521', '', '0', '邵东县', null, '', '0', '0', '430500');
INSERT INTO `t_s_territory` VALUES ('430522', '', '0', '新邵县', null, '', '0', '0', '430500');
INSERT INTO `t_s_territory` VALUES ('430523', '', '0', '邵阳县', null, '', '0', '0', '430500');
INSERT INTO `t_s_territory` VALUES ('430524', '', '0', '隆回县', null, '', '0', '0', '430500');
INSERT INTO `t_s_territory` VALUES ('430525', '', '0', '洞口县', null, '', '0', '0', '430500');
INSERT INTO `t_s_territory` VALUES ('430527', '', '0', '绥宁县', null, '', '0', '0', '430500');
INSERT INTO `t_s_territory` VALUES ('430528', '', '0', '新宁县', null, '', '0', '0', '430500');
INSERT INTO `t_s_territory` VALUES ('430529', '', '0', '城步苗族自治县', null, '', '0', '0', '430500');
INSERT INTO `t_s_territory` VALUES ('430581', '', '0', '武冈市', null, '', '0', '0', '430500');
INSERT INTO `t_s_territory` VALUES ('430600', '', '0', '岳阳市', null, '', '0', '0', '430000');
INSERT INTO `t_s_territory` VALUES ('430601', '', '0', '市辖区', null, '', '0', '0', '430600');
INSERT INTO `t_s_territory` VALUES ('430602', '', '0', '岳阳楼区', null, '', '0', '0', '430600');
INSERT INTO `t_s_territory` VALUES ('430603', '', '0', '云溪区', null, '', '0', '0', '430600');
INSERT INTO `t_s_territory` VALUES ('430611', '', '0', '君山区', null, '', '0', '0', '430600');
INSERT INTO `t_s_territory` VALUES ('430621', '', '0', '岳阳县', null, '', '0', '0', '430600');
INSERT INTO `t_s_territory` VALUES ('430623', '', '0', '华容县', null, '', '0', '0', '430600');
INSERT INTO `t_s_territory` VALUES ('430624', '', '0', '湘阴县', null, '', '0', '0', '430600');
INSERT INTO `t_s_territory` VALUES ('430626', '', '0', '平江县', null, '', '0', '0', '430600');
INSERT INTO `t_s_territory` VALUES ('430681', '', '0', '汨罗市', null, '', '0', '0', '430600');
INSERT INTO `t_s_territory` VALUES ('430682', '', '0', '临湘市', null, '', '0', '0', '430600');
INSERT INTO `t_s_territory` VALUES ('430700', '', '0', '常德市', null, '', '0', '0', '430000');
INSERT INTO `t_s_territory` VALUES ('430701', '', '0', '市辖区', null, '', '0', '0', '430700');
INSERT INTO `t_s_territory` VALUES ('430702', '', '0', '武陵区', null, '', '0', '0', '430700');
INSERT INTO `t_s_territory` VALUES ('430703', '', '0', '鼎城区', null, '', '0', '0', '430700');
INSERT INTO `t_s_territory` VALUES ('430721', '', '0', '安乡县', null, '', '0', '0', '430700');
INSERT INTO `t_s_territory` VALUES ('430722', '', '0', '汉寿县', null, '', '0', '0', '430700');
INSERT INTO `t_s_territory` VALUES ('430723', '', '0', '澧县', null, '', '0', '0', '430700');
INSERT INTO `t_s_territory` VALUES ('430724', '', '0', '临澧县', null, '', '0', '0', '430700');
INSERT INTO `t_s_territory` VALUES ('430725', '', '0', '桃源县', null, '', '0', '0', '430700');
INSERT INTO `t_s_territory` VALUES ('430726', '', '0', '石门县', null, '', '0', '0', '430700');
INSERT INTO `t_s_territory` VALUES ('430781', '', '0', '津市市', null, '', '0', '0', '430700');
INSERT INTO `t_s_territory` VALUES ('430800', '', '0', '张家界市', null, '', '0', '0', '430000');
INSERT INTO `t_s_territory` VALUES ('430801', '', '0', '市辖区', null, '', '0', '0', '430800');
INSERT INTO `t_s_territory` VALUES ('430802', '', '0', '永定区', null, '', '0', '0', '430800');
INSERT INTO `t_s_territory` VALUES ('430811', '', '0', '武陵源区', null, '', '0', '0', '430800');
INSERT INTO `t_s_territory` VALUES ('430821', '', '0', '慈利县', null, '', '0', '0', '430800');
INSERT INTO `t_s_territory` VALUES ('430822', '', '0', '桑植县', null, '', '0', '0', '430800');
INSERT INTO `t_s_territory` VALUES ('430900', '', '0', '益阳市', null, '', '0', '0', '430000');
INSERT INTO `t_s_territory` VALUES ('430901', '', '0', '市辖区', null, '', '0', '0', '430900');
INSERT INTO `t_s_territory` VALUES ('430902', '', '0', '资阳区', null, '', '0', '0', '430900');
INSERT INTO `t_s_territory` VALUES ('430903', '', '0', '赫山区', null, '', '0', '0', '430900');
INSERT INTO `t_s_territory` VALUES ('430921', '', '0', '南县', null, '', '0', '0', '430900');
INSERT INTO `t_s_territory` VALUES ('430922', '', '0', '桃江县', null, '', '0', '0', '430900');
INSERT INTO `t_s_territory` VALUES ('430923', '', '0', '安化县', null, '', '0', '0', '430900');
INSERT INTO `t_s_territory` VALUES ('430981', '', '0', '沅江市', null, '', '0', '0', '430900');
INSERT INTO `t_s_territory` VALUES ('431000', '', '0', '郴州市', null, '', '0', '0', '430000');
INSERT INTO `t_s_territory` VALUES ('431001', '', '0', '市辖区', null, '', '0', '0', '431000');
INSERT INTO `t_s_territory` VALUES ('431002', '', '0', '北湖区', null, '', '0', '0', '431000');
INSERT INTO `t_s_territory` VALUES ('431003', '', '0', '苏仙区', null, '', '0', '0', '431000');
INSERT INTO `t_s_territory` VALUES ('431021', '', '0', '桂阳县', null, '', '0', '0', '431000');
INSERT INTO `t_s_territory` VALUES ('431022', '', '0', '宜章县', null, '', '0', '0', '431000');
INSERT INTO `t_s_territory` VALUES ('431023', '', '0', '永兴县', null, '', '0', '0', '431000');
INSERT INTO `t_s_territory` VALUES ('431024', '', '0', '嘉禾县', null, '', '0', '0', '431000');
INSERT INTO `t_s_territory` VALUES ('431025', '', '0', '临武县', null, '', '0', '0', '431000');
INSERT INTO `t_s_territory` VALUES ('431026', '', '0', '汝城县', null, '', '0', '0', '431000');
INSERT INTO `t_s_territory` VALUES ('431027', '', '0', '桂东县', null, '', '0', '0', '431000');
INSERT INTO `t_s_territory` VALUES ('431028', '', '0', '安仁县', null, '', '0', '0', '431000');
INSERT INTO `t_s_territory` VALUES ('431081', '', '0', '资兴市', null, '', '0', '0', '431000');
INSERT INTO `t_s_territory` VALUES ('431100', '', '0', '永州市', null, '', '0', '0', '430000');
INSERT INTO `t_s_territory` VALUES ('431101', '', '0', '市辖区', null, '', '0', '0', '431100');
INSERT INTO `t_s_territory` VALUES ('431102', '', '0', '零陵区', null, '', '0', '0', '431100');
INSERT INTO `t_s_territory` VALUES ('431103', '', '0', '冷水滩区', null, '', '0', '0', '431100');
INSERT INTO `t_s_territory` VALUES ('431121', '', '0', '祁阳县', null, '', '0', '0', '431100');
INSERT INTO `t_s_territory` VALUES ('431122', '', '0', '东安县', null, '', '0', '0', '431100');
INSERT INTO `t_s_territory` VALUES ('431123', '', '0', '双牌县', null, '', '0', '0', '431100');
INSERT INTO `t_s_territory` VALUES ('431124', '', '0', '道县', null, '', '0', '0', '431100');
INSERT INTO `t_s_territory` VALUES ('431125', '', '0', '江永县', null, '', '0', '0', '431100');
INSERT INTO `t_s_territory` VALUES ('431126', '', '0', '宁远县', null, '', '0', '0', '431100');
INSERT INTO `t_s_territory` VALUES ('431127', '', '0', '蓝山县', null, '', '0', '0', '431100');
INSERT INTO `t_s_territory` VALUES ('431128', '', '0', '新田县', null, '', '0', '0', '431100');
INSERT INTO `t_s_territory` VALUES ('431129', '', '0', '江华瑶族自治县', null, '', '0', '0', '431100');
INSERT INTO `t_s_territory` VALUES ('431200', '', '0', '怀化市', null, '', '0', '0', '430000');
INSERT INTO `t_s_territory` VALUES ('431201', '', '0', '市辖区', null, '', '0', '0', '431200');
INSERT INTO `t_s_territory` VALUES ('431202', '', '0', '鹤城区', null, '', '0', '0', '431200');
INSERT INTO `t_s_territory` VALUES ('431221', '', '0', '中方县', null, '', '0', '0', '431200');
INSERT INTO `t_s_territory` VALUES ('431222', '', '0', '沅陵县', null, '', '0', '0', '431200');
INSERT INTO `t_s_territory` VALUES ('431223', '', '0', '辰溪县', null, '', '0', '0', '431200');
INSERT INTO `t_s_territory` VALUES ('431224', '', '0', '溆浦县', null, '', '0', '0', '431200');
INSERT INTO `t_s_territory` VALUES ('431225', '', '0', '会同县', null, '', '0', '0', '431200');
INSERT INTO `t_s_territory` VALUES ('431226', '', '0', '麻阳苗族自治县', null, '', '0', '0', '431200');
INSERT INTO `t_s_territory` VALUES ('431227', '', '0', '新晃侗族自治县', null, '', '0', '0', '431200');
INSERT INTO `t_s_territory` VALUES ('431228', '', '0', '芷江侗族自治县', null, '', '0', '0', '431200');
INSERT INTO `t_s_territory` VALUES ('431229', '', '0', '靖州苗族侗族自治县', null, '', '0', '0', '431200');
INSERT INTO `t_s_territory` VALUES ('431230', '', '0', '通道侗族自治县', null, '', '0', '0', '431200');
INSERT INTO `t_s_territory` VALUES ('431281', '', '0', '洪江市', null, '', '0', '0', '431200');
INSERT INTO `t_s_territory` VALUES ('431300', '', '0', '娄底市', null, '', '0', '0', '430000');
INSERT INTO `t_s_territory` VALUES ('431301', '', '0', '市辖区', null, '', '0', '0', '431300');
INSERT INTO `t_s_territory` VALUES ('431302', '', '0', '娄星区', null, '', '0', '0', '431300');
INSERT INTO `t_s_territory` VALUES ('431321', '', '0', '双峰县', null, '', '0', '0', '431300');
INSERT INTO `t_s_territory` VALUES ('431322', '', '0', '新化县', null, '', '0', '0', '431300');
INSERT INTO `t_s_territory` VALUES ('431381', '', '0', '冷水江市', null, '', '0', '0', '431300');
INSERT INTO `t_s_territory` VALUES ('431382', '', '0', '涟源市', null, '', '0', '0', '431300');
INSERT INTO `t_s_territory` VALUES ('433100', '', '0', '湘西土家族苗族自治州', null, '', '0', '0', '430000');
INSERT INTO `t_s_territory` VALUES ('433101', '', '0', '吉首市', null, '', '0', '0', '433100');
INSERT INTO `t_s_territory` VALUES ('433122', '', '0', '泸溪县', null, '', '0', '0', '433100');
INSERT INTO `t_s_territory` VALUES ('433123', '', '0', '凤凰县', null, '', '0', '0', '433100');
INSERT INTO `t_s_territory` VALUES ('433124', '', '0', '花垣县', null, '', '0', '0', '433100');
INSERT INTO `t_s_territory` VALUES ('433125', '', '0', '保靖县', null, '', '0', '0', '433100');
INSERT INTO `t_s_territory` VALUES ('433126', '', '0', '古丈县', null, '', '0', '0', '433100');
INSERT INTO `t_s_territory` VALUES ('433127', '', '0', '永顺县', null, '', '0', '0', '433100');
INSERT INTO `t_s_territory` VALUES ('433130', '', '0', '龙山县', null, '', '0', '0', '433100');
INSERT INTO `t_s_territory` VALUES ('440000', '', '0', '广东省', null, '', '0', '0', '1');
INSERT INTO `t_s_territory` VALUES ('440100', '', '0', '广州市', null, '', '0', '0', '440000');
INSERT INTO `t_s_territory` VALUES ('440101', '', '0', '市辖区', null, '', '0', '0', '440100');
INSERT INTO `t_s_territory` VALUES ('440103', '', '0', '荔湾区', null, '', '0', '0', '440100');
INSERT INTO `t_s_territory` VALUES ('440104', '', '0', '越秀区', null, '', '0', '0', '440100');
INSERT INTO `t_s_territory` VALUES ('440105', '', '0', '海珠区', null, '', '0', '0', '440100');
INSERT INTO `t_s_territory` VALUES ('440106', '', '0', '天河区', null, '', '0', '0', '440100');
INSERT INTO `t_s_territory` VALUES ('440111', '', '0', '白云区', null, '', '0', '0', '440100');
INSERT INTO `t_s_territory` VALUES ('440112', '', '0', '黄埔区', null, '', '0', '0', '440100');
INSERT INTO `t_s_territory` VALUES ('440113', '', '0', '番禺区', null, '', '0', '0', '440100');
INSERT INTO `t_s_territory` VALUES ('440114', '', '0', '花都区', null, '', '0', '0', '440100');
INSERT INTO `t_s_territory` VALUES ('440115', '', '0', '南沙区', null, '', '0', '0', '440100');
INSERT INTO `t_s_territory` VALUES ('440116', '', '0', '萝岗区', null, '', '0', '0', '440100');
INSERT INTO `t_s_territory` VALUES ('440117', '', '0', '从化区', null, '', '0', '0', '440100');
INSERT INTO `t_s_territory` VALUES ('440118', '', '0', '增城区', null, '', '0', '0', '440100');
INSERT INTO `t_s_territory` VALUES ('440200', '', '0', '韶关市', null, '', '0', '0', '440000');
INSERT INTO `t_s_territory` VALUES ('440201', '', '0', '市辖区', null, '', '0', '0', '440200');
INSERT INTO `t_s_territory` VALUES ('440203', '', '0', '武江区', null, '', '0', '0', '440200');
INSERT INTO `t_s_territory` VALUES ('440204', '', '0', '浈江区', null, '', '0', '0', '440200');
INSERT INTO `t_s_territory` VALUES ('440205', '', '0', '曲江区', null, '', '0', '0', '440200');
INSERT INTO `t_s_territory` VALUES ('440222', '', '0', '始兴县', null, '', '0', '0', '440200');
INSERT INTO `t_s_territory` VALUES ('440224', '', '0', '仁化县', null, '', '0', '0', '440200');
INSERT INTO `t_s_territory` VALUES ('440229', '', '0', '翁源县', null, '', '0', '0', '440200');
INSERT INTO `t_s_territory` VALUES ('440232', '', '0', '乳源瑶族自治县', null, '', '0', '0', '440200');
INSERT INTO `t_s_territory` VALUES ('440233', '', '0', '新丰县', null, '', '0', '0', '440200');
INSERT INTO `t_s_territory` VALUES ('440281', '', '0', '乐昌市', null, '', '0', '0', '440200');
INSERT INTO `t_s_territory` VALUES ('440282', '', '0', '南雄市', null, '', '0', '0', '440200');
INSERT INTO `t_s_territory` VALUES ('440300', '', '0', '深圳市', null, '', '0', '0', '440000');
INSERT INTO `t_s_territory` VALUES ('440301', '', '0', '市辖区', null, '', '0', '0', '440300');
INSERT INTO `t_s_territory` VALUES ('440303', '', '0', '罗湖区', null, '', '0', '0', '440300');
INSERT INTO `t_s_territory` VALUES ('440304', '', '0', '福田区', null, '', '0', '0', '440300');
INSERT INTO `t_s_territory` VALUES ('440305', '', '0', '南山区', null, '', '0', '0', '440300');
INSERT INTO `t_s_territory` VALUES ('440306', '', '0', '宝安区', null, '', '0', '0', '440300');
INSERT INTO `t_s_territory` VALUES ('440307', '', '0', '龙岗区', null, '', '0', '0', '440300');
INSERT INTO `t_s_territory` VALUES ('440308', '', '0', '盐田区', null, '', '0', '0', '440300');
INSERT INTO `t_s_territory` VALUES ('440400', '', '0', '珠海市', null, '', '0', '0', '440000');
INSERT INTO `t_s_territory` VALUES ('440401', '', '0', '市辖区', null, '', '0', '0', '440400');
INSERT INTO `t_s_territory` VALUES ('440402', '', '0', '香洲区', null, '', '0', '0', '440400');
INSERT INTO `t_s_territory` VALUES ('440403', '', '0', '斗门区', null, '', '0', '0', '440400');
INSERT INTO `t_s_territory` VALUES ('440404', '', '0', '金湾区', null, '', '0', '0', '440400');
INSERT INTO `t_s_territory` VALUES ('440500', '', '0', '汕头市', null, '', '0', '0', '440000');
INSERT INTO `t_s_territory` VALUES ('440501', '', '0', '市辖区', null, '', '0', '0', '440500');
INSERT INTO `t_s_territory` VALUES ('440507', '', '0', '龙湖区', null, '', '0', '0', '440500');
INSERT INTO `t_s_territory` VALUES ('440511', '', '0', '金平区', null, '', '0', '0', '440500');
INSERT INTO `t_s_territory` VALUES ('440512', '', '0', '濠江区', null, '', '0', '0', '440500');
INSERT INTO `t_s_territory` VALUES ('440513', '', '0', '潮阳区', null, '', '0', '0', '440500');
INSERT INTO `t_s_territory` VALUES ('440514', '', '0', '潮南区', null, '', '0', '0', '440500');
INSERT INTO `t_s_territory` VALUES ('440515', '', '0', '澄海区', null, '', '0', '0', '440500');
INSERT INTO `t_s_territory` VALUES ('440523', '', '0', '南澳县', null, '', '0', '0', '440500');
INSERT INTO `t_s_territory` VALUES ('440600', '', '0', '佛山市', null, '', '0', '0', '440000');
INSERT INTO `t_s_territory` VALUES ('440601', '', '0', '市辖区', null, '', '0', '0', '440600');
INSERT INTO `t_s_territory` VALUES ('440604', '', '0', '禅城区', null, '', '0', '0', '440600');
INSERT INTO `t_s_territory` VALUES ('440605', '', '0', '南海区', null, '', '0', '0', '440600');
INSERT INTO `t_s_territory` VALUES ('440606', '', '0', '顺德区', null, '', '0', '0', '440600');
INSERT INTO `t_s_territory` VALUES ('440607', '', '0', '三水区', null, '', '0', '0', '440600');
INSERT INTO `t_s_territory` VALUES ('440608', '', '0', '高明区', null, '', '0', '0', '440600');
INSERT INTO `t_s_territory` VALUES ('440700', '', '0', '江门市', null, '', '0', '0', '440000');
INSERT INTO `t_s_territory` VALUES ('440701', '', '0', '市辖区', null, '', '0', '0', '440700');
INSERT INTO `t_s_territory` VALUES ('440703', '', '0', '蓬江区', null, '', '0', '0', '440700');
INSERT INTO `t_s_territory` VALUES ('440704', '', '0', '江海区', null, '', '0', '0', '440700');
INSERT INTO `t_s_territory` VALUES ('440705', '', '0', '新会区', null, '', '0', '0', '440700');
INSERT INTO `t_s_territory` VALUES ('440781', '', '0', '台山市', null, '', '0', '0', '440700');
INSERT INTO `t_s_territory` VALUES ('440783', '', '0', '开平市', null, '', '0', '0', '440700');
INSERT INTO `t_s_territory` VALUES ('440784', '', '0', '鹤山市', null, '', '0', '0', '440700');
INSERT INTO `t_s_territory` VALUES ('440785', '', '0', '恩平市', null, '', '0', '0', '440700');
INSERT INTO `t_s_territory` VALUES ('440800', '', '0', '湛江市', null, '', '0', '0', '440000');
INSERT INTO `t_s_territory` VALUES ('440801', '', '0', '市辖区', null, '', '0', '0', '440800');
INSERT INTO `t_s_territory` VALUES ('440802', '', '0', '赤坎区', null, '', '0', '0', '440800');
INSERT INTO `t_s_territory` VALUES ('440803', '', '0', '霞山区', null, '', '0', '0', '440800');
INSERT INTO `t_s_territory` VALUES ('440804', '', '0', '坡头区', null, '', '0', '0', '440800');
INSERT INTO `t_s_territory` VALUES ('440811', '', '0', '麻章区', null, '', '0', '0', '440800');
INSERT INTO `t_s_territory` VALUES ('440823', '', '0', '遂溪县', null, '', '0', '0', '440800');
INSERT INTO `t_s_territory` VALUES ('440825', '', '0', '徐闻县', null, '', '0', '0', '440800');
INSERT INTO `t_s_territory` VALUES ('440881', '', '0', '廉江市', null, '', '0', '0', '440800');
INSERT INTO `t_s_territory` VALUES ('440882', '', '0', '雷州市', null, '', '0', '0', '440800');
INSERT INTO `t_s_territory` VALUES ('440883', '', '0', '吴川市', null, '', '0', '0', '440800');
INSERT INTO `t_s_territory` VALUES ('440900', '', '0', '茂名市', null, '', '0', '0', '440000');
INSERT INTO `t_s_territory` VALUES ('440901', '', '0', '市辖区', null, '', '0', '0', '440900');
INSERT INTO `t_s_territory` VALUES ('440902', '', '0', '茂南区', null, '', '0', '0', '440900');
INSERT INTO `t_s_territory` VALUES ('440904', '', '0', '电白区', null, '', '0', '0', '440900');
INSERT INTO `t_s_territory` VALUES ('440981', '', '0', '高州市', null, '', '0', '0', '440900');
INSERT INTO `t_s_territory` VALUES ('440982', '', '0', '化州市', null, '', '0', '0', '440900');
INSERT INTO `t_s_territory` VALUES ('440983', '', '0', '信宜市', null, '', '0', '0', '440900');
INSERT INTO `t_s_territory` VALUES ('441200', '', '0', '肇庆市', null, '', '0', '0', '440000');
INSERT INTO `t_s_territory` VALUES ('441201', '', '0', '市辖区', null, '', '0', '0', '441200');
INSERT INTO `t_s_territory` VALUES ('441202', '', '0', '端州区', null, '', '0', '0', '441200');
INSERT INTO `t_s_territory` VALUES ('441203', '', '0', '鼎湖区', null, '', '0', '0', '441200');
INSERT INTO `t_s_territory` VALUES ('441223', '', '0', '广宁县', null, '', '0', '0', '441200');
INSERT INTO `t_s_territory` VALUES ('441224', '', '0', '怀集县', null, '', '0', '0', '441200');
INSERT INTO `t_s_territory` VALUES ('441225', '', '0', '封开县', null, '', '0', '0', '441200');
INSERT INTO `t_s_territory` VALUES ('441226', '', '0', '德庆县', null, '', '0', '0', '441200');
INSERT INTO `t_s_territory` VALUES ('441283', '', '0', '高要市', null, '', '0', '0', '441200');
INSERT INTO `t_s_territory` VALUES ('441284', '', '0', '四会市', null, '', '0', '0', '441200');
INSERT INTO `t_s_territory` VALUES ('441300', '', '0', '惠州市', null, '', '0', '0', '440000');
INSERT INTO `t_s_territory` VALUES ('441301', '', '0', '市辖区', null, '', '0', '0', '441300');
INSERT INTO `t_s_territory` VALUES ('441302', '', '0', '惠城区', null, '', '0', '0', '441300');
INSERT INTO `t_s_territory` VALUES ('441303', '', '0', '惠阳区', null, '', '0', '0', '441300');
INSERT INTO `t_s_territory` VALUES ('441322', '', '0', '博罗县', null, '', '0', '0', '441300');
INSERT INTO `t_s_territory` VALUES ('441323', '', '0', '惠东县', null, '', '0', '0', '441300');
INSERT INTO `t_s_territory` VALUES ('441324', '', '0', '龙门县', null, '', '0', '0', '441300');
INSERT INTO `t_s_territory` VALUES ('441400', '', '0', '梅州市', null, '', '0', '0', '440000');
INSERT INTO `t_s_territory` VALUES ('441401', '', '0', '市辖区', null, '', '0', '0', '441400');
INSERT INTO `t_s_territory` VALUES ('441402', '', '0', '梅江区', null, '', '0', '0', '441400');
INSERT INTO `t_s_territory` VALUES ('441403', '', '0', '梅县区', null, '', '0', '0', '441400');
INSERT INTO `t_s_territory` VALUES ('441422', '', '0', '大埔县', null, '', '0', '0', '441400');
INSERT INTO `t_s_territory` VALUES ('441423', '', '0', '丰顺县', null, '', '0', '0', '441400');
INSERT INTO `t_s_territory` VALUES ('441424', '', '0', '五华县', null, '', '0', '0', '441400');
INSERT INTO `t_s_territory` VALUES ('441426', '', '0', '平远县', null, '', '0', '0', '441400');
INSERT INTO `t_s_territory` VALUES ('441427', '', '0', '蕉岭县', null, '', '0', '0', '441400');
INSERT INTO `t_s_territory` VALUES ('441481', '', '0', '兴宁市', null, '', '0', '0', '441400');
INSERT INTO `t_s_territory` VALUES ('441500', '', '0', '汕尾市', null, '', '0', '0', '440000');
INSERT INTO `t_s_territory` VALUES ('441501', '', '0', '市辖区', null, '', '0', '0', '441500');
INSERT INTO `t_s_territory` VALUES ('441502', '', '0', '城区', null, '', '0', '0', '441500');
INSERT INTO `t_s_territory` VALUES ('441521', '', '0', '海丰县', null, '', '0', '0', '441500');
INSERT INTO `t_s_territory` VALUES ('441523', '', '0', '陆河县', null, '', '0', '0', '441500');
INSERT INTO `t_s_territory` VALUES ('441581', '', '0', '陆丰市', null, '', '0', '0', '441500');
INSERT INTO `t_s_territory` VALUES ('441600', '', '0', '河源市', null, '', '0', '0', '440000');
INSERT INTO `t_s_territory` VALUES ('441601', '', '0', '市辖区', null, '', '0', '0', '441600');
INSERT INTO `t_s_territory` VALUES ('441602', '', '0', '源城区', null, '', '0', '0', '441600');
INSERT INTO `t_s_territory` VALUES ('441621', '', '0', '紫金县', null, '', '0', '0', '441600');
INSERT INTO `t_s_territory` VALUES ('441622', '', '0', '龙川县', null, '', '0', '0', '441600');
INSERT INTO `t_s_territory` VALUES ('441623', '', '0', '连平县', null, '', '0', '0', '441600');
INSERT INTO `t_s_territory` VALUES ('441624', '', '0', '和平县', null, '', '0', '0', '441600');
INSERT INTO `t_s_territory` VALUES ('441625', '', '0', '东源县', null, '', '0', '0', '441600');
INSERT INTO `t_s_territory` VALUES ('441700', '', '0', '阳江市', null, '', '0', '0', '440000');
INSERT INTO `t_s_territory` VALUES ('441701', '', '0', '市辖区', null, '', '0', '0', '441700');
INSERT INTO `t_s_territory` VALUES ('441702', '', '0', '江城区', null, '', '0', '0', '441700');
INSERT INTO `t_s_territory` VALUES ('441721', '', '0', '阳西县', null, '', '0', '0', '441700');
INSERT INTO `t_s_territory` VALUES ('441723', '', '0', '阳东县', null, '', '0', '0', '441700');
INSERT INTO `t_s_territory` VALUES ('441781', '', '0', '阳春市', null, '', '0', '0', '441700');
INSERT INTO `t_s_territory` VALUES ('441800', '', '0', '清远市', null, '', '0', '0', '440000');
INSERT INTO `t_s_territory` VALUES ('441801', '', '0', '市辖区', null, '', '0', '0', '441800');
INSERT INTO `t_s_territory` VALUES ('441802', '', '0', '清城区', null, '', '0', '0', '441800');
INSERT INTO `t_s_territory` VALUES ('441803', '', '0', '清新区', null, '', '0', '0', '441800');
INSERT INTO `t_s_territory` VALUES ('441821', '', '0', '佛冈县', null, '', '0', '0', '441800');
INSERT INTO `t_s_territory` VALUES ('441823', '', '0', '阳山县', null, '', '0', '0', '441800');
INSERT INTO `t_s_territory` VALUES ('441825', '', '0', '连山壮族瑶族自治县', null, '', '0', '0', '441800');
INSERT INTO `t_s_territory` VALUES ('441826', '', '0', '连南瑶族自治县', null, '', '0', '0', '441800');
INSERT INTO `t_s_territory` VALUES ('441881', '', '0', '英德市', null, '', '0', '0', '441800');
INSERT INTO `t_s_territory` VALUES ('441882', '', '0', '连州市', null, '', '0', '0', '441800');
INSERT INTO `t_s_territory` VALUES ('441900', '', '0', '东莞市', null, '', '0', '0', '440000');
INSERT INTO `t_s_territory` VALUES ('442000', '', '0', '中山市', null, '', '0', '0', '440000');
INSERT INTO `t_s_territory` VALUES ('445100', '', '0', '潮州市', null, '', '0', '0', '440000');
INSERT INTO `t_s_territory` VALUES ('445101', '', '0', '市辖区', null, '', '0', '0', '445100');
INSERT INTO `t_s_territory` VALUES ('445102', '', '0', '湘桥区', null, '', '0', '0', '445100');
INSERT INTO `t_s_territory` VALUES ('445103', '', '0', '潮安区', null, '', '0', '0', '445100');
INSERT INTO `t_s_territory` VALUES ('445122', '', '0', '饶平县', null, '', '0', '0', '445100');
INSERT INTO `t_s_territory` VALUES ('445200', '', '0', '揭阳市', null, '', '0', '0', '440000');
INSERT INTO `t_s_territory` VALUES ('445201', '', '0', '市辖区', null, '', '0', '0', '445200');
INSERT INTO `t_s_territory` VALUES ('445202', '', '0', '榕城区', null, '', '0', '0', '445200');
INSERT INTO `t_s_territory` VALUES ('445203', '', '0', '揭东区', null, '', '0', '0', '445200');
INSERT INTO `t_s_territory` VALUES ('445222', '', '0', '揭西县', null, '', '0', '0', '445200');
INSERT INTO `t_s_territory` VALUES ('445224', '', '0', '惠来县', null, '', '0', '0', '445200');
INSERT INTO `t_s_territory` VALUES ('445281', '', '0', '普宁市', null, '', '0', '0', '445200');
INSERT INTO `t_s_territory` VALUES ('445300', '', '0', '云浮市', null, '', '0', '0', '440000');
INSERT INTO `t_s_territory` VALUES ('445301', '', '0', '市辖区', null, '', '0', '0', '445300');
INSERT INTO `t_s_territory` VALUES ('445302', '', '0', '云城区', null, '', '0', '0', '445300');
INSERT INTO `t_s_territory` VALUES ('445303', '', '0', '云安区', null, '', '0', '0', '445300');
INSERT INTO `t_s_territory` VALUES ('445321', '', '0', '新兴县', null, '', '0', '0', '445300');
INSERT INTO `t_s_territory` VALUES ('445322', '', '0', '郁南县', null, '', '0', '0', '445300');
INSERT INTO `t_s_territory` VALUES ('445381', '', '0', '罗定市', null, '', '0', '0', '445300');
INSERT INTO `t_s_territory` VALUES ('450000', '', '0', '广西壮族自治区', null, '', '0', '0', '1');
INSERT INTO `t_s_territory` VALUES ('450100', '', '0', '南宁市', null, '', '0', '0', '450000');
INSERT INTO `t_s_territory` VALUES ('450101', '', '0', '市辖区', null, '', '0', '0', '450100');
INSERT INTO `t_s_territory` VALUES ('450102', '', '0', '兴宁区', null, '', '0', '0', '450100');
INSERT INTO `t_s_territory` VALUES ('450103', '', '0', '青秀区', null, '', '0', '0', '450100');
INSERT INTO `t_s_territory` VALUES ('450105', '', '0', '江南区', null, '', '0', '0', '450100');
INSERT INTO `t_s_territory` VALUES ('450107', '', '0', '西乡塘区', null, '', '0', '0', '450100');
INSERT INTO `t_s_territory` VALUES ('450108', '', '0', '良庆区', null, '', '0', '0', '450100');
INSERT INTO `t_s_territory` VALUES ('450109', '', '0', '邕宁区', null, '', '0', '0', '450100');
INSERT INTO `t_s_territory` VALUES ('450122', '', '0', '武鸣县', null, '', '0', '0', '450100');
INSERT INTO `t_s_territory` VALUES ('450123', '', '0', '隆安县', null, '', '0', '0', '450100');
INSERT INTO `t_s_territory` VALUES ('450124', '', '0', '马山县', null, '', '0', '0', '450100');
INSERT INTO `t_s_territory` VALUES ('450125', '', '0', '上林县', null, '', '0', '0', '450100');
INSERT INTO `t_s_territory` VALUES ('450126', '', '0', '宾阳县', null, '', '0', '0', '450100');
INSERT INTO `t_s_territory` VALUES ('450127', '', '0', '横县', null, '', '0', '0', '450100');
INSERT INTO `t_s_territory` VALUES ('450200', '', '0', '柳州市', null, '', '0', '0', '450000');
INSERT INTO `t_s_territory` VALUES ('450201', '', '0', '市辖区', null, '', '0', '0', '450200');
INSERT INTO `t_s_territory` VALUES ('450202', '', '0', '城中区', null, '', '0', '0', '450200');
INSERT INTO `t_s_territory` VALUES ('450203', '', '0', '鱼峰区', null, '', '0', '0', '450200');
INSERT INTO `t_s_territory` VALUES ('450204', '', '0', '柳南区', null, '', '0', '0', '450200');
INSERT INTO `t_s_territory` VALUES ('450205', '', '0', '柳北区', null, '', '0', '0', '450200');
INSERT INTO `t_s_territory` VALUES ('450221', '', '0', '柳江县', null, '', '0', '0', '450200');
INSERT INTO `t_s_territory` VALUES ('450222', '', '0', '柳城县', null, '', '0', '0', '450200');
INSERT INTO `t_s_territory` VALUES ('450223', '', '0', '鹿寨县', null, '', '0', '0', '450200');
INSERT INTO `t_s_territory` VALUES ('450224', '', '0', '融安县', null, '', '0', '0', '450200');
INSERT INTO `t_s_territory` VALUES ('450225', '', '0', '融水苗族自治县', null, '', '0', '0', '450200');
INSERT INTO `t_s_territory` VALUES ('450226', '', '0', '三江侗族自治县', null, '', '0', '0', '450200');
INSERT INTO `t_s_territory` VALUES ('450300', '', '0', '桂林市', null, '', '0', '0', '450000');
INSERT INTO `t_s_territory` VALUES ('450301', '', '0', '市辖区', null, '', '0', '0', '450300');
INSERT INTO `t_s_territory` VALUES ('450302', '', '0', '秀峰区', null, '', '0', '0', '450300');
INSERT INTO `t_s_territory` VALUES ('450303', '', '0', '叠彩区', null, '', '0', '0', '450300');
INSERT INTO `t_s_territory` VALUES ('450304', '', '0', '象山区', null, '', '0', '0', '450300');
INSERT INTO `t_s_territory` VALUES ('450305', '', '0', '七星区', null, '', '0', '0', '450300');
INSERT INTO `t_s_territory` VALUES ('450311', '', '0', '雁山区', null, '', '0', '0', '450300');
INSERT INTO `t_s_territory` VALUES ('450312', '', '0', '临桂区', null, '', '0', '0', '450300');
INSERT INTO `t_s_territory` VALUES ('450321', '', '0', '阳朔县', null, '', '0', '0', '450300');
INSERT INTO `t_s_territory` VALUES ('450323', '', '0', '灵川县', null, '', '0', '0', '450300');
INSERT INTO `t_s_territory` VALUES ('450324', '', '0', '全州县', null, '', '0', '0', '450300');
INSERT INTO `t_s_territory` VALUES ('450325', '', '0', '兴安县', null, '', '0', '0', '450300');
INSERT INTO `t_s_territory` VALUES ('450326', '', '0', '永福县', null, '', '0', '0', '450300');
INSERT INTO `t_s_territory` VALUES ('450327', '', '0', '灌阳县', null, '', '0', '0', '450300');
INSERT INTO `t_s_territory` VALUES ('450328', '', '0', '龙胜各族自治县', null, '', '0', '0', '450300');
INSERT INTO `t_s_territory` VALUES ('450329', '', '0', '资源县', null, '', '0', '0', '450300');
INSERT INTO `t_s_territory` VALUES ('450330', '', '0', '平乐县', null, '', '0', '0', '450300');
INSERT INTO `t_s_territory` VALUES ('450331', '', '0', '荔浦县', null, '', '0', '0', '450300');
INSERT INTO `t_s_territory` VALUES ('450332', '', '0', '恭城瑶族自治县', null, '', '0', '0', '450300');
INSERT INTO `t_s_territory` VALUES ('450400', '', '0', '梧州市', null, '', '0', '0', '450000');
INSERT INTO `t_s_territory` VALUES ('450401', '', '0', '市辖区', null, '', '0', '0', '450400');
INSERT INTO `t_s_territory` VALUES ('450403', '', '0', '万秀区', null, '', '0', '0', '450400');
INSERT INTO `t_s_territory` VALUES ('450405', '', '0', '长洲区', null, '', '0', '0', '450400');
INSERT INTO `t_s_territory` VALUES ('450406', '', '0', '龙圩区', null, '', '0', '0', '450400');
INSERT INTO `t_s_territory` VALUES ('450421', '', '0', '苍梧县', null, '', '0', '0', '450400');
INSERT INTO `t_s_territory` VALUES ('450422', '', '0', '藤县', null, '', '0', '0', '450400');
INSERT INTO `t_s_territory` VALUES ('450423', '', '0', '蒙山县', null, '', '0', '0', '450400');
INSERT INTO `t_s_territory` VALUES ('450481', '', '0', '岑溪市', null, '', '0', '0', '450400');
INSERT INTO `t_s_territory` VALUES ('450500', '', '0', '北海市', null, '', '0', '0', '450000');
INSERT INTO `t_s_territory` VALUES ('450501', '', '0', '市辖区', null, '', '0', '0', '450500');
INSERT INTO `t_s_territory` VALUES ('450502', '', '0', '海城区', null, '', '0', '0', '450500');
INSERT INTO `t_s_territory` VALUES ('450503', '', '0', '银海区', null, '', '0', '0', '450500');
INSERT INTO `t_s_territory` VALUES ('450512', '', '0', '铁山港区', null, '', '0', '0', '450500');
INSERT INTO `t_s_territory` VALUES ('450521', '', '0', '合浦县', null, '', '0', '0', '450500');
INSERT INTO `t_s_territory` VALUES ('450600', '', '0', '防城港市', null, '', '0', '0', '450000');
INSERT INTO `t_s_territory` VALUES ('450601', '', '0', '市辖区', null, '', '0', '0', '450600');
INSERT INTO `t_s_territory` VALUES ('450602', '', '0', '港口区', null, '', '0', '0', '450600');
INSERT INTO `t_s_territory` VALUES ('450603', '', '0', '防城区', null, '', '0', '0', '450600');
INSERT INTO `t_s_territory` VALUES ('450621', '', '0', '上思县', null, '', '0', '0', '450600');
INSERT INTO `t_s_territory` VALUES ('450681', '', '0', '东兴市', null, '', '0', '0', '450600');
INSERT INTO `t_s_territory` VALUES ('450700', '', '0', '钦州市', null, '', '0', '0', '450000');
INSERT INTO `t_s_territory` VALUES ('450701', '', '0', '市辖区', null, '', '0', '0', '450700');
INSERT INTO `t_s_territory` VALUES ('450702', '', '0', '钦南区', null, '', '0', '0', '450700');
INSERT INTO `t_s_territory` VALUES ('450703', '', '0', '钦北区', null, '', '0', '0', '450700');
INSERT INTO `t_s_territory` VALUES ('450721', '', '0', '灵山县', null, '', '0', '0', '450700');
INSERT INTO `t_s_territory` VALUES ('450722', '', '0', '浦北县', null, '', '0', '0', '450700');
INSERT INTO `t_s_territory` VALUES ('450800', '', '0', '贵港市', null, '', '0', '0', '450000');
INSERT INTO `t_s_territory` VALUES ('450801', '', '0', '市辖区', null, '', '0', '0', '450800');
INSERT INTO `t_s_territory` VALUES ('450802', '', '0', '港北区', null, '', '0', '0', '450800');
INSERT INTO `t_s_territory` VALUES ('450803', '', '0', '港南区', null, '', '0', '0', '450800');
INSERT INTO `t_s_territory` VALUES ('450804', '', '0', '覃塘区', null, '', '0', '0', '450800');
INSERT INTO `t_s_territory` VALUES ('450821', '', '0', '平南县', null, '', '0', '0', '450800');
INSERT INTO `t_s_territory` VALUES ('450881', '', '0', '桂平市', null, '', '0', '0', '450800');
INSERT INTO `t_s_territory` VALUES ('450900', '', '0', '玉林市', null, '', '0', '0', '450000');
INSERT INTO `t_s_territory` VALUES ('450901', '', '0', '市辖区', null, '', '0', '0', '450900');
INSERT INTO `t_s_territory` VALUES ('450902', '', '0', '玉州区', null, '', '0', '0', '450900');
INSERT INTO `t_s_territory` VALUES ('450903', '', '0', '福绵区', null, '', '0', '0', '450900');
INSERT INTO `t_s_territory` VALUES ('450921', '', '0', '容县', null, '', '0', '0', '450900');
INSERT INTO `t_s_territory` VALUES ('450922', '', '0', '陆川县', null, '', '0', '0', '450900');
INSERT INTO `t_s_territory` VALUES ('450923', '', '0', '博白县', null, '', '0', '0', '450900');
INSERT INTO `t_s_territory` VALUES ('450924', '', '0', '兴业县', null, '', '0', '0', '450900');
INSERT INTO `t_s_territory` VALUES ('450981', '', '0', '北流市', null, '', '0', '0', '450900');
INSERT INTO `t_s_territory` VALUES ('451000', '', '0', '百色市', null, '', '0', '0', '450000');
INSERT INTO `t_s_territory` VALUES ('451001', '', '0', '市辖区', null, '', '0', '0', '451000');
INSERT INTO `t_s_territory` VALUES ('451002', '', '0', '右江区', null, '', '0', '0', '451000');
INSERT INTO `t_s_territory` VALUES ('451021', '', '0', '田阳县', null, '', '0', '0', '451000');
INSERT INTO `t_s_territory` VALUES ('451022', '', '0', '田东县', null, '', '0', '0', '451000');
INSERT INTO `t_s_territory` VALUES ('451023', '', '0', '平果县', null, '', '0', '0', '451000');
INSERT INTO `t_s_territory` VALUES ('451024', '', '0', '德保县', null, '', '0', '0', '451000');
INSERT INTO `t_s_territory` VALUES ('451025', '', '0', '靖西县', null, '', '0', '0', '451000');
INSERT INTO `t_s_territory` VALUES ('451026', '', '0', '那坡县', null, '', '0', '0', '451000');
INSERT INTO `t_s_territory` VALUES ('451027', '', '0', '凌云县', null, '', '0', '0', '451000');
INSERT INTO `t_s_territory` VALUES ('451028', '', '0', '乐业县', null, '', '0', '0', '451000');
INSERT INTO `t_s_territory` VALUES ('451029', '', '0', '田林县', null, '', '0', '0', '451000');
INSERT INTO `t_s_territory` VALUES ('451030', '', '0', '西林县', null, '', '0', '0', '451000');
INSERT INTO `t_s_territory` VALUES ('451031', '', '0', '隆林各族自治县', null, '', '0', '0', '451000');
INSERT INTO `t_s_territory` VALUES ('451100', '', '0', '贺州市', null, '', '0', '0', '450000');
INSERT INTO `t_s_territory` VALUES ('451101', '', '0', '市辖区', null, '', '0', '0', '451100');
INSERT INTO `t_s_territory` VALUES ('451102', '', '0', '八步区', null, '', '0', '0', '451100');
INSERT INTO `t_s_territory` VALUES ('451121', '', '0', '昭平县', null, '', '0', '0', '451100');
INSERT INTO `t_s_territory` VALUES ('451122', '', '0', '钟山县', null, '', '0', '0', '451100');
INSERT INTO `t_s_territory` VALUES ('451123', '', '0', '富川瑶族自治县', null, '', '0', '0', '451100');
INSERT INTO `t_s_territory` VALUES ('451200', '', '0', '河池市', null, '', '0', '0', '450000');
INSERT INTO `t_s_territory` VALUES ('451201', '', '0', '市辖区', null, '', '0', '0', '451200');
INSERT INTO `t_s_territory` VALUES ('451202', '', '0', '金城江区', null, '', '0', '0', '451200');
INSERT INTO `t_s_territory` VALUES ('451221', '', '0', '南丹县', null, '', '0', '0', '451200');
INSERT INTO `t_s_territory` VALUES ('451222', '', '0', '天峨县', null, '', '0', '0', '451200');
INSERT INTO `t_s_territory` VALUES ('451223', '', '0', '凤山县', null, '', '0', '0', '451200');
INSERT INTO `t_s_territory` VALUES ('451224', '', '0', '东兰县', null, '', '0', '0', '451200');
INSERT INTO `t_s_territory` VALUES ('451225', '', '0', '罗城仫佬族自治县', null, '', '0', '0', '451200');
INSERT INTO `t_s_territory` VALUES ('451226', '', '0', '环江毛南族自治县', null, '', '0', '0', '451200');
INSERT INTO `t_s_territory` VALUES ('451227', '', '0', '巴马瑶族自治县', null, '', '0', '0', '451200');
INSERT INTO `t_s_territory` VALUES ('451228', '', '0', '都安瑶族自治县', null, '', '0', '0', '451200');
INSERT INTO `t_s_territory` VALUES ('451229', '', '0', '大化瑶族自治县', null, '', '0', '0', '451200');
INSERT INTO `t_s_territory` VALUES ('451281', '', '0', '宜州市', null, '', '0', '0', '451200');
INSERT INTO `t_s_territory` VALUES ('451300', '', '0', '来宾市', null, '', '0', '0', '450000');
INSERT INTO `t_s_territory` VALUES ('451301', '', '0', '市辖区', null, '', '0', '0', '451300');
INSERT INTO `t_s_territory` VALUES ('451302', '', '0', '兴宾区', null, '', '0', '0', '451300');
INSERT INTO `t_s_territory` VALUES ('451321', '', '0', '忻城县', null, '', '0', '0', '451300');
INSERT INTO `t_s_territory` VALUES ('451322', '', '0', '象州县', null, '', '0', '0', '451300');
INSERT INTO `t_s_territory` VALUES ('451323', '', '0', '武宣县', null, '', '0', '0', '451300');
INSERT INTO `t_s_territory` VALUES ('451324', '', '0', '金秀瑶族自治县', null, '', '0', '0', '451300');
INSERT INTO `t_s_territory` VALUES ('451381', '', '0', '合山市', null, '', '0', '0', '451300');
INSERT INTO `t_s_territory` VALUES ('451400', '', '0', '崇左市', null, '', '0', '0', '450000');
INSERT INTO `t_s_territory` VALUES ('451401', '', '0', '市辖区', null, '', '0', '0', '451400');
INSERT INTO `t_s_territory` VALUES ('451402', '', '0', '江州区', null, '', '0', '0', '451400');
INSERT INTO `t_s_territory` VALUES ('451421', '', '0', '扶绥县', null, '', '0', '0', '451400');
INSERT INTO `t_s_territory` VALUES ('451422', '', '0', '宁明县', null, '', '0', '0', '451400');
INSERT INTO `t_s_territory` VALUES ('451423', '', '0', '龙州县', null, '', '0', '0', '451400');
INSERT INTO `t_s_territory` VALUES ('451424', '', '0', '大新县', null, '', '0', '0', '451400');
INSERT INTO `t_s_territory` VALUES ('451425', '', '0', '天等县', null, '', '0', '0', '451400');
INSERT INTO `t_s_territory` VALUES ('451481', '', '0', '凭祥市', null, '', '0', '0', '451400');
INSERT INTO `t_s_territory` VALUES ('460000', '', '0', '海南省', null, '', '0', '0', '1');
INSERT INTO `t_s_territory` VALUES ('460100', '', '0', '海口市', null, '', '0', '0', '460000');
INSERT INTO `t_s_territory` VALUES ('460101', '', '0', '市辖区', null, '', '0', '0', '460100');
INSERT INTO `t_s_territory` VALUES ('460105', '', '0', '秀英区', null, '', '0', '0', '460100');
INSERT INTO `t_s_territory` VALUES ('460106', '', '0', '龙华区', null, '', '0', '0', '460100');
INSERT INTO `t_s_territory` VALUES ('460107', '', '0', '琼山区', null, '', '0', '0', '460100');
INSERT INTO `t_s_territory` VALUES ('460108', '', '0', '美兰区', null, '', '0', '0', '460100');
INSERT INTO `t_s_territory` VALUES ('460200', '', '0', '三亚市', null, '', '0', '0', '460000');
INSERT INTO `t_s_territory` VALUES ('460201', '', '0', '市辖区', null, '', '0', '0', '460200');
INSERT INTO `t_s_territory` VALUES ('460202', '', '0', '海棠区', null, '', '0', '0', '460200');
INSERT INTO `t_s_territory` VALUES ('460203', '', '0', '吉阳区', null, '', '0', '0', '460200');
INSERT INTO `t_s_territory` VALUES ('460204', '', '0', '天涯区', null, '', '0', '0', '460200');
INSERT INTO `t_s_territory` VALUES ('460205', '', '0', '崖州区', null, '', '0', '0', '460200');
INSERT INTO `t_s_territory` VALUES ('460300', '', '0', '三沙市', null, '', '0', '0', '460000');
INSERT INTO `t_s_territory` VALUES ('469001', '', '0', '五指山市', null, '', '0', '0', '460000');
INSERT INTO `t_s_territory` VALUES ('469002', '', '0', '琼海市', null, '', '0', '0', '460000');
INSERT INTO `t_s_territory` VALUES ('469003', '', '0', '儋州市', null, '', '0', '0', '460000');
INSERT INTO `t_s_territory` VALUES ('469005', '', '0', '文昌市', null, '', '0', '0', '460000');
INSERT INTO `t_s_territory` VALUES ('469006', '', '0', '万宁市', null, '', '0', '0', '460000');
INSERT INTO `t_s_territory` VALUES ('469007', '', '0', '东方市', null, '', '0', '0', '460000');
INSERT INTO `t_s_territory` VALUES ('469021', '', '0', '定安县', null, '', '0', '0', '460000');
INSERT INTO `t_s_territory` VALUES ('469022', '', '0', '屯昌县', null, '', '0', '0', '460000');
INSERT INTO `t_s_territory` VALUES ('469023', '', '0', '澄迈县', null, '', '0', '0', '460000');
INSERT INTO `t_s_territory` VALUES ('469024', '', '0', '临高县', null, '', '0', '0', '460000');
INSERT INTO `t_s_territory` VALUES ('469025', '', '0', '白沙黎族自治县', null, '', '0', '0', '460000');
INSERT INTO `t_s_territory` VALUES ('469026', '', '0', '昌江黎族自治县', null, '', '0', '0', '460000');
INSERT INTO `t_s_territory` VALUES ('469027', '', '0', '乐东黎族自治县', null, '', '0', '0', '460000');
INSERT INTO `t_s_territory` VALUES ('469028', '', '0', '陵水黎族自治县', null, '', '0', '0', '460000');
INSERT INTO `t_s_territory` VALUES ('469029', '', '0', '保亭黎族苗族自治县', null, '', '0', '0', '460000');
INSERT INTO `t_s_territory` VALUES ('469030', '', '0', '琼中黎族苗族自治县', null, '', '0', '0', '460000');
INSERT INTO `t_s_territory` VALUES ('500000', '', '1', '重庆', null, '8', '0', '0', '1');
INSERT INTO `t_s_territory` VALUES ('500100', '', '0', '重庆市', null, '', '0', '0', '500000');
INSERT INTO `t_s_territory` VALUES ('500101', '', '0', '万州区', null, '', '0', '0', '500100');
INSERT INTO `t_s_territory` VALUES ('500102', '', '0', '涪陵区', null, '', '0', '0', '500100');
INSERT INTO `t_s_territory` VALUES ('500103', '', '0', '渝中区', null, '', '0', '0', '500100');
INSERT INTO `t_s_territory` VALUES ('500104', '', '0', '大渡口区', null, '', '0', '0', '500100');
INSERT INTO `t_s_territory` VALUES ('500105', '', '0', '江北区', null, '', '0', '0', '500100');
INSERT INTO `t_s_territory` VALUES ('500106', '', '0', '沙坪坝区', null, '', '0', '0', '500100');
INSERT INTO `t_s_territory` VALUES ('500107', '', '0', '九龙坡区', null, '', '0', '0', '500100');
INSERT INTO `t_s_territory` VALUES ('500108', '', '0', '南岸区', null, '', '0', '0', '500100');
INSERT INTO `t_s_territory` VALUES ('500109', '', '0', '北碚区', null, '', '0', '0', '500100');
INSERT INTO `t_s_territory` VALUES ('500110', '', '0', '綦江区', null, '', '0', '0', '500100');
INSERT INTO `t_s_territory` VALUES ('500111', '', '0', '大足区', null, '', '0', '0', '500100');
INSERT INTO `t_s_territory` VALUES ('500112', '', '0', '渝北区', null, '', '0', '0', '500100');
INSERT INTO `t_s_territory` VALUES ('500113', '', '0', '巴南区', null, '', '0', '0', '500100');
INSERT INTO `t_s_territory` VALUES ('500114', '', '0', '黔江区', null, '', '0', '0', '500100');
INSERT INTO `t_s_territory` VALUES ('500115', '', '0', '长寿区', null, '', '0', '0', '500100');
INSERT INTO `t_s_territory` VALUES ('500116', '', '0', '江津区', null, '', '0', '0', '500100');
INSERT INTO `t_s_territory` VALUES ('500117', '', '0', '合川区', null, '', '0', '0', '500100');
INSERT INTO `t_s_territory` VALUES ('500118', '', '0', '永川区', null, '', '0', '0', '500100');
INSERT INTO `t_s_territory` VALUES ('500119', '', '0', '南川区', null, '', '0', '0', '500100');
INSERT INTO `t_s_territory` VALUES ('500120', '', '0', '璧山区', null, '', '0', '0', '500100');
INSERT INTO `t_s_territory` VALUES ('500151', '', '0', '铜梁区', null, '', '0', '0', '500100');
INSERT INTO `t_s_territory` VALUES ('500223', '', '0', '潼南县', null, '', '0', '0', '500100');
INSERT INTO `t_s_territory` VALUES ('500226', '', '0', '荣昌县', null, '', '0', '0', '500100');
INSERT INTO `t_s_territory` VALUES ('500228', '', '0', '梁平县', null, '', '0', '0', '500100');
INSERT INTO `t_s_territory` VALUES ('500229', '', '0', '城口县', null, '', '0', '0', '500100');
INSERT INTO `t_s_territory` VALUES ('500230', '', '0', '丰都县', null, '', '0', '0', '500100');
INSERT INTO `t_s_territory` VALUES ('500231', '', '0', '垫江县', null, '', '0', '0', '500100');
INSERT INTO `t_s_territory` VALUES ('500232', '', '0', '武隆县', null, '', '0', '0', '500100');
INSERT INTO `t_s_territory` VALUES ('500233', '', '0', '忠县', null, '', '0', '0', '500100');
INSERT INTO `t_s_territory` VALUES ('500234', '', '0', '开县', null, '', '0', '0', '500100');
INSERT INTO `t_s_territory` VALUES ('500235', '', '0', '云阳县', null, '', '0', '0', '500100');
INSERT INTO `t_s_territory` VALUES ('500236', '', '0', '奉节县', null, '', '0', '0', '500100');
INSERT INTO `t_s_territory` VALUES ('500237', '', '0', '巫山县', null, '', '0', '0', '500100');
INSERT INTO `t_s_territory` VALUES ('500238', '', '0', '巫溪县', null, '', '0', '0', '500100');
INSERT INTO `t_s_territory` VALUES ('500240', '', '0', '石柱土家族自治县', null, '', '0', '0', '500100');
INSERT INTO `t_s_territory` VALUES ('500241', '', '0', '秀山土家族苗族自治县', null, '', '0', '0', '500100');
INSERT INTO `t_s_territory` VALUES ('500242', '', '0', '酉阳土家族苗族自治县', null, '', '0', '0', '500100');
INSERT INTO `t_s_territory` VALUES ('500243', '', '0', '彭水苗族土家族自治县', null, '', '0', '0', '500100');
INSERT INTO `t_s_territory` VALUES ('510000', '', '0', '四川省', null, '', '0', '0', '1');
INSERT INTO `t_s_territory` VALUES ('510100', '', '0', '成都市', null, '', '0', '0', '510000');
INSERT INTO `t_s_territory` VALUES ('510101', '', '0', '市辖区', null, '', '0', '0', '510100');
INSERT INTO `t_s_territory` VALUES ('510104', '', '0', '锦江区', null, '', '0', '0', '510100');
INSERT INTO `t_s_territory` VALUES ('510105', '', '0', '青羊区', null, '', '0', '0', '510100');
INSERT INTO `t_s_territory` VALUES ('510106', '', '0', '金牛区', null, '', '0', '0', '510100');
INSERT INTO `t_s_territory` VALUES ('510107', '', '0', '武侯区', null, '', '0', '0', '510100');
INSERT INTO `t_s_territory` VALUES ('510108', '', '0', '成华区', null, '', '0', '0', '510100');
INSERT INTO `t_s_territory` VALUES ('510112', '', '0', '龙泉驿区', null, '', '0', '0', '510100');
INSERT INTO `t_s_territory` VALUES ('510113', '', '0', '青白江区', null, '', '0', '0', '510100');
INSERT INTO `t_s_territory` VALUES ('510114', '', '0', '新都区', null, '', '0', '0', '510100');
INSERT INTO `t_s_territory` VALUES ('510115', '', '0', '温江区', null, '', '0', '0', '510100');
INSERT INTO `t_s_territory` VALUES ('510121', '', '0', '金堂县', null, '', '0', '0', '510100');
INSERT INTO `t_s_territory` VALUES ('510122', '', '0', '双流县', null, '', '0', '0', '510100');
INSERT INTO `t_s_territory` VALUES ('510124', '', '0', '郫县', null, '', '0', '0', '510100');
INSERT INTO `t_s_territory` VALUES ('510129', '', '0', '大邑县', null, '', '0', '0', '510100');
INSERT INTO `t_s_territory` VALUES ('510131', '', '0', '蒲江县', null, '', '0', '0', '510100');
INSERT INTO `t_s_territory` VALUES ('510132', '', '0', '新津县', null, '', '0', '0', '510100');
INSERT INTO `t_s_territory` VALUES ('510181', '', '0', '都江堰市', null, '', '0', '0', '510100');
INSERT INTO `t_s_territory` VALUES ('510182', '', '0', '彭州市', null, '', '0', '0', '510100');
INSERT INTO `t_s_territory` VALUES ('510183', '', '0', '邛崃市', null, '', '0', '0', '510100');
INSERT INTO `t_s_territory` VALUES ('510184', '', '0', '崇州市', null, '', '0', '0', '510100');
INSERT INTO `t_s_territory` VALUES ('510300', '', '0', '自贡市', null, '', '0', '0', '510000');
INSERT INTO `t_s_territory` VALUES ('510301', '', '0', '市辖区', null, '', '0', '0', '510300');
INSERT INTO `t_s_territory` VALUES ('510302', '', '0', '自流井区', null, '', '0', '0', '510300');
INSERT INTO `t_s_territory` VALUES ('510303', '', '0', '贡井区', null, '', '0', '0', '510300');
INSERT INTO `t_s_territory` VALUES ('510304', '', '0', '大安区', null, '', '0', '0', '510300');
INSERT INTO `t_s_territory` VALUES ('510311', '', '0', '沿滩区', null, '', '0', '0', '510300');
INSERT INTO `t_s_territory` VALUES ('510321', '', '0', '荣县', null, '', '0', '0', '510300');
INSERT INTO `t_s_territory` VALUES ('510322', '', '0', '富顺县', null, '', '0', '0', '510300');
INSERT INTO `t_s_territory` VALUES ('510400', '', '0', '攀枝花市', null, '', '0', '0', '510000');
INSERT INTO `t_s_territory` VALUES ('510401', '', '0', '市辖区', null, '', '0', '0', '510400');
INSERT INTO `t_s_territory` VALUES ('510402', '', '0', '东区', null, '', '0', '0', '510400');
INSERT INTO `t_s_territory` VALUES ('510403', '', '0', '西区', null, '', '0', '0', '510400');
INSERT INTO `t_s_territory` VALUES ('510411', '', '0', '仁和区', null, '', '0', '0', '510400');
INSERT INTO `t_s_territory` VALUES ('510421', '', '0', '米易县', null, '', '0', '0', '510400');
INSERT INTO `t_s_territory` VALUES ('510422', '', '0', '盐边县', null, '', '0', '0', '510400');
INSERT INTO `t_s_territory` VALUES ('510500', '', '0', '泸州市', null, '', '0', '0', '510000');
INSERT INTO `t_s_territory` VALUES ('510501', '', '0', '市辖区', null, '', '0', '0', '510500');
INSERT INTO `t_s_territory` VALUES ('510502', '', '0', '江阳区', null, '', '0', '0', '510500');
INSERT INTO `t_s_territory` VALUES ('510503', '', '0', '纳溪区', null, '', '0', '0', '510500');
INSERT INTO `t_s_territory` VALUES ('510504', '', '0', '龙马潭区', null, '', '0', '0', '510500');
INSERT INTO `t_s_territory` VALUES ('510521', '', '0', '泸县', null, '', '0', '0', '510500');
INSERT INTO `t_s_territory` VALUES ('510522', '', '0', '合江县', null, '', '0', '0', '510500');
INSERT INTO `t_s_territory` VALUES ('510524', '', '0', '叙永县', null, '', '0', '0', '510500');
INSERT INTO `t_s_territory` VALUES ('510525', '', '0', '古蔺县', null, '', '0', '0', '510500');
INSERT INTO `t_s_territory` VALUES ('510600', '', '0', '德阳市', null, '', '0', '0', '510000');
INSERT INTO `t_s_territory` VALUES ('510601', '', '0', '市辖区', null, '', '0', '0', '510600');
INSERT INTO `t_s_territory` VALUES ('510603', '', '0', '旌阳区', null, '', '0', '0', '510600');
INSERT INTO `t_s_territory` VALUES ('510623', '', '0', '中江县', null, '', '0', '0', '510600');
INSERT INTO `t_s_territory` VALUES ('510626', '', '0', '罗江县', null, '', '0', '0', '510600');
INSERT INTO `t_s_territory` VALUES ('510681', '', '0', '广汉市', null, '', '0', '0', '510600');
INSERT INTO `t_s_territory` VALUES ('510682', '', '0', '什邡市', null, '', '0', '0', '510600');
INSERT INTO `t_s_territory` VALUES ('510683', '', '0', '绵竹市', null, '', '0', '0', '510600');
INSERT INTO `t_s_territory` VALUES ('510700', '', '0', '绵阳市', null, '', '0', '0', '510000');
INSERT INTO `t_s_territory` VALUES ('510701', '', '0', '市辖区', null, '', '0', '0', '510700');
INSERT INTO `t_s_territory` VALUES ('510703', '', '0', '涪城区', null, '', '0', '0', '510700');
INSERT INTO `t_s_territory` VALUES ('510704', '', '0', '游仙区', null, '', '0', '0', '510700');
INSERT INTO `t_s_territory` VALUES ('510722', '', '0', '三台县', null, '', '0', '0', '510700');
INSERT INTO `t_s_territory` VALUES ('510723', '', '0', '盐亭县', null, '', '0', '0', '510700');
INSERT INTO `t_s_territory` VALUES ('510724', '', '0', '安县', null, '', '0', '0', '510700');
INSERT INTO `t_s_territory` VALUES ('510725', '', '0', '梓潼县', null, '', '0', '0', '510700');
INSERT INTO `t_s_territory` VALUES ('510726', '', '0', '北川羌族自治县', null, '', '0', '0', '510700');
INSERT INTO `t_s_territory` VALUES ('510727', '', '0', '平武县', null, '', '0', '0', '510700');
INSERT INTO `t_s_territory` VALUES ('510781', '', '0', '江油市', null, '', '0', '0', '510700');
INSERT INTO `t_s_territory` VALUES ('510800', '', '0', '广元市', null, '', '0', '0', '510000');
INSERT INTO `t_s_territory` VALUES ('510801', '', '0', '市辖区', null, '', '0', '0', '510800');
INSERT INTO `t_s_territory` VALUES ('510802', '', '0', '利州区', null, '', '0', '0', '510800');
INSERT INTO `t_s_territory` VALUES ('510811', '', '0', '昭化区', null, '', '0', '0', '510800');
INSERT INTO `t_s_territory` VALUES ('510812', '', '0', '朝天区', null, '', '0', '0', '510800');
INSERT INTO `t_s_territory` VALUES ('510821', '', '0', '旺苍县', null, '', '0', '0', '510800');
INSERT INTO `t_s_territory` VALUES ('510822', '', '0', '青川县', null, '', '0', '0', '510800');
INSERT INTO `t_s_territory` VALUES ('510823', '', '0', '剑阁县', null, '', '0', '0', '510800');
INSERT INTO `t_s_territory` VALUES ('510824', '', '0', '苍溪县', null, '', '0', '0', '510800');
INSERT INTO `t_s_territory` VALUES ('510900', '', '0', '遂宁市', null, '', '0', '0', '510000');
INSERT INTO `t_s_territory` VALUES ('510901', '', '0', '市辖区', null, '', '0', '0', '510900');
INSERT INTO `t_s_territory` VALUES ('510903', '', '0', '船山区', null, '', '0', '0', '510900');
INSERT INTO `t_s_territory` VALUES ('510904', '', '0', '安居区', null, '', '0', '0', '510900');
INSERT INTO `t_s_territory` VALUES ('510921', '', '0', '蓬溪县', null, '', '0', '0', '510900');
INSERT INTO `t_s_territory` VALUES ('510922', '', '0', '射洪县', null, '', '0', '0', '510900');
INSERT INTO `t_s_territory` VALUES ('510923', '', '0', '大英县', null, '', '0', '0', '510900');
INSERT INTO `t_s_territory` VALUES ('511000', '', '0', '内江市', null, '', '0', '0', '510000');
INSERT INTO `t_s_territory` VALUES ('511001', '', '0', '市辖区', null, '', '0', '0', '511000');
INSERT INTO `t_s_territory` VALUES ('511002', '', '0', '市中区', null, '', '0', '0', '511000');
INSERT INTO `t_s_territory` VALUES ('511011', '', '0', '东兴区', null, '', '0', '0', '511000');
INSERT INTO `t_s_territory` VALUES ('511024', '', '0', '威远县', null, '', '0', '0', '511000');
INSERT INTO `t_s_territory` VALUES ('511025', '', '0', '资中县', null, '', '0', '0', '511000');
INSERT INTO `t_s_territory` VALUES ('511028', '', '0', '隆昌县', null, '', '0', '0', '511000');
INSERT INTO `t_s_territory` VALUES ('511100', '', '0', '乐山市', null, '', '0', '0', '510000');
INSERT INTO `t_s_territory` VALUES ('511101', '', '0', '市辖区', null, '', '0', '0', '511100');
INSERT INTO `t_s_territory` VALUES ('511102', '', '0', '市中区', null, '', '0', '0', '511100');
INSERT INTO `t_s_territory` VALUES ('511111', '', '0', '沙湾区', null, '', '0', '0', '511100');
INSERT INTO `t_s_territory` VALUES ('511112', '', '0', '五通桥区', null, '', '0', '0', '511100');
INSERT INTO `t_s_territory` VALUES ('511113', '', '0', '金口河区', null, '', '0', '0', '511100');
INSERT INTO `t_s_territory` VALUES ('511123', '', '0', '犍为县', null, '', '0', '0', '511100');
INSERT INTO `t_s_territory` VALUES ('511124', '', '0', '井研县', null, '', '0', '0', '511100');
INSERT INTO `t_s_territory` VALUES ('511126', '', '0', '夹江县', null, '', '0', '0', '511100');
INSERT INTO `t_s_territory` VALUES ('511129', '', '0', '沐川县', null, '', '0', '0', '511100');
INSERT INTO `t_s_territory` VALUES ('511132', '', '0', '峨边彝族自治县', null, '', '0', '0', '511100');
INSERT INTO `t_s_territory` VALUES ('511133', '', '0', '马边彝族自治县', null, '', '0', '0', '511100');
INSERT INTO `t_s_territory` VALUES ('511181', '', '0', '峨眉山市', null, '', '0', '0', '511100');
INSERT INTO `t_s_territory` VALUES ('511300', '', '0', '南充市', null, '', '0', '0', '510000');
INSERT INTO `t_s_territory` VALUES ('511301', '', '0', '市辖区', null, '', '0', '0', '511300');
INSERT INTO `t_s_territory` VALUES ('511302', '', '0', '顺庆区', null, '', '0', '0', '511300');
INSERT INTO `t_s_territory` VALUES ('511303', '', '0', '高坪区', null, '', '0', '0', '511300');
INSERT INTO `t_s_territory` VALUES ('511304', '', '0', '嘉陵区', null, '', '0', '0', '511300');
INSERT INTO `t_s_territory` VALUES ('511321', '', '0', '南部县', null, '', '0', '0', '511300');
INSERT INTO `t_s_territory` VALUES ('511322', '', '0', '营山县', null, '', '0', '0', '511300');
INSERT INTO `t_s_territory` VALUES ('511323', '', '0', '蓬安县', null, '', '0', '0', '511300');
INSERT INTO `t_s_territory` VALUES ('511324', '', '0', '仪陇县', null, '', '0', '0', '511300');
INSERT INTO `t_s_territory` VALUES ('511325', '', '0', '西充县', null, '', '0', '0', '511300');
INSERT INTO `t_s_territory` VALUES ('511381', '', '0', '阆中市', null, '', '0', '0', '511300');
INSERT INTO `t_s_territory` VALUES ('511400', '', '0', '眉山市', null, '', '0', '0', '510000');
INSERT INTO `t_s_territory` VALUES ('511401', '', '0', '市辖区', null, '', '0', '0', '511400');
INSERT INTO `t_s_territory` VALUES ('511402', '', '0', '东坡区', null, '', '0', '0', '511400');
INSERT INTO `t_s_territory` VALUES ('511421', '', '0', '仁寿县', null, '', '0', '0', '511400');
INSERT INTO `t_s_territory` VALUES ('511422', '', '0', '彭山县', null, '', '0', '0', '511400');
INSERT INTO `t_s_territory` VALUES ('511423', '', '0', '洪雅县', null, '', '0', '0', '511400');
INSERT INTO `t_s_territory` VALUES ('511424', '', '0', '丹棱县', null, '', '0', '0', '511400');
INSERT INTO `t_s_territory` VALUES ('511425', '', '0', '青神县', null, '', '0', '0', '511400');
INSERT INTO `t_s_territory` VALUES ('511500', '', '0', '宜宾市', null, '', '0', '0', '510000');
INSERT INTO `t_s_territory` VALUES ('511501', '', '0', '市辖区', null, '', '0', '0', '511500');
INSERT INTO `t_s_territory` VALUES ('511502', '', '0', '翠屏区', null, '', '0', '0', '511500');
INSERT INTO `t_s_territory` VALUES ('511503', '', '0', '南溪区', null, '', '0', '0', '511500');
INSERT INTO `t_s_territory` VALUES ('511521', '', '0', '宜宾县', null, '', '0', '0', '511500');
INSERT INTO `t_s_territory` VALUES ('511523', '', '0', '江安县', null, '', '0', '0', '511500');
INSERT INTO `t_s_territory` VALUES ('511524', '', '0', '长宁县', null, '', '0', '0', '511500');
INSERT INTO `t_s_territory` VALUES ('511525', '', '0', '高县', null, '', '0', '0', '511500');
INSERT INTO `t_s_territory` VALUES ('511526', '', '0', '珙县', null, '', '0', '0', '511500');
INSERT INTO `t_s_territory` VALUES ('511527', '', '0', '筠连县', null, '', '0', '0', '511500');
INSERT INTO `t_s_territory` VALUES ('511528', '', '0', '兴文县', null, '', '0', '0', '511500');
INSERT INTO `t_s_territory` VALUES ('511529', '', '0', '屏山县', null, '', '0', '0', '511500');
INSERT INTO `t_s_territory` VALUES ('511600', '', '0', '广安市', null, '', '0', '0', '510000');
INSERT INTO `t_s_territory` VALUES ('511601', '', '0', '市辖区', null, '', '0', '0', '511600');
INSERT INTO `t_s_territory` VALUES ('511602', '', '0', '广安区', null, '', '0', '0', '511600');
INSERT INTO `t_s_territory` VALUES ('511603', '', '0', '前锋区', null, '', '0', '0', '511600');
INSERT INTO `t_s_territory` VALUES ('511621', '', '0', '岳池县', null, '', '0', '0', '511600');
INSERT INTO `t_s_territory` VALUES ('511622', '', '0', '武胜县', null, '', '0', '0', '511600');
INSERT INTO `t_s_territory` VALUES ('511623', '', '0', '邻水县', null, '', '0', '0', '511600');
INSERT INTO `t_s_territory` VALUES ('511681', '', '0', '华蓥市', null, '', '0', '0', '511600');
INSERT INTO `t_s_territory` VALUES ('511700', '', '0', '达州市', null, '', '0', '0', '510000');
INSERT INTO `t_s_territory` VALUES ('511701', '', '0', '市辖区', null, '', '0', '0', '511700');
INSERT INTO `t_s_territory` VALUES ('511702', '', '0', '通川区', null, '', '0', '0', '511700');
INSERT INTO `t_s_territory` VALUES ('511703', '', '0', '达川区', null, '', '0', '0', '511700');
INSERT INTO `t_s_territory` VALUES ('511722', '', '0', '宣汉县', null, '', '0', '0', '511700');
INSERT INTO `t_s_territory` VALUES ('511723', '', '0', '开江县', null, '', '0', '0', '511700');
INSERT INTO `t_s_territory` VALUES ('511724', '', '0', '大竹县', null, '', '0', '0', '511700');
INSERT INTO `t_s_territory` VALUES ('511725', '', '0', '渠县', null, '', '0', '0', '511700');
INSERT INTO `t_s_territory` VALUES ('511781', '', '0', '万源市', null, '', '0', '0', '511700');
INSERT INTO `t_s_territory` VALUES ('511800', '', '0', '雅安市', null, '', '0', '0', '510000');
INSERT INTO `t_s_territory` VALUES ('511801', '', '0', '市辖区', null, '', '0', '0', '511800');
INSERT INTO `t_s_territory` VALUES ('511802', '', '0', '雨城区', null, '', '0', '0', '511800');
INSERT INTO `t_s_territory` VALUES ('511803', '', '0', '名山区', null, '', '0', '0', '511800');
INSERT INTO `t_s_territory` VALUES ('511822', '', '0', '荥经县', null, '', '0', '0', '511800');
INSERT INTO `t_s_territory` VALUES ('511823', '', '0', '汉源县', null, '', '0', '0', '511800');
INSERT INTO `t_s_territory` VALUES ('511824', '', '0', '石棉县', null, '', '0', '0', '511800');
INSERT INTO `t_s_territory` VALUES ('511825', '', '0', '天全县', null, '', '0', '0', '511800');
INSERT INTO `t_s_territory` VALUES ('511826', '', '0', '芦山县', null, '', '0', '0', '511800');
INSERT INTO `t_s_territory` VALUES ('511827', '', '0', '宝兴县', null, '', '0', '0', '511800');
INSERT INTO `t_s_territory` VALUES ('511900', '', '0', '巴中市', null, '', '0', '0', '510000');
INSERT INTO `t_s_territory` VALUES ('511901', '', '0', '市辖区', null, '', '0', '0', '511900');
INSERT INTO `t_s_territory` VALUES ('511902', '', '0', '巴州区', null, '', '0', '0', '511900');
INSERT INTO `t_s_territory` VALUES ('511903', '', '0', '恩阳区', null, '', '0', '0', '511900');
INSERT INTO `t_s_territory` VALUES ('511921', '', '0', '通江县', null, '', '0', '0', '511900');
INSERT INTO `t_s_territory` VALUES ('511922', '', '0', '南江县', null, '', '0', '0', '511900');
INSERT INTO `t_s_territory` VALUES ('511923', '', '0', '平昌县', null, '', '0', '0', '511900');
INSERT INTO `t_s_territory` VALUES ('512000', '', '0', '资阳市', null, '', '0', '0', '510000');
INSERT INTO `t_s_territory` VALUES ('512001', '', '0', '市辖区', null, '', '0', '0', '512000');
INSERT INTO `t_s_territory` VALUES ('512002', '', '0', '雁江区', null, '', '0', '0', '512000');
INSERT INTO `t_s_territory` VALUES ('512021', '', '0', '安岳县', null, '', '0', '0', '512000');
INSERT INTO `t_s_territory` VALUES ('512022', '', '0', '乐至县', null, '', '0', '0', '512000');
INSERT INTO `t_s_territory` VALUES ('512081', '', '0', '简阳市', null, '', '0', '0', '512000');
INSERT INTO `t_s_territory` VALUES ('513200', '', '0', '阿坝藏族羌族自治州', null, '', '0', '0', '510000');
INSERT INTO `t_s_territory` VALUES ('513221', '', '0', '汶川县', null, '', '0', '0', '513200');
INSERT INTO `t_s_territory` VALUES ('513222', '', '0', '理县', null, '', '0', '0', '513200');
INSERT INTO `t_s_territory` VALUES ('513223', '', '0', '茂县', null, '', '0', '0', '513200');
INSERT INTO `t_s_territory` VALUES ('513224', '', '0', '松潘县', null, '', '0', '0', '513200');
INSERT INTO `t_s_territory` VALUES ('513225', '', '0', '九寨沟县', null, '', '0', '0', '513200');
INSERT INTO `t_s_territory` VALUES ('513226', '', '0', '金川县', null, '', '0', '0', '513200');
INSERT INTO `t_s_territory` VALUES ('513227', '', '0', '小金县', null, '', '0', '0', '513200');
INSERT INTO `t_s_territory` VALUES ('513228', '', '0', '黑水县', null, '', '0', '0', '513200');
INSERT INTO `t_s_territory` VALUES ('513229', '', '0', '马尔康县', null, '', '0', '0', '513200');
INSERT INTO `t_s_territory` VALUES ('513230', '', '0', '壤塘县', null, '', '0', '0', '513200');
INSERT INTO `t_s_territory` VALUES ('513231', '', '0', '阿坝县', null, '', '0', '0', '513200');
INSERT INTO `t_s_territory` VALUES ('513232', '', '0', '若尔盖县', null, '', '0', '0', '513200');
INSERT INTO `t_s_territory` VALUES ('513233', '', '0', '红原县', null, '', '0', '0', '513200');
INSERT INTO `t_s_territory` VALUES ('513300', '', '0', '甘孜藏族自治州', null, '', '0', '0', '510000');
INSERT INTO `t_s_territory` VALUES ('513321', '', '0', '康定县', null, '', '0', '0', '513300');
INSERT INTO `t_s_territory` VALUES ('513322', '', '0', '泸定县', null, '', '0', '0', '513300');
INSERT INTO `t_s_territory` VALUES ('513323', '', '0', '丹巴县', null, '', '0', '0', '513300');
INSERT INTO `t_s_territory` VALUES ('513324', '', '0', '九龙县', null, '', '0', '0', '513300');
INSERT INTO `t_s_territory` VALUES ('513325', '', '0', '雅江县', null, '', '0', '0', '513300');
INSERT INTO `t_s_territory` VALUES ('513326', '', '0', '道孚县', null, '', '0', '0', '513300');
INSERT INTO `t_s_territory` VALUES ('513327', '', '0', '炉霍县', null, '', '0', '0', '513300');
INSERT INTO `t_s_territory` VALUES ('513328', '', '0', '甘孜县', null, '', '0', '0', '513300');
INSERT INTO `t_s_territory` VALUES ('513329', '', '0', '新龙县', null, '', '0', '0', '513300');
INSERT INTO `t_s_territory` VALUES ('513330', '', '0', '德格县', null, '', '0', '0', '513300');
INSERT INTO `t_s_territory` VALUES ('513331', '', '0', '白玉县', null, '', '0', '0', '513300');
INSERT INTO `t_s_territory` VALUES ('513332', '', '0', '石渠县', null, '', '0', '0', '513300');
INSERT INTO `t_s_territory` VALUES ('513333', '', '0', '色达县', null, '', '0', '0', '513300');
INSERT INTO `t_s_territory` VALUES ('513334', '', '0', '理塘县', null, '', '0', '0', '513300');
INSERT INTO `t_s_territory` VALUES ('513335', '', '0', '巴塘县', null, '', '0', '0', '513300');
INSERT INTO `t_s_territory` VALUES ('513336', '', '0', '乡城县', null, '', '0', '0', '513300');
INSERT INTO `t_s_territory` VALUES ('513337', '', '0', '稻城县', null, '', '0', '0', '513300');
INSERT INTO `t_s_territory` VALUES ('513338', '', '0', '得荣县', null, '', '0', '0', '513300');
INSERT INTO `t_s_territory` VALUES ('513400', '', '0', '凉山彝族自治州', null, '', '0', '0', '510000');
INSERT INTO `t_s_territory` VALUES ('513401', '', '0', '西昌市', null, '', '0', '0', '513400');
INSERT INTO `t_s_territory` VALUES ('513422', '', '0', '木里藏族自治县', null, '', '0', '0', '513400');
INSERT INTO `t_s_territory` VALUES ('513423', '', '0', '盐源县', null, '', '0', '0', '513400');
INSERT INTO `t_s_territory` VALUES ('513424', '', '0', '德昌县', null, '', '0', '0', '513400');
INSERT INTO `t_s_territory` VALUES ('513425', '', '0', '会理县', null, '', '0', '0', '513400');
INSERT INTO `t_s_territory` VALUES ('513426', '', '0', '会东县', null, '', '0', '0', '513400');
INSERT INTO `t_s_territory` VALUES ('513427', '', '0', '宁南县', null, '', '0', '0', '513400');
INSERT INTO `t_s_territory` VALUES ('513428', '', '0', '普格县', null, '', '0', '0', '513400');
INSERT INTO `t_s_territory` VALUES ('513429', '', '0', '布拖县', null, '', '0', '0', '513400');
INSERT INTO `t_s_territory` VALUES ('513430', '', '0', '金阳县', null, '', '0', '0', '513400');
INSERT INTO `t_s_territory` VALUES ('513431', '', '0', '昭觉县', null, '', '0', '0', '513400');
INSERT INTO `t_s_territory` VALUES ('513432', '', '0', '喜德县', null, '', '0', '0', '513400');
INSERT INTO `t_s_territory` VALUES ('513433', '', '0', '冕宁县', null, '', '0', '0', '513400');
INSERT INTO `t_s_territory` VALUES ('513434', '', '0', '越西县', null, '', '0', '0', '513400');
INSERT INTO `t_s_territory` VALUES ('513435', '', '0', '甘洛县', null, '', '0', '0', '513400');
INSERT INTO `t_s_territory` VALUES ('513436', '', '0', '美姑县', null, '', '0', '0', '513400');
INSERT INTO `t_s_territory` VALUES ('513437', '', '0', '雷波县', null, '', '0', '0', '513400');
INSERT INTO `t_s_territory` VALUES ('520000', '', '0', '贵州省', null, '', '0', '0', '1');
INSERT INTO `t_s_territory` VALUES ('520100', '', '0', '贵阳市', null, '', '0', '0', '520000');
INSERT INTO `t_s_territory` VALUES ('520101', '', '0', '市辖区', null, '', '0', '0', '520100');
INSERT INTO `t_s_territory` VALUES ('520102', '', '0', '南明区', null, '', '0', '0', '520100');
INSERT INTO `t_s_territory` VALUES ('520103', '', '0', '云岩区', null, '', '0', '0', '520100');
INSERT INTO `t_s_territory` VALUES ('520111', '', '0', '花溪区', null, '', '0', '0', '520100');
INSERT INTO `t_s_territory` VALUES ('520112', '', '0', '乌当区', null, '', '0', '0', '520100');
INSERT INTO `t_s_territory` VALUES ('520113', '', '0', '白云区', null, '', '0', '0', '520100');
INSERT INTO `t_s_territory` VALUES ('520115', '', '0', '观山湖区', null, '', '0', '0', '520100');
INSERT INTO `t_s_territory` VALUES ('520121', '', '0', '开阳县', null, '', '0', '0', '520100');
INSERT INTO `t_s_territory` VALUES ('520122', '', '0', '息烽县', null, '', '0', '0', '520100');
INSERT INTO `t_s_territory` VALUES ('520123', '', '0', '修文县', null, '', '0', '0', '520100');
INSERT INTO `t_s_territory` VALUES ('520181', '', '0', '清镇市', null, '', '0', '0', '520100');
INSERT INTO `t_s_territory` VALUES ('520200', '', '0', '六盘水市', null, '', '0', '0', '520000');
INSERT INTO `t_s_territory` VALUES ('520201', '', '0', '钟山区', null, '', '0', '0', '520200');
INSERT INTO `t_s_territory` VALUES ('520203', '', '0', '六枝特区', null, '', '0', '0', '520200');
INSERT INTO `t_s_territory` VALUES ('520221', '', '0', '水城县', null, '', '0', '0', '520200');
INSERT INTO `t_s_territory` VALUES ('520222', '', '0', '盘县', null, '', '0', '0', '520200');
INSERT INTO `t_s_territory` VALUES ('520300', '', '0', '遵义市', null, '', '0', '0', '520000');
INSERT INTO `t_s_territory` VALUES ('520301', '', '0', '市辖区', null, '', '0', '0', '520300');
INSERT INTO `t_s_territory` VALUES ('520302', '', '0', '红花岗区', null, '', '0', '0', '520300');
INSERT INTO `t_s_territory` VALUES ('520303', '', '0', '汇川区', null, '', '0', '0', '520300');
INSERT INTO `t_s_territory` VALUES ('520321', '', '0', '遵义县', null, '', '0', '0', '520300');
INSERT INTO `t_s_territory` VALUES ('520322', '', '0', '桐梓县', null, '', '0', '0', '520300');
INSERT INTO `t_s_territory` VALUES ('520323', '', '0', '绥阳县', null, '', '0', '0', '520300');
INSERT INTO `t_s_territory` VALUES ('520324', '', '0', '正安县', null, '', '0', '0', '520300');
INSERT INTO `t_s_territory` VALUES ('520325', '', '0', '道真仡佬族苗族自治县', null, '', '0', '0', '520300');
INSERT INTO `t_s_territory` VALUES ('520326', '', '0', '务川仡佬族苗族自治县', null, '', '0', '0', '520300');
INSERT INTO `t_s_territory` VALUES ('520327', '', '0', '凤冈县', null, '', '0', '0', '520300');
INSERT INTO `t_s_territory` VALUES ('520328', '', '0', '湄潭县', null, '', '0', '0', '520300');
INSERT INTO `t_s_territory` VALUES ('520329', '', '0', '余庆县', null, '', '0', '0', '520300');
INSERT INTO `t_s_territory` VALUES ('520330', '', '0', '习水县', null, '', '0', '0', '520300');
INSERT INTO `t_s_territory` VALUES ('520381', '', '0', '赤水市', null, '', '0', '0', '520300');
INSERT INTO `t_s_territory` VALUES ('520382', '', '0', '仁怀市', null, '', '0', '0', '520300');
INSERT INTO `t_s_territory` VALUES ('520400', '', '0', '安顺市', null, '', '0', '0', '520000');
INSERT INTO `t_s_territory` VALUES ('520401', '', '0', '市辖区', null, '', '0', '0', '520400');
INSERT INTO `t_s_territory` VALUES ('520402', '', '0', '西秀区', null, '', '0', '0', '520400');
INSERT INTO `t_s_territory` VALUES ('520421', '', '0', '平坝县', null, '', '0', '0', '520400');
INSERT INTO `t_s_territory` VALUES ('520422', '', '0', '普定县', null, '', '0', '0', '520400');
INSERT INTO `t_s_territory` VALUES ('520423', '', '0', '镇宁布依族苗族自治县', null, '', '0', '0', '520400');
INSERT INTO `t_s_territory` VALUES ('520424', '', '0', '关岭布依族苗族自治县', null, '', '0', '0', '520400');
INSERT INTO `t_s_territory` VALUES ('520425', '', '0', '紫云苗族布依族自治县', null, '', '0', '0', '520400');
INSERT INTO `t_s_territory` VALUES ('520500', '', '0', '毕节市', null, '', '0', '0', '520000');
INSERT INTO `t_s_territory` VALUES ('520501', '', '0', '市辖区', null, '', '0', '0', '520500');
INSERT INTO `t_s_territory` VALUES ('520502', '', '0', '七星关区', null, '', '0', '0', '520500');
INSERT INTO `t_s_territory` VALUES ('520521', '', '0', '大方县', null, '', '0', '0', '520500');
INSERT INTO `t_s_territory` VALUES ('520522', '', '0', '黔西县', null, '', '0', '0', '520500');
INSERT INTO `t_s_territory` VALUES ('520523', '', '0', '金沙县', null, '', '0', '0', '520500');
INSERT INTO `t_s_territory` VALUES ('520524', '', '0', '织金县', null, '', '0', '0', '520500');
INSERT INTO `t_s_territory` VALUES ('520525', '', '0', '纳雍县', null, '', '0', '0', '520500');
INSERT INTO `t_s_territory` VALUES ('520526', '', '0', '威宁彝族回族苗族自治县', null, '', '0', '0', '520500');
INSERT INTO `t_s_territory` VALUES ('520527', '', '0', '赫章县', null, '', '0', '0', '520500');
INSERT INTO `t_s_territory` VALUES ('520600', '', '0', '铜仁市', null, '', '0', '0', '520000');
INSERT INTO `t_s_territory` VALUES ('520601', '', '0', '市辖区', null, '', '0', '0', '520600');
INSERT INTO `t_s_territory` VALUES ('520602', '', '0', '碧江区', null, '', '0', '0', '520600');
INSERT INTO `t_s_territory` VALUES ('520603', '', '0', '万山区', null, '', '0', '0', '520600');
INSERT INTO `t_s_territory` VALUES ('520621', '', '0', '江口县', null, '', '0', '0', '520600');
INSERT INTO `t_s_territory` VALUES ('520622', '', '0', '玉屏侗族自治县', null, '', '0', '0', '520600');
INSERT INTO `t_s_territory` VALUES ('520623', '', '0', '石阡县', null, '', '0', '0', '520600');
INSERT INTO `t_s_territory` VALUES ('520624', '', '0', '思南县', null, '', '0', '0', '520600');
INSERT INTO `t_s_territory` VALUES ('520625', '', '0', '印江土家族苗族自治县', null, '', '0', '0', '520600');
INSERT INTO `t_s_territory` VALUES ('520626', '', '0', '德江县', null, '', '0', '0', '520600');
INSERT INTO `t_s_territory` VALUES ('520627', '', '0', '沿河土家族自治县', null, '', '0', '0', '520600');
INSERT INTO `t_s_territory` VALUES ('520628', '', '0', '松桃苗族自治县', null, '', '0', '0', '520600');
INSERT INTO `t_s_territory` VALUES ('522300', '', '0', '黔西南布依族苗族自治州', null, '', '0', '0', '520000');
INSERT INTO `t_s_territory` VALUES ('522301', '', '0', '兴义市', null, '', '0', '0', '522300');
INSERT INTO `t_s_territory` VALUES ('522322', '', '0', '兴仁县', null, '', '0', '0', '522300');
INSERT INTO `t_s_territory` VALUES ('522323', '', '0', '普安县', null, '', '0', '0', '522300');
INSERT INTO `t_s_territory` VALUES ('522324', '', '0', '晴隆县', null, '', '0', '0', '522300');
INSERT INTO `t_s_territory` VALUES ('522325', '', '0', '贞丰县', null, '', '0', '0', '522300');
INSERT INTO `t_s_territory` VALUES ('522326', '', '0', '望谟县', null, '', '0', '0', '522300');
INSERT INTO `t_s_territory` VALUES ('522327', '', '0', '册亨县', null, '', '0', '0', '522300');
INSERT INTO `t_s_territory` VALUES ('522328', '', '0', '安龙县', null, '', '0', '0', '522300');
INSERT INTO `t_s_territory` VALUES ('522600', '', '0', '黔东南苗族侗族自治州', null, '', '0', '0', '520000');
INSERT INTO `t_s_territory` VALUES ('522601', '', '0', '凯里市', null, '', '0', '0', '522600');
INSERT INTO `t_s_territory` VALUES ('522622', '', '0', '黄平县', null, '', '0', '0', '522600');
INSERT INTO `t_s_territory` VALUES ('522623', '', '0', '施秉县', null, '', '0', '0', '522600');
INSERT INTO `t_s_territory` VALUES ('522624', '', '0', '三穗县', null, '', '0', '0', '522600');
INSERT INTO `t_s_territory` VALUES ('522625', '', '0', '镇远县', null, '', '0', '0', '522600');
INSERT INTO `t_s_territory` VALUES ('522626', '', '0', '岑巩县', null, '', '0', '0', '522600');
INSERT INTO `t_s_territory` VALUES ('522627', '', '0', '天柱县', null, '', '0', '0', '522600');
INSERT INTO `t_s_territory` VALUES ('522628', '', '0', '锦屏县', null, '', '0', '0', '522600');
INSERT INTO `t_s_territory` VALUES ('522629', '', '0', '剑河县', null, '', '0', '0', '522600');
INSERT INTO `t_s_territory` VALUES ('522630', '', '0', '台江县', null, '', '0', '0', '522600');
INSERT INTO `t_s_territory` VALUES ('522631', '', '0', '黎平县', null, '', '0', '0', '522600');
INSERT INTO `t_s_territory` VALUES ('522632', '', '0', '榕江县', null, '', '0', '0', '522600');
INSERT INTO `t_s_territory` VALUES ('522633', '', '0', '从江县', null, '', '0', '0', '522600');
INSERT INTO `t_s_territory` VALUES ('522634', '', '0', '雷山县', null, '', '0', '0', '522600');
INSERT INTO `t_s_territory` VALUES ('522635', '', '0', '麻江县', null, '', '0', '0', '522600');
INSERT INTO `t_s_territory` VALUES ('522636', '', '0', '丹寨县', null, '', '0', '0', '522600');
INSERT INTO `t_s_territory` VALUES ('522700', '', '0', '黔南布依族苗族自治州', null, '', '0', '0', '520000');
INSERT INTO `t_s_territory` VALUES ('522701', '', '0', '都匀市', null, '', '0', '0', '522700');
INSERT INTO `t_s_territory` VALUES ('522702', '', '0', '福泉市', null, '', '0', '0', '522700');
INSERT INTO `t_s_territory` VALUES ('522722', '', '0', '荔波县', null, '', '0', '0', '522700');
INSERT INTO `t_s_territory` VALUES ('522723', '', '0', '贵定县', null, '', '0', '0', '522700');
INSERT INTO `t_s_territory` VALUES ('522725', '', '0', '瓮安县', null, '', '0', '0', '522700');
INSERT INTO `t_s_territory` VALUES ('522726', '', '0', '独山县', null, '', '0', '0', '522700');
INSERT INTO `t_s_territory` VALUES ('522727', '', '0', '平塘县', null, '', '0', '0', '522700');
INSERT INTO `t_s_territory` VALUES ('522728', '', '0', '罗甸县', null, '', '0', '0', '522700');
INSERT INTO `t_s_territory` VALUES ('522729', '', '0', '长顺县', null, '', '0', '0', '522700');
INSERT INTO `t_s_territory` VALUES ('522730', '', '0', '龙里县', null, '', '0', '0', '522700');
INSERT INTO `t_s_territory` VALUES ('522731', '', '0', '惠水县', null, '', '0', '0', '522700');
INSERT INTO `t_s_territory` VALUES ('522732', '', '0', '三都水族自治县', null, '', '0', '0', '522700');
INSERT INTO `t_s_territory` VALUES ('530000', '', '0', '云南省', null, '', '0', '0', '1');
INSERT INTO `t_s_territory` VALUES ('530100', '', '0', '昆明市', null, '', '0', '0', '530000');
INSERT INTO `t_s_territory` VALUES ('530101', '', '0', '市辖区', null, '', '0', '0', '530100');
INSERT INTO `t_s_territory` VALUES ('530102', '', '0', '五华区', null, '', '0', '0', '530100');
INSERT INTO `t_s_territory` VALUES ('530103', '', '0', '盘龙区', null, '', '0', '0', '530100');
INSERT INTO `t_s_territory` VALUES ('530111', '', '0', '官渡区', null, '', '0', '0', '530100');
INSERT INTO `t_s_territory` VALUES ('530112', '', '0', '西山区', null, '', '0', '0', '530100');
INSERT INTO `t_s_territory` VALUES ('530113', '', '0', '东川区', null, '', '0', '0', '530100');
INSERT INTO `t_s_territory` VALUES ('530114', '', '0', '呈贡区', null, '', '0', '0', '530100');
INSERT INTO `t_s_territory` VALUES ('530122', '', '0', '晋宁县', null, '', '0', '0', '530100');
INSERT INTO `t_s_territory` VALUES ('530124', '', '0', '富民县', null, '', '0', '0', '530100');
INSERT INTO `t_s_territory` VALUES ('530125', '', '0', '宜良县', null, '', '0', '0', '530100');
INSERT INTO `t_s_territory` VALUES ('530126', '', '0', '石林彝族自治县', null, '', '0', '0', '530100');
INSERT INTO `t_s_territory` VALUES ('530127', '', '0', '嵩明县', null, '', '0', '0', '530100');
INSERT INTO `t_s_territory` VALUES ('530128', '', '0', '禄劝彝族苗族自治县', null, '', '0', '0', '530100');
INSERT INTO `t_s_territory` VALUES ('530129', '', '0', '寻甸回族彝族自治县', null, '', '0', '0', '530100');
INSERT INTO `t_s_territory` VALUES ('530181', '', '0', '安宁市', null, '', '0', '0', '530100');
INSERT INTO `t_s_territory` VALUES ('530300', '', '0', '曲靖市', null, '', '0', '0', '530000');
INSERT INTO `t_s_territory` VALUES ('530301', '', '0', '市辖区', null, '', '0', '0', '530300');
INSERT INTO `t_s_territory` VALUES ('530302', '', '0', '麒麟区', null, '', '0', '0', '530300');
INSERT INTO `t_s_territory` VALUES ('530321', '', '0', '马龙县', null, '', '0', '0', '530300');
INSERT INTO `t_s_territory` VALUES ('530322', '', '0', '陆良县', null, '', '0', '0', '530300');
INSERT INTO `t_s_territory` VALUES ('530323', '', '0', '师宗县', null, '', '0', '0', '530300');
INSERT INTO `t_s_territory` VALUES ('530324', '', '0', '罗平县', null, '', '0', '0', '530300');
INSERT INTO `t_s_territory` VALUES ('530325', '', '0', '富源县', null, '', '0', '0', '530300');
INSERT INTO `t_s_territory` VALUES ('530326', '', '0', '会泽县', null, '', '0', '0', '530300');
INSERT INTO `t_s_territory` VALUES ('530328', '', '0', '沾益县', null, '', '0', '0', '530300');
INSERT INTO `t_s_territory` VALUES ('530381', '', '0', '宣威市', null, '', '0', '0', '530300');
INSERT INTO `t_s_territory` VALUES ('530400', '', '0', '玉溪市', null, '', '0', '0', '530000');
INSERT INTO `t_s_territory` VALUES ('530401', '', '0', '市辖区', null, '', '0', '0', '530400');
INSERT INTO `t_s_territory` VALUES ('530402', '', '0', '红塔区', null, '', '0', '0', '530400');
INSERT INTO `t_s_territory` VALUES ('530421', '', '0', '江川县', null, '', '0', '0', '530400');
INSERT INTO `t_s_territory` VALUES ('530422', '', '0', '澄江县', null, '', '0', '0', '530400');
INSERT INTO `t_s_territory` VALUES ('530423', '', '0', '通海县', null, '', '0', '0', '530400');
INSERT INTO `t_s_territory` VALUES ('530424', '', '0', '华宁县', null, '', '0', '0', '530400');
INSERT INTO `t_s_territory` VALUES ('530425', '', '0', '易门县', null, '', '0', '0', '530400');
INSERT INTO `t_s_territory` VALUES ('530426', '', '0', '峨山彝族自治县', null, '', '0', '0', '530400');
INSERT INTO `t_s_territory` VALUES ('530427', '', '0', '新平彝族傣族自治县', null, '', '0', '0', '530400');
INSERT INTO `t_s_territory` VALUES ('530428', '', '0', '元江哈尼族彝族傣族自治县', null, '', '0', '0', '530400');
INSERT INTO `t_s_territory` VALUES ('530500', '', '0', '保山市', null, '', '0', '0', '530000');
INSERT INTO `t_s_territory` VALUES ('530501', '', '0', '市辖区', null, '', '0', '0', '530500');
INSERT INTO `t_s_territory` VALUES ('530502', '', '0', '隆阳区', null, '', '0', '0', '530500');
INSERT INTO `t_s_territory` VALUES ('530521', '', '0', '施甸县', null, '', '0', '0', '530500');
INSERT INTO `t_s_territory` VALUES ('530522', '', '0', '腾冲县', null, '', '0', '0', '530500');
INSERT INTO `t_s_territory` VALUES ('530523', '', '0', '龙陵县', null, '', '0', '0', '530500');
INSERT INTO `t_s_territory` VALUES ('530524', '', '0', '昌宁县', null, '', '0', '0', '530500');
INSERT INTO `t_s_territory` VALUES ('530600', '', '0', '昭通市', null, '', '0', '0', '530000');
INSERT INTO `t_s_territory` VALUES ('530601', '', '0', '市辖区', null, '', '0', '0', '530600');
INSERT INTO `t_s_territory` VALUES ('530602', '', '0', '昭阳区', null, '', '0', '0', '530600');
INSERT INTO `t_s_territory` VALUES ('530621', '', '0', '鲁甸县', null, '', '0', '0', '530600');
INSERT INTO `t_s_territory` VALUES ('530622', '', '0', '巧家县', null, '', '0', '0', '530600');
INSERT INTO `t_s_territory` VALUES ('530623', '', '0', '盐津县', null, '', '0', '0', '530600');
INSERT INTO `t_s_territory` VALUES ('530624', '', '0', '大关县', null, '', '0', '0', '530600');
INSERT INTO `t_s_territory` VALUES ('530625', '', '0', '永善县', null, '', '0', '0', '530600');
INSERT INTO `t_s_territory` VALUES ('530626', '', '0', '绥江县', null, '', '0', '0', '530600');
INSERT INTO `t_s_territory` VALUES ('530627', '', '0', '镇雄县', null, '', '0', '0', '530600');
INSERT INTO `t_s_territory` VALUES ('530628', '', '0', '彝良县', null, '', '0', '0', '530600');
INSERT INTO `t_s_territory` VALUES ('530629', '', '0', '威信县', null, '', '0', '0', '530600');
INSERT INTO `t_s_territory` VALUES ('530630', '', '0', '水富县', null, '', '0', '0', '530600');
INSERT INTO `t_s_territory` VALUES ('530700', '', '0', '丽江市', null, '', '0', '0', '530000');
INSERT INTO `t_s_territory` VALUES ('530701', '', '0', '市辖区', null, '', '0', '0', '530700');
INSERT INTO `t_s_territory` VALUES ('530702', '', '0', '古城区', null, '', '0', '0', '530700');
INSERT INTO `t_s_territory` VALUES ('530721', '', '0', '玉龙纳西族自治县', null, '', '0', '0', '530700');
INSERT INTO `t_s_territory` VALUES ('530722', '', '0', '永胜县', null, '', '0', '0', '530700');
INSERT INTO `t_s_territory` VALUES ('530723', '', '0', '华坪县', null, '', '0', '0', '530700');
INSERT INTO `t_s_territory` VALUES ('530724', '', '0', '宁蒗彝族自治县', null, '', '0', '0', '530700');
INSERT INTO `t_s_territory` VALUES ('530800', '', '0', '普洱市', null, '', '0', '0', '530000');
INSERT INTO `t_s_territory` VALUES ('530801', '', '0', '市辖区', null, '', '0', '0', '530800');
INSERT INTO `t_s_territory` VALUES ('530802', '', '0', '思茅区', null, '', '0', '0', '530800');
INSERT INTO `t_s_territory` VALUES ('530821', '', '0', '宁洱哈尼族彝族自治县', null, '', '0', '0', '530800');
INSERT INTO `t_s_territory` VALUES ('530822', '', '0', '墨江哈尼族自治县', null, '', '0', '0', '530800');
INSERT INTO `t_s_territory` VALUES ('530823', '', '0', '景东彝族自治县', null, '', '0', '0', '530800');
INSERT INTO `t_s_territory` VALUES ('530824', '', '0', '景谷傣族彝族自治县', null, '', '0', '0', '530800');
INSERT INTO `t_s_territory` VALUES ('530825', '', '0', '镇沅彝族哈尼族拉祜族自治县', null, '', '0', '0', '530800');
INSERT INTO `t_s_territory` VALUES ('530826', '', '0', '江城哈尼族彝族自治县', null, '', '0', '0', '530800');
INSERT INTO `t_s_territory` VALUES ('530827', '', '0', '孟连傣族拉祜族佤族自治县', null, '', '0', '0', '530800');
INSERT INTO `t_s_territory` VALUES ('530828', '', '0', '澜沧拉祜族自治县', null, '', '0', '0', '530800');
INSERT INTO `t_s_territory` VALUES ('530829', '', '0', '西盟佤族自治县', null, '', '0', '0', '530800');
INSERT INTO `t_s_territory` VALUES ('530900', '', '0', '临沧市', null, '', '0', '0', '530000');
INSERT INTO `t_s_territory` VALUES ('530901', '', '0', '市辖区', null, '', '0', '0', '530900');
INSERT INTO `t_s_territory` VALUES ('530902', '', '0', '临翔区', null, '', '0', '0', '530900');
INSERT INTO `t_s_territory` VALUES ('530921', '', '0', '凤庆县', null, '', '0', '0', '530900');
INSERT INTO `t_s_territory` VALUES ('530922', '', '0', '云县', null, '', '0', '0', '530900');
INSERT INTO `t_s_territory` VALUES ('530923', '', '0', '永德县', null, '', '0', '0', '530900');
INSERT INTO `t_s_territory` VALUES ('530924', '', '0', '镇康县', null, '', '0', '0', '530900');
INSERT INTO `t_s_territory` VALUES ('530925', '', '0', '双江拉祜族佤族布朗族傣族自治县', null, '', '0', '0', '530900');
INSERT INTO `t_s_territory` VALUES ('530926', '', '0', '耿马傣族佤族自治县', null, '', '0', '0', '530900');
INSERT INTO `t_s_territory` VALUES ('530927', '', '0', '沧源佤族自治县', null, '', '0', '0', '530900');
INSERT INTO `t_s_territory` VALUES ('532300', '', '0', '楚雄彝族自治州', null, '', '0', '0', '530000');
INSERT INTO `t_s_territory` VALUES ('532301', '', '0', '楚雄市', null, '', '0', '0', '532300');
INSERT INTO `t_s_territory` VALUES ('532322', '', '0', '双柏县', null, '', '0', '0', '532300');
INSERT INTO `t_s_territory` VALUES ('532323', '', '0', '牟定县', null, '', '0', '0', '532300');
INSERT INTO `t_s_territory` VALUES ('532324', '', '0', '南华县', null, '', '0', '0', '532300');
INSERT INTO `t_s_territory` VALUES ('532325', '', '0', '姚安县', null, '', '0', '0', '532300');
INSERT INTO `t_s_territory` VALUES ('532326', '', '0', '大姚县', null, '', '0', '0', '532300');
INSERT INTO `t_s_territory` VALUES ('532327', '', '0', '永仁县', null, '', '0', '0', '532300');
INSERT INTO `t_s_territory` VALUES ('532328', '', '0', '元谋县', null, '', '0', '0', '532300');
INSERT INTO `t_s_territory` VALUES ('532329', '', '0', '武定县', null, '', '0', '0', '532300');
INSERT INTO `t_s_territory` VALUES ('532331', '', '0', '禄丰县', null, '', '0', '0', '532300');
INSERT INTO `t_s_territory` VALUES ('532500', '', '0', '红河哈尼族彝族自治州', null, '', '0', '0', '530000');
INSERT INTO `t_s_territory` VALUES ('532501', '', '0', '个旧市', null, '', '0', '0', '532500');
INSERT INTO `t_s_territory` VALUES ('532502', '', '0', '开远市', null, '', '0', '0', '532500');
INSERT INTO `t_s_territory` VALUES ('532503', '', '0', '蒙自市', null, '', '0', '0', '532500');
INSERT INTO `t_s_territory` VALUES ('532504', '', '0', '弥勒市', null, '', '0', '0', '532500');
INSERT INTO `t_s_territory` VALUES ('532523', '', '0', '屏边苗族自治县', null, '', '0', '0', '532500');
INSERT INTO `t_s_territory` VALUES ('532524', '', '0', '建水县', null, '', '0', '0', '532500');
INSERT INTO `t_s_territory` VALUES ('532525', '', '0', '石屏县', null, '', '0', '0', '532500');
INSERT INTO `t_s_territory` VALUES ('532527', '', '0', '泸西县', null, '', '0', '0', '532500');
INSERT INTO `t_s_territory` VALUES ('532528', '', '0', '元阳县', null, '', '0', '0', '532500');
INSERT INTO `t_s_territory` VALUES ('532529', '', '0', '红河县', null, '', '0', '0', '532500');
INSERT INTO `t_s_territory` VALUES ('532530', '', '0', '金平苗族瑶族傣族自治县', null, '', '0', '0', '532500');
INSERT INTO `t_s_territory` VALUES ('532531', '', '0', '绿春县', null, '', '0', '0', '532500');
INSERT INTO `t_s_territory` VALUES ('532532', '', '0', '河口瑶族自治县', null, '', '0', '0', '532500');
INSERT INTO `t_s_territory` VALUES ('532600', '', '0', '文山壮族苗族自治州', null, '', '0', '0', '530000');
INSERT INTO `t_s_territory` VALUES ('532601', '', '0', '文山市', null, '', '0', '0', '532600');
INSERT INTO `t_s_territory` VALUES ('532622', '', '0', '砚山县', null, '', '0', '0', '532600');
INSERT INTO `t_s_territory` VALUES ('532623', '', '0', '西畴县', null, '', '0', '0', '532600');
INSERT INTO `t_s_territory` VALUES ('532624', '', '0', '麻栗坡县', null, '', '0', '0', '532600');
INSERT INTO `t_s_territory` VALUES ('532625', '', '0', '马关县', null, '', '0', '0', '532600');
INSERT INTO `t_s_territory` VALUES ('532626', '', '0', '丘北县', null, '', '0', '0', '532600');
INSERT INTO `t_s_territory` VALUES ('532627', '', '0', '广南县', null, '', '0', '0', '532600');
INSERT INTO `t_s_territory` VALUES ('532628', '', '0', '富宁县', null, '', '0', '0', '532600');
INSERT INTO `t_s_territory` VALUES ('532800', '', '0', '西双版纳傣族自治州', null, '', '0', '0', '530000');
INSERT INTO `t_s_territory` VALUES ('532801', '', '0', '景洪市', null, '', '0', '0', '532800');
INSERT INTO `t_s_territory` VALUES ('532822', '', '0', '勐海县', null, '', '0', '0', '532800');
INSERT INTO `t_s_territory` VALUES ('532823', '', '0', '勐腊县', null, '', '0', '0', '532800');
INSERT INTO `t_s_territory` VALUES ('532900', '', '0', '大理白族自治州', null, '', '0', '0', '530000');
INSERT INTO `t_s_territory` VALUES ('532901', '', '0', '大理市', null, '', '0', '0', '532900');
INSERT INTO `t_s_territory` VALUES ('532922', '', '0', '漾濞彝族自治县', null, '', '0', '0', '532900');
INSERT INTO `t_s_territory` VALUES ('532923', '', '0', '祥云县', null, '', '0', '0', '532900');
INSERT INTO `t_s_territory` VALUES ('532924', '', '0', '宾川县', null, '', '0', '0', '532900');
INSERT INTO `t_s_territory` VALUES ('532925', '', '0', '弥渡县', null, '', '0', '0', '532900');
INSERT INTO `t_s_territory` VALUES ('532926', '', '0', '南涧彝族自治县', null, '', '0', '0', '532900');
INSERT INTO `t_s_territory` VALUES ('532927', '', '0', '巍山彝族回族自治县', null, '', '0', '0', '532900');
INSERT INTO `t_s_territory` VALUES ('532928', '', '0', '永平县', null, '', '0', '0', '532900');
INSERT INTO `t_s_territory` VALUES ('532929', '', '0', '云龙县', null, '', '0', '0', '532900');
INSERT INTO `t_s_territory` VALUES ('532930', '', '0', '洱源县', null, '', '0', '0', '532900');
INSERT INTO `t_s_territory` VALUES ('532931', '', '0', '剑川县', null, '', '0', '0', '532900');
INSERT INTO `t_s_territory` VALUES ('532932', '', '0', '鹤庆县', null, '', '0', '0', '532900');
INSERT INTO `t_s_territory` VALUES ('533100', '', '0', '德宏傣族景颇族自治州', null, '', '0', '0', '530000');
INSERT INTO `t_s_territory` VALUES ('533102', '', '0', '瑞丽市', null, '', '0', '0', '533100');
INSERT INTO `t_s_territory` VALUES ('533103', '', '0', '芒市', null, '', '0', '0', '533100');
INSERT INTO `t_s_territory` VALUES ('533122', '', '0', '梁河县', null, '', '0', '0', '533100');
INSERT INTO `t_s_territory` VALUES ('533123', '', '0', '盈江县', null, '', '0', '0', '533100');
INSERT INTO `t_s_territory` VALUES ('533124', '', '0', '陇川县', null, '', '0', '0', '533100');
INSERT INTO `t_s_territory` VALUES ('533300', '', '0', '怒江傈僳族自治州', null, '', '0', '0', '530000');
INSERT INTO `t_s_territory` VALUES ('533321', '', '0', '泸水县', null, '', '0', '0', '533300');
INSERT INTO `t_s_territory` VALUES ('533323', '', '0', '福贡县', null, '', '0', '0', '533300');
INSERT INTO `t_s_territory` VALUES ('533324', '', '0', '贡山独龙族怒族自治县', null, '', '0', '0', '533300');
INSERT INTO `t_s_territory` VALUES ('533325', '', '0', '兰坪白族普米族自治县', null, '', '0', '0', '533300');
INSERT INTO `t_s_territory` VALUES ('533400', '', '0', '迪庆藏族自治州', null, '', '0', '0', '530000');
INSERT INTO `t_s_territory` VALUES ('533421', '', '0', '香格里拉县', null, '', '0', '0', '533400');
INSERT INTO `t_s_territory` VALUES ('533422', '', '0', '德钦县', null, '', '0', '0', '533400');
INSERT INTO `t_s_territory` VALUES ('533423', '', '0', '维西傈僳族自治县', null, '', '0', '0', '533400');
INSERT INTO `t_s_territory` VALUES ('540000', '', '0', '西藏自治区', null, '', '0', '0', '1');
INSERT INTO `t_s_territory` VALUES ('540100', '', '0', '拉萨市', null, '', '0', '0', '540000');
INSERT INTO `t_s_territory` VALUES ('540101', '', '0', '市辖区', null, '', '0', '0', '540100');
INSERT INTO `t_s_territory` VALUES ('540102', '', '0', '城关区', null, '', '0', '0', '540100');
INSERT INTO `t_s_territory` VALUES ('540121', '', '0', '林周县', null, '', '0', '0', '540100');
INSERT INTO `t_s_territory` VALUES ('540122', '', '0', '当雄县', null, '', '0', '0', '540100');
INSERT INTO `t_s_territory` VALUES ('540123', '', '0', '尼木县', null, '', '0', '0', '540100');
INSERT INTO `t_s_territory` VALUES ('540124', '', '0', '曲水县', null, '', '0', '0', '540100');
INSERT INTO `t_s_territory` VALUES ('540125', '', '0', '堆龙德庆县', null, '', '0', '0', '540100');
INSERT INTO `t_s_territory` VALUES ('540126', '', '0', '达孜县', null, '', '0', '0', '540100');
INSERT INTO `t_s_territory` VALUES ('540127', '', '0', '墨竹工卡县', null, '', '0', '0', '540100');
INSERT INTO `t_s_territory` VALUES ('540200', '', '0', '日喀则市', null, '', '0', '0', '540000');
INSERT INTO `t_s_territory` VALUES ('540202', '', '0', '桑珠孜区', null, '', '0', '0', '540200');
INSERT INTO `t_s_territory` VALUES ('540221', '', '0', '南木林县', null, '', '0', '0', '540200');
INSERT INTO `t_s_territory` VALUES ('540222', '', '0', '江孜县', null, '', '0', '0', '540200');
INSERT INTO `t_s_territory` VALUES ('540223', '', '0', '定日县', null, '', '0', '0', '540200');
INSERT INTO `t_s_territory` VALUES ('540224', '', '0', '萨迦县', null, '', '0', '0', '540200');
INSERT INTO `t_s_territory` VALUES ('540225', '', '0', '拉孜县', null, '', '0', '0', '540200');
INSERT INTO `t_s_territory` VALUES ('540226', '', '0', '昂仁县', null, '', '0', '0', '540200');
INSERT INTO `t_s_territory` VALUES ('540227', '', '0', '谢通门县', null, '', '0', '0', '540200');
INSERT INTO `t_s_territory` VALUES ('540228', '', '0', '白朗县', null, '', '0', '0', '540200');
INSERT INTO `t_s_territory` VALUES ('540229', '', '0', '仁布县', null, '', '0', '0', '540200');
INSERT INTO `t_s_territory` VALUES ('540230', '', '0', '康马县', null, '', '0', '0', '540200');
INSERT INTO `t_s_territory` VALUES ('540231', '', '0', '定结县', null, '', '0', '0', '540200');
INSERT INTO `t_s_territory` VALUES ('540232', '', '0', '仲巴县', null, '', '0', '0', '540200');
INSERT INTO `t_s_territory` VALUES ('540233', '', '0', '亚东县', null, '', '0', '0', '540200');
INSERT INTO `t_s_territory` VALUES ('540234', '', '0', '吉隆县', null, '', '0', '0', '540200');
INSERT INTO `t_s_territory` VALUES ('540235', '', '0', '聂拉木县', null, '', '0', '0', '540200');
INSERT INTO `t_s_territory` VALUES ('540236', '', '0', '萨嘎县', null, '', '0', '0', '540200');
INSERT INTO `t_s_territory` VALUES ('540237', '', '0', '岗巴县', null, '', '0', '0', '540200');
INSERT INTO `t_s_territory` VALUES ('542100', '', '0', '昌都地区', null, '', '0', '0', '540000');
INSERT INTO `t_s_territory` VALUES ('542121', '', '0', '昌都县', null, '', '0', '0', '542100');
INSERT INTO `t_s_territory` VALUES ('542122', '', '0', '江达县', null, '', '0', '0', '542100');
INSERT INTO `t_s_territory` VALUES ('542123', '', '0', '贡觉县', null, '', '0', '0', '542100');
INSERT INTO `t_s_territory` VALUES ('542124', '', '0', '类乌齐县', null, '', '0', '0', '542100');
INSERT INTO `t_s_territory` VALUES ('542125', '', '0', '丁青县', null, '', '0', '0', '542100');
INSERT INTO `t_s_territory` VALUES ('542126', '', '0', '察雅县', null, '', '0', '0', '542100');
INSERT INTO `t_s_territory` VALUES ('542127', '', '0', '八宿县', null, '', '0', '0', '542100');
INSERT INTO `t_s_territory` VALUES ('542128', '', '0', '左贡县', null, '', '0', '0', '542100');
INSERT INTO `t_s_territory` VALUES ('542129', '', '0', '芒康县', null, '', '0', '0', '542100');
INSERT INTO `t_s_territory` VALUES ('542132', '', '0', '洛隆县', null, '', '0', '0', '542100');
INSERT INTO `t_s_territory` VALUES ('542133', '', '0', '边坝县', null, '', '0', '0', '542100');
INSERT INTO `t_s_territory` VALUES ('542200', '', '0', '山南地区', null, '', '0', '0', '540000');
INSERT INTO `t_s_territory` VALUES ('542221', '', '0', '乃东县', null, '', '0', '0', '542200');
INSERT INTO `t_s_territory` VALUES ('542222', '', '0', '扎囊县', null, '', '0', '0', '542200');
INSERT INTO `t_s_territory` VALUES ('542223', '', '0', '贡嘎县', null, '', '0', '0', '542200');
INSERT INTO `t_s_territory` VALUES ('542224', '', '0', '桑日县', null, '', '0', '0', '542200');
INSERT INTO `t_s_territory` VALUES ('542225', '', '0', '琼结县', null, '', '0', '0', '542200');
INSERT INTO `t_s_territory` VALUES ('542226', '', '0', '曲松县', null, '', '0', '0', '542200');
INSERT INTO `t_s_territory` VALUES ('542227', '', '0', '措美县', null, '', '0', '0', '542200');
INSERT INTO `t_s_territory` VALUES ('542228', '', '0', '洛扎县', null, '', '0', '0', '542200');
INSERT INTO `t_s_territory` VALUES ('542229', '', '0', '加查县', null, '', '0', '0', '542200');
INSERT INTO `t_s_territory` VALUES ('542231', '', '0', '隆子县', null, '', '0', '0', '542200');
INSERT INTO `t_s_territory` VALUES ('542232', '', '0', '错那县', null, '', '0', '0', '542200');
INSERT INTO `t_s_territory` VALUES ('542233', '', '0', '浪卡子县', null, '', '0', '0', '542200');
INSERT INTO `t_s_territory` VALUES ('542400', '', '0', '那曲地区', null, '', '0', '0', '540000');
INSERT INTO `t_s_territory` VALUES ('542421', '', '0', '那曲县', null, '', '0', '0', '542400');
INSERT INTO `t_s_territory` VALUES ('542422', '', '0', '嘉黎县', null, '', '0', '0', '542400');
INSERT INTO `t_s_territory` VALUES ('542423', '', '0', '比如县', null, '', '0', '0', '542400');
INSERT INTO `t_s_territory` VALUES ('542424', '', '0', '聂荣县', null, '', '0', '0', '542400');
INSERT INTO `t_s_territory` VALUES ('542425', '', '0', '安多县', null, '', '0', '0', '542400');
INSERT INTO `t_s_territory` VALUES ('542426', '', '0', '申扎县', null, '', '0', '0', '542400');
INSERT INTO `t_s_territory` VALUES ('542427', '', '0', '索县', null, '', '0', '0', '542400');
INSERT INTO `t_s_territory` VALUES ('542428', '', '0', '班戈县', null, '', '0', '0', '542400');
INSERT INTO `t_s_territory` VALUES ('542429', '', '0', '巴青县', null, '', '0', '0', '542400');
INSERT INTO `t_s_territory` VALUES ('542430', '', '0', '尼玛县', null, '', '0', '0', '542400');
INSERT INTO `t_s_territory` VALUES ('542431', '', '0', '双湖县', null, '', '0', '0', '542400');
INSERT INTO `t_s_territory` VALUES ('542500', '', '0', '阿里地区', null, '', '0', '0', '540000');
INSERT INTO `t_s_territory` VALUES ('542521', '', '0', '普兰县', null, '', '0', '0', '542500');
INSERT INTO `t_s_territory` VALUES ('542522', '', '0', '札达县', null, '', '0', '0', '542500');
INSERT INTO `t_s_territory` VALUES ('542523', '', '0', '噶尔县', null, '', '0', '0', '542500');
INSERT INTO `t_s_territory` VALUES ('542524', '', '0', '日土县', null, '', '0', '0', '542500');
INSERT INTO `t_s_territory` VALUES ('542525', '', '0', '革吉县', null, '', '0', '0', '542500');
INSERT INTO `t_s_territory` VALUES ('542526', '', '0', '改则县', null, '', '0', '0', '542500');
INSERT INTO `t_s_territory` VALUES ('542527', '', '0', '措勤县', null, '', '0', '0', '542500');
INSERT INTO `t_s_territory` VALUES ('542600', '', '0', '林芝地区', null, '', '0', '0', '540000');
INSERT INTO `t_s_territory` VALUES ('542621', '', '0', '林芝县', null, '', '0', '0', '542600');
INSERT INTO `t_s_territory` VALUES ('542622', '', '0', '工布江达县', null, '', '0', '0', '542600');
INSERT INTO `t_s_territory` VALUES ('542623', '', '0', '米林县', null, '', '0', '0', '542600');
INSERT INTO `t_s_territory` VALUES ('542624', '', '0', '墨脱县', null, '', '0', '0', '542600');
INSERT INTO `t_s_territory` VALUES ('542625', '', '0', '波密县', null, '', '0', '0', '542600');
INSERT INTO `t_s_territory` VALUES ('542626', '', '0', '察隅县', null, '', '0', '0', '542600');
INSERT INTO `t_s_territory` VALUES ('542627', '', '0', '朗县', null, '', '0', '0', '542600');
INSERT INTO `t_s_territory` VALUES ('610000', '', '0', '陕西省', null, '', '0', '0', '1');
INSERT INTO `t_s_territory` VALUES ('610100', '', '0', '西安市', null, '', '0', '0', '610000');
INSERT INTO `t_s_territory` VALUES ('610101', '', '0', '市辖区', null, '', '0', '0', '610100');
INSERT INTO `t_s_territory` VALUES ('610102', '', '0', '新城区', null, '', '0', '0', '610100');
INSERT INTO `t_s_territory` VALUES ('610103', '', '0', '碑林区', null, '', '0', '0', '610100');
INSERT INTO `t_s_territory` VALUES ('610104', '', '0', '莲湖区', null, '', '0', '0', '610100');
INSERT INTO `t_s_territory` VALUES ('610111', '', '0', '灞桥区', null, '', '0', '0', '610100');
INSERT INTO `t_s_territory` VALUES ('610112', '', '0', '未央区', null, '', '0', '0', '610100');
INSERT INTO `t_s_territory` VALUES ('610113', '', '0', '雁塔区', null, '', '0', '0', '610100');
INSERT INTO `t_s_territory` VALUES ('610114', '', '0', '阎良区', null, '', '0', '0', '610100');
INSERT INTO `t_s_territory` VALUES ('610115', '', '0', '临潼区', null, '', '0', '0', '610100');
INSERT INTO `t_s_territory` VALUES ('610116', '', '0', '长安区', null, '', '0', '0', '610100');
INSERT INTO `t_s_territory` VALUES ('610122', '', '0', '蓝田县', null, '', '0', '0', '610100');
INSERT INTO `t_s_territory` VALUES ('610124', '', '0', '周至县', null, '', '0', '0', '610100');
INSERT INTO `t_s_territory` VALUES ('610125', '', '0', '户县', null, '', '0', '0', '610100');
INSERT INTO `t_s_territory` VALUES ('610126', '', '0', '高陵县', null, '', '0', '0', '610100');
INSERT INTO `t_s_territory` VALUES ('610200', '', '0', '铜川市', null, '', '0', '0', '610000');
INSERT INTO `t_s_territory` VALUES ('610201', '', '0', '市辖区', null, '', '0', '0', '610200');
INSERT INTO `t_s_territory` VALUES ('610202', '', '0', '王益区', null, '', '0', '0', '610200');
INSERT INTO `t_s_territory` VALUES ('610203', '', '0', '印台区', null, '', '0', '0', '610200');
INSERT INTO `t_s_territory` VALUES ('610204', '', '0', '耀州区', null, '', '0', '0', '610200');
INSERT INTO `t_s_territory` VALUES ('610222', '', '0', '宜君县', null, '', '0', '0', '610200');
INSERT INTO `t_s_territory` VALUES ('610300', '', '0', '宝鸡市', null, '', '0', '0', '610000');
INSERT INTO `t_s_territory` VALUES ('610301', '', '0', '市辖区', null, '', '0', '0', '610300');
INSERT INTO `t_s_territory` VALUES ('610302', '', '0', '渭滨区', null, '', '0', '0', '610300');
INSERT INTO `t_s_territory` VALUES ('610303', '', '0', '金台区', null, '', '0', '0', '610300');
INSERT INTO `t_s_territory` VALUES ('610304', '', '0', '陈仓区', null, '', '0', '0', '610300');
INSERT INTO `t_s_territory` VALUES ('610322', '', '0', '凤翔县', null, '', '0', '0', '610300');
INSERT INTO `t_s_territory` VALUES ('610323', '', '0', '岐山县', null, '', '0', '0', '610300');
INSERT INTO `t_s_territory` VALUES ('610324', '', '0', '扶风县', null, '', '0', '0', '610300');
INSERT INTO `t_s_territory` VALUES ('610326', '', '0', '眉县', null, '', '0', '0', '610300');
INSERT INTO `t_s_territory` VALUES ('610327', '', '0', '陇县', null, '', '0', '0', '610300');
INSERT INTO `t_s_territory` VALUES ('610328', '', '0', '千阳县', null, '', '0', '0', '610300');
INSERT INTO `t_s_territory` VALUES ('610329', '', '0', '麟游县', null, '', '0', '0', '610300');
INSERT INTO `t_s_territory` VALUES ('610330', '', '0', '凤县', null, '', '0', '0', '610300');
INSERT INTO `t_s_territory` VALUES ('610331', '', '0', '太白县', null, '', '0', '0', '610300');
INSERT INTO `t_s_territory` VALUES ('610400', '', '0', '咸阳市', null, '', '0', '0', '610000');
INSERT INTO `t_s_territory` VALUES ('610401', '', '0', '市辖区', null, '', '0', '0', '610400');
INSERT INTO `t_s_territory` VALUES ('610402', '', '0', '秦都区', null, '', '0', '0', '610400');
INSERT INTO `t_s_territory` VALUES ('610403', '', '0', '杨陵区', null, '', '0', '0', '610400');
INSERT INTO `t_s_territory` VALUES ('610404', '', '0', '渭城区', null, '', '0', '0', '610400');
INSERT INTO `t_s_territory` VALUES ('610422', '', '0', '三原县', null, '', '0', '0', '610400');
INSERT INTO `t_s_territory` VALUES ('610423', '', '0', '泾阳县', null, '', '0', '0', '610400');
INSERT INTO `t_s_territory` VALUES ('610424', '', '0', '乾县', null, '', '0', '0', '610400');
INSERT INTO `t_s_territory` VALUES ('610425', '', '0', '礼泉县', null, '', '0', '0', '610400');
INSERT INTO `t_s_territory` VALUES ('610426', '', '0', '永寿县', null, '', '0', '0', '610400');
INSERT INTO `t_s_territory` VALUES ('610427', '', '0', '彬县', null, '', '0', '0', '610400');
INSERT INTO `t_s_territory` VALUES ('610428', '', '0', '长武县', null, '', '0', '0', '610400');
INSERT INTO `t_s_territory` VALUES ('610429', '', '0', '旬邑县', null, '', '0', '0', '610400');
INSERT INTO `t_s_territory` VALUES ('610430', '', '0', '淳化县', null, '', '0', '0', '610400');
INSERT INTO `t_s_territory` VALUES ('610431', '', '0', '武功县', null, '', '0', '0', '610400');
INSERT INTO `t_s_territory` VALUES ('610481', '', '0', '兴平市', null, '', '0', '0', '610400');
INSERT INTO `t_s_territory` VALUES ('610500', '', '0', '渭南市', null, '', '0', '0', '610000');
INSERT INTO `t_s_territory` VALUES ('610501', '', '0', '市辖区', null, '', '0', '0', '610500');
INSERT INTO `t_s_territory` VALUES ('610502', '', '0', '临渭区', null, '', '0', '0', '610500');
INSERT INTO `t_s_territory` VALUES ('610521', '', '0', '华县', null, '', '0', '0', '610500');
INSERT INTO `t_s_territory` VALUES ('610522', '', '0', '潼关县', null, '', '0', '0', '610500');
INSERT INTO `t_s_territory` VALUES ('610523', '', '0', '大荔县', null, '', '0', '0', '610500');
INSERT INTO `t_s_territory` VALUES ('610524', '', '0', '合阳县', null, '', '0', '0', '610500');
INSERT INTO `t_s_territory` VALUES ('610525', '', '0', '澄城县', null, '', '0', '0', '610500');
INSERT INTO `t_s_territory` VALUES ('610526', '', '0', '蒲城县', null, '', '0', '0', '610500');
INSERT INTO `t_s_territory` VALUES ('610527', '', '0', '白水县', null, '', '0', '0', '610500');
INSERT INTO `t_s_territory` VALUES ('610528', '', '0', '富平县', null, '', '0', '0', '610500');
INSERT INTO `t_s_territory` VALUES ('610581', '', '0', '韩城市', null, '', '0', '0', '610500');
INSERT INTO `t_s_territory` VALUES ('610582', '', '0', '华阴市', null, '', '0', '0', '610500');
INSERT INTO `t_s_territory` VALUES ('610600', '', '0', '延安市', null, '', '0', '0', '610000');
INSERT INTO `t_s_territory` VALUES ('610601', '', '0', '市辖区', null, '', '0', '0', '610600');
INSERT INTO `t_s_territory` VALUES ('610602', '', '0', '宝塔区', null, '', '0', '0', '610600');
INSERT INTO `t_s_territory` VALUES ('610621', '', '0', '延长县', null, '', '0', '0', '610600');
INSERT INTO `t_s_territory` VALUES ('610622', '', '0', '延川县', null, '', '0', '0', '610600');
INSERT INTO `t_s_territory` VALUES ('610623', '', '0', '子长县', null, '', '0', '0', '610600');
INSERT INTO `t_s_territory` VALUES ('610624', '', '0', '安塞县', null, '', '0', '0', '610600');
INSERT INTO `t_s_territory` VALUES ('610625', '', '0', '志丹县', null, '', '0', '0', '610600');
INSERT INTO `t_s_territory` VALUES ('610626', '', '0', '吴起县', null, '', '0', '0', '610600');
INSERT INTO `t_s_territory` VALUES ('610627', '', '0', '甘泉县', null, '', '0', '0', '610600');
INSERT INTO `t_s_territory` VALUES ('610628', '', '0', '富县', null, '', '0', '0', '610600');
INSERT INTO `t_s_territory` VALUES ('610629', '', '0', '洛川县', null, '', '0', '0', '610600');
INSERT INTO `t_s_territory` VALUES ('610630', '', '0', '宜川县', null, '', '0', '0', '610600');
INSERT INTO `t_s_territory` VALUES ('610631', '', '0', '黄龙县', null, '', '0', '0', '610600');
INSERT INTO `t_s_territory` VALUES ('610632', '', '0', '黄陵县', null, '', '0', '0', '610600');
INSERT INTO `t_s_territory` VALUES ('610700', '', '0', '汉中市', null, '', '0', '0', '610000');
INSERT INTO `t_s_territory` VALUES ('610701', '', '0', '市辖区', null, '', '0', '0', '610700');
INSERT INTO `t_s_territory` VALUES ('610702', '', '0', '汉台区', null, '', '0', '0', '610700');
INSERT INTO `t_s_territory` VALUES ('610721', '', '0', '南郑县', null, '', '0', '0', '610700');
INSERT INTO `t_s_territory` VALUES ('610722', '', '0', '城固县', null, '', '0', '0', '610700');
INSERT INTO `t_s_territory` VALUES ('610723', '', '0', '洋县', null, '', '0', '0', '610700');
INSERT INTO `t_s_territory` VALUES ('610724', '', '0', '西乡县', null, '', '0', '0', '610700');
INSERT INTO `t_s_territory` VALUES ('610725', '', '0', '勉县', null, '', '0', '0', '610700');
INSERT INTO `t_s_territory` VALUES ('610726', '', '0', '宁强县', null, '', '0', '0', '610700');
INSERT INTO `t_s_territory` VALUES ('610727', '', '0', '略阳县', null, '', '0', '0', '610700');
INSERT INTO `t_s_territory` VALUES ('610728', '', '0', '镇巴县', null, '', '0', '0', '610700');
INSERT INTO `t_s_territory` VALUES ('610729', '', '0', '留坝县', null, '', '0', '0', '610700');
INSERT INTO `t_s_territory` VALUES ('610730', '', '0', '佛坪县', null, '', '0', '0', '610700');
INSERT INTO `t_s_territory` VALUES ('610800', '', '0', '榆林市', null, '', '0', '0', '610000');
INSERT INTO `t_s_territory` VALUES ('610801', '', '0', '市辖区', null, '', '0', '0', '610800');
INSERT INTO `t_s_territory` VALUES ('610802', '', '0', '榆阳区', null, '', '0', '0', '610800');
INSERT INTO `t_s_territory` VALUES ('610821', '', '0', '神木县', null, '', '0', '0', '610800');
INSERT INTO `t_s_territory` VALUES ('610822', '', '0', '府谷县', null, '', '0', '0', '610800');
INSERT INTO `t_s_territory` VALUES ('610823', '', '0', '横山县', null, '', '0', '0', '610800');
INSERT INTO `t_s_territory` VALUES ('610824', '', '0', '靖边县', null, '', '0', '0', '610800');
INSERT INTO `t_s_territory` VALUES ('610825', '', '0', '定边县', null, '', '0', '0', '610800');
INSERT INTO `t_s_territory` VALUES ('610826', '', '0', '绥德县', null, '', '0', '0', '610800');
INSERT INTO `t_s_territory` VALUES ('610827', '', '0', '米脂县', null, '', '0', '0', '610800');
INSERT INTO `t_s_territory` VALUES ('610828', '', '0', '佳县', null, '', '0', '0', '610800');
INSERT INTO `t_s_territory` VALUES ('610829', '', '0', '吴堡县', null, '', '0', '0', '610800');
INSERT INTO `t_s_territory` VALUES ('610830', '', '0', '清涧县', null, '', '0', '0', '610800');
INSERT INTO `t_s_territory` VALUES ('610831', '', '0', '子洲县', null, '', '0', '0', '610800');
INSERT INTO `t_s_territory` VALUES ('610900', '', '0', '安康市', null, '', '0', '0', '610000');
INSERT INTO `t_s_territory` VALUES ('610901', '', '0', '市辖区', null, '', '0', '0', '610900');
INSERT INTO `t_s_territory` VALUES ('610902', '', '0', '汉滨区', null, '', '0', '0', '610900');
INSERT INTO `t_s_territory` VALUES ('610921', '', '0', '汉阴县', null, '', '0', '0', '610900');
INSERT INTO `t_s_territory` VALUES ('610922', '', '0', '石泉县', null, '', '0', '0', '610900');
INSERT INTO `t_s_territory` VALUES ('610923', '', '0', '宁陕县', null, '', '0', '0', '610900');
INSERT INTO `t_s_territory` VALUES ('610924', '', '0', '紫阳县', null, '', '0', '0', '610900');
INSERT INTO `t_s_territory` VALUES ('610925', '', '0', '岚皋县', null, '', '0', '0', '610900');
INSERT INTO `t_s_territory` VALUES ('610926', '', '0', '平利县', null, '', '0', '0', '610900');
INSERT INTO `t_s_territory` VALUES ('610927', '', '0', '镇坪县', null, '', '0', '0', '610900');
INSERT INTO `t_s_territory` VALUES ('610928', '', '0', '旬阳县', null, '', '0', '0', '610900');
INSERT INTO `t_s_territory` VALUES ('610929', '', '0', '白河县', null, '', '0', '0', '610900');
INSERT INTO `t_s_territory` VALUES ('611000', '', '0', '商洛市', null, '', '0', '0', '610000');
INSERT INTO `t_s_territory` VALUES ('611001', '', '0', '市辖区', null, '', '0', '0', '611000');
INSERT INTO `t_s_territory` VALUES ('611002', '', '0', '商州区', null, '', '0', '0', '611000');
INSERT INTO `t_s_territory` VALUES ('611021', '', '0', '洛南县', null, '', '0', '0', '611000');
INSERT INTO `t_s_territory` VALUES ('611022', '', '0', '丹凤县', null, '', '0', '0', '611000');
INSERT INTO `t_s_territory` VALUES ('611023', '', '0', '商南县', null, '', '0', '0', '611000');
INSERT INTO `t_s_territory` VALUES ('611024', '', '0', '山阳县', null, '', '0', '0', '611000');
INSERT INTO `t_s_territory` VALUES ('611025', '', '0', '镇安县', null, '', '0', '0', '611000');
INSERT INTO `t_s_territory` VALUES ('611026', '', '0', '柞水县', null, '', '0', '0', '611000');
INSERT INTO `t_s_territory` VALUES ('620000', '', '0', '甘肃省', null, '', '0', '0', '1');
INSERT INTO `t_s_territory` VALUES ('620100', '', '0', '兰州市', null, '', '0', '0', '620000');
INSERT INTO `t_s_territory` VALUES ('620101', '', '0', '市辖区', null, '', '0', '0', '620100');
INSERT INTO `t_s_territory` VALUES ('620102', '', '0', '城关区', null, '', '0', '0', '620100');
INSERT INTO `t_s_territory` VALUES ('620103', '', '0', '七里河区', null, '', '0', '0', '620100');
INSERT INTO `t_s_territory` VALUES ('620104', '', '0', '西固区', null, '', '0', '0', '620100');
INSERT INTO `t_s_territory` VALUES ('620105', '', '0', '安宁区', null, '', '0', '0', '620100');
INSERT INTO `t_s_territory` VALUES ('620111', '', '0', '红古区', null, '', '0', '0', '620100');
INSERT INTO `t_s_territory` VALUES ('620121', '', '0', '永登县', null, '', '0', '0', '620100');
INSERT INTO `t_s_territory` VALUES ('620122', '', '0', '皋兰县', null, '', '0', '0', '620100');
INSERT INTO `t_s_territory` VALUES ('620123', '', '0', '榆中县', null, '', '0', '0', '620100');
INSERT INTO `t_s_territory` VALUES ('620200', '', '0', '嘉峪关市', null, '', '0', '0', '620000');
INSERT INTO `t_s_territory` VALUES ('620201', '', '0', '新城镇', null, '', '0', '0', '620200');
INSERT INTO `t_s_territory` VALUES ('620300', '', '0', '金昌市', null, '', '0', '0', '620000');
INSERT INTO `t_s_territory` VALUES ('620301', '', '0', '市辖区', null, '', '0', '0', '620300');
INSERT INTO `t_s_territory` VALUES ('620302', '', '0', '金川区', null, '', '0', '0', '620300');
INSERT INTO `t_s_territory` VALUES ('620321', '', '0', '永昌县', null, '', '0', '0', '620300');
INSERT INTO `t_s_territory` VALUES ('620400', '', '0', '白银市', null, '', '0', '0', '620000');
INSERT INTO `t_s_territory` VALUES ('620401', '', '0', '市辖区', null, '', '0', '0', '620400');
INSERT INTO `t_s_territory` VALUES ('620402', '', '0', '白银区', null, '', '0', '0', '620400');
INSERT INTO `t_s_territory` VALUES ('620403', '', '0', '平川区', null, '', '0', '0', '620400');
INSERT INTO `t_s_territory` VALUES ('620421', '', '0', '靖远县', null, '', '0', '0', '620400');
INSERT INTO `t_s_territory` VALUES ('620422', '', '0', '会宁县', null, '', '0', '0', '620400');
INSERT INTO `t_s_territory` VALUES ('620423', '', '0', '景泰县', null, '', '0', '0', '620400');
INSERT INTO `t_s_territory` VALUES ('620500', '', '0', '天水市', null, '', '0', '0', '620000');
INSERT INTO `t_s_territory` VALUES ('620501', '', '0', '市辖区', null, '', '0', '0', '620500');
INSERT INTO `t_s_territory` VALUES ('620502', '', '0', '秦州区', null, '', '0', '0', '620500');
INSERT INTO `t_s_territory` VALUES ('620503', '', '0', '麦积区', null, '', '0', '0', '620500');
INSERT INTO `t_s_territory` VALUES ('620521', '', '0', '清水县', null, '', '0', '0', '620500');
INSERT INTO `t_s_territory` VALUES ('620522', '', '0', '秦安县', null, '', '0', '0', '620500');
INSERT INTO `t_s_territory` VALUES ('620523', '', '0', '甘谷县', null, '', '0', '0', '620500');
INSERT INTO `t_s_territory` VALUES ('620524', '', '0', '武山县', null, '', '0', '0', '620500');
INSERT INTO `t_s_territory` VALUES ('620525', '', '0', '张家川回族自治县', null, '', '0', '0', '620500');
INSERT INTO `t_s_territory` VALUES ('620600', '', '0', '武威市', null, '', '0', '0', '620000');
INSERT INTO `t_s_territory` VALUES ('620601', '', '0', '市辖区', null, '', '0', '0', '620600');
INSERT INTO `t_s_territory` VALUES ('620602', '', '0', '凉州区', null, '', '0', '0', '620600');
INSERT INTO `t_s_territory` VALUES ('620621', '', '0', '民勤县', null, '', '0', '0', '620600');
INSERT INTO `t_s_territory` VALUES ('620622', '', '0', '古浪县', null, '', '0', '0', '620600');
INSERT INTO `t_s_territory` VALUES ('620623', '', '0', '天祝藏族自治县', null, '', '0', '0', '620600');
INSERT INTO `t_s_territory` VALUES ('620700', '', '0', '张掖市', null, '', '0', '0', '620000');
INSERT INTO `t_s_territory` VALUES ('620701', '', '0', '市辖区', null, '', '0', '0', '620700');
INSERT INTO `t_s_territory` VALUES ('620702', '', '0', '甘州区', null, '', '0', '0', '620700');
INSERT INTO `t_s_territory` VALUES ('620721', '', '0', '肃南裕固族自治县', null, '', '0', '0', '620700');
INSERT INTO `t_s_territory` VALUES ('620722', '', '0', '民乐县', null, '', '0', '0', '620700');
INSERT INTO `t_s_territory` VALUES ('620723', '', '0', '临泽县', null, '', '0', '0', '620700');
INSERT INTO `t_s_territory` VALUES ('620724', '', '0', '高台县', null, '', '0', '0', '620700');
INSERT INTO `t_s_territory` VALUES ('620725', '', '0', '山丹县', null, '', '0', '0', '620700');
INSERT INTO `t_s_territory` VALUES ('620800', '', '0', '平凉市', null, '', '0', '0', '620000');
INSERT INTO `t_s_territory` VALUES ('620801', '', '0', '市辖区', null, '', '0', '0', '620800');
INSERT INTO `t_s_territory` VALUES ('620802', '', '0', '崆峒区', null, '', '0', '0', '620800');
INSERT INTO `t_s_territory` VALUES ('620821', '', '0', '泾川县', null, '', '0', '0', '620800');
INSERT INTO `t_s_territory` VALUES ('620822', '', '0', '灵台县', null, '', '0', '0', '620800');
INSERT INTO `t_s_territory` VALUES ('620823', '', '0', '崇信县', null, '', '0', '0', '620800');
INSERT INTO `t_s_territory` VALUES ('620824', '', '0', '华亭县', null, '', '0', '0', '620800');
INSERT INTO `t_s_territory` VALUES ('620825', '', '0', '庄浪县', null, '', '0', '0', '620800');
INSERT INTO `t_s_territory` VALUES ('620826', '', '0', '静宁县', null, '', '0', '0', '620800');
INSERT INTO `t_s_territory` VALUES ('620900', '', '0', '酒泉市', null, '', '0', '0', '620000');
INSERT INTO `t_s_territory` VALUES ('620901', '', '0', '市辖区', null, '', '0', '0', '620900');
INSERT INTO `t_s_territory` VALUES ('620902', '', '0', '肃州区', null, '', '0', '0', '620900');
INSERT INTO `t_s_territory` VALUES ('620921', '', '0', '金塔县', null, '', '0', '0', '620900');
INSERT INTO `t_s_territory` VALUES ('620922', '', '0', '瓜州县', null, '', '0', '0', '620900');
INSERT INTO `t_s_territory` VALUES ('620923', '', '0', '肃北蒙古族自治县', null, '', '0', '0', '620900');
INSERT INTO `t_s_territory` VALUES ('620924', '', '0', '阿克塞哈萨克族自治县', null, '', '0', '0', '620900');
INSERT INTO `t_s_territory` VALUES ('620981', '', '0', '玉门市', null, '', '0', '0', '620900');
INSERT INTO `t_s_territory` VALUES ('620982', '', '0', '敦煌市', null, '', '0', '0', '620900');
INSERT INTO `t_s_territory` VALUES ('621000', '', '0', '庆阳市', null, '', '0', '0', '620000');
INSERT INTO `t_s_territory` VALUES ('621001', '', '0', '市辖区', null, '', '0', '0', '621000');
INSERT INTO `t_s_territory` VALUES ('621002', '', '0', '西峰区', null, '', '0', '0', '621000');
INSERT INTO `t_s_territory` VALUES ('621021', '', '0', '庆城县', null, '', '0', '0', '621000');
INSERT INTO `t_s_territory` VALUES ('621022', '', '0', '环县', null, '', '0', '0', '621000');
INSERT INTO `t_s_territory` VALUES ('621023', '', '0', '华池县', null, '', '0', '0', '621000');
INSERT INTO `t_s_territory` VALUES ('621024', '', '0', '合水县', null, '', '0', '0', '621000');
INSERT INTO `t_s_territory` VALUES ('621025', '', '0', '正宁县', null, '', '0', '0', '621000');
INSERT INTO `t_s_territory` VALUES ('621026', '', '0', '宁县', null, '', '0', '0', '621000');
INSERT INTO `t_s_territory` VALUES ('621027', '', '0', '镇原县', null, '', '0', '0', '621000');
INSERT INTO `t_s_territory` VALUES ('621100', '', '0', '定西市', null, '', '0', '0', '620000');
INSERT INTO `t_s_territory` VALUES ('621101', '', '0', '市辖区', null, '', '0', '0', '621100');
INSERT INTO `t_s_territory` VALUES ('621102', '', '0', '安定区', null, '', '0', '0', '621100');
INSERT INTO `t_s_territory` VALUES ('621121', '', '0', '通渭县', null, '', '0', '0', '621100');
INSERT INTO `t_s_territory` VALUES ('621122', '', '0', '陇西县', null, '', '0', '0', '621100');
INSERT INTO `t_s_territory` VALUES ('621123', '', '0', '渭源县', null, '', '0', '0', '621100');
INSERT INTO `t_s_territory` VALUES ('621124', '', '0', '临洮县', null, '', '0', '0', '621100');
INSERT INTO `t_s_territory` VALUES ('621125', '', '0', '漳县', null, '', '0', '0', '621100');
INSERT INTO `t_s_territory` VALUES ('621126', '', '0', '岷县', null, '', '0', '0', '621100');
INSERT INTO `t_s_territory` VALUES ('621200', '', '0', '陇南市', null, '', '0', '0', '620000');
INSERT INTO `t_s_territory` VALUES ('621201', '', '0', '市辖区', null, '', '0', '0', '621200');
INSERT INTO `t_s_territory` VALUES ('621202', '', '0', '武都区', null, '', '0', '0', '621200');
INSERT INTO `t_s_territory` VALUES ('621221', '', '0', '成县', null, '', '0', '0', '621200');
INSERT INTO `t_s_territory` VALUES ('621222', '', '0', '文县', null, '', '0', '0', '621200');
INSERT INTO `t_s_territory` VALUES ('621223', '', '0', '宕昌县', null, '', '0', '0', '621200');
INSERT INTO `t_s_territory` VALUES ('621224', '', '0', '康县', null, '', '0', '0', '621200');
INSERT INTO `t_s_territory` VALUES ('621225', '', '0', '西和县', null, '', '0', '0', '621200');
INSERT INTO `t_s_territory` VALUES ('621226', '', '0', '礼县', null, '', '0', '0', '621200');
INSERT INTO `t_s_territory` VALUES ('621227', '', '0', '徽县', null, '', '0', '0', '621200');
INSERT INTO `t_s_territory` VALUES ('621228', '', '0', '两当县', null, '', '0', '0', '621200');
INSERT INTO `t_s_territory` VALUES ('622900', '', '0', '临夏回族自治州', null, '', '0', '0', '620000');
INSERT INTO `t_s_territory` VALUES ('622901', '', '0', '临夏市', null, '', '0', '0', '622900');
INSERT INTO `t_s_territory` VALUES ('622921', '', '0', '临夏县', null, '', '0', '0', '622900');
INSERT INTO `t_s_territory` VALUES ('622922', '', '0', '康乐县', null, '', '0', '0', '622900');
INSERT INTO `t_s_territory` VALUES ('622923', '', '0', '永靖县', null, '', '0', '0', '622900');
INSERT INTO `t_s_territory` VALUES ('622924', '', '0', '广河县', null, '', '0', '0', '622900');
INSERT INTO `t_s_territory` VALUES ('622925', '', '0', '和政县', null, '', '0', '0', '622900');
INSERT INTO `t_s_territory` VALUES ('622926', '', '0', '东乡族自治县', null, '', '0', '0', '622900');
INSERT INTO `t_s_territory` VALUES ('622927', '', '0', '积石山保安族东乡族撒拉族自治县', null, '', '0', '0', '622900');
INSERT INTO `t_s_territory` VALUES ('623000', '', '0', '甘南藏族自治州', null, '', '0', '0', '620000');
INSERT INTO `t_s_territory` VALUES ('623001', '', '0', '合作市', null, '', '0', '0', '623000');
INSERT INTO `t_s_territory` VALUES ('623021', '', '0', '临潭县', null, '', '0', '0', '623000');
INSERT INTO `t_s_territory` VALUES ('623022', '', '0', '卓尼县', null, '', '0', '0', '623000');
INSERT INTO `t_s_territory` VALUES ('623023', '', '0', '舟曲县', null, '', '0', '0', '623000');
INSERT INTO `t_s_territory` VALUES ('623024', '', '0', '迭部县', null, '', '0', '0', '623000');
INSERT INTO `t_s_territory` VALUES ('623025', '', '0', '玛曲县', null, '', '0', '0', '623000');
INSERT INTO `t_s_territory` VALUES ('623026', '', '0', '碌曲县', null, '', '0', '0', '623000');
INSERT INTO `t_s_territory` VALUES ('623027', '', '0', '夏河县', null, '', '0', '0', '623000');
INSERT INTO `t_s_territory` VALUES ('630000', '', '0', '青海省', null, '', '0', '0', '1');
INSERT INTO `t_s_territory` VALUES ('630100', '', '0', '西宁市', null, '', '0', '0', '630000');
INSERT INTO `t_s_territory` VALUES ('630101', '', '0', '市辖区', null, '', '0', '0', '630100');
INSERT INTO `t_s_territory` VALUES ('630102', '', '0', '城东区', null, '', '0', '0', '630100');
INSERT INTO `t_s_territory` VALUES ('630103', '', '0', '城中区', null, '', '0', '0', '630100');
INSERT INTO `t_s_territory` VALUES ('630104', '', '0', '城西区', null, '', '0', '0', '630100');
INSERT INTO `t_s_territory` VALUES ('630105', '', '0', '城北区', null, '', '0', '0', '630100');
INSERT INTO `t_s_territory` VALUES ('630121', '', '0', '大通回族土族自治县', null, '', '0', '0', '630100');
INSERT INTO `t_s_territory` VALUES ('630122', '', '0', '湟中县', null, '', '0', '0', '630100');
INSERT INTO `t_s_territory` VALUES ('630123', '', '0', '湟源县', null, '', '0', '0', '630100');
INSERT INTO `t_s_territory` VALUES ('630200', '', '0', '海东市', null, '', '0', '0', '630000');
INSERT INTO `t_s_territory` VALUES ('630202', '', '0', '乐都区', null, '', '0', '0', '630200');
INSERT INTO `t_s_territory` VALUES ('630221', '', '0', '平安县', null, '', '0', '0', '630200');
INSERT INTO `t_s_territory` VALUES ('630222', '', '0', '民和回族土族自治县', null, '', '0', '0', '630200');
INSERT INTO `t_s_territory` VALUES ('630223', '', '0', '互助土族自治县', null, '', '0', '0', '630200');
INSERT INTO `t_s_territory` VALUES ('630224', '', '0', '化隆回族自治县', null, '', '0', '0', '630200');
INSERT INTO `t_s_territory` VALUES ('630225', '', '0', '循化撒拉族自治县', null, '', '0', '0', '630200');
INSERT INTO `t_s_territory` VALUES ('632200', '', '0', '海北藏族自治州', null, '', '0', '0', '630000');
INSERT INTO `t_s_territory` VALUES ('632221', '', '0', '门源回族自治县', null, '', '0', '0', '632200');
INSERT INTO `t_s_territory` VALUES ('632222', '', '0', '祁连县', null, '', '0', '0', '632200');
INSERT INTO `t_s_territory` VALUES ('632223', '', '0', '海晏县', null, '', '0', '0', '632200');
INSERT INTO `t_s_territory` VALUES ('632224', '', '0', '刚察县', null, '', '0', '0', '632200');
INSERT INTO `t_s_territory` VALUES ('632300', '', '0', '黄南藏族自治州', null, '', '0', '0', '630000');
INSERT INTO `t_s_territory` VALUES ('632321', '', '0', '同仁县', null, '', '0', '0', '632300');
INSERT INTO `t_s_territory` VALUES ('632322', '', '0', '尖扎县', null, '', '0', '0', '632300');
INSERT INTO `t_s_territory` VALUES ('632323', '', '0', '泽库县', null, '', '0', '0', '632300');
INSERT INTO `t_s_territory` VALUES ('632324', '', '0', '河南蒙古族自治县', null, '', '0', '0', '632300');
INSERT INTO `t_s_territory` VALUES ('632500', '', '0', '海南藏族自治州', null, '', '0', '0', '630000');
INSERT INTO `t_s_territory` VALUES ('632521', '', '0', '共和县', null, '', '0', '0', '632500');
INSERT INTO `t_s_territory` VALUES ('632522', '', '0', '同德县', null, '', '0', '0', '632500');
INSERT INTO `t_s_territory` VALUES ('632523', '', '0', '贵德县', null, '', '0', '0', '632500');
INSERT INTO `t_s_territory` VALUES ('632524', '', '0', '兴海县', null, '', '0', '0', '632500');
INSERT INTO `t_s_territory` VALUES ('632525', '', '0', '贵南县', null, '', '0', '0', '632500');
INSERT INTO `t_s_territory` VALUES ('632600', '', '0', '果洛藏族自治州', null, '', '0', '0', '630000');
INSERT INTO `t_s_territory` VALUES ('632621', '', '0', '玛沁县', null, '', '0', '0', '632600');
INSERT INTO `t_s_territory` VALUES ('632622', '', '0', '班玛县', null, '', '0', '0', '632600');
INSERT INTO `t_s_territory` VALUES ('632623', '', '0', '甘德县', null, '', '0', '0', '632600');
INSERT INTO `t_s_territory` VALUES ('632624', '', '0', '达日县', null, '', '0', '0', '632600');
INSERT INTO `t_s_territory` VALUES ('632625', '', '0', '久治县', null, '', '0', '0', '632600');
INSERT INTO `t_s_territory` VALUES ('632626', '', '0', '玛多县', null, '', '0', '0', '632600');
INSERT INTO `t_s_territory` VALUES ('632700', '', '0', '玉树藏族自治州', null, '', '0', '0', '630000');
INSERT INTO `t_s_territory` VALUES ('632701', '', '0', '玉树市', null, '', '0', '0', '632700');
INSERT INTO `t_s_territory` VALUES ('632722', '', '0', '杂多县', null, '', '0', '0', '632700');
INSERT INTO `t_s_territory` VALUES ('632723', '', '0', '称多县', null, '', '0', '0', '632700');
INSERT INTO `t_s_territory` VALUES ('632724', '', '0', '治多县', null, '', '0', '0', '632700');
INSERT INTO `t_s_territory` VALUES ('632725', '', '0', '囊谦县', null, '', '0', '0', '632700');
INSERT INTO `t_s_territory` VALUES ('632726', '', '0', '曲麻莱县', null, '', '0', '0', '632700');
INSERT INTO `t_s_territory` VALUES ('632800', '', '0', '海西蒙古族藏族自治州', null, '', '0', '0', '630000');
INSERT INTO `t_s_territory` VALUES ('632801', '', '0', '格尔木市', null, '', '0', '0', '632800');
INSERT INTO `t_s_territory` VALUES ('632802', '', '0', '德令哈市', null, '', '0', '0', '632800');
INSERT INTO `t_s_territory` VALUES ('632821', '', '0', '乌兰县', null, '', '0', '0', '632800');
INSERT INTO `t_s_territory` VALUES ('632822', '', '0', '都兰县', null, '', '0', '0', '632800');
INSERT INTO `t_s_territory` VALUES ('632823', '', '0', '天峻县', null, '', '0', '0', '632800');
INSERT INTO `t_s_territory` VALUES ('640000', '', '0', '宁夏回族自治区', null, '', '0', '0', '1');
INSERT INTO `t_s_territory` VALUES ('640100', '', '0', '银川市', null, '', '0', '0', '640000');
INSERT INTO `t_s_territory` VALUES ('640101', '', '0', '市辖区', null, '', '0', '0', '640100');
INSERT INTO `t_s_territory` VALUES ('640104', '', '0', '兴庆区', null, '', '0', '0', '640100');
INSERT INTO `t_s_territory` VALUES ('640105', '', '0', '西夏区', null, '', '0', '0', '640100');
INSERT INTO `t_s_territory` VALUES ('640106', '', '0', '金凤区', null, '', '0', '0', '640100');
INSERT INTO `t_s_territory` VALUES ('640121', '', '0', '永宁县', null, '', '0', '0', '640100');
INSERT INTO `t_s_territory` VALUES ('640122', '', '0', '贺兰县', null, '', '0', '0', '640100');
INSERT INTO `t_s_territory` VALUES ('640181', '', '0', '灵武市', null, '', '0', '0', '640100');
INSERT INTO `t_s_territory` VALUES ('640200', '', '0', '石嘴山市', null, '', '0', '0', '640000');
INSERT INTO `t_s_territory` VALUES ('640201', '', '0', '市辖区', null, '', '0', '0', '640200');
INSERT INTO `t_s_territory` VALUES ('640202', '', '0', '大武口区', null, '', '0', '0', '640200');
INSERT INTO `t_s_territory` VALUES ('640205', '', '0', '惠农区', null, '', '0', '0', '640200');
INSERT INTO `t_s_territory` VALUES ('640221', '', '0', '平罗县', null, '', '0', '0', '640200');
INSERT INTO `t_s_territory` VALUES ('640300', '', '0', '吴忠市', null, '', '0', '0', '640000');
INSERT INTO `t_s_territory` VALUES ('640301', '', '0', '市辖区', null, '', '0', '0', '640300');
INSERT INTO `t_s_territory` VALUES ('640302', '', '0', '利通区', null, '', '0', '0', '640300');
INSERT INTO `t_s_territory` VALUES ('640303', '', '0', '红寺堡区', null, '', '0', '0', '640300');
INSERT INTO `t_s_territory` VALUES ('640323', '', '0', '盐池县', null, '', '0', '0', '640300');
INSERT INTO `t_s_territory` VALUES ('640324', '', '0', '同心县', null, '', '0', '0', '640300');
INSERT INTO `t_s_territory` VALUES ('640381', '', '0', '青铜峡市', null, '', '0', '0', '640300');
INSERT INTO `t_s_territory` VALUES ('640400', '', '0', '固原市', null, '', '0', '0', '640000');
INSERT INTO `t_s_territory` VALUES ('640401', '', '0', '市辖区', null, '', '0', '0', '640400');
INSERT INTO `t_s_territory` VALUES ('640402', '', '0', '原州区', null, '', '0', '0', '640400');
INSERT INTO `t_s_territory` VALUES ('640422', '', '0', '西吉县', null, '', '0', '0', '640400');
INSERT INTO `t_s_territory` VALUES ('640423', '', '0', '隆德县', null, '', '0', '0', '640400');
INSERT INTO `t_s_territory` VALUES ('640424', '', '0', '泾源县', null, '', '0', '0', '640400');
INSERT INTO `t_s_territory` VALUES ('640425', '', '0', '彭阳县', null, '', '0', '0', '640400');
INSERT INTO `t_s_territory` VALUES ('640500', '', '0', '中卫市', null, '', '0', '0', '640000');
INSERT INTO `t_s_territory` VALUES ('640501', '', '0', '市辖区', null, '', '0', '0', '640500');
INSERT INTO `t_s_territory` VALUES ('640502', '', '0', '沙坡头区', null, '', '0', '0', '640500');
INSERT INTO `t_s_territory` VALUES ('640521', '', '0', '中宁县', null, '', '0', '0', '640500');
INSERT INTO `t_s_territory` VALUES ('640522', '', '0', '海原县', null, '', '0', '0', '640500');
INSERT INTO `t_s_territory` VALUES ('650000', '', '0', '新疆维吾尔自治区', null, '', '0', '0', '1');
INSERT INTO `t_s_territory` VALUES ('650100', '', '0', '乌鲁木齐市', null, '', '0', '0', '650000');
INSERT INTO `t_s_territory` VALUES ('650101', '', '0', '市辖区', null, '', '0', '0', '650100');
INSERT INTO `t_s_territory` VALUES ('650102', '', '0', '天山区', null, '', '0', '0', '650100');
INSERT INTO `t_s_territory` VALUES ('650103', '', '0', '沙依巴克区', null, '', '0', '0', '650100');
INSERT INTO `t_s_territory` VALUES ('650104', '', '0', '新市区', null, '', '0', '0', '650100');
INSERT INTO `t_s_territory` VALUES ('650105', '', '0', '水磨沟区', null, '', '0', '0', '650100');
INSERT INTO `t_s_territory` VALUES ('650106', '', '0', '头屯河区', null, '', '0', '0', '650100');
INSERT INTO `t_s_territory` VALUES ('650107', '', '0', '达坂城区', null, '', '0', '0', '650100');
INSERT INTO `t_s_territory` VALUES ('650109', '', '0', '米东区', null, '', '0', '0', '650100');
INSERT INTO `t_s_territory` VALUES ('650121', '', '0', '乌鲁木齐县', null, '', '0', '0', '650100');
INSERT INTO `t_s_territory` VALUES ('650200', '', '0', '克拉玛依市', null, '', '0', '0', '650000');
INSERT INTO `t_s_territory` VALUES ('650201', '', '0', '市辖区', null, '', '0', '0', '650200');
INSERT INTO `t_s_territory` VALUES ('650202', '', '0', '独山子区', null, '', '0', '0', '650200');
INSERT INTO `t_s_territory` VALUES ('650203', '', '0', '克拉玛依区', null, '', '0', '0', '650200');
INSERT INTO `t_s_territory` VALUES ('650204', '', '0', '白碱滩区', null, '', '0', '0', '650200');
INSERT INTO `t_s_territory` VALUES ('650205', '', '0', '乌尔禾区', null, '', '0', '0', '650200');
INSERT INTO `t_s_territory` VALUES ('652100', '', '0', '吐鲁番地区', null, '', '0', '0', '650000');
INSERT INTO `t_s_territory` VALUES ('652101', '', '0', '吐鲁番市', null, '', '0', '0', '652100');
INSERT INTO `t_s_territory` VALUES ('652122', '', '0', '鄯善县', null, '', '0', '0', '652100');
INSERT INTO `t_s_territory` VALUES ('652123', '', '0', '托克逊县', null, '', '0', '0', '652100');
INSERT INTO `t_s_territory` VALUES ('652200', '', '0', '哈密地区', null, '', '0', '0', '650000');
INSERT INTO `t_s_territory` VALUES ('652201', '', '0', '哈密市', null, '', '0', '0', '652200');
INSERT INTO `t_s_territory` VALUES ('652222', '', '0', '巴里坤哈萨克自治县', null, '', '0', '0', '652200');
INSERT INTO `t_s_territory` VALUES ('652223', '', '0', '伊吾县', null, '', '0', '0', '652200');
INSERT INTO `t_s_territory` VALUES ('652300', '', '0', '昌吉回族自治州', null, '', '0', '0', '650000');
INSERT INTO `t_s_territory` VALUES ('652301', '', '0', '昌吉市', null, '', '0', '0', '652300');
INSERT INTO `t_s_territory` VALUES ('652302', '', '0', '阜康市', null, '', '0', '0', '652300');
INSERT INTO `t_s_territory` VALUES ('652323', '', '0', '呼图壁县', null, '', '0', '0', '652300');
INSERT INTO `t_s_territory` VALUES ('652324', '', '0', '玛纳斯县', null, '', '0', '0', '652300');
INSERT INTO `t_s_territory` VALUES ('652325', '', '0', '奇台县', null, '', '0', '0', '652300');
INSERT INTO `t_s_territory` VALUES ('652327', '', '0', '吉木萨尔县', null, '', '0', '0', '652300');
INSERT INTO `t_s_territory` VALUES ('652328', '', '0', '木垒哈萨克自治县', null, '', '0', '0', '652300');
INSERT INTO `t_s_territory` VALUES ('652700', '', '0', '博尔塔拉蒙古自治州', null, '', '0', '0', '650000');
INSERT INTO `t_s_territory` VALUES ('652701', '', '0', '博乐市', null, '', '0', '0', '652700');
INSERT INTO `t_s_territory` VALUES ('652702', '', '0', '阿拉山口市', null, '', '0', '0', '652700');
INSERT INTO `t_s_territory` VALUES ('652722', '', '0', '精河县', null, '', '0', '0', '652700');
INSERT INTO `t_s_territory` VALUES ('652723', '', '0', '温泉县', null, '', '0', '0', '652700');
INSERT INTO `t_s_territory` VALUES ('652800', '', '0', '巴音郭楞蒙古自治州', null, '', '0', '0', '650000');
INSERT INTO `t_s_territory` VALUES ('652801', '', '0', '库尔勒市', null, '', '0', '0', '652800');
INSERT INTO `t_s_territory` VALUES ('652822', '', '0', '轮台县', null, '', '0', '0', '652800');
INSERT INTO `t_s_territory` VALUES ('652823', '', '0', '尉犁县', null, '', '0', '0', '652800');
INSERT INTO `t_s_territory` VALUES ('652824', '', '0', '若羌县', null, '', '0', '0', '652800');
INSERT INTO `t_s_territory` VALUES ('652825', '', '0', '且末县', null, '', '0', '0', '652800');
INSERT INTO `t_s_territory` VALUES ('652826', '', '0', '焉耆回族自治县', null, '', '0', '0', '652800');
INSERT INTO `t_s_territory` VALUES ('652827', '', '0', '和静县', null, '', '0', '0', '652800');
INSERT INTO `t_s_territory` VALUES ('652828', '', '0', '和硕县', null, '', '0', '0', '652800');
INSERT INTO `t_s_territory` VALUES ('652829', '', '0', '博湖县', null, '', '0', '0', '652800');
INSERT INTO `t_s_territory` VALUES ('652900', '', '0', '阿克苏地区', null, '', '0', '0', '650000');
INSERT INTO `t_s_territory` VALUES ('652901', '', '0', '阿克苏市', null, '', '0', '0', '652900');
INSERT INTO `t_s_territory` VALUES ('652922', '', '0', '温宿县', null, '', '0', '0', '652900');
INSERT INTO `t_s_territory` VALUES ('652923', '', '0', '库车县', null, '', '0', '0', '652900');
INSERT INTO `t_s_territory` VALUES ('652924', '', '0', '沙雅县', null, '', '0', '0', '652900');
INSERT INTO `t_s_territory` VALUES ('652925', '', '0', '新和县', null, '', '0', '0', '652900');
INSERT INTO `t_s_territory` VALUES ('652926', '', '0', '拜城县', null, '', '0', '0', '652900');
INSERT INTO `t_s_territory` VALUES ('652927', '', '0', '乌什县', null, '', '0', '0', '652900');
INSERT INTO `t_s_territory` VALUES ('652928', '', '0', '阿瓦提县', null, '', '0', '0', '652900');
INSERT INTO `t_s_territory` VALUES ('652929', '', '0', '柯坪县', null, '', '0', '0', '652900');
INSERT INTO `t_s_territory` VALUES ('653000', '', '0', '克孜勒苏柯尔克孜自治州', null, '', '0', '0', '650000');
INSERT INTO `t_s_territory` VALUES ('653001', '', '0', '阿图什市', null, '', '0', '0', '653000');
INSERT INTO `t_s_territory` VALUES ('653022', '', '0', '阿克陶县', null, '', '0', '0', '653000');
INSERT INTO `t_s_territory` VALUES ('653023', '', '0', '阿合奇县', null, '', '0', '0', '653000');
INSERT INTO `t_s_territory` VALUES ('653024', '', '0', '乌恰县', null, '', '0', '0', '653000');
INSERT INTO `t_s_territory` VALUES ('653100', '', '0', '喀什地区', null, '', '0', '0', '650000');
INSERT INTO `t_s_territory` VALUES ('653101', '', '0', '喀什市', null, '', '0', '0', '653100');
INSERT INTO `t_s_territory` VALUES ('653121', '', '0', '疏附县', null, '', '0', '0', '653100');
INSERT INTO `t_s_territory` VALUES ('653122', '', '0', '疏勒县', null, '', '0', '0', '653100');
INSERT INTO `t_s_territory` VALUES ('653123', '', '0', '英吉沙县', null, '', '0', '0', '653100');
INSERT INTO `t_s_territory` VALUES ('653124', '', '0', '泽普县', null, '', '0', '0', '653100');
INSERT INTO `t_s_territory` VALUES ('653125', '', '0', '莎车县', null, '', '0', '0', '653100');
INSERT INTO `t_s_territory` VALUES ('653126', '', '0', '叶城县', null, '', '0', '0', '653100');
INSERT INTO `t_s_territory` VALUES ('653127', '', '0', '麦盖提县', null, '', '0', '0', '653100');
INSERT INTO `t_s_territory` VALUES ('653128', '', '0', '岳普湖县', null, '', '0', '0', '653100');
INSERT INTO `t_s_territory` VALUES ('653129', '', '0', '伽师县', null, '', '0', '0', '653100');
INSERT INTO `t_s_territory` VALUES ('653130', '', '0', '巴楚县', null, '', '0', '0', '653100');
INSERT INTO `t_s_territory` VALUES ('653131', '', '0', '塔什库尔干塔吉克自治县', null, '', '0', '0', '653100');
INSERT INTO `t_s_territory` VALUES ('653200', '', '0', '和田地区', null, '', '0', '0', '650000');
INSERT INTO `t_s_territory` VALUES ('653201', '', '0', '和田市', null, '', '0', '0', '653200');
INSERT INTO `t_s_territory` VALUES ('653221', '', '0', '和田县', null, '', '0', '0', '653200');
INSERT INTO `t_s_territory` VALUES ('653222', '', '0', '墨玉县', null, '', '0', '0', '653200');
INSERT INTO `t_s_territory` VALUES ('653223', '', '0', '皮山县', null, '', '0', '0', '653200');
INSERT INTO `t_s_territory` VALUES ('653224', '', '0', '洛浦县', null, '', '0', '0', '653200');
INSERT INTO `t_s_territory` VALUES ('653225', '', '0', '策勒县', null, '', '0', '0', '653200');
INSERT INTO `t_s_territory` VALUES ('653226', '', '0', '于田县', null, '', '0', '0', '653200');
INSERT INTO `t_s_territory` VALUES ('653227', '', '0', '民丰县', null, '', '0', '0', '653200');
INSERT INTO `t_s_territory` VALUES ('654000', '', '0', '伊犁哈萨克自治州', null, '', '0', '0', '650000');
INSERT INTO `t_s_territory` VALUES ('654002', '', '0', '伊宁市', null, '', '0', '0', '654000');
INSERT INTO `t_s_territory` VALUES ('654003', '', '0', '奎屯市', null, '', '0', '0', '654000');
INSERT INTO `t_s_territory` VALUES ('654021', '', '0', '伊宁县', null, '', '0', '0', '654000');
INSERT INTO `t_s_territory` VALUES ('654022', '', '0', '察布查尔锡伯自治县', null, '', '0', '0', '654000');
INSERT INTO `t_s_territory` VALUES ('654023', '', '0', '霍城县', null, '', '0', '0', '654000');
INSERT INTO `t_s_territory` VALUES ('654024', '', '0', '巩留县', null, '', '0', '0', '654000');
INSERT INTO `t_s_territory` VALUES ('654025', '', '0', '新源县', null, '', '0', '0', '654000');
INSERT INTO `t_s_territory` VALUES ('654026', '', '0', '昭苏县', null, '', '0', '0', '654000');
INSERT INTO `t_s_territory` VALUES ('654027', '', '0', '特克斯县', null, '', '0', '0', '654000');
INSERT INTO `t_s_territory` VALUES ('654028', '', '0', '尼勒克县', null, '', '0', '0', '654000');
INSERT INTO `t_s_territory` VALUES ('654200', '', '0', '塔城地区', null, '', '0', '0', '650000');
INSERT INTO `t_s_territory` VALUES ('654201', '', '0', '塔城市', null, '', '0', '0', '654200');
INSERT INTO `t_s_territory` VALUES ('654202', '', '0', '乌苏市', null, '', '0', '0', '654200');
INSERT INTO `t_s_territory` VALUES ('654221', '', '0', '额敏县', null, '', '0', '0', '654200');
INSERT INTO `t_s_territory` VALUES ('654223', '', '0', '沙湾县', null, '', '0', '0', '654200');
INSERT INTO `t_s_territory` VALUES ('654224', '', '0', '托里县', null, '', '0', '0', '654200');
INSERT INTO `t_s_territory` VALUES ('654225', '', '0', '裕民县', null, '', '0', '0', '654200');
INSERT INTO `t_s_territory` VALUES ('654226', '', '0', '和布克赛尔蒙古自治县', null, '', '0', '0', '654200');
INSERT INTO `t_s_territory` VALUES ('654300', '', '0', '阿勒泰地区', null, '', '0', '0', '650000');
INSERT INTO `t_s_territory` VALUES ('654301', '', '0', '阿勒泰市', null, '', '0', '0', '654300');
INSERT INTO `t_s_territory` VALUES ('654321', '', '0', '布尔津县', null, '', '0', '0', '654300');
INSERT INTO `t_s_territory` VALUES ('654322', '', '0', '富蕴县', null, '', '0', '0', '654300');
INSERT INTO `t_s_territory` VALUES ('654323', '', '0', '福海县', null, '', '0', '0', '654300');
INSERT INTO `t_s_territory` VALUES ('654324', '', '0', '哈巴河县', null, '', '0', '0', '654300');
INSERT INTO `t_s_territory` VALUES ('654325', '', '0', '青河县', null, '', '0', '0', '654300');
INSERT INTO `t_s_territory` VALUES ('654326', '', '0', '吉木乃县', null, '', '0', '0', '654300');
INSERT INTO `t_s_territory` VALUES ('659000', '', '0', '自治区直辖县级行政区划', null, '', '0', '0', '650000');
INSERT INTO `t_s_territory` VALUES ('659001', '', '0', '石河子市', null, '', '0', '0', '659000');
INSERT INTO `t_s_territory` VALUES ('659002', '', '0', '阿拉尔市', null, '', '0', '0', '659000');
INSERT INTO `t_s_territory` VALUES ('659003', '', '0', '图木舒克市', null, '', '0', '0', '659000');
INSERT INTO `t_s_territory` VALUES ('659004', '', '0', '五家渠市', null, '', '0', '0', '659000');
INSERT INTO `t_s_territory` VALUES ('710000', '', '0', '台湾', null, '', '0', '0', '1');
INSERT INTO `t_s_territory` VALUES ('810000', '', '0', '香港', null, '', '0', '0', '1');
INSERT INTO `t_s_territory` VALUES ('820000', '', '0', '澳门', null, '', '0', '0', '1');
INSERT INTO `t_s_territory` VALUES ('1', '', '0', '中国', null, '', '0', '0', '0');
INSERT INTO `t_s_territory` VALUES ('510109', '', '0', '高新区', null, '', '0', '0', '510100');
INSERT INTO `t_s_territory` VALUES ('710100', '', '1', '台湾', null, '0', '0', '0', '710000');
INSERT INTO `t_s_territory` VALUES ('710101', '', '0', '市区内', null, '', '0', '0', '710100');
INSERT INTO `t_s_territory` VALUES ('810100', '', '1', '香港', null, '0', '0', '0', '810000');
INSERT INTO `t_s_territory` VALUES ('810101', '', '0', '市区内', null, '', '0', '0', '810100');
INSERT INTO `t_s_territory` VALUES ('820100', '', '1', '澳门', null, '0', '0', '0', '820000');
INSERT INTO `t_s_territory` VALUES ('820101', '', '0', '市区内', null, '', '0', '0', '820100');
INSERT INTO `t_s_territory` VALUES ('441901', '', '0', '石碣镇', null, '', '0', '0', '441900');
INSERT INTO `t_s_territory` VALUES ('441902', '', '0', '石龙镇', null, '', '0', '0', '441900');
INSERT INTO `t_s_territory` VALUES ('441903', '', '0', '茶山镇', null, '', '0', '0', '441900');
INSERT INTO `t_s_territory` VALUES ('441904', '', '0', '石排镇', null, '', '0', '0', '441900');
INSERT INTO `t_s_territory` VALUES ('441905', '', '0', '企石镇', null, '', '0', '0', '441900');
INSERT INTO `t_s_territory` VALUES ('441906', '', '0', '横沥镇', null, '', '0', '0', '441900');
INSERT INTO `t_s_territory` VALUES ('441907', '', '0', '桥头镇', null, '', '0', '0', '441900');
INSERT INTO `t_s_territory` VALUES ('441908', '', '0', '谢岗镇', null, '', '0', '0', '441900');
INSERT INTO `t_s_territory` VALUES ('441909', '', '0', '东坑镇', null, '', '0', '0', '441900');
INSERT INTO `t_s_territory` VALUES ('441910', '', '0', '常平镇', null, '', '0', '0', '441900');
INSERT INTO `t_s_territory` VALUES ('441911', '', '0', '寮步镇', null, '', '0', '0', '441900');
INSERT INTO `t_s_territory` VALUES ('441912', '', '0', '樟木头镇', null, '', '0', '0', '441900');
INSERT INTO `t_s_territory` VALUES ('441913', '', '0', '大朗镇', null, '', '0', '0', '441900');
INSERT INTO `t_s_territory` VALUES ('441914', '', '0', '黄江镇', null, '', '0', '0', '441900');
INSERT INTO `t_s_territory` VALUES ('441915', '', '0', '清溪镇', null, '', '0', '0', '441900');
INSERT INTO `t_s_territory` VALUES ('441916', '', '0', '塘厦镇', null, '', '0', '0', '441900');
INSERT INTO `t_s_territory` VALUES ('441917', '', '0', '凤岗镇', null, '', '0', '0', '441900');
INSERT INTO `t_s_territory` VALUES ('441918', '', '0', '大岭山镇', null, '', '0', '0', '441900');
INSERT INTO `t_s_territory` VALUES ('441919', '', '0', '长安镇', null, '', '0', '0', '441900');
INSERT INTO `t_s_territory` VALUES ('441921', '', '0', '虎门镇', null, '', '0', '0', '441900');
INSERT INTO `t_s_territory` VALUES ('441922', '', '0', '厚街镇', null, '', '0', '0', '441900');
INSERT INTO `t_s_territory` VALUES ('441923', '', '0', '沙田镇', null, '', '0', '0', '441900');
INSERT INTO `t_s_territory` VALUES ('441924', '', '0', '道滘镇', null, '', '0', '0', '441900');
INSERT INTO `t_s_territory` VALUES ('441925', '', '0', '洪梅镇', null, '', '0', '0', '441900');
INSERT INTO `t_s_territory` VALUES ('441926', '', '0', '麻涌镇', null, '', '0', '0', '441900');
INSERT INTO `t_s_territory` VALUES ('441927', '', '0', '望牛墩镇', null, '', '0', '0', '441900');
INSERT INTO `t_s_territory` VALUES ('441928', '', '0', '中堂镇', null, '', '0', '0', '441900');
INSERT INTO `t_s_territory` VALUES ('441929', '', '0', '高埗镇', null, '', '0', '0', '441900');
INSERT INTO `t_s_territory` VALUES ('441930', '', '0', '东城街道', null, '', '0', '0', '441900');
INSERT INTO `t_s_territory` VALUES ('441931', '', '0', '南城街道', null, '', '0', '0', '441900');
INSERT INTO `t_s_territory` VALUES ('441932', '', '0', '万江街道', null, '', '0', '0', '441900');
INSERT INTO `t_s_territory` VALUES ('441933', '', '0', '莞城街道', null, '', '0', '0', '441900');
INSERT INTO `t_s_territory` VALUES ('441934', '', '0', '松山湖管委会', null, '', '0', '0', '441900');
INSERT INTO `t_s_territory` VALUES ('441935', '', '0', '虎门港管委会', null, '', '0', '0', '441900');
INSERT INTO `t_s_territory` VALUES ('441936', '', '0', '东莞生态园', null, '', '0', '0', '441900');
INSERT INTO `t_s_territory` VALUES ('442001', '', '0', '石岐区街道', null, '', '0', '0', '442000');
INSERT INTO `t_s_territory` VALUES ('442002', '', '0', '东区街道', null, '', '0', '0', '442000');
INSERT INTO `t_s_territory` VALUES ('442003', '', '0', '火炬开发区街道', null, '', '0', '0', '442000');
INSERT INTO `t_s_territory` VALUES ('442004', '', '0', '西区街道', null, '', '0', '0', '442000');
INSERT INTO `t_s_territory` VALUES ('442005', '', '0', '南区街道', null, '', '0', '0', '442000');
INSERT INTO `t_s_territory` VALUES ('442006', '', '0', '五桂山街道', null, '', '0', '0', '442000');
INSERT INTO `t_s_territory` VALUES ('442007', '', '0', '小榄镇', null, '', '0', '0', '442000');
INSERT INTO `t_s_territory` VALUES ('442008', '', '0', '黄圃镇', null, '', '0', '0', '442000');
INSERT INTO `t_s_territory` VALUES ('442009', '', '0', '民众镇', null, '', '0', '0', '442000');
INSERT INTO `t_s_territory` VALUES ('442010', '', '0', '东凤镇', null, '', '0', '0', '442000');
INSERT INTO `t_s_territory` VALUES ('442011', '', '0', '东升镇', null, '', '0', '0', '442000');
INSERT INTO `t_s_territory` VALUES ('442012', '', '0', '古镇镇', null, '', '0', '0', '442000');
INSERT INTO `t_s_territory` VALUES ('442013', '', '0', '沙溪镇', null, '', '0', '0', '442000');
INSERT INTO `t_s_territory` VALUES ('442014', '', '0', '坦洲镇', null, '', '0', '0', '442000');
INSERT INTO `t_s_territory` VALUES ('442015', '', '0', '港口镇', null, '', '0', '0', '442000');
INSERT INTO `t_s_territory` VALUES ('442016', '', '0', '三角镇', null, '', '0', '0', '442000');
INSERT INTO `t_s_territory` VALUES ('442017', '', '0', '横栏镇', null, '', '0', '0', '442000');
INSERT INTO `t_s_territory` VALUES ('442018', '', '0', '南头镇', null, '', '0', '0', '442000');
INSERT INTO `t_s_territory` VALUES ('442019', '', '0', '阜沙镇', null, '', '0', '0', '442000');
INSERT INTO `t_s_territory` VALUES ('442020', '', '0', '南朗镇', null, '', '0', '0', '442000');
INSERT INTO `t_s_territory` VALUES ('442021', '', '0', '三乡镇', null, '', '0', '0', '442000');
INSERT INTO `t_s_territory` VALUES ('442022', '', '0', '板芙镇', null, '', '0', '0', '442000');
INSERT INTO `t_s_territory` VALUES ('442023', '', '0', '大涌镇', null, '', '0', '0', '442000');
INSERT INTO `t_s_territory` VALUES ('442024', '', '0', '神湾镇', null, '', '0', '0', '442000');
INSERT INTO `t_s_territory` VALUES ('620202', '', '0', '峪泉镇', null, '', '0', '0', '620200');
INSERT INTO `t_s_territory` VALUES ('620203', '', '0', '文殊镇', null, '', '0', '0', '620200');
INSERT INTO `t_s_territory` VALUES ('620204', '', '0', '雄关区', null, '', '0', '0', '620200');
INSERT INTO `t_s_territory` VALUES ('620205', '', '0', '镜铁区', null, '', '0', '0', '620200');
INSERT INTO `t_s_territory` VALUES ('620206', '', '0', '长城区', null, '', '0', '0', '620200');
INSERT INTO `t_s_territory` VALUES ('460321', '', '0', '西沙', null, '', '0', '0', '460300');
INSERT INTO `t_s_territory` VALUES ('460322', '', '0', '南沙', null, '', '0', '0', '460300');
INSERT INTO `t_s_territory` VALUES ('460323', '', '0', '中沙', null, '', '0', '0', '460300');

-- ----------------------------
-- Table structure for t_s_timetask
-- ----------------------------
DROP TABLE IF EXISTS `t_s_timetask`;
CREATE TABLE `t_s_timetask` (
  `ID` varchar(32) NOT NULL,
  `CREATE_BY` varchar(32) DEFAULT NULL,
  `CREATE_DATE` datetime DEFAULT NULL,
  `CREATE_NAME` varchar(32) DEFAULT NULL,
  `CRON_EXPRESSION` varchar(100) NOT NULL,
  `IS_EFFECT` varchar(1) NOT NULL,
  `IS_START` varchar(1) NOT NULL,
  `TASK_DESCRIBE` varchar(50) NOT NULL,
  `TASK_ID` varchar(100) NOT NULL,
  `UPDATE_BY` varchar(32) DEFAULT NULL,
  `UPDATE_DATE` datetime DEFAULT NULL,
  `UPDATE_NAME` varchar(32) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of t_s_timetask
-- ----------------------------
INSERT INTO `t_s_timetask` VALUES ('40280081544c16d601544c173ca40033', null, null, null, '0 0/1 * * * ?', '0', '0', '测试taskDemo', 'taskDemoServiceTaskCronTrigger', null, null, null);

-- ----------------------------
-- Table structure for t_s_type
-- ----------------------------
DROP TABLE IF EXISTS `t_s_type`;
CREATE TABLE `t_s_type` (
  `ID` varchar(32) NOT NULL,
  `typecode` varchar(50) DEFAULT NULL,
  `typename` varchar(50) DEFAULT NULL,
  `typepid` varchar(32) DEFAULT NULL,
  `typegroupid` varchar(32) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `FK_nw2b22gy7plh7pqows186odmq` (`typepid`) USING BTREE,
  KEY `FK_3q40mr4ebtd0cvx79matl39x1` (`typegroupid`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of t_s_type
-- ----------------------------
INSERT INTO `t_s_type` VALUES ('40280081544c16d601544c173c84001d', '2', '菜单图标', null, '40280081544c16d601544c173c690013');
INSERT INTO `t_s_type` VALUES ('40280081544c16d601544c173c87001e', '1', '系统图标', null, '40280081544c16d601544c173c690013');
INSERT INTO `t_s_type` VALUES ('40280081544c16d601544c173c88001f', 'files', '附件', null, '40280081544c16d601544c173c75001b');
INSERT INTO `t_s_type` VALUES ('40280081544c16d601544c173c8a0020', '1', '优质订单', null, '40280081544c16d601544c173c6b0014');
INSERT INTO `t_s_type` VALUES ('40280081544c16d601544c173c8b0021', '2', '普通订单', null, '40280081544c16d601544c173c6b0014');
INSERT INTO `t_s_type` VALUES ('40280081544c16d601544c173c8c0022', '1', '签约客户', null, '40280081544c16d601544c173c6d0015');
INSERT INTO `t_s_type` VALUES ('40280081544c16d601544c173c8e0023', '2', '普通客户', null, '40280081544c16d601544c173c6d0015');
INSERT INTO `t_s_type` VALUES ('40280081544c16d601544c173c8f0024', '1', '特殊服务', null, '40280081544c16d601544c173c6f0016');
INSERT INTO `t_s_type` VALUES ('40280081544c16d601544c173c900025', '2', '普通服务', null, '40280081544c16d601544c173c6f0016');
INSERT INTO `t_s_type` VALUES ('40280081544c16d601544c173c920026', 'single', '单条件查询', null, '40280081544c16d601544c173c710017');
INSERT INTO `t_s_type` VALUES ('40280081544c16d601544c173c930027', 'group', '范围查询', null, '40280081544c16d601544c173c710017');
INSERT INTO `t_s_type` VALUES ('40280081544c16d601544c173c940028', 'Y', '是', null, '40280081544c16d601544c173c720018');
INSERT INTO `t_s_type` VALUES ('40280081544c16d601544c173c960029', 'N', '否', null, '40280081544c16d601544c173c720018');
INSERT INTO `t_s_type` VALUES ('40280081544c16d601544c173c97002a', 'Integer', 'Integer', null, '40280081544c16d601544c173c730019');
INSERT INTO `t_s_type` VALUES ('40280081544c16d601544c173c98002b', 'Date', 'Date', null, '40280081544c16d601544c173c730019');
INSERT INTO `t_s_type` VALUES ('40280081544c16d601544c173c9a002c', 'String', 'String', null, '40280081544c16d601544c173c730019');
INSERT INTO `t_s_type` VALUES ('40280081544c16d601544c173c9b002d', 'Long', 'Long', null, '40280081544c16d601544c173c730019');
INSERT INTO `t_s_type` VALUES ('40280081544c16d601544c173c9d002e', 't_s', '系统基础表', null, '40280081544c16d601544c173c74001a');
INSERT INTO `t_s_type` VALUES ('40280081544c16d601544c173c9e002f', 't_b', '业务表', null, '40280081544c16d601544c173c74001a');
INSERT INTO `t_s_type` VALUES ('40280081544c16d601544c173ca00030', 'news', '新闻', null, '40280081544c16d601544c173c75001b');
INSERT INTO `t_s_type` VALUES ('40280081544c16d601544c173ca10031', '0', '男性', null, '40280081544c16d601544c173c77001c');
INSERT INTO `t_s_type` VALUES ('40280081544c16d601544c173ca30032', '1', '女性', null, '40280081544c16d601544c173c77001c');
INSERT INTO `t_s_type` VALUES ('40280081546714880154674ab0a6001d', 'BLOCKED', '线程阻塞状态', null, '40280081546714880154673b12600001');
INSERT INTO `t_s_type` VALUES ('4028008154671488015467488d110015', 'NORMAL', '正常状态', null, '40280081546714880154673b12600001');
INSERT INTO `t_s_type` VALUES ('40280081546714880154674926fd0017', 'None', '触发器完成且不会执行', null, '40280081546714880154673b12600001');
INSERT INTO `t_s_type` VALUES ('40280081546714880154674985120019', 'PAUSED', '暂停状态', null, '40280081546714880154673b12600001');
INSERT INTO `t_s_type` VALUES ('40280081546714880154674a6b19001b', 'COMPLETE', '触发器完成且还在执行', null, '40280081546714880154673b12600001');
INSERT INTO `t_s_type` VALUES ('40280081546714880154674af2e2001f', 'ERROR', '出现错误', null, '40280081546714880154673b12600001');
INSERT INTO `t_s_type` VALUES ('40280081546714880154674efb540023', 'false', '否', null, '40280081546714880154674ebc110021');
INSERT INTO `t_s_type` VALUES ('40280081546714880154674f13b80025', 'true', '是', null, '40280081546714880154674ebc110021');

-- ----------------------------
-- Table structure for t_s_typegroup
-- ----------------------------
DROP TABLE IF EXISTS `t_s_typegroup`;
CREATE TABLE `t_s_typegroup` (
  `ID` varchar(32) NOT NULL,
  `typegroupcode` varchar(50) DEFAULT NULL,
  `typegroupname` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of t_s_typegroup
-- ----------------------------
INSERT INTO `t_s_typegroup` VALUES ('40280081544c16d601544c173c690013', 'icontype', '图标类型');
INSERT INTO `t_s_typegroup` VALUES ('40280081544c16d601544c173c6b0014', 'order', '订单类型');
INSERT INTO `t_s_typegroup` VALUES ('40280081544c16d601544c173c6d0015', 'custom', '客户类型');
INSERT INTO `t_s_typegroup` VALUES ('40280081544c16d601544c173c6f0016', 'service', '服务项目类型');
INSERT INTO `t_s_typegroup` VALUES ('40280081544c16d601544c173c710017', 'searchmode', '查询模式');
INSERT INTO `t_s_typegroup` VALUES ('40280081544c16d601544c173c720018', 'yesorno', '逻辑条件');
INSERT INTO `t_s_typegroup` VALUES ('40280081544c16d601544c173c730019', 'fieldtype', '字段类型');
INSERT INTO `t_s_typegroup` VALUES ('40280081544c16d601544c173c74001a', 'database', '数据表');
INSERT INTO `t_s_typegroup` VALUES ('40280081544c16d601544c173c75001b', 'fieltype', '文档分类');
INSERT INTO `t_s_typegroup` VALUES ('40280081544c16d601544c173c77001c', 'sex', '性别类');
INSERT INTO `t_s_typegroup` VALUES ('40280081546714880154673b12600001', 'jobstatus', '任务状态');
INSERT INTO `t_s_typegroup` VALUES ('40280081546714880154674ebc110021', 'jobissync', '任务是否异步');

-- ----------------------------
-- Table structure for t_s_uploadfile
-- ----------------------------
DROP TABLE IF EXISTS `t_s_uploadfile`;
CREATE TABLE `t_s_uploadfile` (
  `ID` varchar(32) NOT NULL,
  `content` longblob,
  `createdate` datetime DEFAULT NULL,
  `extend` varchar(32) DEFAULT NULL,
  `name` varchar(100) DEFAULT NULL,
  `path` varchar(100) DEFAULT NULL,
  `session_key` varchar(32) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of t_s_uploadfile
-- ----------------------------

-- ----------------------------
-- Table structure for t_s_user
-- ----------------------------
DROP TABLE IF EXISTS `t_s_user`;
CREATE TABLE `t_s_user` (
  `email` varchar(50) DEFAULT NULL,
  `mobilePhone` varchar(30) DEFAULT NULL,
  `officePhone` varchar(20) DEFAULT NULL,
  `signatureFile` varchar(100) DEFAULT NULL,
  `id` varchar(32) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_2cuji5h6yorrxgsr8ojndlmal` (`id`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of t_s_user
-- ----------------------------
INSERT INTO `t_s_user` VALUES ('guanxf_m@126.com', null, null, null, '40280081544c16d601544c173c5a000e');
INSERT INTO `t_s_user` VALUES (null, null, null, 'images/renfang/qm/licf.gif', '40280081544c16d601544c173c50000c');

-- ----------------------------
-- Table structure for t_s_user_org
-- ----------------------------
DROP TABLE IF EXISTS `t_s_user_org`;
CREATE TABLE `t_s_user_org` (
  `ID` varchar(32) NOT NULL,
  `org_id` varchar(32) DEFAULT NULL,
  `user_id` varchar(32) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `FK_6nk8dcyprl1l0j24b5eaorset` (`org_id`) USING BTREE,
  KEY `FK_2c2l9iyw7hc52h9so7dxyi0vh` (`user_id`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of t_s_user_org
-- ----------------------------
INSERT INTO `t_s_user_org` VALUES ('2c90843852877a3d0152877e2621000d', '2c90843852877a3d0152877e25d30009', '2c90843852877a3d0152877e261d000c');
INSERT INTO `t_s_user_org` VALUES ('2c90843852877a3d0152877e2626000f', '2c90843852877a3d0152877e25d30009', '2c90843852877a3d0152877e2624000e');
INSERT INTO `t_s_user_org` VALUES ('2c90843852877fa40152877fd68a000d', '2c90843852877fa40152877fd6780009', '2c90843852877fa40152877fd683000c');
INSERT INTO `t_s_user_org` VALUES ('2c90843852877fa40152877fd690000f', '2c90843852877fa40152877fd6780009', '2c90843852877fa40152877fd68d000e');
INSERT INTO `t_s_user_org` VALUES ('402800815442f20f015442f78c8d000d', '402800815442f20f015442f78c7c0009', '402800815442f20f015442f78c86000c');
INSERT INTO `t_s_user_org` VALUES ('402800815442f20f015442f78c92000f', '402800815442f20f015442f78c7c0009', '402800815442f20f015442f78c8f000e');
INSERT INTO `t_s_user_org` VALUES ('402800815442f20f01544303588a0090', '402800815442f20f015443035881008c', '402800815442f20f015443035888008f');
INSERT INTO `t_s_user_org` VALUES ('402800815442f20f01544303588d0092', '402800815442f20f015443035881008c', '402800815442f20f01544303588b0091');
INSERT INTO `t_s_user_org` VALUES ('402800815442f20f015443039b1f0112', '402800815442f20f015443039b15010e', '402800815442f20f015443039b1c0111');
INSERT INTO `t_s_user_org` VALUES ('402800815442f20f015443039b240114', '402800815442f20f015443039b15010e', '402800815442f20f015443039b210113');
INSERT INTO `t_s_user_org` VALUES ('4028008154464e1b0154464e7979000d', '4028008154464e1b0154464e79640009', '4028008154464e1b0154464e7973000c');
INSERT INTO `t_s_user_org` VALUES ('4028008154464e1b0154464e797e000f', '4028008154464e1b0154464e79640009', '4028008154464e1b0154464e797c000e');
INSERT INTO `t_s_user_org` VALUES ('4028008154464e1b01544652256f008f', '4028008154464e1b015446522563008b', '4028008154464e1b01544652256c008e');
INSERT INTO `t_s_user_org` VALUES ('4028008154464e1b0154465225730091', '4028008154464e1b015446522563008b', '4028008154464e1b0154465225710090');
INSERT INTO `t_s_user_org` VALUES ('4028008154464e1b0154465346a40111', '4028008154464e1b015446534698010d', '4028008154464e1b0154465346a10110');
INSERT INTO `t_s_user_org` VALUES ('4028008154464e1b0154465346a80113', '4028008154464e1b015446534698010d', '4028008154464e1b0154465346a50112');
INSERT INTO `t_s_user_org` VALUES ('40280081544690030154469074ee000d', '40280081544690030154469074dd0009', '40280081544690030154469074e9000c');
INSERT INTO `t_s_user_org` VALUES ('40280081544690030154469074f3000f', '40280081544690030154469074dd0009', '40280081544690030154469074f1000e');
INSERT INTO `t_s_user_org` VALUES ('40280081544690030154469afd4a008f', '40280081544690030154469afd2f008b', '40280081544690030154469afd45008e');
INSERT INTO `t_s_user_org` VALUES ('40280081544690030154469afd540091', '40280081544690030154469afd2f008b', '40280081544690030154469afd4f0090');
INSERT INTO `t_s_user_org` VALUES ('40280081544690030154469cbd720111', '40280081544690030154469cbd56010d', '40280081544690030154469cbd6a0110');
INSERT INTO `t_s_user_org` VALUES ('40280081544690030154469cbd7c0113', '40280081544690030154469cbd56010d', '40280081544690030154469cbd770112');
INSERT INTO `t_s_user_org` VALUES ('40280081544690030154469d8df70193', '40280081544690030154469d8de3018f', '40280081544690030154469d8def0192');
INSERT INTO `t_s_user_org` VALUES ('40280081544690030154469d8e0e0195', '40280081544690030154469d8de3018f', '40280081544690030154469d8dfa0194');
INSERT INTO `t_s_user_org` VALUES ('40280081544690030154469ed73f0215', '40280081544690030154469ed7250211', '40280081544690030154469ed7380214');
INSERT INTO `t_s_user_org` VALUES ('40280081544690030154469ed7480217', '40280081544690030154469ed7250211', '40280081544690030154469ed7440216');
INSERT INTO `t_s_user_org` VALUES ('4028008154469003015446a066070297', '4028008154469003015446a065e70293', '4028008154469003015446a066010296');
INSERT INTO `t_s_user_org` VALUES ('4028008154469003015446a0660f0299', '4028008154469003015446a065e70293', '4028008154469003015446a0660a0298');
INSERT INTO `t_s_user_org` VALUES ('40280081544690030154470ecdf20319', '40280081544690030154470ecdd80315', '40280081544690030154470ecdec0318');
INSERT INTO `t_s_user_org` VALUES ('40280081544690030154470ecdfa031b', '40280081544690030154470ecdd80315', '40280081544690030154470ecdf5031a');
INSERT INTO `t_s_user_org` VALUES ('402800815446900301544710b019039b', '402800815446900301544710b0070397', '402800815446900301544710b014039a');
INSERT INTO `t_s_user_org` VALUES ('402800815446900301544710b021039d', '402800815446900301544710b0070397', '402800815446900301544710b01c039c');
INSERT INTO `t_s_user_org` VALUES ('402800815446900301544710dfd1041d', '402800815446900301544710dfc40419', '402800815446900301544710dfcd041c');
INSERT INTO `t_s_user_org` VALUES ('402800815446900301544710dfd8041f', '402800815446900301544710dfc40419', '402800815446900301544710dfd4041e');
INSERT INTO `t_s_user_org` VALUES ('40280081544711be015447135c6f000d', '40280081544711be015447135c580009', '40280081544711be015447135c66000c');
INSERT INTO `t_s_user_org` VALUES ('40280081544711be015447135c77000f', '40280081544711be015447135c580009', '40280081544711be015447135c74000e');
INSERT INTO `t_s_user_org` VALUES ('40280081544711be015447195e16008f', '40280081544711be015447195e01008b', '40280081544711be015447195e10008e');
INSERT INTO `t_s_user_org` VALUES ('40280081544711be015447195e1f0091', '40280081544711be015447195e01008b', '40280081544711be015447195e190090');
INSERT INTO `t_s_user_org` VALUES ('4028008154471a3a0154471a9990000d', '4028008154471a3a0154471a997d0009', '4028008154471a3a0154471a9988000c');
INSERT INTO `t_s_user_org` VALUES ('4028008154471a3a0154471a9995000f', '4028008154471a3a0154471a997d0009', '4028008154471a3a0154471a9992000e');
INSERT INTO `t_s_user_org` VALUES ('402800815447214f01544721af49000d', '402800815447214f01544721af310009', '402800815447214f01544721af3f000c');
INSERT INTO `t_s_user_org` VALUES ('402800815447214f01544721af50000f', '402800815447214f01544721af310009', '402800815447214f01544721af4e000e');
INSERT INTO `t_s_user_org` VALUES ('402800815447279a01544727faf9000d', '402800815447279a01544727fae80009', '402800815447279a01544727faf2000c');
INSERT INTO `t_s_user_org` VALUES ('402800815447279a01544727fafd000f', '402800815447279a01544727fae80009', '402800815447279a01544727fafb000e');
INSERT INTO `t_s_user_org` VALUES ('4028008154473497015447353770000d', '402800815447349701544735375f0009', '4028008154473497015447353769000c');
INSERT INTO `t_s_user_org` VALUES ('4028008154473497015447353775000f', '402800815447349701544735375f0009', '4028008154473497015447353772000e');
INSERT INTO `t_s_user_org` VALUES ('40280081544738ac01544739142d000d', '40280081544738ac01544739141b0009', '40280081544738ac015447391425000c');
INSERT INTO `t_s_user_org` VALUES ('40280081544738ac015447391433000f', '40280081544738ac01544739141b0009', '40280081544738ac015447391430000e');
INSERT INTO `t_s_user_org` VALUES ('40280081544c16d601544c173c58000d', '40280081544c16d601544c173c440009', '40280081544c16d601544c173c50000c');
INSERT INTO `t_s_user_org` VALUES ('40280081544c16d601544c173c5c000f', '40280081544c16d601544c173c440009', '40280081544c16d601544c173c5a000e');

-- ----------------------------
-- Table structure for t_s_version
-- ----------------------------
DROP TABLE IF EXISTS `t_s_version`;
CREATE TABLE `t_s_version` (
  `ID` varchar(32) NOT NULL,
  `loginpage` varchar(100) DEFAULT NULL,
  `versioncode` varchar(50) DEFAULT NULL,
  `versionname` varchar(30) DEFAULT NULL,
  `versionnum` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of t_s_version
-- ----------------------------
